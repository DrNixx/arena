import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, cv as allLocales, cw as getDefaultLocaleForLang, m as h, p as ontapY, cx as allKeys, cy as getCurrentLocale, E as getLI, cz as setServerLang, cA as loadLanguage, r as redraw } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

var lang = {
    oncreate: viewSlideIn,
    oninit() {
        this.browserLangs = navigator.languages.reduce((langSet, l) => {
            if (allLocales[l] !== undefined)
                return new Set([...langSet, l]);
            else {
                const localeForLang = getDefaultLocaleForLang(l);
                if (localeForLang)
                    return new Set([...langSet, localeForLang]);
            }
            return langSet;
        }, new Set());
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('language')));
        const currentLang = getCurrentLocale();
        function renderLocale(l) {
            const name = allLocales[l];
            const selected = l === currentLang;
            return (h("li", { className: 'list_item' + (selected ? ' selected' : ''), "data-locale": l },
                name,
                selected ?
                    h("span", { className: "fa fa-check" }) : null));
        }
        const onTap = (e) => {
            const el = getLI(e);
            const locale = el && el.dataset.locale;
            if (locale) {
                setServerLang(locale);
                loadLanguage(locale).then(redraw);
            }
        };
        const renderBody = () => {
            return (h("ul", { className: "native_scroller page settings_list", oncreate: ontapY(onTap, undefined, getLI) }, [...this.browserLangs].concat(allKeys).map(l => renderLocale(l))));
        };
        return layout.free(header, renderBody());
    }
};

export { lang as default };
//# sourceMappingURL=lang-CO0ObPms.js.map
