import { f as fetchJSON, d as debounce, r as redraw, i as isForeground, s as socket, l as lobby, a as signals, b as session, n as noop, t as timeline, c as fromNow, Z as Zanimo, e as seeks, g as settings, h as throttle, j as featured, k as hasNetwork, N as Network, A as App, m as h, o as i18n, p as ontapY, q as router, u as distanceToNowStrict, v as renderQuickSetup, w as spinner, x as ontap, y as plural, z as gameIcon, B as formatNumber, C as newGameForm, D as challengeForm, E as getLI, F as viewFadeIn, G as dropShadowHeader, H as safeStringToNum } from './main.js';
import { p as playMachineForm, l as layout } from './layout-DoxuEk9x.js';
import { supportedTypes, renderTimelineEntry, timelineOnTap } from './timeline-BwuTr8-b.js';
import { l as loadNewPuzzle, d as db } from './offlineService-COoOyrIU.js';
import { o as openExternalBrowser } from './userView-BRulENS5.js';
import { e as emptyFen } from './fen-97CPMMDI.js';
import { M as MiniBoard } from './miniBoard-_GdiTw1G.js';
import { T as TabNavigation, a as TabView } from './TabView-CG79fzxt.js';
import { r as renderTournamentList } from './tournamentsListView-Csa0M4-v.js';
import './html-EBv26hf5.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './userXhr-i6lHGN-w.js';
import './CountdownTimer-sy6et_C9.js';
import './tournamentXhr-kOGDWEN6.js';

function featuredStreamers() {
    return fetchJSON('/api/streamer/featured', undefined);
}
function dailyPuzzle() {
    return fetchJSON('/training/daily', undefined);
}
function featuredTournaments() {
    return fetchJSON('/tournament/featured', undefined);
}

class HomeCtrl {
    constructor(defaultTab) {
        this.isScrolling = false;
        // workaround for scroll overflow issue on ios
        this.afterScroll = debounce(() => {
            this.isScrolling = false;
            redraw();
        }, 200);
        this.onScroll = () => {
            this.isScrolling = true;
            this.afterScroll();
        };
        this.redrawIfNotScrolling = () => {
            if (!this.isScrolling)
                redraw();
        };
        this.socketSend = (t, d) => {
            if (this.socket)
                this.socket.send(t, d);
        };
        this.unload = () => {
            this.networkListener.then((v) => v.remove());
            this.appStateListener.then((v) => v.remove());
        };
        this.init = () => {
            if (isForeground()) {
                this.socket = socket.createLobby('homeLobby', () => {
                    this.reloadCorresPool();
                    this.getFeatured();
                }, {
                    redirect: socket.redirectToGame,
                    reload_seeks: this.reloadCorresPool,
                    resync: () => lobby().then(d => {
                        socket.setVersion(d.lobby.version);
                    }),
                    n: (_, d) => {
                        signals.homePong.dispatch(d);
                    },
                    featured: () => {
                        this.getFeatured();
                    },
                    fen: (d) => {
                        if (this.featuredGame && this.featuredGame.id === d.id) {
                            this.featuredGame.fen = d.fen;
                            this.featuredGame.lastMove = d.lm;
                            this.featuredGame.c = {
                                black: d.bc,
                                white: d.wc,
                            };
                            redraw();
                        }
                    },
                    finish: (d) => {
                        if (this.featuredGame && this.featuredGame.id === d.id) {
                            this.featuredGame.finished = true;
                            if (d.win === 'b')
                                this.featuredGame.winner = 'black';
                            else if (d.win === 'w')
                                this.featuredGame.winner = 'white';
                            redraw();
                        }
                    },
                });
                Promise.all([
                    featuredTournaments(),
                    session.refresh().then(() => session.isKidMode() ? Promise.resolve([]) : featuredStreamers()),
                ])
                    .then(results => {
                    const [fTour, fStreamers] = results;
                    this.featuredTournaments = fTour.featured;
                    this.featuredStreamers = fStreamers;
                    redraw();
                })
                    .catch(noop);
                dailyPuzzle()
                    .then(daily => {
                    this.dailyPuzzle = daily;
                    redraw();
                });
                timeline()
                    .then((timeline) => {
                    this.timelineData = {
                        users: timeline.users,
                        entries: timeline.entries
                            .filter((o) => supportedTypes.indexOf(o.type) !== -1)
                            .slice(0, 15)
                            .map(o => {
                            o.fromNow = fromNow(new Date(o.date));
                            return o;
                        })
                    };
                    redraw();
                })
                    .catch(() => {
                    this.timelineData = { entries: [], users: {} };
                });
            }
        };
        this.loadOfflinePuzzle = () => {
            const user = session.get();
            if (user) {
                loadNewPuzzle(db, user)
                    .then(data => {
                    this.offlinePuzzle = data;
                    redraw();
                });
            }
        };
        this.onTabChange = (i) => {
            const loc = window.location.search.replace(/\?tab=\w+$/, '');
            try {
                window.history.replaceState(window.history.state, '', loc + '?tab=' + i);
            }
            catch (e) {
                console.error(e);
            }
            this.selectedTab = i;
            if (this.selectedTab === 1) {
                this.reloadCorresPool();
            }
            redraw();
        };
        this.cancelCorresSeek = (seekId) => {
            const el = document.getElementById(seekId);
            if (el) {
                Zanimo(el, 'opacity', '0', 300, 'ease-out')
                    .then(() => this.socketSend('cancelSeek', seekId))
                    .catch(console.log.bind(console));
            }
        };
        this.joinCorresSeek = (seekId) => {
            this.socketSend('joinSeek', seekId);
        };
        this.reloadCorresPool = () => {
            if (this.selectedTab === 1) {
                seeks(false)
                    .then(d => {
                    this.corresPool = fixSeeks(d)
                        .filter(s => settings.game.supportedVariants.includes(s.variant.key))
                        .sort((a, b) => a.rating > b.rating ? -1 : 1);
                    this.redrawIfNotScrolling();
                });
            }
        };
        this.getFeatured = throttle(() => {
            featured('best', false)
                .then((data) => {
                const opp = playerToFeatured(data.opponent);
                const player = playerToFeatured(data.player);
                this.featuredGame = {
                    c: data.clock ? {
                        white: Math.round(data.clock.white),
                        black: Math.round(data.clock.black),
                    } : undefined,
                    black: data.game.player === 'white' ? opp : player,
                    orientation: data.orientation,
                    fen: data.game.fen,
                    id: data.game.id,
                    lastMove: data.game.lastMove,
                    white: data.game.player === 'white' ? player : opp,
                };
                this.socketSend('startWatching', data.game.id);
                this.redrawIfNotScrolling();
            });
        }, 1000);
        this.corresPool = [];
        this.selectedTab = defaultTab || 0;
        if (hasNetwork()) {
            this.init();
        }
        else {
            this.loadOfflinePuzzle();
        }
        this.networkListener = Network.addListener('networkStatusChange', s => {
            if (s.connected)
                this.init();
        });
        this.appStateListener = App.addListener('appStateChange', (state) => {
            if (state.isActive)
                this.init();
        });
    }
}
function seekUserId(seek) {
    return seek.username.toLowerCase();
}
function fixSeeks(seeks) {
    const userId = session.getUserId();
    if (userId)
        seeks.sort((a, b) => {
            if (seekUserId(a) === userId)
                return -1;
            if (seekUserId(b) === userId)
                return 1;
            return 0;
        });
    return [
        ...seeks
            .map(s => {
            const username = seekUserId(s) === userId ? s.id : s.username;
            const key = username + s.mode + s.perf.key + s.days + s.color;
            return [s, key];
        })
            .filter(([_, key], i, a) => a.map(e => e[1]).indexOf(key) === i)
            .map(([s]) => s)
    ];
}
function playerToFeatured(p) {
    return {
        name: p.name || p.username || p.user && p.user.username || '',
        rating: p.rating || 0,
        ratingDiff: p.ratingDiff || 0,
        berserk: p.berserk,
        title: p.user && p.user.title,
    };
}

function body(ctrl) {
    if (hasNetwork())
        return online(ctrl);
    else
        return offline(ctrl);
}
function offline(ctrl) {
    const puzzleData = ctrl.offlinePuzzle;
    const boardConf = puzzleData ? {
        fixed: true,
        fen: puzzleData.puzzle.fen,
        orientation: puzzleData.puzzle.color,
        link: () => router.set('/training'),
    } : null;
    return (h("div", { className: 'homeOfflineWrapper' + (boardConf ? ' withBoard' : '') },
        h("div", { className: "home homeOffline" },
            h("section", { className: "playOffline" },
                h("h2", null, i18n('playOffline')),
                h("button", { className: "fatButton", oncreate: ontapY(() => router.set('/ai')) }, i18n('computer')),
                h("button", { className: "fatButton", oncreate: ontapY(() => router.set('/otb')) }, i18n('overTheBoard'))),
            boardConf ?
                h("section", { className: "home__miniPuzzle" },
                    h("h2", { className: "homeTitle" }, i18n('puzzles')),
                    h(MiniBoard, boardConf)) : undefined)));
}
function online(ctrl) {
    const playban = session.get()?.playban;
    const playbanEndsAt = playban && new Date(playban.date + playban.mins * 60000);
    return (h("div", { className: "home" },
        playbanEndsAt && ((playbanEndsAt.valueOf() - Date.now()) / 1000) > 1 ?
            renderPlayban(playbanEndsAt) : renderLobby(ctrl),
        renderStart(ctrl),
        h("div", { className: "home__side" },
            renderFeaturedStreamers(ctrl),
            renderFeaturedTournaments(ctrl),
            renderTimeline(ctrl)),
        renderFeaturedGame(ctrl),
        renderDailyPuzzle(ctrl)));
}
function renderStart(ctrl) {
    return (h("div", { className: "home__start" },
        h("div", { className: "home__buttons" },
            h("button", { className: "buttonMetal", oncreate: ontapY(() => newGameForm.openRealTime('custom')) }, i18n('createAGame')),
            h("button", { className: "buttonMetal", oncreate: ontapY(() => challengeForm.open()) }, i18n('playWithAFriend')),
            h("button", { className: "buttonMetal", oncreate: ontapY(playMachineForm.open) }, i18n('playWithTheMachine'))),
        h(Stats, { ctrl })));
}
const Stats = {
    oncreate({ attrs }) {
        const nbRoundSpread = spreadNumber(attrs.ctrl, '#nb_games_in_play > strong', 8, socket.getCurrentPingInterval);
        const nbUserSpread = spreadNumber(attrs.ctrl, '#nb_connected_players > strong', 10, socket.getCurrentPingInterval);
        this.render = (pong) => {
            nbUserSpread(pong.d);
            setTimeout(() => {
                nbRoundSpread(pong.r);
            }, socket.getCurrentPingInterval() / 2);
        };
        signals.homePong.add(this.render);
    },
    onremove() {
        signals.homePong.remove(this.render);
    },
    view() {
        return h('div.home__stats', [
            h('div#nb_connected_players', h.trust(i18n('nbPlayers:other', '<strong>?</strong>'))),
            h('div#nb_games_in_play', h.trust(i18n('nbGames:other', '<strong>?</strong>'))),
        ]);
    }
};
function spreadNumber(ctrl, selector, nbSteps, getDuration) {
    let previous;
    let displayed;
    function display(el, prev, cur, it) {
        const val = formatNumber(Math.round(((prev * (nbSteps - 1 - it)) + (cur * (it + 1))) / nbSteps));
        if (el && val !== displayed) {
            if (!ctrl.isScrolling) {
                el.textContent = val;
                displayed = val;
            }
        }
    }
    let timeouts = [];
    return function (nb, overrideNbSteps) {
        const el = document.querySelector(selector);
        if (!el || (!nb && nb !== 0))
            return;
        if (overrideNbSteps)
            nbSteps = Math.abs(overrideNbSteps);
        timeouts.forEach(clearTimeout);
        timeouts = [];
        const prev = previous === 0 ? 0 : (previous || nb);
        previous = nb;
        const interv = Math.abs(getDuration() / nbSteps);
        for (let i = 0; i < nbSteps; i++) {
            timeouts.push(setTimeout(() => display(el, prev, nb, i), Math.round(i * interv)));
        }
    };
}
function renderLobby(ctrl) {
    const tabsContent = [
        { id: 'quick', f: () => renderQuickSetup(() => newGameForm.openRealTime('custom')) },
        { id: 'corres', f: () => renderCorresPool(ctrl) },
    ];
    return h('div.home__lobby', [
        h(TabNavigation, {
            buttons: [
                {
                    label: i18n('quickPairing')
                },
                {
                    label: i18n('correspondence')
                }
            ],
            selectedIndex: ctrl.selectedTab,
            onTabChange: ctrl.onTabChange,
            wrapperClass: 'homeSetup',
            withBottomBorder: true,
        }),
        h(TabView, {
            selectedIndex: ctrl.selectedTab,
            tabs: tabsContent,
            onTabChange: ctrl.onTabChange,
            className: 'home__setupTabView',
        }),
    ]);
}
function renderCorresPool(ctrl) {
    return h('div.corresPoolWrapper.native_scroller', [
        h('table.corres_seeks', [
            h('thead', [
                h('tr', [
                    h('th', ''),
                    h('th', i18n('player')),
                    h('th', i18n('rating')),
                    h('th', i18n('time')),
                    h('th', i18n('mode')),
                ]),
            ]),
            h('tbody', ctrl.corresPool.map(s => renderSeek(ctrl, s)))
        ]),
        h('div.corres_create', [
            h('button.defaultButton', {
                oncreate: ontap(newGameForm.openCorrespondence)
            }, i18n('createAGame')),
        ]),
    ]);
}
function renderSeek(ctrl, seek) {
    const action = seek.username.toLowerCase() === session.getUserId() ?
        'cancelCorresSeek' :
        'joinCorresSeek';
    const icon = seek.color === '' ? 'random' :
        seek.color === 'white' ? 'white' : 'black';
    return h('tr', {
        key: 'seek' + seek.id,
        'id': seek.id,
        className: 'corres_seek ' + action,
        oncreate: ontapY(() => ctrl[action](seek.id))
    }, [
        h('td', h('span.color-icon.' + icon)),
        h('td', seek.username),
        h('td', seek.rating + (seek.provisional ? '?' : '')),
        h('td', seek.days ? plural('nbDays', seek.days) : '∞'),
        h('td', h('span.withIcon', {
            'data-icon': gameIcon(seek.perf.key)
        }, i18n(seek.mode === 1 ? 'rated' : 'casual'))),
    ]);
}
function renderFeaturedTournaments(ctrl) {
    if (ctrl.featuredTournaments?.length)
        return (h("div", { className: "home__tournament" }, renderTournamentList(ctrl.featuredTournaments)));
    else
        return null;
}
function renderFeaturedStreamers(ctrl) {
    if (ctrl.featuredStreamers?.length)
        return h('ul.home__streamers', ctrl.featuredStreamers.map(s => h('li.home__streamer', {
            oncreate: ontapY(() => openExternalBrowser(s.url)),
        }, [
            h('strong[data-icon=]', (s.user.title ? s.user.title + ' ' : '') + s.user.name),
            h('span.status', ' ' + s.status),
        ])));
    else
        return null;
}
function renderFeaturedGame(ctrl) {
    const featured = ctrl.featuredGame;
    const boardConf = featured ? {
        fixed: false,
        fen: featured.fen,
        orientation: featured.orientation,
        lastMove: featured.lastMove,
        link: () => {
            settings.tv.channel('best');
            router.set('/tv');
        },
        gameObj: featured,
    } : {
        fixed: false,
        orientation: 'white',
        fen: emptyFen,
    };
    return (h("section", { className: "home__featured" }, h(MiniBoard, boardConf)));
}
function renderDailyPuzzle(ctrl) {
    const daily = ctrl.dailyPuzzle;
    const boardConf = daily && daily.puzzle && daily.game && daily.game.treeParts ? {
        fixed: true,
        fen: daily.game.treeParts.fen,
        lastMove: daily.game.treeParts.uci,
        orientation: daily.puzzle.color,
        link: () => router.set(`/training/${daily.puzzle.id}?initFen=${daily.puzzle.fen}&initColor=${daily.puzzle.color}`),
        topText: i18n('puzzleOfTheDay'),
        bottomText: daily.puzzle.color === 'white' ? i18n('whitePlays') : i18n('blackPlays'),
    } : {
        fixed: true,
        orientation: 'white',
        fen: emptyFen,
    };
    return (h("section", { className: "home__miniPuzzle" }, h(MiniBoard, boardConf)));
}
function renderTimeline(ctrl) {
    const timelineData = ctrl.timelineData;
    if (timelineData === undefined) {
        return (h("section", { className: "home__timeline loading" }, spinner.getVdom('monochrome')));
    }
    if (timelineData.entries.length === 0) {
        return (h("section", { className: "home__timeline" }));
    }
    return (h("section", { className: "home__timeline" },
        h("ul", { oncreate: ontapY(timelineOnTap, undefined, getLI) }, timelineData.entries.map(entry => renderTimelineEntry(entry, timelineData.users))),
        h("div", { className: "more" },
            h("button", { oncreate: ontapY(() => router.set('/timeline')) },
                i18n('more'),
                " \u00BB"))));
}
function renderPlayban(endsAt) {
    return (h("div", { className: "home-playbanInfo" },
        h("h2", null, i18n('sorry')),
        h("p", null, i18n('weHadToTimeYouOutForAWhile')),
        h("br", null),
        h("p", null, h.trust(i18n('timeoutExpires', `<strong>${distanceToNowStrict(endsAt)}</strong>`))),
        h("h2", null, i18n('why')),
        h("p", null,
            i18n('pleasantChessExperience'),
            h("br", null),
            i18n('goodPractice'),
            h("br", null),
            i18n('potentialProblem')),
        h("h2", null, i18n('howToAvoidThis')),
        h("ul", null,
            h("li", null, i18n('playEveryGame')),
            h("li", null, i18n('tryToWin')),
            h("li", null, i18n('resignLostGames'))),
        h("br", null),
        h("p", null,
            i18n('temporaryInconvenience'),
            h("br", null),
            i18n('wishYouGreatGames'),
            h("br", null),
            i18n('thankYouForReading'))));
}

var home = {
    oninit({ attrs }) {
        this.ctrl = new HomeCtrl(safeStringToNum(attrs.tab));
        signals.sessionRestored.add(this.ctrl.loadOfflinePuzzle);
    },
    oncreate: viewFadeIn,
    onremove() {
        socket.destroy();
        this.ctrl.unload();
        signals.sessionRestored.remove(this.ctrl.loadOfflinePuzzle);
    },
    view() {
        const header = dropShadowHeader('Chess-Online Arena');
        return layout.free(header, body(this.ctrl), undefined, undefined, undefined);
    }
};

export { home as default };
//# sourceMappingURL=home-D9_89Ruf.js.map
