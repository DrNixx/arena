import { m as h, x as ontap, bH as getButton, bI as elSlideIn, Y as viewportDim, aL as findParentBySelector } from './main.js';
import { G as Gesture } from './layout-DoxuEk9x.js';

var TabNavigation = {
    oninit({ attrs }) {
        this.onTap = (e) => {
            const el = getButton(e);
            let i;
            if (el && (i = el.dataset.index)) {
                attrs.onTabChange(Number(i));
            }
        };
    },
    view(vnode) {
        const { buttons, selectedIndex, wrapperClass, withBottomBorder = false } = vnode.attrs;
        const iWidth = 100 / buttons.length;
        const shift = selectedIndex * (iWidth * buttons.length);
        const indicatorStyle = {
            width: iWidth + '%',
            transform: `translateX(${shift}%)`
        };
        const buttonStyle = {
            width: iWidth + '%'
        };
        function renderTab(b, i) {
            const className = [
                'tab-button',
                selectedIndex === i ? 'selected' : '',
                b.className
            ].join(' ');
            return (h("button", { "data-index": i, className: className, style: buttonStyle },
                b.label,
                b.chip !== undefined ?
                    h("span", { className: "chip" }, b.chip) : null));
        }
        return (h("div", { className: 'tabs-navigation' + (wrapperClass ? ' ' + wrapperClass : '') +
                (withBottomBorder ? ' withBorder' : ''), oncreate: ontap(this.onTap) },
            buttons.map(renderTab),
            h("div", { className: "tabIndicator", style: indicatorStyle })));
    }
};

var TabView = {
    oninit({ attrs }) {
        this.nbTabs = attrs.tabs.length;
        this.prevIndex = attrs.selectedIndex;
    },
    oncreate({ attrs, dom }) {
        this.gesture = new Gesture(dom, viewportDim());
        this.gesture.on('swiperight', (e) => {
            const tab = findParentBySelector(e.target, '.tab-content');
            if (tab) {
                const ds = tab.dataset;
                const index = Number(ds.index);
                if (index !== undefined && index > 0) {
                    attrs.onTabChange(index - 1);
                }
            }
        });
        this.gesture.on('swipeleft', (e) => {
            const tab = findParentBySelector(e.target, '.tab-content');
            if (tab) {
                const ds = tab.dataset;
                const index = Number(ds.index);
                if (index !== undefined) {
                    if (index < this.nbTabs - 1) {
                        attrs.onTabChange(index + 1);
                    }
                }
            }
        });
    },
    onupdate({ attrs, dom }) {
        this.nbTabs = attrs.tabs.length;
        if (attrs.selectedIndex > this.prevIndex) {
            const el = dom.querySelector('.tab-content') || dom;
            elSlideIn(el, 'left');
        }
        else if (attrs.selectedIndex < this.prevIndex) {
            const el = dom.querySelector('.tab-content') || dom;
            elSlideIn(el, 'right');
        }
        this.prevIndex = attrs.selectedIndex;
    },
    onremove() {
        this.gesture.destroy();
    },
    view({ attrs }) {
        const { tabs, selectedIndex, } = attrs;
        const tab = tabs[selectedIndex];
        return h('div.tabs-view-wrapper', h('div.tab-content.box', {
            'data-index': selectedIndex,
            key: tab.id,
            className: attrs.className
        }, tab.f()));
    }
};

export { TabNavigation as T, TabView as a };
//# sourceMappingURL=TabView-CG79fzxt.js.map
