import { W as WebPlugin } from './main.js';

class SplashScreenWeb extends WebPlugin {
    async show(_options) {
        return undefined;
    }
    async hide(_options) {
        return undefined;
    }
}

export { SplashScreenWeb };
//# sourceMappingURL=web-aFjPH8MG.js.map
