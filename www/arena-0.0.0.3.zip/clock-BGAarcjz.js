import { aA as viewSlideIn, b as session, G as dropShadowHeader, I as backButton, o as i18n, m as h, O as formWidgets } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { M as MoreTime, c as ClockTenths, d as ClockTenthsChoices, e as MoreTimeChoices } from './prefs-CFmBYsqy.js';

var clock = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('clock')));
        return layout.free(header, h('ul.native_scroller.page.settings_list.game', render(prefsCtrl)));
    }
};
const prefsCtrl = {
    clockTenths: session.lichessBackedProp('prefs.clockTenths', ClockTenths.LOWTIME),
    clockSound: session.lichessBackedProp('prefs.clockSound', true),
    moreTime: session.lichessBackedProp('prefs.moretime', MoreTime.ALWAYS),
};
function render(ctrl) {
    return [
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('tenthsOfSeconds'), ClockTenthsChoices, ctrl.clockTenths)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('soundWhenTimeGetsCritical'), [
            { label: i18n('no'), value: false },
            { label: i18n('yes'), value: true },
        ], ctrl.clockSound)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('giveMoreTime'), MoreTimeChoices, ctrl.moreTime)),
    ];
}

export { clock as default, prefsCtrl, render };
//# sourceMappingURL=clock-BGAarcjz.js.map
