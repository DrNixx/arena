import { m as h, o as i18n, M as popup, x as ontap, q as router, r as redraw, aW as move, aX as end, $ as Toast, aY as INITIAL_FEN, aZ as EMPTY_FEN, a_ as loadLocalJsonFile, a6 as Chessground, g as settings, a$ as parseFen, b0 as Board, b1 as parseCastlingFen, b2 as makeFen, b3 as Material, b4 as RemainingChecks, X as isPortrait, a0 as header, b5 as isTablet, F as viewFadeIn, s as socket } from './main.js';
import { c as continuePopup, s as setupPosition, C as Castles } from './variant-Cl-7Z946.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { B as Board$1 } from './Board-UV3Z06Mn.js';
import { l as layout } from './layout-DoxuEk9x.js';
import './fen-97CPMMDI.js';

var menu = {
    controller(root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open: open,
            close: close,
            isOpen() {
                return isOpen;
            },
            root
        };
    },
    view(ctrl) {
        return popup('editorMenu', undefined, () => renderEditorMenu(ctrl.root), ctrl.isOpen(), ctrl.close);
    }
};
function renderEditorMenu(ctrl) {
    return h('div.editorMenu', [
        renderSelectColorPosition(ctrl),
        renderCastlingOptions(ctrl)
    ]);
}
function renderSelectColorPosition(ctrl) {
    const fen = ctrl.getFen();
    return h('div.editorSelectors', [
        h('div.select_input', [
            h('select.positions', {
                id: 'select_editor_positions',
                onchange(e) {
                    ctrl.loadNewFen(e.target.value);
                }
            }, [
                optgroup(i18n('setTheBoard'), [
                    position2option(fen, {
                        name: `-- ${i18n('popularOpenings')} --`,
                        fen: '',
                        eco: '',
                    }),
                    ctrl.extraPositions.map((pos) => position2option(fen, pos))
                ]),
                optgroup(i18n('popularOpenings'), ctrl.positions.map((pos) => position2option(fen, pos, true)))
            ])
        ]),
        h('div.select_input', [
            h('select.positions', {
                id: 'select_editor_endgames',
                onchange(e) {
                    ctrl.loadNewFen(e.target.value);
                }
            }, [
                position2option(fen, {
                    name: `-- ${i18n('endgame')} --`,
                    fen: '',
                    eco: '',
                }),
                optgroup(i18n('endgame'), ctrl.endgamesPositions.map((pos) => position2option(fen, pos)))
            ])
        ]),
        h('div.select_input', [
            h('select', {
                id: 'select_editor_color',
                value: ctrl.turn,
                onchange(e) {
                    ctrl.setTurn(e.target.value);
                },
            }, [
                h('option[value=white]', i18n('whitePlays')),
                h('option[value=black]', i18n('blackPlays'))
            ])
        ])
    ]);
}
function renderCastlingOptions(ctrl) {
    return h('div.editor-castling', [
        h('h3', i18n('castling')),
        h('div.form-multipleChoice', [
            castlingButton(ctrl, 'K', i18n('whiteCastlingKingside')),
            castlingButton(ctrl, 'Q', i18n('O-O-O')),
        ]),
        h('div.form-multipleChoice', [
            castlingButton(ctrl, 'k', i18n('blackCastlingKingside')),
            castlingButton(ctrl, 'q', i18n('O-O-O')),
        ]),
    ]);
}
function castlingButton(ctrl, id, label) {
    return h('div', {
        className: ctrl.castlingToggles[id] ? 'selected' : '',
        oncreate: ontap(() => ctrl.setCastlingToggle(id, !ctrl.castlingToggles[id]))
    }, label);
}
function position2option(fen, pos, showEco = false) {
    return h('option', {
        value: pos.fen,
        selected: fen === pos.fen
    }, (showEco ? pos.eco + ' ' : '') + pos.name);
}
function optgroup(name, opts) {
    return h('optgroup', {
        label: name
    }, opts);
}

var pasteFenPopup = {
    controller(root) {
        const data = {
            isOpen: false,
            fenError: null,
        };
        function open() {
            router.backbutton.stack.push(close);
            data.isOpen = true;
            data.fenError = null;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && data.isOpen)
                router.backbutton.stack.pop();
            data.isOpen = false;
        }
        return {
            open: open,
            close: close,
            isOpen() {
                return data.isOpen;
            },
            root,
            data,
        };
    },
    view(ctrl) {
        return popup('pasteFenPopup', undefined, () => {
            return h('form', {
                onsubmit(e) {
                    e.preventDefault();
                    const input = e.target[0];
                    const value = input.value;
                    if (value && value.length) {
                        const isValid = ctrl.root.loadNewFen(value);
                        if (!isValid) {
                            ctrl.data.fenError = i18n('invalidFen');
                        }
                        else {
                            ctrl.data.fenError = null;
                            ctrl.close();
                        }
                        redraw();
                    }
                }
            }, [
                h('input[type=text]', {
                    placeholder: i18n('pasteTheFenStringHere'),
                }),
                ctrl.data.fenError ? h('div.error', ctrl.data.fenError) : null,
                h('button[data-icon=E].withIcon.popupAction', i18n('loadPosition'))
            ]);
        }, ctrl.isOpen(), ctrl.close);
    }
};

function drag (ctrl, e) {
    if (e.touches && e.touches.length > 1)
        return; // support one finger touch only
    const role = e.target.getAttribute('data-role'), color = e.target.getAttribute('data-color');
    if (!role || !color)
        return;
    e.stopPropagation();
    e.preventDefault();
    const piece = {
        role: role,
        color: color
    };
    ctrl.chessground.dragNewPiece(e, piece, true);
}

const CASTLING_TOGGLES = ['K', 'Q', 'k', 'q'];

class EditorCtrl {
    constructor(fen) {
        this.turn = 'white';
        this.castlingToggles = { K: false, Q: false, k: false, q: false };
        // TODO variants support
        this.rules = 'chess';
        this.halfmoves = 0;
        this.fullmoves = 0;
        this.positions = [];
        this.endgamesPositions = [];
        this.extraPositions = [];
        this.onChange = () => {
            const fen = this.getFen();
            const path = `/editor/${encodeURIComponent(fen)}`;
            window.history.replaceState(window.history.state, '', '?=' + path);
            redraw();
        };
        this.onstart = (e) => drag(this, e);
        this.onmove = (e) => move(this.chessground, e);
        this.onend = (e) => end(this.chessground, e);
        this.editorOnCreate = (vn) => {
            if (!vn.dom)
                return;
            const editorNode = document.getElementById('boardEditor');
            if (editorNode) {
                editorNode.addEventListener('touchstart', this.onstart);
                editorNode.addEventListener('touchmove', this.onmove);
                editorNode.addEventListener('touchend', this.onend);
            }
        };
        this.editorOnRemove = () => {
            const editorNode = document.getElementById('boardEditor');
            if (editorNode) {
                editorNode.removeEventListener('touchstart', this.onstart);
                editorNode.removeEventListener('touchmove', this.onmove);
                editorNode.removeEventListener('touchend', this.onend);
            }
        };
        this.loadNewFen = (newFen) => {
            return this.setFen(newFen);
        };
        this.goToAnalyse = () => {
            const state = this.getState();
            if (state.legalFen) {
                router.set(this.makeAnalysisUrl(state.legalFen));
            }
        };
        this.continueFromHere = () => {
            const state = this.getState();
            if (state.legalFen && state.playable) {
                this.continuePopup.open(state.legalFen, 'standard');
            }
            else {
                Toast.show({ text: i18n('invalidFen'), position: 'center', duration: 'short' });
            }
        };
        this.initFen = fen || INITIAL_FEN;
        this.menu = menu.controller(this);
        this.pasteFenPopup = pasteFenPopup.controller(this);
        this.continuePopup = continuePopup.controller();
        this.extraPositions = [{
                fen: INITIAL_FEN,
                name: i18n('startPosition'),
                eco: '',
            }, {
                fen: EMPTY_FEN,
                name: i18n('clearBoard'),
                eco: '',
            }];
        Promise.all([
            loadLocalJsonFile('data/positions.json'),
            loadLocalJsonFile('data/endgames.json')
        ])
            .then(([openings, endgames]) => {
            this.positions =
                openings.reduce((acc, c) => acc.concat(c.positions), []);
            this.endgamesPositions = endgames;
            redraw();
        });
        this.chessground = new Chessground({
            fen: this.initFen,
            orientation: 'white',
            movable: {
                free: true,
                color: 'both'
            },
            highlight: {
                lastMove: false,
                check: false
            },
            animation: {
                duration: 300
            },
            premovable: {
                enabled: false
            },
            draggable: {
                magnified: settings.game.magnified(),
                deleteOnDropOff: true
            },
            events: {
                change: this.onChange
            }
        });
        this.setFen(this.initFen);
    }
    bottomColor() {
        return this.chessground ? this.chessground.state.orientation : 'white';
    }
    setCastlingToggle(id, value) {
        if (this.castlingToggles[id] !== value)
            this.unmovedRooks = undefined;
        this.castlingToggles[id] = value;
        this.onChange();
    }
    setTurn(turn) {
        this.turn = turn;
        this.onChange();
    }
    castlingToggleFen() {
        let fen = '';
        for (const toggle of CASTLING_TOGGLES) {
            if (this.castlingToggles[toggle])
                fen += toggle;
        }
        return fen;
    }
    getSetup() {
        const boardFen = this.chessground ? this.chessground.getFen() : this.initFen;
        const board = parseFen(boardFen).unwrap(setup => setup.board, () => Board.empty());
        return {
            board,
            pockets: this.pockets,
            turn: this.turn,
            unmovedRooks: this.unmovedRooks || parseCastlingFen(board, this.castlingToggleFen()).unwrap(),
            epSquare: this.epSquare,
            remainingChecks: this.remainingChecks,
            halfmoves: this.halfmoves,
            fullmoves: this.fullmoves,
        };
    }
    getFen() {
        return makeFen(this.getSetup(), { promoted: this.rules === 'crazyhouse' });
    }
    getLegalFen() {
        return setupPosition(this.rules, this.getSetup()).unwrap(pos => {
            return makeFen(pos.toSetup(), { promoted: pos.rules === 'crazyhouse' });
        }, () => undefined);
    }
    isPlayable() {
        return setupPosition(this.rules, this.getSetup()).unwrap(pos => !pos.isEnd(), () => false);
    }
    getState() {
        return {
            fen: this.getFen(),
            legalFen: this.getLegalFen(),
            playable: this.rules === 'chess' && this.isPlayable(),
        };
    }
    makeAnalysisUrl(legalFen) {
        switch (this.rules) {
            case 'chess': return this.makeUrl('/analyse/fen/', legalFen);
            case '3check': return this.makeUrl('/analyse/variant/threeCheck/fen/', legalFen);
            case 'kingofthehill': return this.makeUrl('/analyse/variant/kingOfTheHill/fen/', legalFen);
            case 'racingkings': return this.makeUrl('/analyse/variant/racingKings/fen/', legalFen);
            case 'antichess':
            case 'atomic':
            case 'horde':
            case 'crazyhouse':
                return this.makeUrl(`/analyse/variant/${this.rules}/fen/`, legalFen);
        }
    }
    makeUrl(baseUrl, fen) {
        return baseUrl + encodeURIComponent(fen);
    }
    setFen(fen) {
        return parseFen(fen).unwrap(setup => {
            if (this.chessground) {
                this.chessground.set({ fen });
            }
            this.pockets = setup.pockets;
            this.turn = setup.turn;
            this.unmovedRooks = setup.unmovedRooks;
            this.epSquare = setup.epSquare;
            this.remainingChecks = setup.remainingChecks;
            this.halfmoves = setup.halfmoves;
            this.fullmoves = setup.fullmoves;
            const castles = Castles.fromSetup(setup);
            this.castlingToggles['K'] = castles.rook.white.h !== undefined;
            this.castlingToggles['Q'] = castles.rook.white.a !== undefined;
            this.castlingToggles['k'] = castles.rook.black.h !== undefined;
            this.castlingToggles['q'] = castles.rook.black.a !== undefined;
            this.onChange();
            return true;
        }, () => false);
    }
    setRules(rules) {
        this.rules = rules;
        if (rules !== 'crazyhouse')
            this.pockets = undefined;
        else if (!this.pockets)
            this.pockets = Material.empty();
        if (rules !== '3check')
            this.remainingChecks = undefined;
        else if (!this.remainingChecks)
            this.remainingChecks = RemainingChecks.default();
        this.onChange();
    }
}

function view(ctrl) {
    const color = ctrl.chessground.state.orientation;
    const opposite = color === 'white' ? 'black' : 'white';
    const isPortrait$1 = isPortrait();
    const board = h(Board$1, {
        variant: 'standard',
        chessground: ctrl.chessground,
        wrapperClasses: 'editor-board',
    });
    return layout.board(header(i18n('boardEditor')), [
        board,
        h('div.editor-wrapper', [
            h('div#boardEditor.editor-table.box', {
                className: settings.general.theme.piece(),
                oncreate: ctrl.editorOnCreate,
                onremove: ctrl.editorOnRemove
            }, [
                h('div.editor-piecesDrawer', [
                    sparePieces(opposite, color, 'top'),
                    sparePieces(color, color, 'bottom')
                ]),
                !isPortrait$1 && isTablet() ? h('div.editor-menu', [
                    renderSelectColorPosition(ctrl),
                    renderCastlingOptions(ctrl)
                ]) : null
            ]),
            renderActionsBar(ctrl)
        ])
    ], undefined, [
        menu.view(ctrl.menu),
        continuePopup.view(ctrl.continuePopup),
        pasteFenPopup.view(ctrl.pasteFenPopup)
    ]);
}
function sparePieces(color, orientation, position) {
    return h('div', {
        className: ['sparePieces', position, 'orientation-' + orientation, color].join(' ')
    }, h('div.sparePiecesInner', ['king', 'queen', 'rook', 'bishop', 'knight', 'pawn'].map((role) => {
        return h('div.sparePiece', h('piece', {
            className: color + ' ' + role,
            'data-color': color,
            'data-role': role
        }));
    })));
}
function renderActionsBar(ctrl) {
    const state = ctrl.getState();
    return h('section.actions_bar', [
        isPortrait() || !isTablet() ? h('button.action_bar_button.fa.fa-gear', {
            oncreate: ontap(ctrl.menu.open)
        }) : null,
        h('button.action_bar_button[data-icon=B]', {
            oncreate: ontap(ctrl.chessground.toggleOrientation)
        }),
        h('button.action_bar_button[data-icon=U]', {
            disabled: !state.playable,
            oncreate: ontap(ctrl.continueFromHere, () => Toast.show({ text: i18n('continueFromHere'), duration: 'short', position: 'bottom' }))
        }),
        h('button.action_bar_button[data-icon=A]', {
            disabled: state.legalFen === undefined,
            oncreate: ontap(ctrl.goToAnalyse, () => Toast.show({ text: i18n('analysis'), duration: 'short', position: 'bottom' }))
        }),
        h('button.action_bar_button.fa.fa-upload', {
            oncreate: ontap(ctrl.pasteFenPopup.open, () => Toast.show({ text: i18n('loadAPositionFromFen'), duration: 'short', position: 'bottom' }))
        }),
        h('button.action_bar_button.fa.fa-share-alt', {
            oncreate: ontap(() => Share.share({ text: ctrl.getLegalFen() }), () => Toast.show({ text: 'Share FEN', duration: 'short', position: 'bottom' }))
        })
    ]);
}

const EditorScreen = {
    oninit({ attrs }) {
        socket.createDefault();
        this.editor = new EditorCtrl(attrs.fen);
    },
    oncreate: viewFadeIn,
    onremove() {
    },
    view() {
        return view(this.editor);
    }
};

export { EditorScreen as default };
//# sourceMappingURL=editor-D_5O4t7t.js.map
