import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, s as socket, A as App, r as redraw, m as h, p as ontapY, q as router } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

var settings = {
    oncreate: viewSlideIn,
    oninit() {
        socket.createDefault();
        App.getInfo()
            .then(info => {
            this.appVersion = info.version;
            redraw();
        });
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('settings')));
        return layout.free(header, renderBody(this.appVersion));
    }
};
function renderBody(appVersion) {
    return [
        h('ul.settings_list.native_scroller.page', [
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/gameDisplay'))
            }, i18n('gameDisplay')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/clock'))
            }, i18n('clock')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/gameBehavior'))
            }, i18n('gameBehavior')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/lang'))
            }, i18n('language')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/background'))
            }, `${i18n('background')}`),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/themes/board'))
            }, i18n('boardTheme')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/themes/piece'))
            }, i18n('pieceSet')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/settings/soundNotifications'))
            }, i18n('sound'))
        ]),
        appVersion ? h('section.app_version', 'v' + appVersion) : null
    ];
}

export { settings as default };
//# sourceMappingURL=settings-B5Pww0OA.js.map
