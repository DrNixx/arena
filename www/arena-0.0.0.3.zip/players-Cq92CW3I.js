import { f as fetchJSON, r as redraw, q as router, d as debounce, K as handleXhrError, a0 as header$1, m as h, o as i18n, x as ontap, g as settings, bf as backArrow, bh as autofocus, p as ontapY, aI as userStatus, w as spinner, z as gameIcon, E as getLI, F as viewFadeIn, s as socket, H as safeStringToNum } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { b as perfTitle } from './perfs-BLfNpglP.js';
import { T as TabNavigation, a as TabView } from './TabView-CG79fzxt.js';

async function autocomplete(term) {
    const data = await fetchJSON('/api/player/autocomplete?friend=1&object=1', {
        query: { term },
    });
    return data.result;
}
async function onlinePlayers$1() {
    const data = await fetchJSON('/player/online', { query: { nb: 50 } });
    data.forEach(user => user.online = true); // every player returned from this endpoint is implicitly online
    return data;
}
function ranking() {
    return fetchJSON('/player');
}

class PlayersCtrl {
    constructor(defaultTab) {
        this.isSearchOpen = false;
        this.searchResults = [];
        this.onTabChange = (tabIndex) => {
            const loc = window.location.search.replace(/\?tab=\w+$/, '');
            try {
                window.history.replaceState(window.history.state, '', loc + '?tab=' + tabIndex);
            }
            catch (e) {
                console.error(e);
            }
            this.currentTab = tabIndex;
            redraw();
        };
        this.closeSearch = (fromBB) => {
            if (fromBB !== 'backbutton' && this.isSearchOpen)
                router.backbutton.stack.pop();
            this.isSearchOpen = false;
        };
        this.onSearchInput = (e) => {
            const term = e.target.value.trim();
            if (!(/^[a-z0-9][\w-]{2,29}$/i.exec(term)))
                return;
            if (term.length >= 3)
                this.searchXhr(term);
        };
        this.searchXhr = debounce(term => {
            autocomplete(term).then(data => {
                this.searchResults = data;
                redraw();
            });
        }, 300);
        this.goSearch = () => {
            router.backbutton.stack.push(this.closeSearch);
            this.isSearchOpen = true;
        };
        this.goToProfile = (u) => {
            router.set('/@/' + u);
        };
        this.currentTab = defaultTab || 0;
        onlinePlayers$1()
            .then(data => {
            this.players = data;
            redraw();
        })
            .catch(handleXhrError);
        ranking()
            .then(data => {
            this.leaderboard = data;
            redraw();
        })
            .catch(handleXhrError);
    }
}

function header(ctrl) {
    return header$1(h('div.players_main_header', [
        h('div.main_header_title', i18n('players')),
        h('button.main_header_button[data-icon=y]', {
            oncreate: ontap(ctrl.goSearch)
        })
    ]));
}
function body(ctrl) {
    const tabsContent = [
        { id: 'leaderboard', f: () => renderLeaderboard(ctrl) },
        { id: 'players', f: () => onlinePlayers(ctrl) },
    ];
    return [
        h('div.tabs-nav-header.subHeader', h(TabNavigation, {
            buttons: [
                { label: i18n('leaderboard') },
                { label: i18n('onlinePlayers') },
            ],
            selectedIndex: ctrl.currentTab,
            onTabChange: ctrl.onTabChange
        })),
        h(TabView, {
            selectedIndex: ctrl.currentTab,
            tabs: tabsContent,
            onTabChange: ctrl.onTabChange,
        })
    ];
}
function searchModal(ctrl) {
    if (!ctrl.isSearchOpen)
        return null;
    const className = [
        'modal',
        'show',
        settings.general.theme.background()
    ].join(' ');
    return (h("div", { id: "searchPlayersModal", className: className },
        h("header", { class: "main_header" },
            h("button", { className: "main_header_button", oncreate: ontap(() => ctrl.closeSearch()) }, backArrow),
            h("div", { className: "search_input allow_select" },
                h("input", { id: "searchPlayers", type: "search", placeholder: "Search players", oninput: ctrl.onSearchInput, autocapitalize: "off", autocomplete: "off", oncreate: autofocus }))),
        h("ul", { id: "playersSearchResults", className: "modal_content native_scroller" }, ctrl.searchResults.map((u, i) => {
            const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
            return (h("li", { className: `list_item nav ${evenOrOdd}`, key: u.id, oncreate: ontapY(() => ctrl.goToProfile(u.id)) }, userStatus({ username: u.name, ...u })));
        }))));
}
function onlinePlayers(ctrl) {
    return ctrl.players ?
        h("ul", { className: "playersSuggestion native_scroller page", oncreate: ontapY(onPlayerTap, undefined, getLI) }, ctrl.players.map(renderPlayer)) :
        h("div", { className: "loader_container" }, spinner.getVdom('monochrome'));
}
function onPlayerTap(e) {
    const el = getLI(e);
    if (el) {
        const ds = el.dataset;
        if (ds.id) {
            router.set('/@/' + ds.id);
        }
    }
}
function renderPlayer(user, i) {
    const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
    const perf = Object.keys(user.perfs).reduce((prev, curr) => {
        if (!prev)
            return curr;
        if (curr === 'opening' || curr === 'puzzle')
            return prev;
        if (user.perfs[prev].rating < user.perfs[curr].rating)
            return curr;
        else
            return prev;
    });
    return (h("li", { className: `list_item playerSuggestion nav ${evenOrOdd}`, "data-id": user.id },
        userStatus(user),
        h("span", { className: "rating", "data-icon": gameIcon(perf) }, user.perfs[perf].rating)));
}
function renderLeaderboard(ctrl) {
    const leaderboard = ctrl.leaderboard;
    if (!leaderboard)
        return (h("div", { className: "loader_container" }, spinner.getVdom('monochrome')));
    const keys = Object.keys(leaderboard).filter(k => k !== 'online');
    const categories = keys.map((k) => renderRankingCategory(leaderboard, k));
    return (h("div", { className: "native_scroller page leaderboard_wrapper" }, categories));
}
function renderRankingCategory(ranking, key) {
    return (h("section", { className: 'leaderboard_section ' + key },
        h("h3", { className: "leaderboard_title" },
            h("span", { className: "perfIcon", "data-icon": gameIcon(key) }),
            perfTitle(key)),
        h("ul", { className: "leaderboard" }, ranking[key].map((p) => renderRankingPlayer(p, key)))));
}
function renderRankingPlayer(user, key) {
    return (h("li", { className: "list_item leaderboard_player", oncreate: ontapY(() => router.set('/@/' + user.id)) },
        userStatus(user),
        h("span", { className: "rating" }, user.perfs[key].rating)));
}

var players = {
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = new PlayersCtrl(safeStringToNum(attrs.tab));
    },
    oncreate: viewFadeIn,
    view() {
        const ctrl = this.ctrl;
        const headerCtrl = header(ctrl);
        const bodyCtrl = body(ctrl);
        const searchModalCtrl = searchModal(ctrl);
        return layout.free(headerCtrl, bodyCtrl, undefined, searchModalCtrl);
    }
};

export { players as default };
//# sourceMappingURL=players-Cq92CW3I.js.map
