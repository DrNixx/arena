import { f as fetchJSON, aw as serializeQueryParameters, g as settings, r as redraw, K as handleXhrError, az as toggleGameBookmark, ay as batchRequestAnimationFrame, c as fromNow, m as h, h as throttle, o as i18n, w as spinner, p as ontapY, x as ontap, bi as closestHandler, be as closest, q as router, F as viewFadeIn, G as dropShadowHeader, s as socket } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { G as GameItem } from './GameItem-Qant7ELU.js';
import './game-CgD9Ef6g.js';
import './perfs-BLfNpglP.js';

function search$1(query, page = 1) {
    return fetchJSON('/games/search', {
        method: 'GET',
        query: Object.assign({}, query, { page })
    }, false);
}

let cachedSearchState;
function SearchCtrl(initQuery) {
    // used to restore scroll position only once from cached state
    let initialized = false;
    const query = {
        'players.a': '',
        'players.b': '',
        'players.white': '',
        'players.black': '',
        'players.winner': '',
        ratingMin: '',
        ratingMax: '',
        hasAi: '',
        source: '',
        perf: '',
        turnsMin: '',
        turnsMax: '',
        durationMin: '',
        durationMax: '',
        'clock.initMin': '',
        'clock.initMax': '',
        'clock.incMin': '',
        'clock.incMax': '',
        status: '',
        winnerColor: '',
        dateMin: '',
        dateMax: '',
        'sort.field': 'd',
        'sort.order': 'desc',
        analysed: ''
    };
    Object.assign(query, initQuery);
    const queryString = serializeQueryParameters(query);
    const cacheAvailable = cachedSearchState && queryString === cachedSearchState.queryString;
    const searchState = {
        paginator: undefined,
        games: [],
        scrollPos: 0,
        queryString,
        searching: false
    };
    const boardTheme = settings.general.theme.board();
    const updateSearchStateCache = () => {
        cachedSearchState = searchState;
    };
    const onGamesLoaded = () => {
        if (cacheAvailable && !initialized) {
            batchRequestAnimationFrame(() => {
                const scroller = document.getElementById('searchContent');
                if (scroller)
                    scroller.scrollTop = cachedSearchState.scrollPos;
                initialized = true;
            });
        }
    };
    const onScroll = (e) => {
        const target = e.target;
        searchState.scrollPos = target.scrollTop;
        updateSearchStateCache();
    };
    function search() {
        if (!searchState.searching) {
            searchState.searching = true;
            redraw();
            // go to the bottom to see spinner and the beginning of search results
            setTimeout(() => {
                const scroller = document.getElementById('searchContent');
                if (scroller) {
                    scroller.scrollTop = 99999;
                }
            }, 250);
            search$1(query)
                .then(prepareData)
                .then(data => {
                searchState.queryString = serializeQueryParameters(query);
                searchState.searching = false;
                searchState.paginator = data.paginator;
                if (data.paginator) {
                    searchState.games = data.paginator.currentPageResults;
                }
                else {
                    searchState.games = [];
                }
                updateHref();
                updateSearchStateCache();
                // delay display of result to have a little feedback of searching
                // even when it's super fast
                setTimeout(redraw, 500);
            })
                .catch(err => {
                searchState.searching = false;
                redraw();
                handleXhrError(err);
            });
        }
    }
    function toggleBookmark(id) {
        toggleGameBookmark(id).then(() => {
            const i = searchState.games.findIndex(h => h.id === id);
            const g = searchState.games[i];
            if (g) {
                const ng = Object.assign({}, g, { bookmarked: !g.bookmarked });
                searchState.games[i] = ng;
                redraw();
            }
        });
    }
    function updateHref() {
        const path = `/search?${searchState.queryString}`;
        try {
            window.history.replaceState(window.history.state, '', '?=' + path);
        }
        catch (e) {
            console.error(e);
        }
    }
    function more() {
        const curPaginator = searchState.paginator;
        if (curPaginator && curPaginator.nextPage) {
            search$1(query, curPaginator.nextPage)
                .then(prepareData)
                .then(data => {
                searchState.paginator = data.paginator;
                if (searchState.paginator) {
                    searchState.games = searchState.games.concat(searchState.paginator.currentPageResults);
                    redraw();
                }
                updateSearchStateCache();
            })
                .catch(handleXhrError);
        }
    }
    const handleChange = (name) => (e) => {
        const val = e.target.value.trim();
        Object.assign(query, { [name]: val });
        redraw();
    };
    const toggleAnalysis = () => {
        query.analysed = query.analysed === '1' ? '' : '1';
        redraw();
    };
    if (cacheAvailable) {
        setTimeout(() => {
            Object.assign(searchState, cachedSearchState);
            redraw();
        }, 300);
    }
    else if (Object.keys(initQuery).length > 0) {
        search();
    }
    return {
        searchState,
        query,
        search,
        toggleBookmark,
        more,
        boardTheme,
        handleChange,
        toggleAnalysis,
        onScroll,
        onGamesLoaded
    };
}
function prepareData(xhrData) {
    if (xhrData.paginator && xhrData.paginator.currentPageResults) {
        xhrData.paginator.currentPageResults.forEach(g => {
            g.date = fromNow(new Date(g.timestamp));
        });
    }
    return xhrData;
}

function renderSearchForm(ctrl) {
    const players = getPlayers(ctrl.query);
    const isComputerOpp = ctrl.query.hasAi === '1';
    return (h("div", { id: "searchContent", className: "native_scroller searchWraper", onscroll: throttle(ctrl.onScroll, 30) },
        h("form", { id: "advancedSearchForm", onsubmit: (e) => {
                e.preventDefault();
                ctrl.search();
            } },
            h("div", { className: "game_search_row" },
                h("label", null, "Players"),
                h("div", { className: "game_search_input_wrapper" },
                    h("div", { className: "game_search_input" },
                        h("input", { type: "text", name: "players.a", value: ctrl.query['players.a'], oninput: throttle(ctrl.handleChange('players.a'), 200), autocomplete: "off", autocapitalize: "off", autocorrect: "off", spellcheck: false })),
                    h("div", { className: "game_search_input" },
                        h("input", { type: "text", name: "players.b", value: ctrl.query['players.b'], oninput: throttle(ctrl.handleChange('players.b'), 200), autocomplete: "off", autocapitalize: "off", autocorrect: "off", spellcheck: false })))),
            renderSelectRow(ctrl, i18n('white'), !!players.length, { name: 'players.white', options: players }),
            renderSelectRow(ctrl, i18n('black'), !!players.length, { name: 'players.black', options: players }),
            renderSelectRow(ctrl, i18n('winner'), !!players.length, { name: 'players.winner', options: players }),
            renderSelectRow(ctrl, i18n('ratingRange'), true, { name: 'ratingMin', options: ratingOptions, placeholder: 'From' }, { name: 'ratingMax', options: ratingOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, i18n('opponent'), true, { name: 'hasAi', options: opponentOptions }),
            renderSelectRow(ctrl, i18n('aiNameLevelAiLevel', 'A.I.', '').trim(), isComputerOpp, { name: 'aiLevelMin', options: aiLevelOptions, placeholder: 'From' }, { name: 'aiLevelMax', options: aiLevelOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, 'Source', true, { name: 'source', options: sourceOptions }),
            renderSelectRow(ctrl, i18n('variant'), true, { name: 'perf', options: perfOptions }),
            renderSelectRow(ctrl, 'Turns', true, { name: 'turnsMin', options: turnOptions, placeholder: 'From' }, { name: 'turnsMax', options: turnOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, i18n('duration'), true, { name: 'durationMin', options: durationOptions, placeholder: 'From' }, { name: 'durationMax', options: durationOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, i18n('time'), true, { name: 'clock.initMin', options: timeOptions, placeholder: 'From' }, { name: 'clock.initMax', options: timeOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, i18n('increment'), true, { name: 'clock.incMin', options: incrementOptions, placeholder: 'From' }, { name: 'clock.incMax', options: incrementOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, 'Result', true, { name: 'status', options: resultOptions }),
            renderSelectRow(ctrl, i18n('winner'), true, { name: 'winnerColor', options: winnerOptions }),
            renderSelectRow(ctrl, 'Date', true, { name: 'dateMin', options: dateOptions, placeholder: 'From', noEmpty: true }, { name: 'dateMax', options: dateOptions, placeholder: 'To' }),
            renderSelectRow(ctrl, 'Sort', true, { name: 'sort.field', options: sortFieldOptions, noEmpty: true }, { name: 'sort.order', options: sortOrderOptions, noEmpty: true }),
            h("div", { className: "game_search_row" },
                h("label", null, "Analysis"),
                h("div", { className: "game_search_input_wrapper" },
                    h("div", { className: "game_search_input full" },
                        h("div", { className: "check_container" },
                            h("input", { type: "checkbox", name: "analysed", checked: ctrl.query.analysed === '1', onchange: ctrl.toggleAnalysis }))))),
            h("button", { className: "fatButton", type: "submit" },
                h("span", { className: "fa fa-search" }),
                i18n('search'))),
        renderResult(ctrl),
        renderPaginator(ctrl)));
}
function getButton(e) {
    const target = e.target;
    return target.tagName === 'BUTTON' ? target : undefined;
}
function onTap(ctrl, e) {
    const starButton = getButton(e);
    const el = closest(e, '.userGame');
    const id = (el?.dataset).id;
    if (starButton) {
        ctrl.toggleBookmark(id);
    }
    else {
        if (id) {
            const g = ctrl.searchState.games.find(game => game.id === id);
            if (g) {
                router.set(`/analyse/online/${id}`);
            }
        }
    }
}
function renderResult(ctrl) {
    const children = ctrl.searchState.searching ? spinner.getVdom('monochrome') :
        ctrl.searchState.paginator === undefined ? null :
            ctrl.searchState.games.length === 0 ?
                h('div.search-empty', i18n('noGameFound')) :
                h.fragment({ oncreate: ctrl.onGamesLoaded }, [
                    ctrl.searchState.games.map((g, index) => h(GameItem, { key: g.id, g, index, boardTheme: ctrl.boardTheme })),
                ]);
    return h('ul.searchGamesList', {
        className: ctrl.searchState.searching ? 'searching' : '',
        oncreate: ontapY(e => onTap(ctrl, e), undefined, closestHandler('.userGame'))
    }, children);
}
function renderPaginator(ctrl) {
    return ctrl.searchState.paginator && ctrl.searchState.paginator.nextPage ?
        h('div.moreButton', [
            h('button', {
                oncreate: ontap(ctrl.more)
            }, h('span.fa.fa-arrow-down'))
        ]) : null;
}
function renderSelectRow(ctrl, label, isDisplayed, select1, select2) {
    if (!isDisplayed)
        return null;
    const select1Val = ctrl.query[select1.name];
    return (h("div", { className: "game_search_row" },
        h("label", null, label),
        h("div", { className: "game_search_input_wrapper" },
            h("div", { className: 'game_search_select' + (select2 ? '' : ' full') },
                h("label", null, select1Val === '' && select1.placeholder ? select1.placeholder : ''),
                h("select", { value: select1Val, name: select1.name, onchange: ctrl.handleChange(select1.name) },
                    !select1.noEmpty ?
                        h("option", { value: "" }) :
                        null,
                    select1.options.map(renderOption))),
            select2 ?
                h("div", { className: "game_search_select" },
                    h("label", null, ctrl.query[select2.name] === '' && select2.placeholder ? select2.placeholder : ''),
                    h("select", { value: ctrl.query[select2.name], name: select2.name, onchange: ctrl.handleChange(select2.name) },
                        !select2.noEmpty ?
                            h("option", { value: "" }) :
                            null,
                        select2.options.map(renderOption))) : null)));
}
function renderOption(opt) {
    return h("option", { key: opt.value, value: opt.value }, opt.label);
}
function getPlayers(query) {
    const players = [];
    const playerA = query['players.a'];
    const playerB = query['players.b'];
    if (playerA) {
        players.push({ value: playerA, label: playerA });
    }
    if (playerB) {
        players.push({ value: playerB, label: playerB });
    }
    return players;
}
const searchOpts = {
    ratings: ['800', '900', '1000', '1100', '1200', '1300', '1400', '1500', '1600', '1700', '1800', '1900', '2000', '2100', '2200', '2300', '2400', '2500', '2600', '2700', '2800', '2900'],
    aiLevels: ['1', '2', '3', '4', '5', '6', '7', '8'],
    sources: [['1', 'Lobby'], ['2', 'Friend'], ['3', 'Ai'], ['6', 'Position'], ['7', 'Import'], ['5', 'Tournament'], ['10', 'Simul'], ['12', 'Pool']],
    perfs: [['0', 'UltraBullet'], ['1', 'Bullet'], ['2', 'Blitz'], ['6', 'Rapid'], ['3', 'Classical'], ['4', 'Correspondence'], ['18', 'Crazyhouse'], ['11', 'Chess960'], ['12', 'King of the Hill'], ['15', 'Three-check'], ['13', 'Antichess'], ['14', 'Atomic'], ['16', 'Horde'], ['17', 'Racing Kings']],
    turns: ['1', '2', '3', '4', '5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '60', '70', '80', '90', '100', '125', '150', '175', '200', '225', '250', '275', '300'],
    durations: [['30', '30 seconds'], ['60', '1 minute'], ['120', '2 minutes'], ['300', '5 minutes'], ['600', '10 minutes'], ['900', '15 minutes'], ['1200', '20 minutes'], ['1800', '30 minutes'], ['3600', '1 hour'], ['10800', '3 hours'], ['86400', '1 day'], ['259200', '3 days'], ['604800', '1 week'], ['1209600', '2 weeks'], ['2592000', '1 month'], ['7776000', '3 months'], ['15552000', '6 months'], ['31536000', '1 year']],
    times: [['0', '0 seconds'], ['30', '30 seconds'], ['45', '45 seconds'], ['60', '1 minute'], ['120', '2 minutes'], ['180', '3 minutes'], ['300', '5 minutes'], ['600', '10 minutes'], ['900', '15 minutes'], ['1200', '20 minutes'], ['1800', '30 minutes'], ['2700', '45 minutes'], ['3600', '60 minutes'], ['5400', '90 minutes'], ['7200', '120 minutes'], ['9000', '150 minutes'], ['10800', '180 minutes']],
    increments: [['0', '0 seconds'], ['1', '1 second'], ['2', '2 seconds'], ['3', '3 seconds'], ['5', '5 seconds'], ['10', '10 seconds'], ['15', '15 seconds'], ['30', '30 seconds'], ['45', '45 seconds'], ['60', '60 seconds'], ['90', '90 seconds'], ['120', '120 seconds'], ['150', '150 seconds'], ['180', '180 seconds']],
    results: [['30', 'Mate'], ['31', 'Resign'], ['32', 'Stalemate'], ['34', 'Draw'], ['35', 'Clock Flag'], ['60', 'Variant End']],
    winners: [['1', 'white'], ['2', 'black'], ['3', 'none']],
    dates: [['0d', 'Now'], ['1h', '1 hour ago'], ['2h', '2 hours ago'], ['6h', '6 hours ago'], ['1d', '1 day ago'], ['2d', '2 days ago'], ['3d', '3 days ago'], ['4d', '4 days ago'], ['5d', '5 days ago'], ['6d', '6 days ago'], ['1w', '1 week ago'], ['2w', '2 weeks ago'], ['3w', '3 weeks ago'], ['4w', '4 weeks ago'], ['5w', '5 weeks ago'], ['6w', '6 weeks ago'], ['1m', '1 month ago'], ['2m', '2 months ago'], ['3m', '3 months ago'], ['4m', '4 months ago'], ['5m', '5 months ago'], ['6m', '6 months ago'], ['1y', '1 year ago'], ['2y', '2 years ago'], ['3y', '3 years ago'], ['4y', '4 years ago'], ['5y', '5 years ago']],
    sortFields: [['d', 'Date'], ['t', 'Moves'], ['a', 'Rating']],
    sortOrders: [['desc', 'Descending'], ['asc', 'Ascending']]
};
const ratingOptions = searchOpts.ratings.map((a) => ({ value: a, label: a }));
const opponents = [['0', i18n('human') + ' ' + i18n('opponent')], ['1', i18n('computer') + ' ' + i18n('opponent')]];
const opponentOptions = opponents.map((a) => ({ value: a[0], label: a[1] }));
const aiLevelOptions = searchOpts.aiLevels.map((a) => ({ value: a, label: i18n('level') + ' ' + a }));
const sourceOptions = searchOpts.sources.map((a) => ({ value: a[0], label: a[1] }));
const perfOptions = searchOpts.perfs.map((a) => ({ value: a[0], label: a[1] }));
const turnOptions = searchOpts.turns.map((a) => ({ value: a, label: a }));
const durationOptions = searchOpts.durations.map((a) => ({ value: a[0], label: a[1] }));
const timeOptions = searchOpts.times.map((a) => ({ value: a[0], label: a[1] }));
const incrementOptions = searchOpts.increments.map((a) => ({ value: a[0], label: a[1] }));
const resultOptions = searchOpts.results.map((a) => ({ value: a[0], label: a[1] }));
const winnerOptions = searchOpts.winners.map((a) => ({ value: a[0], label: i18n(a[1]) }));
const dateOptions = searchOpts.dates.map((a) => ({ value: a[0], label: a[1] }));
const sortFieldOptions = searchOpts.sortFields.map((a) => ({ value: a[0], label: a[1] }));
const sortOrderOptions = searchOpts.sortOrders.map((a) => ({ value: a[0], label: a[1] }));

var search = {
    oncreate: viewFadeIn,
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = SearchCtrl(attrs);
    },
    view() {
        return layout.free(dropShadowHeader(i18n('advancedSearch')), renderSearchForm(this.ctrl));
    }
};

export { search as default };
//# sourceMappingURL=search-BqbHtXW3.js.map
