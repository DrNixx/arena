import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, s as socket, q as router } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

var about = {
    oncreate: viewSlideIn,
    oninit() {
        socket.createDefault();
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('about')));
        return layout.free(header, h("div", { class: "aboutBody native_scroller page" },
            h("p", null, "live.chess-online.com is a free, open-source chess server."),
            h("p", null,
                "In 2010, Thibault Duplessis began work on Lichess as a hobby project. The site was simple in the beginning, not even checking to see if moves were legal. He made the site ",
                externalLink('open-source', 'https://www.youtube.com/watch?v=Tyd0FO0tko8'),
                ", which means anyone is free to read the source code and make contributions.  Gradually, the site improved and collected users as an enthusiastic volunteer staff assembled to help Thibault build and maintain the site."),
            h("p", null, "Today, lichess users play more than a million games every day. Lichess is one of the most popular chess websites in the world while remaining 100% free. Most \u201Cfree\u201D websites subsist by selling ads or selling user data. Others do it by putting all the good stuff behind paywalls. Lichess does none of these things and never will. With no investors demanding profits, Lichess staff can focus on improving the site as their only goal."),
            h("p", null,
                "Despite Lichess's humble origins, playing a chess game is far from the only thing you can do on Lichess. After finishing a game, you can request computer analysis using the latest ",
                externalLink('Stockfish', 'https://stockfishchess.org/'),
                " chess engine and learn from your mistakes or compare your game against a ",
                internalLink('massive database', '/analyse/variant/standard?tabId=explorer'),
                " of chess masters\u2019 games. You can watch ",
                internalLink('top players battle it out live', '/tv'),
                " and discuss the game with your friends; ",
                externalLink('even World Champions play on Lichess!', 'https://live.chess-online.com/blog/WjRTPScAAJXo7r5s/magnus-carlsen-wins-the-first-lichess-titled-arena')),
            h("p", null,
                "A site the size of Lichess requires a significant number of people to maintain it. It also requires monetary resources for ",
                externalLink('expenses', 'https://docs.google.com/spreadsheets/d/1CGgu-7aNxlZkjLl9l-OlL00fch06xp0Q7eCVDDakYEE/preview'),
                ", such as servers and other hosting services. The number of people who have contributed to these things is difficult to count precisely but fall into the following categories:"),
            h("ul", null,
                h("li", null,
                    "Lichess would not exist without the thousands of hours of time from volunteers, both from ",
                    externalLink('website devs', 'https://github.com/lichess-org/lila/graphs/contributors'),
                    " and ",
                    externalLink('mobile devs', 'https://github.com/lichess-org/lichobile/graphs/contributors'),
                    ", who create new features and/or bugs, as well as our administrative team, who police the site and help with long-term vision."),
                h("li", null, "Finally, the players who come to Lichess to have fun, relax and learn, without whom this would all be pointless!")),
            h("h2", null, "Links"),
            h("ul", { className: "about_links" },
                h("li", null, externalLink('Github', 'https://github.com/lichess-org/lichobile')),
                h("li", null, externalLink('Contribute', 'https://live.chess-online.com/help/contribute')),
                h("li", null, externalLink('Contact', 'https://live.chess-online.com/contact')),
                h("li", null, externalLink('Terms of Service', 'https://live.chess-online.com/terms-of-service')),
                h("li", null, externalLink('Privacy Policy', 'https://live.chess-online.com/privacy')),
                h("li", null, externalLink('Database', 'https://database.lichess.org/')),
                h("li", null, externalLink('live.chess-online.com/about', 'https://live.chess-online.com/about')))));
    }
};
function externalLink(text, url) {
    return h('a', {
        className: 'external_link',
        onclick: () => window.open(url, '_blank'),
    }, text);
}
function internalLink(text, route) {
    return h('a', {
        onclick: () => router.set(route)
    }, text);
}

export { about as default };
//# sourceMappingURL=about-CqkXicxU.js.map
