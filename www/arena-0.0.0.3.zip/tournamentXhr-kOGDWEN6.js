import { f as fetchJSON } from './main.js';

function currentTournaments() {
    return fetchJSON('/tournament', {}, true);
}
function tournament(id) {
    return fetchJSON('/tournament/' + id, { query: { socketVersion: 1, scores: 0 } }, true);
}
function reload(id, page) {
    return fetchJSON('/tournament/' + id, {
        method: 'GET',
        query: {
            partial: 1,
            scores: 0,
            ...(page ? { page } : {})
        },
    });
}
function loadPage(id, p) {
    return fetchJSON('/tournament/' + id + '/standing/' + p, { query: { scores: 0 } });
}
function join(id, password, team) {
    return fetchJSON('/tournament/' + id + '/join', {
        method: 'POST',
        body: JSON.stringify({
            p: password || null,
            team: team || null
        })
    }, true);
}
function withdraw(id) {
    return fetchJSON('/tournament/' + id + '/withdraw', { method: 'POST' }, true);
}
function playerInfo(tournamentId, playerId) {
    return fetchJSON('/tournament/' + tournamentId + '/player/' + playerId, {}, true);
}
function create(name, variant, position, mode, clockTime, clockIncrement, minutes, waitMinutes, isPrivate, password) {
    return fetchJSON('/tournament/new', {
        method: 'POST',
        body: JSON.stringify({
            name,
            variant,
            position,
            mode,
            clockTime,
            clockIncrement,
            minutes,
            waitMinutes,
            private: isPrivate,
            password
        })
    }, true);
}

export { currentTournaments as a, create as c, join as j, loadPage as l, playerInfo as p, reload as r, tournament as t, withdraw as w };
//# sourceMappingURL=tournamentXhr-kOGDWEN6.js.map
