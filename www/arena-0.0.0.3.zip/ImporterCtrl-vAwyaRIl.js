import { J as prop, r as redraw, g as settings, q as router, K as handleXhrError, f as fetchJSON, aw as serializeQueryParameters, ax as config } from './main.js';

function ImporterCtrl() {
    const importing = prop(false);
    function submitOnline(pgn, analyse) {
        const data = { pgn };
        if (analyse)
            data.analyse = '1';
        return fetchJSON('/import', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/vnd.lichess.v' + config.apiVersion + '+json'
            },
            body: serializeQueryParameters(data)
        }, true);
    }
    return {
        importGame(pgn) {
            importing(true);
            redraw();
            submitOnline(pgn, settings.importer.analyse())
                .then(data => {
                router.set(`/analyse/online${data.url.round}`);
            })
                .catch(err => {
                importing(false);
                redraw();
                console.error(err);
                handleXhrError(err);
            });
        },
        importing
    };
}

export { ImporterCtrl as I };
//# sourceMappingURL=ImporterCtrl-vAwyaRIl.js.map
