import { f as fetchJSON, bT as fetchText } from './main.js';

function list(category = 'all', order = 'hot', page = 1, feedback = false) {
    return fetchJSON(`/study/${category}/${order}`, {
        query: {
            page
        }
    }, feedback);
}
function search(q, page = 1, feedback = false) {
    return fetchJSON('/study/search', {
        query: {
            q,
            page
        }
    }, feedback);
}
function load(id, chapterId) {
    return fetchJSON(`/study/${id}` + (chapterId ? `/${chapterId}` : ''));
}
function studyPGN(id) {
    return fetchText(`/study/${id}.pgn`, undefined, true);
}
function studyChapterPGN(id, chapterId) {
    return fetchText(`/study/${id}/${chapterId}.pgn`, undefined, true);
}

export { studyChapterPGN as a, search as b, load as c, list as l, studyPGN as s };
//# sourceMappingURL=studyXhr-CPiJUv6u.js.map
