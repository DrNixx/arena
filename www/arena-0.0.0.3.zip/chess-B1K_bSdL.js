import { bW as askWorker } from './main.js';

const worker = new Worker('vendor/scalachess.js');
// warmup
worker.postMessage({ topic: 'init', payload: { variant: 'standard' } });
function uniqId() {
    return String(performance.now());
}
function init(payload) {
    return askWorker(worker, { topic: 'init', payload });
}
function situation(payload) {
    return askWorker(worker, { topic: 'situation', payload, reqid: uniqId() });
}
function move(payload) {
    return askWorker(worker, { topic: 'move', payload, reqid: uniqId() });
}
function drop(payload) {
    return askWorker(worker, { topic: 'drop', payload, reqid: uniqId() });
}
function threefoldTest(payload) {
    return askWorker(worker, { topic: 'threefoldTest', payload });
}
function pgnDump(payload) {
    return askWorker(worker, { topic: 'pgnDump', payload });
}

export { drop as d, init as i, move as m, pgnDump as p, situation as s, threefoldTest as t };
//# sourceMappingURL=chess-B1K_bSdL.js.map
