import { F as viewFadeIn, G as dropShadowHeader, o as i18n, s as socket, m as h, O as formWidgets, g as settings } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { I as ImporterCtrl } from './ImporterCtrl-vAwyaRIl.js';

const ImporterScreen = {
    oninit() {
        socket.createDefault();
        this.ctrl = ImporterCtrl();
    },
    oncreate: viewFadeIn,
    view() {
        const header = dropShadowHeader(i18n('importGame'));
        const body = renderBody(this.ctrl);
        return layout.free(header, body);
    }
};
function renderBody(ctrl) {
    return h('div.gameImporter.native_scroller', [
        h('p', i18n('importGameExplanation')),
        h('form', {
            onsubmit: (e) => {
                e.preventDefault();
                const target = e.target;
                const pgn = target[0].value;
                if (pgn)
                    ctrl.importGame(pgn);
            }
        }, [
            h('label', i18n('pasteThePgnStringHere') + ' :'),
            h('textarea.pgnImport'),
            formWidgets.renderCheckbox(i18n('requestAComputerAnalysis'), 'analyse', settings.importer.analyse),
            h('button.fatButton', ctrl.importing() ?
                h('div.fa.fa-hourglass-half') : i18n('importGame'))
        ])
    ]);
}

export { ImporterScreen as default };
//# sourceMappingURL=importer-BmXRijVr.js.map
