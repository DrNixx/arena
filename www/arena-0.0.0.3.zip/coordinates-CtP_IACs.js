import { g as settings, a6 as Chessground, aY as INITIAL_FEN, av as asyncStorage, r as redraw, cJ as randomColor, a0 as header, o as i18n, m as h, x as ontap, F as viewFadeIn } from './main.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import { l as layout } from './layout-DoxuEk9x.js';

const FILES = 'abcdefgh';
const RANKS = '12345678';
const duration = 1000 * 30;
const storeKey = 'coordinates';
const storeMaxScores = 100;
class CoordCtrl {
    constructor() {
        this.coords = [];
        this.wrongAnswer = false;
        this.tempWrong = false;
        this.score = 0;
        this.progress = 100;
        this.started = false;
        this.orientation = this.getOrientation(settings.coordinates.colorChoice());
        this.chessground = new Chessground({
            fen: INITIAL_FEN,
            orientation: this.orientation,
            coordinates: false,
            movable: {
                free: false,
                color: null,
            },
            events: {
                select: (key) => this.handleSelect(key),
            },
        });
        asyncStorage.get(storeKey)
            .then(saved => {
            if (saved) {
                this.averageScores = getAverage(saved);
                redraw();
            }
        });
    }
    getOrientation(color) {
        return color === 'random' ? randomColor() : color;
    }
    updateOrientation() {
        this.orientation = this.getOrientation(settings.coordinates.colorChoice());
        this.chessground.set({
            orientation: this.orientation
        });
        redraw();
    }
    nextCoord() {
        return (FILES[Math.round(Math.random() * (FILES.length - 1))] +
            RANKS[Math.round(Math.random() * (RANKS.length - 1))]);
    }
    pushCoords() {
        while (this.coords.length < 3) {
            const c = this.nextCoord();
            if (this.coords.indexOf(c) === -1) {
                this.coords.push(c);
            }
        }
    }
    handleSelect(key) {
        if (this.started) {
            if (key === this.coords[0]) {
                this.coords.shift();
                this.pushCoords();
                this.wrongAnswer = false;
                this.tempWrong = false;
                this.score++;
            }
            else {
                this.wrongAnswer = true;
                this.tempWrong = true;
                setTimeout(() => {
                    this.tempWrong = false;
                    redraw();
                }, 350);
            }
            redraw();
        }
    }
    startTraining() {
        if (!this.started) {
            this.started = true;
            this.pushCoords();
            this.progress = 0;
            this.score = 0;
            this.wrongAnswer = false;
            this.tempWrong = false;
            this.updateOrientation();
            const startedAt = performance.now();
            const frame = () => {
                const spent = Math.min(duration, performance.now() - startedAt);
                if (spent >= duration) {
                    clearInterval(id);
                    this.progress = 100;
                    this.started = false;
                    this.wrongAnswer = false;
                    this.tempWrong = false;
                    this.lastScore = this.score;
                    this.coords = [];
                    this.saveScore().then(s => {
                        this.averageScores = getAverage(s);
                        redraw();
                    });
                    redraw();
                }
                else {
                    this.progress = (100 * spent) / duration;
                    redraw();
                }
            };
            const id = setInterval(frame, 50);
            redraw();
        }
    }
    saveScore() {
        return asyncStorage.get(storeKey)
            .then(saved => {
            saved = saved || {};
            const scores = saved[this.orientation] || [];
            if (scores.length >= storeMaxScores) {
                scores.shift();
            }
            scores.push(this.score);
            saved[this.orientation] = scores;
            return saved;
        })
            .then(newState => asyncStorage.set(storeKey, newState));
    }
}
function getAverage(s) {
    return {
        white: s.white ? computeAverage(s.white) : null,
        black: s.black ? computeAverage(s.black) : null,
    };
}
function computeAverage(n) {
    return Math.round((n.reduce((t, x) => t + x, 0) / n.length) * 100) / 100;
}

function view(ctrl) {
    const store = settings.coordinates;
    const renderCoord = (e, i) => {
        return h('div.next_coord', {
            className: ('coord' + (i + 1)) + (ctrl.tempWrong === true && i === 0 ? ' nope' : ''),
        }, e);
    };
    return layout.board(header(i18n('coordinateTraining')), [
        h('div.coord-trainer__board_wrapper', [
            h('div.coord-trainer__progress', [
                h('div.coord-trainer__progress_bar', {
                    className: ctrl.wrongAnswer ? 'nope' : '',
                    style: { width: ctrl.progress + '%' }
                }),
            ]),
            h('div.coord-trainer__coords', [
                ...ctrl.coords.map(renderCoord),
            ]),
            h(Board, {
                variant: 'standard',
                chessground: ctrl.chessground
            }),
        ]),
        h('div.table.training-tableWrapper', [
            h('div.training-table.coord-trainer__table.native_scroller.box', [
                ctrl.started ?
                    h('div.coord-trainer__score', {
                        className: ctrl.wrongAnswer ? 'nope' : '',
                    }, ctrl.score) :
                    h.fragment({}, [
                        ctrl.lastScore !== undefined ? h('div.coord-trainer__previous', h.trust(i18n('lastScore', `<strong>${ctrl.lastScore}</strong>`))) : null,
                        ctrl.averageScores ? h('div.coord-trainer__average', [
                            h('div', h.trust(i18n('averageScoreAsWhiteX', `<strong>${ctrl.averageScores.white !== null ? ctrl.averageScores.white : '?'}</strong>`))),
                            h('div', h.trust(i18n('averageScoreAsBlackX', `<strong>${ctrl.averageScores.black !== null ? ctrl.averageScores.black : '?'}</strong>`))),
                        ]) : null,
                        h('button.start.defaultButton.fat.wrap', { oncreate: ontap(() => ctrl.startTraining()) }, i18n('startTraining')),
                    ]),
            ]),
            h('div.actions_bar.coord-trainer__colorChoice', ['black', 'random', 'white'].map(o => {
                return h('i.action_bar_button.' + o, {
                    className: o === store.colorChoice() ? 'selected' : '',
                    oncreate: ontap(() => {
                        if (!ctrl.started) {
                            store.colorChoice(o);
                            ctrl.updateOrientation();
                        }
                    })
                });
            })),
        ]),
    ]);
}

var coordinates = {
    oninit() {
        this.coordCtrl = new CoordCtrl();
    },
    oncreate: viewFadeIn,
    view() {
        return view(this.coordCtrl);
    },
};

export { coordinates as default };
//# sourceMappingURL=coordinates-CtP_IACs.js.map
