import { ah as registerPlugin, ax as config, b as session, f as fetchJSON, r as redraw, k as hasNetwork, K as handleXhrError, J as prop, q as router, aw as serializeQueryParameters, D as challengeForm, I as backButton, G as dropShadowHeader, m as h, o as i18n, aB as formatDate, aC as lichessAssetSrc, c as fromNow, aD as formatDuration, p as ontapY, y as plural, z as gameIcon, aE as progress } from './main.js';
import { l as linkify } from './html-EBv26hf5.js';
import { p as perfTypes, a as provisionalDeviation } from './perfs-BLfNpglP.js';
import { c as countries } from './countries-D-Tn65Re.js';
import { b as user, c as unblock, d as block, u as unfollow, f as follow } from './userXhr-i6lHGN-w.js';

const Browser = registerPlugin('Browser', {
    web: () => import('./web-BJzL1xPD.js').then(m => new m.BrowserWeb()),
});

function createToken() {
    return fetchJSON('/auth/token', { method: 'POST' }, true);
}
function openWebsitePage(path, withoutAuth = false) {
    const anonUrl = `${config.apiEndPoint}${path}`;
    // we don't want to open a internal browser in kid mode since it is not
    // protected like the device browser can be
    if (!session.isKidMode()) {
        if (session.isConnected() && !withoutAuth) {
            createToken()
                .then((data) => {
                // we must use the Browser plugin to open authenticated pages because window.open
                // doesn't work inside a promise
                Browser.open({ url: `${data.url}?referrer=${encodeURIComponent(path)}` });
            })
                .catch(() => {
                Browser.open({ url: anonUrl });
            });
        }
        else {
            Browser.open({ url: anonUrl });
        }
    }
    else {
        openExternalBrowser(anonUrl);
    }
}
function openExternalBrowser(url) {
    window.open(url, '_blank');
}

function UserCtrl(userId) {
    const user$1 = prop(null);
    function setNewUserState(newData) {
        Object.assign(user$1() ?? {}, newData);
        redraw();
    }
    // by default, using session user so it can be displayed offline
    const sessionUser = session.get();
    if (sessionUser && sessionUser.id === userId) {
        user$1(sessionUser);
    }
    user(userId)
        .then(data => {
        user$1(data);
        redraw();
    })
        .then(session.refresh)
        .catch(err => {
        if (hasNetwork()) {
            handleXhrError(err);
        }
    });
    return {
        user: user$1,
        isMe: () => session.getUserId() === userId,
        toggleFollowing() {
            const u = user$1();
            if (u && isFullUser(u) && u.following)
                unfollow(u.id).then(setNewUserState);
            else if (u)
                follow(u.id).then(setNewUserState);
        },
        toggleBlocking() {
            const u = user$1();
            if (u && isFullUser(u) && u.blocking)
                unblock(u.id).then(setNewUserState);
            else if (u)
                block(u.id).then(setNewUserState);
        },
        goToGames() {
            const u = user$1();
            if (u) {
                const params = {
                    username: u.username,
                };
                if (u.patron)
                    params.patron = '1';
                if (u.title)
                    params.title = u.title;
                router.set(`/@/${u.id}/games?${serializeQueryParameters(params)}`);
            }
        },
        goToUserTV() {
            const u = user$1();
            if (u) {
                router.set(`/@/${u.id}/tv`);
            }
        },
        challenge() {
            const u = user$1();
            if (u) {
                challengeForm.open(u.id);
            }
        },
        composeMessage() {
            const u = user$1();
            if (u) {
                router.set(`/inbox/new/${u.id}`);
            }
        },
        followers() {
            const u = user$1();
            if (u) {
                const params = {
                    username: u.username,
                };
                if (u.title)
                    params.title = u.title;
                router.set(`/@/${u.id}/related?${serializeQueryParameters(params)}`);
            }
        },
    };
}
function isFullUser(user) {
    return user.count !== undefined;
}

function header(user, ctrl) {
    const title = userTitle(user.online, user.patron, user.username, user.title);
    const backButton$1 = !ctrl.isMe() ? backButton(title) : null;
    return dropShadowHeader(backButton$1 ? null : title, backButton$1);
}
function userTitle(online, patron, username, title) {
    const status = hasNetwork() && online ? 'online' : 'offline';
    const icon = patron ?
        h("span", { className: 'userStatus patron ' + status, "data-icon": "\uE019" }) :
        h("span", { className: 'fa fa-circle userStatus ' + status });
    const isBot = title === 'BOT';
    return h('div.title', [
        icon,
        h('span', [
            ...(title ? [h('span.userTitle' + (isBot ? '.bot' : ''), title), ' '] : []),
            username
        ])
    ]);
}
function profile(user, ctrl) {
    return (h("div", { id: "userProfile", className: "native_scroller page" },
        renderWarnings(user),
        renderProfile(user),
        renderStats(user),
        renderWebsiteLinks(ctrl, user),
        renderRatings(user),
        renderActions(ctrl, user)));
}
function renderWarnings(user) {
    if (!user.tosViolation)
        return null;
    return (h("section", { className: "warnings" }, user.tosViolation ?
        h("div", { className: "warning", "data-icon": "j" }, i18n('thisAccountViolatedTos')) : null));
}
function renderProfile(user) {
    if (user.profile) {
        const fullname = [user.profile.firstName, user.profile.lastName].filter(x => x != null).join(' ');
        const country = user.profile.country != null ? countries[user.profile.country] : null;
        const location = user.profile.location;
        const memberSince = i18n('memberSince') + ' ' + formatDate(new Date(user.createdAt));
        return (h("section", { className: "profileSection" },
            fullname ?
                h("h3", { className: "fullname" }, fullname) : null,
            user.profile.bio != null ?
                h("p", { className: "profileBio" }, h.trust(linkify(user.profile.bio))) : null,
            h("div", null,
                user.profile.fideRating != null ?
                    h("p", null,
                        "FIDE rating: ",
                        h("strong", null, user.profile.fideRating)) : null,
                h("p", { className: "location" },
                    location,
                    country != null && hasNetwork() ?
                        h("span", { className: "country" },
                            location != null ? ',' : '',
                            " ",
                            h("img", { className: "flag", src: lichessAssetSrc(`images/flags/${user.profile.country}.png`) }),
                            country) : null),
                h("p", null, memberSince),
                user.seenAt ?
                    h("p", null, h.trust(i18n('lastSeenActive', `<small>${fromNow(new Date(user.seenAt))}</small>`))) : null)));
    }
    else
        return null;
}
function renderWebsiteLinks(ctrl, user) {
    return (h("section", { className: "profileSection websiteLinks" },
        ctrl.isMe() ?
            h("p", null,
                h("a", { className: "external_link", oncreate: ontapY(() => openWebsitePage('/account/profile')) }, i18n('editProfile'))) :
            h("p", null,
                h("a", { className: "external_link", oncreate: ontapY(() => openWebsitePage(`/@/${user.id}`)) }, "More on Chess-Online")),
        user.patron ?
            h("p", null,
                h("a", { className: "external_link", oncreate: ontapY(() => openWebsitePage('/patron')) }, "Chess-Online Patron")) : null));
}
function renderStats(user) {
    let tvTime = null;
    const totalPlayTime = user.playTime ? i18n('tpTimeSpentPlaying', formatDuration(user.playTime.total)) : null;
    if (isFullUser(user)) {
        tvTime = user.playTime && user.playTime.tv > 0 ? i18n('tpTimeSpentOnTV', formatDuration(user.playTime.tv)) : null;
    }
    return (h("section", { className: "profileSection" },
        isFullUser(user) && user.completionRate ?
            h("p", null, i18n('gameCompletionRate', user.completionRate + '%')) : null,
        totalPlayTime ?
            h("p", null, totalPlayTime) : null,
        tvTime ?
            h("p", null, tvTime) : null));
}
function userPerfs(user) {
    const res = perfTypes.map(p => {
        const perf = user.perfs[p[0]];
        return {
            key: p[0],
            name: p[1],
            perf: perf || '-'
        };
    });
    if (user.perfs.puzzle)
        res.push({
            key: 'puzzle',
            name: 'Training',
            perf: user.perfs.puzzle
        });
    return res;
}
function variantPerfAvailable(key, perf) {
    return (key !== 'puzzle' && perf.games > 0);
}
function renderPerf(key, name, perf, user) {
    const avail = variantPerfAvailable(key, perf);
    return h('div', {
        className: 'profilePerf' + (avail ? ' nav' : ''),
        'data-icon': gameIcon(key),
        oncreate: ontapY(() => {
            if (avail)
                router.set(`/@/${user.id}/${key}/perf`);
        })
    }, [
        h('span.name', name),
        h('div.rating', [
            perf.rating,
            perf.rd >= provisionalDeviation ? '?' : null,
            progress(perf.prog),
            h('span.nb', '/ ' + perf.games)
        ])
    ]);
}
function renderRatings(user) {
    function isShowing(p) {
        return [
            'blitz', 'bullet', 'rapid', 'classical', 'correspondence'
        ].indexOf(p.key) !== -1 || p.perf.games > 0;
    }
    return (h("section", { id: "userProfileRatings", className: "perfs" }, userPerfs(user).filter(isShowing).map(p => renderPerf(p.key, p.name, p.perf, user))));
}
function renderActions(ctrl, user) {
    return (h("section", { id: "userProfileActions", className: "items_list_block noPadding" },
        isFullUser(user) ?
            h("div", { className: "list_item nav", oncreate: ontapY(ctrl.goToGames) }, plural('nbGames', user.count.all)) : null,
        session.isConnected() && ctrl.isMe() ?
            h("div", { className: "list_item", oncreate: ontapY(() => router.set('/inbox')) },
                h("span", { className: "fa fa-envelope" }),
                i18n('inbox')) : null,
        session.isConnected() && ctrl.isMe() ?
            h("div", { className: "list_item", oncreate: ontapY(() => router.set('/account/preferences')) },
                h("span", { className: "fa fa-cog" }),
                i18n('preferences')) : null,
        session.isConnected() && ctrl.isMe() ?
            h("div", { className: "list_item nav", oncreate: ontapY(ctrl.followers) },
                h("span", { className: "fa fa-users" }),
                i18n('friends')) : null,
        !ctrl.isMe() ? h("div", { className: "list_item nav", "data-icon": "1", oncreate: ontapY(ctrl.goToUserTV) }, i18n('watchGames')) : null,
        session.isConnected() && !ctrl.isMe() ?
            h("div", { className: "list_item", "data-icon": "U", oncreate: ontapY(ctrl.challenge) }, i18n('challengeToPlay')) : null,
        session.isConnected() && !ctrl.isMe() ?
            h("div", { className: "list_item nav", oncreate: ontapY(ctrl.composeMessage) },
                h("span", { className: "fa fa-comment" }),
                i18n('composeMessage')) : null,
        session.isConnected() && isFullUser(user) && user.followable && !ctrl.isMe() ?
            h("div", { className: ['list_item', user.blocking ? 'disabled' : ''].join(' ') },
                h("div", { className: "check_container" },
                    h("label", { htmlFor: "user_following" }, i18n('follow')),
                    h("input", { id: "user_following", type: "checkbox", checked: user.following, disabled: user.blocking, onchange: ctrl.toggleFollowing }))) : null,
        session.isConnected() && isFullUser(user) && !ctrl.isMe() ?
            h("div", { className: ['list_item', user.following ? 'disabled' : ''].join(' ') },
                h("div", { className: "check_container" },
                    h("label", { htmlFor: "user_blocking" }, i18n('block')),
                    h("input", { id: "user_blocking", type: "checkbox", checked: user.blocking, disabled: user.following, onchange: ctrl.toggleBlocking }))) : null,
        session.isConnected() && !ctrl.isMe() ?
            h("div", { className: "list_item", "data-icon": "!", oncreate: ontapY(() => openWebsitePage(`/report?username=${user.username}`)) }, i18n('reportXToModerators', user.username)) : null,
        session.isConnected() && ctrl.isMe() ?
            h("div", { className: "list_item", oncreate: ontapY(session.logout) },
                h("span", { className: "fa fa-power-off" }),
                i18n('logOut')) : null));
}

export { UserCtrl as U, openWebsitePage as a, header as h, openExternalBrowser as o, profile as p, userTitle as u };
//# sourceMappingURL=userView-BRulENS5.js.map
