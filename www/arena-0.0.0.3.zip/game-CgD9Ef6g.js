import { o as i18n, ab as fixCrazySan, Q as getVariant, g as settings, bN as secondsToMinutes, y as plural } from './main.js';
import { s as shortPerfTitle } from './perfs-BLfNpglP.js';

// https://github.com/lichess-org/scalachess/blob/master/src/main/scala/Status.scala
const ids = {
    created: 10,
    started: 20,
    aborted: 25,
    mate: 30,
    resign: 31,
    stalemate: 32,
    timeout: 33,
    draw: 34,
    outoftime: 35,
    cheat: 36,
    noStart: 37,
    unknownFinish: 38,
    variantEnd: 60
};
function started(data) {
    return data.game.status.id >= ids.started;
}
function finished(data) {
    return data.game.status.id >= ids.mate;
}
function aborted(data) {
    return data.game.status.id === ids.aborted;
}
function resigned(data) {
    return data.game.status.id === ids.resign;
}
function toLabel(status, turns, winner, variant) {
    switch (status) {
        case 'started':
            return i18n('playingRightNow');
        case 'aborted':
            return i18n('gameAborted');
        case 'mate':
            return i18n('checkmate');
        case 'resign':
            return i18n(winner === 'white' ? 'blackResigned' : 'whiteResigned');
        case 'stalemate':
            return i18n('stalemate');
        case 'timeout':
            switch (winner) {
                case 'white':
                    return i18n('blackLeftTheGame');
                case 'black':
                    return i18n('whiteLeftTheGame');
                default:
                    return i18n('draw');
            }
        case 'draw':
            return i18n('draw');
        case 'outoftime':
            return `${turns % 2 === 0 ? i18n('whiteTimeOut') : i18n('blackTimeOut')}${winner ? '' : ` • ${i18n('draw')}`}`;
        case 'noStart':
            return (winner === 'white' ? 'Black' : 'White') + ' didn\'t move';
        case 'unknownFinish':
            return i18n('finished');
        case 'cheat':
            return 'Cheat detected';
        case 'variantEnd':
            switch (variant) {
                case 'kingOfTheHill':
                    return 'King in the center';
                case 'threeCheck':
                    return 'Three checks';
                default:
                    return 'Variant ending';
            }
        default:
            return status;
    }
}
var gameStatus = {
    ids,
    started,
    finished,
    aborted,
    resigned,
    toLabel
};

function empty(a) {
    return !a || a.length === 0;
}
function renderEval(e) {
    e = Math.max(Math.min(Math.round(e / 10) / 10, 99), -99);
    return (e > 0 ? '+' : '') + e;
}
const serverNodes = 4e6;
function getBestEval(evs) {
    const serverEv = evs.server, localEv = evs.client;
    if (!serverEv)
        return localEv;
    if (!localEv)
        return serverEv;
    // Prefer localEv if it exeeds fishnet node limit or finds a better mate.
    if (localEv.nodes > serverNodes ||
        (typeof localEv.mate !== 'undefined' && (typeof serverEv.mate === 'undefined' || Math.abs(localEv.mate) < Math.abs(serverEv.mate))))
        return localEv;
    return serverEv;
}
function isSynthetic(data) {
    return data.game.id === 'synthetic';
}
function autoScroll(movelist) {
    if (!movelist)
        return;
    requestAnimationFrame(() => {
        const plyEl = movelist.querySelector('.current');
        if (plyEl) {
            movelist.scrollTop = plyEl.offsetTop - movelist.offsetHeight / 2 + plyEl.offsetHeight / 2;
        }
        else {
            movelist.scrollTop = 0;
        }
    });
}
function plyToTurn(ply) {
    return Math.floor((ply - 1) / 2) + 1;
}
function nodeFullName(node) {
    if (node.san)
        return plyToTurn(node.ply) + (node.ply % 2 === 1 ? '.' : '...') + ' ' + fixCrazySan(node.san);
    return 'Initial position';
}
function pieceCount(fen) {
    const parts = fen.split(/\s/);
    return parts[0].split(/[nbrqkp]/i).length - 1;
}
function tablebasePieces(variant) {
    switch (variant) {
        case 'standard':
        case 'fromPosition':
        case 'chess960':
            return 7;
        case 'atomic':
        case 'antichess':
            return 6;
        default:
            return 0;
    }
}
function tablebaseGuaranteed(variant, fen) {
    return pieceCount(fen) <= tablebasePieces(variant);
}
function defined(v) {
    return v !== undefined;
}
function plyColor(ply) {
    return (ply % 2 === 0) ? 'white' : 'black';
}
function isEvalBetter(a, b) {
    return a.depth > b.depth || (a.depth === b.depth && a.nodes > b.nodes);
}

const analysableVariants = ['standard', 'crazyhouse', 'chess960', 'fromPosition', 'kingOfTheHill', 'threeCheck', 'atomic', 'antichess', 'horde', 'racingKings'];
function parsePossibleMoves(dests) {
    if (!dests)
        return {};
    const dec = {};
    if (typeof dests === 'string')
        dests.split(' ').forEach(ds => {
            dec[ds.slice(0, 2)] = ds.slice(2).match(/.{2}/g);
        });
    else
        for (const k in dests)
            dec[k] = dests[k].match(/.{2}/g);
    return dec;
}
function playable(data) {
    return data.game.source !== 'import' && data.game.status.id < gameStatus.ids.aborted;
}
function isPlayerPlaying(data) {
    return playable(data) && !data.player.spectator;
}
function isPlayerTurn(data) {
    return isPlayerPlaying(data) && data.game.player === data.player.color;
}
function mandatory(data) {
    return !!data.tournament;
}
function playedTurns(data) {
    return data.game.turns - (data.game.startedAtTurn || 0);
}
function bothPlayersHavePlayed(data) {
    return playedTurns(data) > 1;
}
function abortable(data) {
    return playable(data) && !bothPlayersHavePlayed(data) && !mandatory(data);
}
function takebackable(data) {
    return !!(playable(data) && data.takebackable && !data.tournament && playedTurns(data) > 1 && !data.player.proposingTakeback && !data.opponent.proposingTakeback);
}
function drawable(data) {
    return playable(data) && data.game.turns >= 2 && !data.player.offeringDraw && !data.opponent.ai && !data.opponent.offeringDraw;
}
function berserkableBy(data) {
    return data.tournament &&
        data.tournament.berserkable &&
        isPlayerPlaying(data) &&
        playedTurns(data) < 2;
}
function resignable(data) {
    return playable(data) && !abortable(data);
}
function forceResignable(data) {
    return !data.opponent.ai && data.clock && data.opponent.isGone && resignable(data);
}
function moretimeable(data) {
    return data.clock && isPlayerPlaying(data) && !mandatory(data);
}
function imported(data) {
    return data.game.source === 'import';
}
function replayable(data) {
    return imported(data) || gameStatus.finished(data);
}
function userAnalysable(data) {
    return settings.analyse.supportedVariants.indexOf(data.game.variant.key) !== -1 && playable(data) && (!data.clock || !isPlayerPlaying(data));
}
function analysable(data) {
    return replayable(data) && playedTurns(data) > 4 && analysableVariants.indexOf(data.game.variant.key) !== -1;
}
function getPlayer(data, color) {
    if (data.player.color === color)
        return data.player;
    if (data.opponent.color === color)
        return data.opponent;
}
function setIsGone(data, color, isGone) {
    const player = getPlayer(data, color);
    if (player) {
        isGone = isGone && !player.ai;
        player.isGone = isGone;
        if (!isGone && player.user)
            player.user.online = true;
    }
}
function setOnGame(data, color, onGame) {
    const player = getPlayer(data, color);
    if (player) {
        onGame = onGame || !!player.ai;
        player.onGame = onGame;
        if (onGame)
            setIsGone(data, color, false);
    }
}
function nbMoves(data, color) {
    return Math.floor((data.game.turns + (color === 'white' ? 1 : 0)) / 2);
}
function result(data) {
    if (gameStatus.finished(data))
        switch (data.game.winner) {
            case 'white':
                return '1-0';
            case 'black':
                return '0-1';
            default:
                return '½-½';
        }
    return '*';
}
// FIXME
function time(data) {
    if (data.clock) {
        const min = secondsToMinutes(data.clock.initial);
        const t = min === 0.25 ? '¼' : min === 0.5 ? '½' : min === 0.75 ? '¾' : min.toString();
        return t + '+' + data.clock.increment;
    }
    else if (data.correspondence) {
        return plural('nbDays', data.correspondence.daysPerTurn);
    }
    else {
        return '∞';
    }
}
function title(data) {
    const mode = data.game.offline ?
        i18n('offline') :
        data.game.rated ? i18n('rated') : i18n('casual');
    const perf = data.game.perf && shortPerfTitle(data.game.perf);
    const variant = getVariant(data.game.variant.key);
    const name = perf || (variant ? (variant.tinyName || variant.shortName || variant.name) : '?');
    const t = time(data);
    return data.game.source === 'import' ?
        'Import • Standard' :
        `${t} • ${name} • ${mode}`;
}
function publicUrl(data) {
    return 'https://live.chess-online.com/' + data.game.id;
}
function publicAnalyseUrl(data) {
    return 'https://live.chess-online.com/' + data.game.id + '/' + data.orientation;
}
function publicGIFUrl(data) {
    return `https://live.chess-online.com/game/export/gif/${data.game.id}.gif`;
}
function isSupportedVariant(data) {
    return settings.game.supportedVariants.indexOf(data.game.variant.key) !== -1;
}
function forecastable(data) {
    return playable(data) && !isSynthetic(data) && data.game.speed === 'correspondence';
}

export { publicGIFUrl as A, analysable as B, renderEval as C, getBestEval as D, nodeFullName as E, empty as F, plyToTurn as G, tablebaseGuaranteed as H, defined as I, isSynthetic as J, autoScroll as K, isEvalBetter as L, analysableVariants as M, plyColor as N, isSupportedVariant as a, parsePossibleMoves as b, playedTurns as c, setIsGone as d, drawable as e, getPlayer as f, gameStatus as g, berserkableBy as h, isPlayerPlaying as i, replayable as j, forceResignable as k, resignable as l, moretimeable as m, nbMoves as n, publicUrl as o, playable as p, isPlayerTurn as q, result as r, setOnGame as s, title as t, userAnalysable as u, forecastable as v, abortable as w, takebackable as x, time as y, publicAnalyseUrl as z };
//# sourceMappingURL=game-CgD9Ef6g.js.map
