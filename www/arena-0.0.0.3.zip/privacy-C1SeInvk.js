import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, b as session, m as h, O as formWidgets } from './main.js';
import { C as Challenge, b as ChallengeChoices } from './prefs-CFmBYsqy.js';
import { l as layout } from './layout-DoxuEk9x.js';

var privacy = {
    oncreate: viewSlideIn,
    oninit() {
        this.ctrl = {
            follow: session.lichessBackedProp('prefs.follow', true),
            challenge: session.lichessBackedProp('prefs.challenge', Challenge.ALWAYS)
        };
    },
    view() {
        const ctrl = this.ctrl;
        const header = dropShadowHeader(null, backButton(i18n('privacy')));
        return layout.free(header, renderBody(ctrl));
    }
};
function renderBody(ctrl) {
    return [
        h('ul.native_scroller.page.settings_list.game', [
            h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('letOtherPlayersFollowYou'), formWidgets.booleanChoice, ctrl.follow)),
            h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('letOtherPlayersChallengeYou'), ChallengeChoices, ctrl.challenge))
        ])
    ];
}

export { privacy as default };
//# sourceMappingURL=privacy-C1SeInvk.js.map
