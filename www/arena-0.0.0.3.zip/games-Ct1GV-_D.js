import { m as h, y as plural, h as throttle, p as ontapY, w as spinner, E as getLI, q as router, g as settings, d as debounce, r as redraw, K as handleXhrError, c as fromNow, ay as batchRequestAnimationFrame, az as toggleGameBookmark, aj as positionsCache, b as session, aA as viewSlideIn, a0 as header, I as backButton, s as socket } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { G as GameItem } from './GameItem-Qant7ELU.js';
import { g as games, b as user } from './userXhr-i6lHGN-w.js';
import { u as userTitle } from './userView-BRulENS5.js';
import './game-CgD9Ef6g.js';
import './perfs-BLfNpglP.js';
import './html-EBv26hf5.js';
import './countries-D-Tn65Re.js';

function renderBody(ctrl) {
    return (h("div", { className: "userGamesWrapper" },
        h("div", { className: "select_input select_games_filter" },
            h("label", { htmlFor: "filterGames" }),
            h("select", { id: "filterGames", onchange: ctrl.onFilterChange }, ctrl.scrollState.availableFilters.map(f => {
                return (h("option", { value: f.key, selected: ctrl.scrollState.currentFilter === f.key }, plural(f.label, f.count)));
            }))),
        renderAllGames(ctrl)));
}
function getButton(e) {
    const target = e.target;
    return target.tagName === 'BUTTON' ? target : undefined;
}
function onTap(ctrl, e) {
    const starButton = getButton(e);
    const tournamentLink = e.target?.closest('.tournament');
    const el = getLI(e);
    const id = el?.dataset.id;
    const playerId = el?.dataset.pid;
    if (id && starButton) {
        ctrl.toggleBookmark(id);
    }
    else if (tournamentLink) {
        const tid = tournamentLink.dataset.id;
        if (tid) {
            router.set(`/tournament/${tid}`);
        }
    }
    else {
        if (id) {
            ctrl.goToGame(id, playerId);
        }
    }
}
function renderAllGames(ctrl) {
    const { games, paginator } = ctrl.scrollState;
    return (h("div", { id: "scroller-wrapper", className: "native_scroller userGame-scroller box", oncreate: ontapY(e => onTap(ctrl, e), undefined, getLI), onscroll: throttle(ctrl.onScroll, 30) }, paginator ?
        h("ul", { className: "userGames", oncreate: ctrl.onGamesLoaded },
            games.map((g, i) => h(GameItem, {
                key: g.id,
                g,
                index: i,
                boardTheme: ctrl.boardTheme,
                userId: ctrl.scrollState.userId
            })),
            ctrl.scrollState.isLoadingNextPage ?
                h("li", { className: "list_item loadingNext" }, "loading...") : null) :
        h("div", { className: "loader_container" }, spinner.getVdom('monochrome'))));
}

const filters = {
    all: 'nbGames',
    rated: 'nbRated',
    win: 'nbWins',
    loss: 'nbLosses',
    draw: 'nbDraws',
    bookmark: 'nbBookmarks',
    me: 'nbGamesWithYou',
    import: 'nbImportedGames',
    playing: 'nbPlaying'
};
let cachedScrollState;
function UserGamesCtrl(userId, filter) {
    // used to restore scroll position only once from cached state
    let initialized = false;
    const cacheAvailable = cachedScrollState && userId === cachedScrollState.userId;
    const boardTheme = settings.general.theme.board();
    const scrollState = {
        userId,
        user: undefined,
        availableFilters: [],
        currentFilter: filter || 'all',
        games: [],
        paginator: undefined,
        isLoadingNextPage: false,
        scrollPos: 0
    };
    function prepareData(xhrData) {
        if (xhrData.paginator && xhrData.paginator.currentPageResults) {
            xhrData.paginator.currentPageResults.forEach(g => {
                g.date = fromNow(new Date(g.timestamp));
            });
        }
        return xhrData;
    }
    const loadUserAndFilters = (userData) => {
        scrollState.user = userData;
        const f = Object.keys(userData.count)
            .filter(k => Object.prototype.hasOwnProperty.call(filters, k) && (k === 'all' || userData.count[k] > 0))
            .map(k => {
            return {
                key: k,
                label: filters[k],
                count: scrollState.user ? scrollState.user.count[k] : 0
            };
        });
        scrollState.availableFilters = f;
    };
    const saveScrollState = debounce(() => {
        cachedScrollState = scrollState;
    }, 200);
    const loadInitialGames = (data) => {
        scrollState.paginator = data.paginator;
        scrollState.games = data.paginator.currentPageResults;
        setTimeout(() => {
            const scroller = document.getElementById('scroller-wrapper');
            if (scroller)
                scroller.scrollTop = 0;
        }, 50);
        redraw();
    };
    const loadNextPage = (page) => {
        scrollState.isLoadingNextPage = true;
        games(scrollState.userId, scrollState.currentFilter, page)
            .then(prepareData)
            .then(data => {
            scrollState.paginator = data.paginator;
            scrollState.isLoadingNextPage = false;
            scrollState.games = scrollState.games.concat(data.paginator.currentPageResults);
            saveScrollState();
            redraw();
        });
        redraw();
    };
    const onGamesLoaded = ({ dom }) => {
        if (cacheAvailable && !initialized) {
            batchRequestAnimationFrame(() => {
                dom.parentNode.scrollTop = cachedScrollState.scrollPos;
                initialized = true;
            });
        }
    };
    const onScroll = (e) => {
        const target = e.target;
        const content = target.firstChild;
        const paginator = scrollState.paginator;
        const nextPage = paginator && paginator.nextPage;
        if ((target.scrollTop + target.offsetHeight + 50) > content.offsetHeight) {
            // lichess doesn't allow for more than 39 pages
            if (!scrollState.isLoadingNextPage && nextPage && nextPage < 40) {
                loadNextPage(nextPage);
            }
        }
        scrollState.scrollPos = target.scrollTop;
        saveScrollState();
    };
    const onFilterChange = (e) => {
        scrollState.currentFilter = e.target.value;
        games(scrollState.userId, scrollState.currentFilter, 1, true)
            .then(prepareData)
            .then(loadInitialGames);
    };
    const toggleBookmark = (id) => {
        toggleGameBookmark(id).then(() => {
            const i = scrollState.games.findIndex(g => g.id === id);
            const g = scrollState.games[i];
            if (g) {
                const ng = Object.assign({}, g, { bookmarked: !g.bookmarked });
                scrollState.games[i] = ng;
                redraw();
            }
        })
            .catch(handleXhrError);
    };
    const goToGame = (id, playerId) => {
        const g = scrollState.games.find(game => game.id === id);
        if (g) {
            const whiteUser = g.players.white.user;
            const userColor = whiteUser && whiteUser.id === userId ? 'white' : 'black';
            positionsCache.set(g.id, { fen: g.fen, orientation: userColor });
            const mePlaying = session.getUserId() === userId;
            if (mePlaying && playerId !== undefined) {
                router.set(`/game/${id}${playerId}?goingBack=1`);
            }
            else {
                router.set(`/analyse/online/${id}/${userColor}?curFen=${g.fen}&slide=1`);
            }
        }
    };
    // load either from cache (restore previous search) or from server
    if (cacheAvailable) {
        setTimeout(() => {
            Object.assign(scrollState, cachedScrollState);
            redraw();
        }, 300);
    }
    else {
        Promise.all([
            games(scrollState.userId, scrollState.currentFilter, 1, false)
                .then(prepareData),
            user(scrollState.userId, false)
        ])
            .then(([gamesData, userData]) => {
            loadUserAndFilters(userData);
            loadInitialGames(gamesData);
        })
            .catch(err => {
            handleXhrError(err);
        });
    }
    return {
        scrollState,
        onScroll,
        onGamesLoaded,
        onFilterChange,
        toggleBookmark,
        boardTheme,
        goToGame,
    };
}

const UserGames = {
    oncreate: viewSlideIn,
    oninit(vnode) {
        socket.createDefault();
        this.ctrl = UserGamesCtrl(vnode.attrs.id, vnode.attrs.filter);
    },
    view(vnode) {
        const { id, username, title, patron } = vnode.attrs;
        const user = this.ctrl.scrollState.user;
        const displayedTitle = user ?
            userTitle(user.online, user.patron, user.username, user.title) :
            userTitle(false, Boolean(patron), username || id, title);
        const header$1 = header(null, backButton(displayedTitle));
        return layout.free(header$1, renderBody(this.ctrl));
    }
};

export { UserGames as default };
//# sourceMappingURL=games-Ct1GV-_D.js.map
