import { f as fetchJSON } from './main.js';

function getTeam(id, disableCache) {
    return fetchJSON('/api/team/' + id, disableCache ? { cache: 'reload' } : undefined);
}
function joinTeam(id, message) {
    return fetchJSON('/team/' + id + '/join', {
        method: 'POST',
        body: message ? JSON.stringify({ message }) : null
    }, true);
}
function leaveTeam(id) {
    return fetchJSON('/team/' + id + '/quit', {
        method: 'POST'
    }, true);
}
function getPopularTeams() {
    return fetchJSON('/api/team/all');
}
function getUserTeams(userId) {
    return fetchJSON('/api/team/of/' + userId);
}
function search(term) {
    return fetchJSON('/api/team/search', { query: { text: term } });
}

export { getUserTeams as a, getTeam as b, getPopularTeams as g, joinTeam as j, leaveTeam as l, search as s };
//# sourceMappingURL=teamsXhr-Bkb9l9T6.js.map
