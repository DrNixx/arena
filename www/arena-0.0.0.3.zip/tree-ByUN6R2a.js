const root = '';
function size(path) {
    return path.length / 2;
}
function head(path) {
    return path.slice(0, 2);
}
function tail(path) {
    return path.slice(2);
}
function init(path) {
    return path.slice(0, -2);
}
function last$1(path) {
    return path.slice(-2);
}
function contains(p1, p2) {
    return p1.indexOf(p2) === 0;
}
function fromNodeList(nodes) {
    let path = '';
    for (const i in nodes) {
        path += nodes[i].id;
    }
    return path;
}

function mainlineChild(node) {
    return node.children[0];
}
function withMainlineChild(node, f) {
    const next = mainlineChild(node);
    return next ? f(next) : undefined;
}
function findInMainline(fromNode, predicate) {
    const findFrom = (node) => {
        if (predicate(node))
            return node;
        return withMainlineChild(node, findFrom);
    };
    return findFrom(fromNode);
}
// returns a list of nodes collected from the original one
function collect(fromNode, pickChild) {
    const nodes = [fromNode];
    let n = fromNode, c;
    while ((c = pickChild(n))) {
        nodes.push(c);
        n = c;
    }
    return nodes;
}
function pickFirstChild(node) {
    return node.children[0];
}
function childById(node, id) {
    return node.children.find(child => child.id === id);
}
function last(nodeList) {
    return nodeList[nodeList.length - 1];
}
function takePathWhile(nodeList, predicate) {
    let path = '';
    for (const i in nodeList) {
        if (predicate(nodeList[i]))
            path += nodeList[i].id;
        else
            break;
    }
    return path;
}
function removeChild(parent, id) {
    parent.children = parent.children.filter(n => {
        return n.id !== id;
    });
}
function countChildrenAndComments(node) {
    const count = {
        nodes: 1,
        comments: (node.comments || []).length
    };
    node.children.forEach(child => {
        const c = countChildrenAndComments(child);
        count.nodes += c.nodes;
        count.comments += c.comments;
    });
    return count;
}
function reconstruct(parts) {
    const proot = parts[0];
    // adapt to offline format which use crazyhouse field name
    if (proot.crazy !== undefined) {
        proot.crazyhouse = proot.crazy;
        proot.crazy = undefined;
    }
    proot.id = '';
    const root = proot;
    let node = root;
    for (let i = 1, nb = parts.length; i < nb; i++) {
        const np = parts[i];
        if (np.crazy !== undefined) {
            np.crazyhouse = np.crazy;
            np.crazy = undefined;
        }
        const n = np;
        if (node.children)
            node.children.unshift(n);
        else
            node.children = [n];
        node = n;
    }
    node.children = node.children || [];
    return root;
}
// adds n2 into n1
function merge(n1, n2) {
    n1.eval = n2.eval;
    if (n2.glyphs)
        n1.glyphs = n2.glyphs;
    n2.comments && n2.comments.forEach(c => {
        if (!n1.comments)
            n1.comments = [c];
        else if (!n1.comments.filter(d => d.text === c.text).length)
            n1.comments.push(c);
    });
    n2.children.forEach(c => {
        const existing = childById(n1, c.id);
        if (existing)
            merge(existing, c);
        else
            n1.children.push(c);
    });
}
function hasBranching(node, maxDepth) {
    return maxDepth <= 0 || node.children[1] ? true : (node.children[0] ? hasBranching(node.children[0], maxDepth - 1) : false);
}
function mainlineNodeList(fromNode) {
    return collect(fromNode, pickFirstChild);
}
function updateAll(root, f) {
    // applies f recursively to all nodes
    const update = (node) => {
        f(node);
        node.children.forEach(update);
    };
    update(root);
}

function build(root) {
    function lastNode() {
        return findInMainline(root, (node) => {
            return !node.children.length;
        });
    }
    function nodeAtPath(path) {
        return nodeAtPathFrom(root, path);
    }
    function nodeAtPathFrom(node, path) {
        if (path === '')
            return node;
        const child = childById(node, head(path));
        return child ? nodeAtPathFrom(child, tail(path)) : node;
    }
    function nodeAtPathOrNull(path) {
        return nodeAtPathOrNullFrom(root, path);
    }
    function nodeAtPathOrNullFrom(node, path) {
        if (path === '')
            return node;
        const child = childById(node, head(path));
        return child ? nodeAtPathOrNullFrom(child, tail(path)) : undefined;
    }
    function longestValidPathFrom(node, path) {
        const id = head(path);
        const child = childById(node, id);
        return child ? id + longestValidPathFrom(child, tail(path)) : '';
    }
    function getCurrentNodesAfterPly(nodeList, mainline, ply) {
        const nodes = [];
        for (const i in nodeList) {
            const node = nodeList[i];
            if (node.ply <= ply && mainline[i].id !== node.id)
                break;
            if (node.ply > ply)
                nodes.push(node);
        }
        return nodes;
    }
    function pathIsMainline(path) {
        return pathIsMainlineFrom(root, path);
    }
    function pathExists(path) {
        return !!nodeAtPathOrNull(path);
    }
    function pathIsMainlineFrom(node, path) {
        if (path === '')
            return true;
        const pathId = head(path), child = node.children[0];
        if (!child || child.id !== pathId)
            return false;
        return pathIsMainlineFrom(child, tail(path));
    }
    function lastMainlineNodeFrom(node, path) {
        if (path === '')
            return node;
        const pathId = head(path);
        const child = node.children[0];
        if (!child || child.id !== pathId)
            return node;
        return lastMainlineNodeFrom(child, tail(path));
    }
    function getNodeList(path) {
        return collect(root, node => {
            const id = head(path);
            if (id === '')
                return;
            path = tail(path);
            return childById(node, id);
        });
    }
    function getOpening(nodeList) {
        let opening;
        nodeList.forEach((node) => {
            opening = node.opening || opening;
        });
        return opening;
    }
    function updateAt(path, update) {
        const node = nodeAtPathOrNull(path);
        if (node) {
            update(node);
            return node;
        }
        return;
    }
    // returns new path
    function addNode(node, path) {
        const newPath = path + node.id;
        const existing = nodeAtPathOrNull(newPath);
        if (existing) {
            if (node.dests !== undefined && existing.dests === undefined)
                existing.dests = node.dests;
            if (node.drops !== undefined && existing.drops === undefined)
                existing.drops = node.drops;
            return newPath;
        }
        return updateAt(path, (parent) => parent.children.push(node)) ? newPath : undefined;
    }
    function addNodes(nodes, path) {
        const node = nodes[0];
        if (!node)
            return path;
        const newPath = addNode(node, path);
        return newPath ? addNodes(nodes.slice(1), newPath) : undefined;
    }
    function deleteNodeAt(path) {
        const parent = parentNode(path);
        const id = last$1(path);
        removeChild(parent, id);
    }
    function promoteAt(path, toMainline) {
        const nodes = getNodeList(path);
        for (let i = nodes.length - 2; i >= 0; i--) {
            const node = nodes[i + 1];
            const parent = nodes[i];
            if (parent.children[0].id !== node.id) {
                removeChild(parent, node.id);
                parent.children.unshift(node);
                if (!toMainline)
                    break;
            }
        }
    }
    function setCommentAt(comment, path) {
        return !comment.text ? deleteCommentAt(comment.id, path) : updateAt(path, (node) => {
            node.comments = node.comments || [];
            const existing = node.comments.find((c) => {
                return c.id === comment.id;
            });
            if (existing)
                existing.text = comment.text;
            else
                node.comments.push(comment);
        });
    }
    function deleteCommentAt(id, path) {
        return updateAt(path, (node) => {
            const comments = (node.comments || []).filter((c) => {
                return c.id !== id;
            });
            node.comments = comments.length ? comments : undefined;
        });
    }
    function setGlyphsAt(glyphs, path) {
        return updateAt(path, (node) => {
            node.glyphs = glyphs;
        });
    }
    function setClockAt(clock, path) {
        return updateAt(path, (node) => {
            node.clock = clock;
        });
    }
    function parentNode(path) {
        return nodeAtPath(init(path));
    }
    function getParentClock(node, path) {
        if (!('parentClock' in node)) {
            const parent = path && parentNode(path);
            if (!parent)
                node.parentClock = node.clock;
            else if (!('clock' in parent))
                node.parentClock = undefined;
            else
                node.parentClock = parent.clock;
        }
        return node.parentClock;
    }
    return {
        root,
        firstPly() {
            return root.ply;
        },
        lastPly() {
            return lastNode().ply;
        },
        lastNode,
        nodeAtPath,
        getNodeList,
        longestValidPath: (path) => longestValidPathFrom(root, path),
        getOpening,
        updateAt,
        addNode,
        addNodes,
        setShapes(shapes, path) {
            return updateAt(path, (node) => {
                node.shapes = shapes;
            });
        },
        setCommentAt,
        deleteCommentAt,
        setGlyphsAt,
        setClockAt,
        pathIsMainline,
        lastMainlineNode(path) {
            return lastMainlineNodeFrom(root, path);
        },
        pathExists,
        deleteNodeAt,
        promoteAt,
        getCurrentNodesAfterPly,
        merge(tree) {
            merge(root, tree);
        },
        removeCeval() {
            updateAll(root, (n) => {
                n.ceval = undefined;
                n.threat = undefined;
            });
        },
        removeComputerVariations() {
            mainlineNodeList(root).forEach(n => {
                n.children = n.children.filter(c => !c.comp);
            });
        },
        parentNode,
        getParentClock
    };
}

export { reconstruct as a, build as b, contains as c, countChildrenAndComments as d, childById as e, fromNodeList as f, merge as g, hasBranching as h, init as i, last as l, mainlineNodeList as m, root as r, size as s, takePathWhile as t, updateAll as u, withMainlineChild as w };
//# sourceMappingURL=tree-ByUN6R2a.js.map
