import { M as popup, q as router, m as h, o as i18n, O as formWidgets, g as settings, a9 as standardFen, aV as tupleOf, K as handleXhrError, x as ontap, bg as ontapXY, E as getLI, bJ as formatTournamentTimeControl, bK as formatTournamentDuration, bL as capitalize, z as gameIcon, bM as pad } from './main.js';
import { T as TabNavigation, a as TabView } from './TabView-CG79fzxt.js';
import { c as create$1 } from './tournamentXhr-kOGDWEN6.js';

let isOpen = false;
var newTournamentForm = {
    open,
    close,
    view(ctrl) {
        return popup('tournament_form_popup', undefined, () => renderForm(ctrl), isOpen, close);
    }
};
function open() {
    router.backbutton.stack.push(close);
    isOpen = true;
}
function close(fromBB) {
    if (fromBB !== 'backbutton' && isOpen)
        router.backbutton.stack.pop();
    isOpen = false;
}
function renderForm(ctrl) {
    return (h("form", { id: "tournamentCreateForm", class: "tournamentForm", onsubmit: (e) => {
            e.preventDefault();
            return create(e.target);
        } },
        h("fieldset", null,
            h("div", { className: "select_input no_arrow_after" },
                h("div", { className: "text_input_container" },
                    h("label", null,
                        i18n('name'),
                        " "),
                    h("input", { type: "text", id: "name", className: "textField", autocomplete: "off", autocapitalize: "off", autocorrect: "off", spellcheck: false }),
                    "Arena")),
            h("div", { className: "tournament_name_warning" },
                i18n('safeTournamentName'),
                " ",
                i18n('inappropriateNameWarning'),
                " ",
                i18n('emptyTournamentName')),
            h("div", { className: "select_input" }, formWidgets.renderSelect('Variant', 'variant', settings.tournament.availableVariants, settings.tournament.variant, false)),
            ctrl.startPositions !== undefined ?
                h("div", { className: 'select_input' + (settings.tournament.variant() !== '1' ? ' notVisible' : '') },
                    h("label", { for: "select_start_position" }, "Position"),
                    h("select", { id: "select_start_position", className: "positions" },
                        h("option", { value: standardFen }, "Initial Position"),
                        ctrl.startPositions.map(c => {
                            return (h("optgroup", { label: c.name }, c.positions.map(p => h("option", { value: p.fen }, p.eco + ' ' + p.name))));
                        }))) : null,
            h("div", { className: "select_input" }, formWidgets.renderSelect(i18n('mode'), 'mode', settings.tournament.availableModes, settings.tournament.mode, false)),
            h("div", { className: "select_input inline" }, formWidgets.renderSelect(i18n('time'), 'time', settings.tournament.availableTimes, settings.tournament.time, false)),
            h("div", { className: "select_input inline no-margin" }, formWidgets.renderSelect(i18n('increment'), 'increment', settings.tournament.availableIncrements.map((x) => tupleOf(Number(x))), settings.tournament.increment, false)),
            h("div", { className: "select_input inline" }, formWidgets.renderSelect(i18n('duration'), 'duration', settings.tournament.availableDurations.map((x) => tupleOf(Number(x))), settings.tournament.duration, false)),
            h("div", { className: "select_input inline no-margin" }, formWidgets.renderSelect('Time to Start', 'timeToStart', settings.tournament.availableTimesToStart.map((x) => tupleOf(Number(x))), settings.tournament.timeToStart, false)),
            h("div", { className: "select_input" }, formWidgets.renderCheckbox(i18n('isPrivate'), 'private', settings.tournament.private)),
            h("div", { className: 'select_input no_arrow_after' + (settings.tournament.private() ? '' : ' notVisible') },
                h("div", { className: "text_input_container" },
                    h("label", null, "Password "),
                    h("input", { type: "text", id: "password", className: "textField", autocomplete: "off", autocapitalize: "off", autocorrect: "off", spellcheck: false })))),
        h("div", { className: "popupActionWrapper" },
            h("button", { className: "popupAction", type: "submit" },
                h("span", { className: "fa fa-check" }),
                i18n('createANewTournament')))));
}
function create(form) {
    const elements = form[0].elements;
    const name = elements[0].value;
    const variant = elements[1].value;
    const position = settings.tournament.variant() === '1' ? elements[2].value : '---';
    const mode = elements[3].value;
    const time = elements[4].value;
    const increment = elements[5].value;
    const duration = elements[6].value;
    const timeToStart = elements[7].value;
    const isPrivate = elements[8].checked ? elements[8].value : '';
    const password = isPrivate ? elements[9].value : '';
    create$1(name, variant, position, mode, time, increment, duration, timeToStart, isPrivate, password)
        .then((data) => {
        close();
        router.set('/tournament/' + data.id);
    })
        .catch(handleXhrError);
}

const TABS = [{
        label: 'In Progress'
    }, {
        label: 'Upcoming'
    }, {
        label: 'Completed'
    }];
function onTournamentTap(e) {
    const el = getLI(e);
    const ds = el?.dataset;
    if (ds.id) {
        router.set('/tournament/' + ds.id);
    }
}
function renderTournamentsList(ctrl) {
    if (!ctrl.tournaments)
        return null;
    const tabsContent = [
        { id: 'started', f: () => ctrl.tournaments ? renderTournamentList(ctrl.tournaments['started']) : null },
        { id: 'created', f: () => ctrl.tournaments ? renderTournamentList(ctrl.tournaments['created']) : null },
        { id: 'finished', f: () => ctrl.tournaments ? renderTournamentList(ctrl.tournaments['finished']) : null },
    ];
    return [
        h('div.tabs-nav-header.subHeader', h(TabNavigation, {
            buttons: TABS,
            selectedIndex: ctrl.currentTab,
            onTabChange: ctrl.onTabChange
        })),
        h(TabView, {
            selectedIndex: ctrl.currentTab,
            tabs: tabsContent,
            onTabChange: ctrl.onTabChange,
        })
    ];
}
function renderFooter() {
    return (h("div", { className: "actions_bar" },
        h("button", { className: "action_create_button", oncreate: ontap(newTournamentForm.open) },
            h("span", { className: "fa fa-plus-circle" }),
            i18n('createANewTournament'))));
}
function renderTournamentList(list) {
    return h('ul.native_scroller.tournamentList', {
        oncreate: ontapXY(onTournamentTap, undefined, getLI)
    }, list.map(renderTournamentListItem));
}
function renderTournamentListItem(tournament, index) {
    const time = formatTournamentTimeControl(tournament.clock);
    const mode = tournament.rated ? i18n('rated') : i18n('casual');
    const duration = formatTournamentDuration(tournament.minutes);
    const variant = tournament.variant.key !== 'standard' ?
        capitalize(tournament.variant.short) : '';
    const evenOrOdd = index % 2 === 0 ? ' even ' : ' odd ';
    const tournamentType = determineTournamentType(tournament);
    return (h("li", { key: tournament.id, className: 'list_item tournament_item' + evenOrOdd + tournamentType, "data-id": tournament.id },
        h("i", { className: "tournamentListIcon", "data-icon": getIconFromTournament(tournament) }),
        h("div", { className: "tournamentListName" },
            h("div", { className: "fullName" }, tournament.fullName),
            h("small", { className: "infos" },
                time,
                " ",
                variant,
                " ",
                mode,
                " \u2022 ",
                duration)),
        h("div", { className: "tournamentListTime" },
            h("div", { className: "time" },
                formatTime(tournament.startsAt),
                " ",
                h("strong", { className: "timeArrow" }, "-"),
                " ",
                formatTime(tournament.finishesAt)),
            h("small", { className: "nbUsers withIcon", "data-icon": "r" }, tournament.nbPlayers))));
}
function getIconFromTournament(tournament) {
    if (tournament.schedule?.freq === 'shield') {
        return '5';
    }
    return gameIcon(tournament.perf.key);
}
function formatTime(timeInMillis) {
    const date = new Date(timeInMillis);
    const hours = pad(date.getHours(), 2);
    const mins = pad(date.getMinutes(), 2);
    return hours + ':' + mins;
}
function determineTournamentType(tournament) {
    let tournamentType = '';
    if (tournament.battle) {
        tournamentType = 'teamBattle';
    }
    else if (tournament.createdBy !== 'lichess') {
        tournamentType = 'user';
    }
    else if (tournament.hasMaxRating) {
        tournamentType = 'maxRating';
    }
    else {
        tournamentType = tournament.schedule ? tournament.schedule.freq : '';
    }
    return tournamentType;
}

export { renderTournamentsList as a, renderFooter as b, newTournamentForm as n, renderTournamentList as r };
//# sourceMappingURL=tournamentsListView-Csa0M4-v.js.map
