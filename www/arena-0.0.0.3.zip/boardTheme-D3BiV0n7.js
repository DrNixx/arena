import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, g as settings, r as redraw, cs as getLocalFiles, m as h, p as ontapY, ct as filename, U as classSet, E as getLI, cu as onBoardThemeChange, cq as loadImage, cr as handleError } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

const themeSettings = settings.general.theme;
let timeoutId;
var boardTheme = {
    oncreate: viewSlideIn,
    oninit() {
        this.loading = false;
        this.progress = null;
        this.selected = themeSettings.board();
        this.onProgress = (e) => {
            if (e.lengthComputable) {
                this.progress = e;
                redraw();
            }
        };
        this.stopLoading = () => {
            if (this.progress) {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => {
                    this.loading = false;
                    this.progress = null;
                    redraw();
                }, 1500);
            }
            else {
                this.loading = false;
                this.progress = null;
                redraw();
            }
        };
        this.isLocal = ({ key, filename }) => themeSettings.bundledBoardThemes.includes(key) ||
            Boolean(this.localFiles && this.localFiles['board-' + filename]);
        getLocalFiles('board').then(files => {
            this.localFiles = files.reduce((o, key) => ({ [key]: '1', ...o }), {});
            redraw();
        });
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('boardTheme')));
        return layout.free(header, renderBody(this));
    }
};
function renderBody(state) {
    function onTap(e) {
        if (state.loading)
            return;
        const el = getLI(e);
        const key = el && el.dataset.key;
        const filename = el && el.dataset.filename;
        if (key && filename) {
            const prevTheme = state.selected;
            state.selected = key;
            if (themeSettings.bundledBoardThemes.includes(key)) {
                themeSettings.board(key);
                onBoardThemeChange(key);
            }
            else {
                state.loading = true;
                loadImage('board', key, state.onProgress)
                    .then(() => {
                    themeSettings.board(key);
                    onBoardThemeChange(key);
                    if (state.localFiles) {
                        state.localFiles['board-' + filename] = '1';
                    }
                    state.stopLoading();
                })
                    .catch((err) => {
                    state.selected = prevTheme;
                    state.stopLoading();
                    handleError(err);
                });
            }
            redraw();
        }
    }
    return [
        h('div.native_scroller.page.settings_list', [
            h('ul', {
                oncreate: ontapY(onTap, undefined, getLI),
            }, themeSettings.availableBoardThemes.map((t) => {
                const selected = t.key === state.selected;
                const filename$1 = filename(t);
                const loadingSelected = state.loading && selected;
                return h('li.list_item.board_theme', {
                    className: classSet({
                        selected,
                        loading: selected && !!state.loading,
                    }),
                    'data-key': t.key,
                    'data-filename': filename$1,
                }, [
                    h('span.name', t.name),
                    loadingSelected || state.isLocal({ key: t.key, filename: filename$1 }) ? null : h('i.fa.fa-cloud-download'),
                    loadingSelected ? h('i.fa.fa-circle-o-notch.fa-spin') : null,
                    !state.loading && selected ? h('i.fa.fa-check') : null,
                    h('div.board_thumbnail.vertical_align', {
                        className: t.key,
                    }),
                ]);
            }))
        ])
    ];
}

export { boardTheme as default };
//# sourceMappingURL=boardTheme-D3BiV0n7.js.map
