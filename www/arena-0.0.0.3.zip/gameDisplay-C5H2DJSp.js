import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, O as formWidgets, b as session } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { A as AnimationChoices, a as Animation } from './prefs-CFmBYsqy.js';

var gameDisplay = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('gameDisplay')));
        return layout.free(header, h('ul.native_scroller.page.settings_list.game', render(prefsCtrl)));
    }
};
const prefsCtrl = {
    animation: session.lichessBackedProp('prefs.animation', Animation.NORMAL),
    showCaptured: session.lichessBackedProp('prefs.captured', true),
};
function render(ctrl) {
    return [
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('pieceAnimation'), AnimationChoices, ctrl.animation)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('materialDifference'), formWidgets.booleanChoice, ctrl.showCaptured)),
    ];
}

export { gameDisplay as default, render };
//# sourceMappingURL=gameDisplay-C5H2DJSp.js.map
