import { m as h, r as redraw, aA as viewSlideIn, o as i18n, G as dropShadowHeader, I as backButton, g as settings, O as formWidgets } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { v as vibrate } from './vibrate-CyNrNHlt.js';

var Checkbox = {
    oninit({ attrs }) {
        this.value = attrs.prop();
    },
    view({ attrs }) {
        return h('div.check_container', {
            className: attrs.disabled ? 'disabled' : ''
        }, [
            h('label', {
                'for': attrs.name
            }, attrs.label),
            h('input[type=checkbox]', {
                id: attrs.name,
                name: attrs.name,
                disabled: attrs.disabled,
                checked: this.value,
                onchange: () => {
                    this.value = !this.value;
                    attrs.prop(this.value);
                    if (attrs.callback) {
                        attrs.callback(this.value);
                    }
                    redraw();
                }
            })
        ]);
    },
};

function renderBody() {
    return h('ul.native_scroller.page.settings_list.game', [
        h('li.list_item', h(Checkbox, {
            label: i18n('toggleSound'),
            name: 'sound',
            prop: settings.general.sound,
        })),
        h('li.list_item', {}, formWidgets.renderCheckbox(i18n('vibrateOnGameEvents'), 'vibrate', settings.general.vibrateOnGameEvents, vibrate.onSettingChange)),
    ]);
}
var soundNotifications = {
    oncreate: viewSlideIn,
    view() {
        const headerTitle = i18n('sound');
        const header = dropShadowHeader(null, backButton(headerTitle));
        return layout.free(header, renderBody());
    }
};

export { soundNotifications as default };
//# sourceMappingURL=soundNotifications-CJd1cT8g.js.map
