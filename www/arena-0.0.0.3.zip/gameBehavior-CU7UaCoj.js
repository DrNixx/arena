import { aA as viewSlideIn, b as session, G as dropShadowHeader, I as backButton, o as i18n, m as h, O as formWidgets } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { S as SubmitMove, f as AutoThreefold, g as AutoQueen, T as Takeback, h as TakebackChoices, i as AutoQueenChoices, j as AutoThreefoldChoices, k as SubmitMoveChoices } from './prefs-CFmBYsqy.js';

var gameBehavior = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('gameBehavior')));
        return layout.free(header, h('ul.native_scroller.page.settings_list.game', render(prefsCtrl)));
    }
};
const prefsCtrl = {
    premove: session.lichessBackedProp('prefs.premove', true),
    takeback: session.lichessBackedProp('prefs.takeback', Takeback.ALWAYS),
    autoQueen: session.lichessBackedProp('prefs.autoQueen', AutoQueen.PREMOVE),
    autoThreefold: session.lichessBackedProp('prefs.autoThreefold', AutoThreefold.TIME),
    submitMove: session.lichessBackedProp('prefs.submitMove', SubmitMove.CORRESPONDENCE_ONLY),
};
function render(ctrl) {
    return [
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('premovesPlayingDuringOpponentTurn'), formWidgets.booleanChoice, ctrl.premove)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('takebacksWithOpponentApproval'), TakebackChoices, ctrl.takeback)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('promoteToQueenAutomatically'), AutoQueenChoices, ctrl.autoQueen)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('claimDrawOnThreefoldRepetitionAutomatically').replace(/%s/g, ''), AutoThreefoldChoices, ctrl.autoThreefold)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('moveConfirmation'), SubmitMoveChoices, ctrl.submitMove)),
    ];
}

export { gameBehavior as default, prefsCtrl, render };
//# sourceMappingURL=gameBehavior-CU7UaCoj.js.map
