import { F as viewFadeIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, p as ontapY, J as prop, t as timeline$1, c as fromNow, r as redraw, K as handleXhrError, E as getLI, q as router, L as i18nVdom, z as gameIcon } from './main.js';
import { a as openWebsitePage, u as userTitle } from './userView-BRulENS5.js';
import { l as layout } from './layout-DoxuEk9x.js';
import './html-EBv26hf5.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './userXhr-i6lHGN-w.js';

const supportedTypes = ['follow', 'game-end', 'tour-join', 'study-create', 'study-like', 'forum-post', 'blog-post', 'ublog-post', 'ublog-post-like', 'stream-start'];
var timeline = {
    oninit() {
        this.timelineData = prop({ entries: [], users: {} });
        timeline$1()
            .then((data) => {
            this.timelineData({
                users: data.users,
                entries: data.entries
                    .filter(o => supportedTypes.indexOf(o.type) !== -1)
                    .map(o => {
                    o.fromNow = fromNow(new Date(o.date));
                    return o;
                })
            });
            redraw();
        })
            .catch(handleXhrError);
    },
    oncreate: viewFadeIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('timeline')));
        const timelineData = this.timelineData();
        return layout.free(header, [
            h('ul.timeline.native_scroller.page', {
                oncreate: ontapY(timelineOnTap, undefined, getLI)
            }, timelineData.entries.map(entry => renderTimelineEntry(entry, timelineData.users)))
        ]);
    }
};
function timelineOnTap(e) {
    const el = getLI(e);
    const path = el && el.dataset.path;
    const external = el && el.dataset.external;
    if (path) {
        router.set(path);
    }
    if (external) {
        openWebsitePage(external);
    }
}
function renderTimelineEntry(e, users) {
    switch (e.type) {
        case 'follow':
            return renderFollow(e);
        case 'game-end':
            return renderGameEnd(e);
        case 'tour-join':
            return renderTourJoin(e);
        case 'study-create':
        case 'study-like':
            return renderStudy(e);
        case 'forum-post':
            return renderForum(e, users);
        case 'blog-post':
            return renderBlog(e);
        case 'ublog-post':
            return renderUblog(e, users);
        case 'ublog-post-like':
            return renderUblogLike(e, users);
        case 'stream-start':
            return renderStreamStart(e);
        default:
            return null;
    }
}
function renderBlog(entry) {
    const data = entry.data;
    return h('li.list_item.timelineEntry.blogEntry', {
        key: 'blog-post' + data.id,
        'data-external': `/blog/${data.id}/${data.slug}`,
    }, [
        h('span[data-icon=6].withIcon'),
        h('span', data.title),
        ' ',
        h('small', h('em', entry.fromNow)),
    ]);
}
function renderUblog(entry, users) {
    const data = entry.data;
    const actor = users[data.userId];
    return h('li.list_item.timelineEntry', {
        key: `ublog-post${data.id}`,
        'data-external': `/@/${data.userId}/blog/${data.slug}/${data.id}`,
    }, [
        userTitle(false, actor.patron ?? false, actor.id, actor.title),
        i18nVdom('xPublishedY', '', h('strong', data.title)),
        ' ',
        h('small', h('em', entry.fromNow)),
    ]);
}
function renderUblogLike(entry, users) {
    const data = entry.data;
    const actor = users[data.userId];
    return h('li.list_item.timelineEntry', {
        key: `ublog-post-like${data.id}`,
        'data-external': `/ublog/${data.id}/redirect`,
    }, [
        userTitle(false, actor.patron ?? false, actor.id, actor.title),
        i18nVdom('xLikesY', '', h('strong', data.title)),
        ' ',
        h('small', h('em', entry.fromNow)),
    ]);
}
function renderForum(entry, users) {
    const data = entry.data;
    const actor = users[data.userId];
    return h('li.list_item.timelineEntry', {
        key: 'forum-post' + data.postId,
        'data-external': `/forum/redirect/post/${data.postId}`,
    }, [
        userTitle(false, actor.patron ?? false, actor.id, actor.title),
        i18nVdom('xPostedInForumY', '', h('strong', data.topicName)),
        ' ',
        h('small', h('em', entry.fromNow)),
    ]);
}
function renderStudy(entry) {
    const data = entry.data;
    const eType = entry.type === 'study-create' ? 'hosts' : 'likes';
    return h('li.list_item.timelineEntry', {
        key: 'study-like' + entry.date,
        'data-path': `/study/${data.studyId}`
    }, [
        h('span[data-icon=4].withIcon'),
        h('strong', data.userId),
        h('span', ` ${eType} ${data.studyName} `),
        h('small', h('em', entry.fromNow)),
    ]);
}
function renderTourJoin(entry) {
    const entryText = i18nVdom('xCompetesInY', h('strong', entry.data.userId), entry.data.tourName);
    const key = 'tour' + entry.date;
    return (h("li", { className: "list_item timelineEntry", key: key, "data-path": `/tournament/${entry.data.tourId}` },
        h("span", { className: "fa fa-trophy" }),
        entryText,
        h("small", null,
            h("em", null,
                " ",
                entry.fromNow))));
}
function renderFollow(entry) {
    const entryText = i18nVdom('xStartedFollowingY', h('strong', entry.data.u1), entry.data.u2);
    const key = 'follow' + entry.date;
    return (h("li", { className: "list_item timelineEntry", key: key, "data-path": `/@/${entry.data.u2}` },
        h("span", { className: "fa fa-arrow-circle-right" }),
        entryText,
        h("small", null,
            h("em", null,
                " ",
                entry.fromNow))));
}
function renderGameEnd(entry) {
    const icon = gameIcon(entry.data.perf);
    const result = typeof entry.data.win === 'undefined' ? i18n('draw') : (entry.data.win ? 'Victory' : 'Defeat');
    const key = 'game-end' + entry.date;
    return (h("li", { className: "list_item timelineEntry", key: key, "data-icon": icon, "data-path": `/game/${entry.data.playerId}?goingBack=1` },
        h("strong", null, result),
        " vs. ",
        entry.data.opponent,
        h("small", null,
            h("em", null,
                " ",
                entry.fromNow))));
}
function renderStreamStart(entry) {
    const data = entry.data;
    return h('li.list_item.timelineEntry', {
        key: `stream-start${data.date}`,
        'data-external': `/streamer/${data.id}/redirect`
    }, [
        h('span[data-icon=].withIcon'),
        h('strong', i18n('xStartedStreaming', data.name)),
        ' ',
        h('small', h('em', entry.fromNow)),
    ]);
}

export { timeline as default, renderTimelineEntry, supportedTypes, timelineOnTap };
//# sourceMappingURL=timeline-BwuTr8-b.js.map
