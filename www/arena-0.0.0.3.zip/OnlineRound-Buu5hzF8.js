import { a6 as Chessground, aF as uciToMove, aG as uciTolastDrop, g as settings, r as redraw, a8 as boardOrientation, R as sound, h as throttle, s as socket, $ as Toast, o as i18n, q as router, aH as miniUser, k as hasNetwork, b as session, az as toggleGameBookmark, K as handleXhrError, A as App, a as signals, a2 as uciToDropPos } from './main.js';
import { v as vibrate } from './vibrate-CyNrNHlt.js';
import { b as parsePossibleMoves, i as isPlayerPlaying, p as playable, c as playedTurns, s as setOnGame, d as setIsGone, e as drawable, f as getPlayer, g as gameStatus } from './game-CgD9Ef6g.js';
import { C as Chat } from './chat-Dbn1ft42.js';
import { f as formatClockTime, h as formatClockTime$1, p as promotion, c as crazyValid, a as atomic } from './crazyValid-BQyVE87l.js';
import { g as getCrosstable, r as reload$1, N as NotesCtrl } from './toInteger-bGq5KERl.js';

function isMove(o) {
    return o.isMove;
}
function isDrop(o) {
    return o.isDrop;
}
function isMoveRequest(r) {
    return r.u !== undefined;
}
function isDropRequest(r) {
    return r.role !== undefined;
}

/* Tracks moves that were played on the board,
 * sent to the server, possibly acked,
 * but without a move response from the server yet.
 * After a delay, it will trigger a reload.
 * This might fix bugs where the board is in a
 * transient, dirty state, where clocks don't tick,
 * eventually causing the player to flag.
 * It will also help with lila-ws restarts.
 */
class TransientMove {
    constructor(ctrl) {
        this.ctrl = ctrl;
        this.register = () => {
            this.current = setTimeout(this.expire, 10000);
        };
        this.clear = () => {
            clearTimeout(this.current);
        };
        this.expire = () => {
            this.ctrl.reloadGameData();
        };
    }
}

function makeConfig(data, fen, flip = false) {
    const lastStep = data.steps[data.steps.length - 1];
    const lastMove = data.game.lastMove ?
        uciToMove(data.game.lastMove) :
        (data.game.variant.key === 'crazyhouse' &&
            lastStep &&
            lastStep.uci !== null) ?
            uciTolastDrop(lastStep.uci) :
            null;
    const pieceMoveConf = settings.game.pieceMove();
    return {
        fen: fen,
        orientation: boardOrientation(data, flip),
        turnColor: data.game.player,
        lastMove,
        check: lastStep.check,
        coordinates: settings.game.coords(),
        autoCastle: true,
        highlight: {
            lastMove: settings.game.highlights(),
            check: settings.game.highlights()
        },
        movable: {
            free: false,
            color: isPlayerPlaying(data) ? data.player.color : null,
            dests: isPlayerPlaying(data) ? parsePossibleMoves(data.possibleMoves) : {},
            showDests: settings.game.pieceDestinations(),
            rookCastle: settings.game.rookCastle() === 1,
        },
        animation: {
            enabled: !!settings.game.animations(),
            duration: data.pref.animationDuration
        },
        premovable: {
            enabled: data.pref.enablePremove,
            showDests: settings.game.pieceDestinations(),
            castle: data.game.variant.key !== 'antichess',
            events: {
                set: () => redraw(),
                unset: redraw
            }
        },
        predroppable: {
            enabled: data.pref.enablePremove && data.game.variant.key === 'crazyhouse',
            events: {
                set: () => redraw(),
                unset: redraw
            }
        },
        draggable: {
            enabled: pieceMoveConf === 'drag' || pieceMoveConf === 'both',
            distance: 3,
            magnified: settings.game.magnified(),
            preventDefault: data.game.variant.key !== 'crazyhouse'
        },
        selectable: {
            enabled: pieceMoveConf === 'tap' || pieceMoveConf === 'both'
        },
    };
}
function make(data, fen, userMove, userNewPiece, onMove, onNewPiece) {
    const config = makeConfig(data, fen);
    config.movable.events = {
        after: userMove,
        afterNewPiece: userNewPiece
    };
    config.events = {
        move: onMove,
        dropNewPiece: onNewPiece
    };
    config.viewOnly = data.player.spectator;
    return new Chessground(config);
}
function reload(ground, data, fen, flip) {
    ground.reconfigure(makeConfig(data, fen, flip));
}
var ground = {
    make,
    reload,
};

class ClockCtrl {
    constructor(d, opts) {
        this.opts = opts;
        this.emergSound = {
            play: sound.lowtime,
            delay: 20000,
            playable: {
                white: true,
                black: true
            }
        };
        this.elements = {
            white: null,
            black: null
        };
        this.setClock = (d, white, black, delay = 0) => {
            const isClockRunning = playable(d) &&
                (playedTurns(d) > 1 || d.clock.running);
            const delayMs = delay * 10;
            this.times = {
                white: white * 1000,
                black: black * 1000,
                activeColor: isClockRunning ? d.game.player : undefined,
                lastUpdate: performance.now() + delayMs
            };
            if (isClockRunning)
                this.scheduleTick(this.times[d.game.player], delayMs);
        };
        this.addTime = (color, time) => {
            this.times[color] += time * 10;
        };
        this.stopClock = () => {
            const color = this.times.activeColor;
            if (color) {
                const curElapse = this.elapsed();
                this.times[color] = Math.max(0, this.times[color] - curElapse);
                this.times.activeColor = undefined;
            }
        };
        this.millisOf = (color) => (this.times.activeColor === color ?
            Math.max(0, this.times[color] - this.elapsed()) : this.times[color]);
        this.isRunning = () => this.times.activeColor !== undefined;
        this.unload = () => {
            clearTimeout(this.tickTimeoutID);
            this.times.activeColor = undefined;
        };
        this.scheduleTick = (time, extraDelay) => {
            if (this.tickTimeoutID !== undefined)
                clearTimeout(this.tickTimeoutID);
            this.tickTimeoutID = setTimeout(this.tick, time % (this.showTenths(time) ? 100 : 500) + 1 + extraDelay);
        };
        // Should only be invoked by scheduleTick.
        this.tick = () => {
            this.tickTimeoutID = undefined;
            const color = this.times.activeColor;
            if (!color)
                return;
            const now = performance.now();
            const millis = Math.max(0, this.times[color] - this.elapsed(now));
            this.scheduleTick(millis, 0);
            if (millis === 0)
                this.opts.onFlag();
            else
                this.updateElement(color, millis);
            if (this.opts.soundColor === color) {
                if (this.emergSound.playable[color]) {
                    if (millis < this.emergMs && !(now < this.emergSound.next)) {
                        this.emergSound.play();
                        this.emergSound.next = now + this.emergSound.delay;
                        this.emergSound.playable[color] = false;
                    }
                }
                else if (millis > 1.5 * this.emergMs) {
                    this.emergSound.playable[color] = true;
                }
            }
        };
        this.elapsed = (now = performance.now()) => Math.max(0, now - this.times.lastUpdate);
        const cdata = d.clock;
        if (opts.showTenths === 0)
            this.showTenths = () => false;
        else {
            const cutoff = opts.showTenths === 1 ? 10000 : 3600000;
            this.showTenths = (time) => time < cutoff;
        }
        this.emergMs = 1000 * Math.min(60, Math.max(10, cdata.initial * .125));
        this.setClock(d, cdata.white, cdata.black);
    }
    updateElement(color, millis) {
        const el = this.elements[color];
        if (el) {
            const showTenths = this.showTenths(millis);
            const formatted = formatClockTime(millis, showTenths, this.times.activeColor === color);
            if (showTenths) {
                el.innerHTML = formatted;
            }
            else {
                el.textContent = formatted;
            }
            if (millis < this.emergMs)
                el.classList.add('emerg');
            else
                el.classList.remove('emerg');
        }
    }
}

class CorresClockCtrl {
    constructor(data, onFlag) {
        this.lastUpdate = {
            white: data.white,
            black: data.black,
            at: Date.now()
        };
        this.els = {
            black: null,
            white: null
        };
        this.data = data;
        this.onFlag = onFlag;
    }
    setLastUpdate(data) {
        this.lastUpdate.white = data.white;
        this.lastUpdate.black = data.black;
        this.lastUpdate.at = Date.now();
    }
    update(white, black) {
        this.data.white = white;
        this.data.black = black;
        this.setLastUpdate(this.data);
    }
    tick(color) {
        this.data[color] = Math.max(0, this.lastUpdate[color] - (Date.now() - this.lastUpdate.at) / 1000);
        if (this.data[color] === 0)
            this.onFlag();
        const time = this.data[color] * 1000;
        const el = this.els[color];
        if (el)
            el.textContent = formatClockTime$1(time);
    }
}

function backoff(delay, factor, callback) {
    let timer;
    let lastExec = 0;
    return (...args) => {
        const elapsed = performance.now() - lastExec;
        const exec = () => {
            timer = undefined;
            lastExec = performance.now();
            delay *= factor;
            callback(...args);
        };
        if (timer)
            clearTimeout(timer);
        if (elapsed > delay)
            exec();
        else
            timer = setTimeout(exec, delay - elapsed);
    };
}

class RoundSocket {
    constructor(ctrl, onFeatured) {
        this.ctrl = ctrl;
        this.moreTime = throttle(() => {
            this.iface.send('moretime');
        }, 300);
        this.outoftime = backoff(500, 1.1, () => {
            this.iface.send('flag', this.ctrl.data.game.player);
        });
        this.berserk = throttle(() => {
            this.iface.send('berserk', null, { ackable: true });
        }, 200);
        function reload(o) {
            // avoid reload if possible!
            if (o && o.t && handlers[o.t])
                handlers[o.t](o.d);
            else
                ctrl.reloadGameData();
        }
        const handlers = {
            takebackOffers(o) {
                if (!ctrl.data.player.proposingTakeback && o[ctrl.data.player.color]) {
                    sound.dong();
                    vibrate.quick();
                }
                if (!ctrl.data.opponent.proposingTakeback && o[ctrl.data.opponent.color]) {
                    sound.dong();
                    vibrate.quick();
                }
                ctrl.data.player.proposingTakeback = o[ctrl.data.player.color];
                ctrl.data.opponent.proposingTakeback = o[ctrl.data.opponent.color];
                redraw();
            },
            move(o) {
                o.isMove = true;
                ctrl.apiMove(o);
                redraw();
            },
            drop(o) {
                o.isDrop = true;
                ctrl.apiMove(o);
                redraw();
            },
            clockInc(o) {
                if (ctrl.clock) {
                    ctrl.clock.addTime(o.color, o.time);
                    redraw();
                }
            },
            cclock(o) {
                if (ctrl.data.correspondence && ctrl.correspondenceClock) {
                    ctrl.data.correspondence.white = o.white;
                    ctrl.data.correspondence.black = o.black;
                    ctrl.correspondenceClock.update(o.white, o.black);
                    redraw();
                }
            },
            checkCount(e) {
                const isWhite = ctrl.data.player.color === 'white';
                ctrl.data.player.checks = isWhite ? e.white : e.black;
                ctrl.data.opponent.checks = isWhite ? e.black : e.white;
                redraw();
            },
            berserk(color) {
                ctrl.setBerserk(color);
            },
            redirect(e) {
                socket.redirectToGame(e);
            },
            reload,
            endData(o) {
                ctrl.endWithData(o);
                redraw();
            },
            rematchOffer(by) {
                ctrl.data.player.offeringRematch = by === ctrl.data.player.color;
                const fromOp = ctrl.data.opponent.offeringRematch = by === ctrl.data.opponent.color;
                if (fromOp) {
                    Toast.show({ text: i18n('yourOpponentWantsToPlayANewGameWithYou'), position: 'center', duration: 'short' });
                }
                redraw();
            },
            rematchTaken(nextId) {
                ctrl.data.game.rematch = nextId;
                // redraw()
            },
            drawOffer(by) {
                ctrl.data.player.offeringDraw = by === ctrl.data.player.color;
                const fromOp = ctrl.data.opponent.offeringDraw = by === ctrl.data.opponent.color;
                if (fromOp) {
                    Toast.show({ text: i18n('yourOpponentOffersADraw'), position: 'center', duration: 'short' });
                }
                redraw();
            },
            gone(isGone) {
                if (!ctrl.data.opponent.ai && ctrl.data.game.speed !== 'correspondence') {
                    setIsGone(ctrl.data, ctrl.data.opponent.color, isGone);
                    if (!ctrl.chat || !ctrl.chat.showing)
                        redraw();
                }
            },
            message(msg) {
                if (ctrl.chat)
                    ctrl.chat.append(msg);
            },
            tvSelect(o) {
                if (ctrl.data.tv && o.channel === ctrl.data.tv && onFeatured)
                    onFeatured();
            },
            crowd(o) {
                setOnGame(ctrl.data, 'white', o.white);
                setOnGame(ctrl.data, 'black', o.black);
                ctrl.data.watchers = o.watchers;
                if (!ctrl.chat || !ctrl.chat.showing)
                    redraw();
            }
        };
        this.iface = socket.createGame(ctrl.data.url.socket, ctrl.data.player.version, handlers, ctrl.data.url.round, ctrl.data.userTV);
    }
}

class OnlineRound {
    constructor(goingBack, id, cfg, flipped = false, onFeatured, userTv, ply) {
        this.goingBack = goingBack;
        this.id = id;
        this.onFeatured = onFeatured;
        this.promoting = null;
        this.player = () => this.data.player.color;
        this.zenAvailable = () => !this.data.player.spectator &&
            playable(this.data);
        this.isZen = () => this.zenAvailable() && this.zenModeEnabled;
        this.toggleZenMode = () => {
            this.zenModeEnabled = !this.zenModeEnabled;
            redraw();
        };
        this.goToAnalysis = () => {
            const d = this.data;
            router.set(`/analyse/online/${d.game.id}/${boardOrientation(d)}?ply=${this.vm.ply}&curFen=${d.game.fen}`);
        };
        this.openUserPopup = (position, userId) => {
            if (this.score === undefined) {
                const d = this.data;
                if (!d || !d.player.user || !d.opponent.user) {
                    return;
                }
                getCrosstable(d.player.user.id, d.opponent.user.id).then(s => {
                    this.score = s;
                    redraw();
                });
            }
            if (!this.vm.miniUser[position].data) {
                miniUser(userId).then(data => {
                    this.vm.miniUser[position].data = data;
                    redraw();
                })
                    .catch(() => {
                    this.vm.miniUser[position].showing = false;
                    redraw();
                });
            }
            this.vm.miniUser[position].showing = true;
        };
        this.closeUserPopup = (position) => {
            this.vm.miniUser[position].showing = false;
        };
        this.showActions = () => {
            router.backbutton.stack.push(this.hideActions);
            this.vm.showingActions = true;
            this.vm.showingShareActions = false;
        };
        this.showShareActions = () => {
            this.vm.showingShareActions = true;
        };
        this.hideActions = (fromBB) => {
            if (fromBB !== 'backbutton' && this.vm.showingActions)
                router.backbutton.stack.pop();
            this.vm.showingActions = false;
            this.vm.showingShareActions = false;
        };
        this.flip = () => {
            this.vm.flip = !this.vm.flip;
            if (this.data.tv) {
                if (this.vm.flip)
                    router.set('/tv?flip=1', true);
                else
                    router.set('/tv', true);
                return;
            }
            this.chessground.set({
                orientation: boardOrientation(this.data, this.vm.flip)
            });
        };
        this.canOfferDraw = () => {
            return drawable(this.data) && (this.lastDrawOfferAtPly || -99) < (this.vm.ply - 20);
        };
        this.offerDraw = () => {
            if (this.canOfferDraw()) {
                this.lastDrawOfferAtPly = this.vm.ply;
                this.socket.iface.send('draw-yes', null);
            }
        };
        this.canDrop = () => {
            return !this.replaying() && isPlayerPlaying(this.data);
        };
        this.jump = (ply) => {
            if (ply < this.firstPly() || ply > this.lastPly())
                return false;
            const wasReplaying = this.replaying();
            const isFwd = ply > this.vm.ply;
            this.vm.ply = ply;
            const s = this.plyStep(ply);
            const config = {
                fen: s.fen,
                lastMove: s.uci ? uciToMove(s.uci) : null,
                check: s.check,
                turnColor: this.vm.ply % 2 === 0 ? 'white' : 'black'
            };
            if (!this.replaying()) {
                config.movableColor = isPlayerPlaying(this.data) ? this.data.player.color : null;
                config.dests = parsePossibleMoves(this.data.possibleMoves);
            }
            this.chessground.set(config);
            if (!wasReplaying && this.replaying())
                this.chessground.stop();
            if (s.san && isFwd) {
                if (s.san.indexOf('x') !== -1)
                    sound.throttledCapture();
                else
                    sound.throttledMove();
            }
            return true;
        };
        this.userJump = (ply) => {
            this.cancelMove();
            this.chessground.selectSquare(null);
            this.jump(ply);
        };
        this.jumpNext = () => {
            return this.jump(this.vm.ply + 1);
        };
        this.jumpPrev = () => {
            return this.jump(this.vm.ply - 1);
        };
        this.jumpFirst = () => {
            return this.jump(this.firstPly());
        };
        this.jumpLast = () => {
            return this.jump(this.lastPly());
        };
        this.cancelMove = (fromBB) => {
            if (fromBB !== 'backbutton')
                router.backbutton.stack.pop();
            this.vm.moveToSubmit = null;
            this.vm.dropToSubmit = null;
            this.jump(this.vm.ply);
        };
        this.submitMove = (v) => {
            if (v && (this.vm.moveToSubmit || this.vm.dropToSubmit) && !this.vm.submitFeedback) {
                if (this.vm.moveToSubmit) {
                    this.actualSendMove(this.vm.moveToSubmit);
                }
                else if (this.vm.dropToSubmit) {
                    this.actualSendMove(this.vm.dropToSubmit);
                }
                if (this.data.game.speed === 'correspondence' && !hasNetwork()) {
                    Toast.show({ text: 'You need to be connected to Internet to send your move.', position: 'bottom', duration: 'short' });
                }
                this.vm.moveToSubmit = null;
                this.vm.dropToSubmit = null;
                this.vm.submitFeedback = [this.data.game.turns, performance.now()];
            }
            else {
                this.cancelMove();
            }
        };
        this.onReload = (rCfg) => {
            if (rCfg.steps.length !== this.data.steps.length) {
                this.vm.ply = rCfg.steps[rCfg.steps.length - 1].ply;
            }
            if (this.chat)
                this.chat.onReload(rCfg.chat);
            if (this.data.tv)
                rCfg.tv = this.data.tv;
            if (this.data.userTV)
                rCfg.userTV = this.data.userTV;
            this.setData(rCfg);
            this.makeCorrespondenceClock();
            if (this.clock && this.data.clock)
                this.clock.setClock(this.data, this.data.clock.white, this.data.clock.black);
            this.lastMoveMillis = undefined;
            if (!this.replaying())
                ground.reload(this.chessground, this.data, rCfg.game.fen, this.vm.flip);
            redraw();
        };
        this.reloadGameData = (isRetry = false) => {
            Promise.all([
                reload$1(this),
                socket.getVersion(),
            ])
                .then(([data, version]) => {
                if ((version === null) || version > data.player.version) {
                    // race condition! try to reload again
                    if (isRetry)
                        router.reload(); // give up and reload the screen
                    else
                        this.reloadGameData(true);
                }
                else
                    this.onReload(data);
            })
                .catch(router.reload);
        };
        this.endWithData = (o) => {
            const d = this.data;
            d.game.winner = o.winner;
            d.game.status = o.status;
            d.game.boosted = o.boosted;
            // in case game is ended with a draw offer
            d.opponent.offeringDraw = false;
            this.userJump(this.lastPly());
            this.chessground.stop();
            if (this.vm.submitFeedback) {
                this.vm.submitFeedback = undefined;
            }
            if (o.ratingDiff) {
                d.player.ratingDiff = o.ratingDiff[d.player.color];
                d.opponent.ratingDiff = o.ratingDiff[d.opponent.color];
            }
            if (this.clock && o.clock)
                this.clock.setClock(d, o.clock.wc * .01, o.clock.bc * .01);
            if (d.game.turns > 1) {
                sound.dong();
                if (d.player.color === d.game.winner) {
                    vibrate.good();
                }
                else {
                    vibrate.bad();
                }
            }
            if (!this.data.player.spectator) {
                session.backgroundRefresh();
                Toast.show({ text: this.gameStatus(), position: 'center', duration: 'short' });
            }
            this.score === undefined;
        };
        this.toggleBookmark = () => {
            return toggleGameBookmark(this.data.game.id).then(() => {
                this.data.bookmarked = !this.data.bookmarked;
                redraw();
            })
                .catch(handleXhrError);
        };
        this.correspondenceClockTick = () => {
            if (this.correspondenceClock && playable(this.data))
                this.correspondenceClock.tick(this.data.game.player);
        };
        this.userMove = (orig, dest, meta) => {
            const hasPremove = !!meta.premove;
            if (!promotion.start(this, orig, dest, hasPremove)) {
                this.sendMove(orig, dest, undefined, hasPremove);
            }
        };
        this.onUserNewPiece = (role, key, meta) => {
            if (!this.replaying() && crazyValid.drop(this.data, role, key, this.data.possibleDrops)) {
                this.sendNewPiece(role, key, !!meta.predrop);
            }
            else {
                this.jump(this.vm.ply);
            }
        };
        this.onMove = (_, dest, capturedPiece) => {
            if (capturedPiece) {
                if (this.data.game.variant.key === 'atomic') {
                    atomic.capture(this.chessground, dest);
                    sound.explosion();
                }
                else {
                    sound.capture();
                }
                if (!this.data.player.spectator) {
                    vibrate.heavy();
                }
            }
            else {
                sound.move();
                if (!this.data.player.spectator) {
                    vibrate.tap();
                }
            }
        };
        this.onNewPiece = () => {
            sound.move();
        };
        this.onResume = () => {
            this.blur = true;
            // hack to avoid nasty race condition on resume: socket will reconnect with
            // an old version and server will send move event that will be processed after
            // a reload by xhr triggered by same resume event
            // thus we disconnect socket and reconnect it after reloading data in order to
            // have last version
            reload$1(this)
                .then(data => {
                socket.setVersion(data.player.version);
                this.onReload(data);
            });
        };
        this.setData(cfg);
        this.data.userTV = userTv;
        this.zenModeEnabled = settings.game.zenMode();
        this.blur = false;
        this.vm = {
            ply: this.lastPly(),
            flip: flipped,
            miniUser: {
                player: {
                    showing: false,
                    data: null
                },
                opponent: {
                    showing: false,
                    data: null
                }
            },
            clockPosition: settings.game.clockPosition() || 'right',
            showCaptured: !!this.data.pref.showCaptured,
            moveList: settings.game.moveList(),
            showingActions: false,
            showingShareActions: false,
            confirmResign: false,
            confirmDraw: false,
            goneBerserk: {
                [this.data.player.color]: !!this.data.player.berserk,
                [this.data.opponent.color]: !!this.data.opponent.berserk
            },
            moveToSubmit: null,
            dropToSubmit: null,
            tClockEl: null,
            // I came to this game offline: I'm an offline watcher
            offlineWatcher: !hasNetwork()
        };
        this.socket = new RoundSocket(this, this.onFeatured);
        this.chat = (session.isKidMode() || this.data.tv || (!this.data.player.spectator && (this.data.game.tournamentId || this.data.opponent.ai))) ? null : new Chat(this.socket.iface, this.data.game.id, this.data.chat || [], this.data.player.spectator ? undefined : this.data.player, session.isConnected() || this.data.game.source === 'friend', session.isShadowban(), this.data.game.speed === 'correspondence' ? 'Corres' : 'Game');
        this.notes = this.data.game.speed === 'correspondence' ? new NotesCtrl(this.data) : null;
        this.chessground = ground.make(this.data, cfg.game.fen, this.userMove, this.onUserNewPiece, this.onMove, this.onNewPiece);
        this.clock = this.data.clock ? new ClockCtrl(this.data, {
            onFlag: this.socket.outoftime,
            soundColor: (this.data.player.spectator || !this.data.pref.clockSound) ? null : this.data.player.color,
            showTenths: this.data.pref.clockTenths,
        }) : null;
        this.makeCorrespondenceClock();
        if (this.correspondenceClock)
            this.clockIntervId = setInterval(this.correspondenceClockTick, 6000);
        this.appStateListener = App.addListener('appStateChange', (state) => {
            if (state.isActive)
                this.onResume();
        });
        signals.gameBackButton.add(() => {
            if (router.backbutton.stack.length === 0 && !isPlayerPlaying(this.data)) {
                router.backHistory();
            }
        });
        this.transientMove = new TransientMove(this);
        if (ply !== undefined) {
            this.jump(ply);
        }
        redraw();
    }
    replaying() {
        return this.vm.ply !== this.lastPly();
    }
    firstPly() {
        return this.data.steps[0].ply;
    }
    lastPly() {
        return this.data.steps[this.data.steps.length - 1].ply;
    }
    plyStep(ply) {
        return this.data.steps[ply - this.firstPly()];
    }
    isClockRunning() {
        return !!this.data.clock && playable(this.data) &&
            ((this.data.game.turns - this.data.game.startedAtTurn) > 1 || this.data.clock.running);
    }
    sendMove(orig, dest, prom, isPremove = false) {
        const move = {
            u: orig + dest
        };
        if (prom) {
            move.u += (prom === 'knight' ? 'n' : prom[0]);
        }
        const sendBlur = this.getBlurAndReset();
        if (this.data.pref.submitMove && !isPremove) {
            router.backbutton.stack.push(this.cancelMove);
            this.vm.moveToSubmit = move;
            redraw();
        }
        else {
            this.actualSendMove(move, isPremove, sendBlur);
            if (this.data.game.speed === 'correspondence' && !hasNetwork()) {
                Toast.show({ text: 'You need to be connected to Internet to send your move.', position: 'bottom', duration: 'short' });
            }
        }
    }
    sendNewPiece(role, key, isPredrop) {
        const drop = {
            role: role,
            pos: key
        };
        const sendBlur = this.getBlurAndReset();
        if (this.data.pref.submitMove && !isPredrop) {
            setTimeout(() => {
                router.backbutton.stack.push(this.cancelMove);
                this.vm.dropToSubmit = drop;
                redraw();
            }, this.data.pref.animationDuration || 0);
        }
        else {
            this.actualSendMove(drop, isPredrop, sendBlur);
        }
    }
    getBlurAndReset() {
        if (this.blur) {
            this.blur = false;
            return true;
        }
        return false;
    }
    apiMove(o) {
        const d = this.data;
        const playing = isPlayerPlaying(d);
        if (playing)
            this.lastMoveMillis = performance.now();
        if (this.vm.submitFeedback && this.vm.submitFeedback[0] + 1 === o.ply) {
            const feebackDuration = this.data.game.speed === 'correspondence' ?
                Math.max(500 - (performance.now() - this.vm.submitFeedback[1]), 0) :
                0;
            setTimeout(() => {
                this.vm.submitFeedback = undefined;
                if (playing) {
                    sound.confirmation();
                    vibrate.tap();
                }
                redraw();
            }, feebackDuration);
        }
        d.game.turns = o.ply;
        d.game.player = o.ply % 2 === 0 ? 'white' : 'black';
        const playedColor = o.ply % 2 === 0 ? 'black' : 'white';
        const white = d.player.color === 'white' ? d.player : d.opponent;
        const black = d.player.color === 'black' ? d.player : d.opponent;
        const activeColor = d.player.color === d.game.player;
        if (o.status) {
            d.game.status = o.status;
        }
        if (o.winner) {
            d.game.winner = o.winner;
        }
        if (o.check) {
            vibrate.doubleTap();
        }
        const wDraw = white.offeringDraw;
        const bDraw = black.offeringDraw;
        if (!wDraw && o.wDraw) {
            sound.dong();
            vibrate.warn();
        }
        if (!bDraw && o.bDraw) {
            sound.dong();
            vibrate.warn();
        }
        white.offeringDraw = o.wDraw;
        black.offeringDraw = o.bDraw;
        d.possibleMoves = activeColor ? o.dests : undefined;
        d.possibleDrops = activeColor ? o.drops : undefined;
        if (!this.replaying()) {
            this.vm.ply++;
            const newConf = {
                turnColor: d.game.player,
                dests: playing ? parsePossibleMoves(d.possibleMoves) : {},
                check: !!o.check
            };
            if (isMove(o)) {
                const enpassantPieces = new Map();
                if (o.enpassant) {
                    const p = o.enpassant;
                    enpassantPieces.set(p.key, null);
                }
                const castlePieces = new Map();
                if (o.castle && !this.chessground.state.autoCastle) {
                    const c = o.castle;
                    castlePieces.set(c.king[0], null);
                    castlePieces.set(c.rook[0], null);
                    castlePieces.set(c.king[1], {
                        role: 'king',
                        color: c.color
                    });
                    castlePieces.set(c.rook[1], {
                        role: 'rook',
                        color: c.color
                    });
                }
                const pdiff = new Map([...enpassantPieces, ...castlePieces]);
                const move = uciToMove(o.uci);
                const pieces = this.chessground.state.pieces;
                if (!o.castle ||
                    (pieces.get(o.castle.king[0])?.role === 'king' &&
                        pieces.get(o.castle.rook[0])?.role === 'rook')) {
                    this.chessground.apiMove(move[0], move[1], pdiff, newConf);
                }
                else {
                    this.chessground.set(newConf);
                }
            }
            else if (isDrop(o)) {
                this.chessground.apiNewPiece({
                    role: o.role,
                    color: playedColor
                }, uciToDropPos(o.uci), newConf);
            }
            if (o.promotion) {
                this.chessground.promote(o.promotion.key, o.promotion.pieceClass);
            }
            if (o.enpassant) {
                const p = o.enpassant;
                if (d.game.variant.key === 'atomic') {
                    atomic.enpassant(this.chessground, p.key, p.color);
                }
                else {
                    sound.capture();
                }
            }
        }
        if (o.clock) {
            const c = o.clock;
            if (this.clock) {
                const delay = (playing && activeColor) ? 0 : (c.lag || 1);
                this.clock.setClock(d, c.white, c.black, delay);
            }
            else if (this.correspondenceClock) {
                this.correspondenceClock.update(c.white, c.black);
            }
        }
        d.game.threefold = !!o.threefold;
        d.steps.push({
            ply: this.lastPly() + 1,
            fen: o.fen,
            san: o.san,
            uci: o.uci,
            check: o.check,
            crazy: o.crazyhouse
        });
        setOnGame(d, playedColor, true);
        if (this.data.expiration) {
            if (this.data.steps.length > 2)
                this.data.expiration = undefined;
            else
                this.data.expiration.movedAt = Date.now();
        }
        if (playing && playedColor === d.player.color) {
            this.transientMove.clear();
        }
        if (!this.replaying() && playedColor !== d.player.color &&
            (this.chessground.state.premovable.current || this.chessground.state.predroppable.current)) {
            // atrocious hack to prevent race condition
            // with explosions and premoves
            // https://github.com/lichess-org/lila/issues/343
            const premoveDelay = d.game.variant.key === 'atomic' ? 100 : 1;
            setTimeout(() => {
                this.chessground.playPremove();
                this.playPredrop();
            }, premoveDelay);
        }
        if (this.data.game.speed === 'correspondence') {
            session.refresh();
        }
    }
    gameStatus() {
        const winner = getPlayer(this.data, this.data.game.winner);
        return gameStatus.toLabel(this.data.game.status.name, this.data.game.turns, this.data.game.winner, this.data.game.variant.key) +
            (winner ? '. ' + i18n(winner.color === 'white' ? 'whiteIsVictorious' : 'blackIsVictorious') + '.' : '');
    }
    goBerserk() {
        this.socket.berserk();
        sound.berserk();
    }
    setBerserk(color) {
        if (this.vm.goneBerserk[color])
            return;
        this.vm.goneBerserk[color] = true;
        if (color !== this.data.player.color)
            sound.berserk();
        redraw();
    }
    unload() {
        this.transientMove.clear();
        if (this.clock)
            this.clock.unload();
        clearInterval(this.clockIntervId);
        this.appStateListener.then((v) => v.remove());
        signals.gameBackButton.removeAll();
    }
    acceptTakeback() {
        this.chessground.cancelPremove();
        this.socket.iface.send('takeback-yes');
    }
    makeCorrespondenceClock() {
        if (this.data.correspondence && !this.correspondenceClock)
            this.correspondenceClock = new CorresClockCtrl(this.data.correspondence, this.socket.outoftime);
    }
    actualSendMove(moveOrDropReq, premove = false, blur = false) {
        const millis = premove ? 0 : this.lastMoveMillis !== undefined ?
            performance.now() - this.lastMoveMillis : undefined;
        const opts = {
            ackable: true,
            withLag: !!this.clock && (millis === undefined || !this.isClockRunning()),
            millis,
            blur
        };
        // Pauses both clocks. When the server echoes back this move, the clocks will resume.
        // This prevents a confusing user experience where a laggy network makes it appear that
        // it's still the user's turn; see #2000.
        this.clock?.stopClock();
        redraw();
        if (isMoveRequest(moveOrDropReq)) {
            this.socket.iface.send('move', moveOrDropReq, opts);
        }
        else if (isDropRequest(moveOrDropReq)) {
            this.socket.iface.send('drop', moveOrDropReq, opts);
        }
        this.transientMove.register();
    }
    playPredrop() {
        return this.chessground.playPredrop((drop) => {
            return crazyValid.drop(this.data, drop.role, drop.key, this.data.possibleDrops);
        });
    }
    setData(cfg) {
        if (cfg.expiration) {
            cfg.expiration.movedAt = Date.now() - cfg.expiration.idleMillis;
        }
        this.data = cfg;
    }
}

export { OnlineRound as O };
//# sourceMappingURL=OnlineRound-Buu5hzF8.js.map
