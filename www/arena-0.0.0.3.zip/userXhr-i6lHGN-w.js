import { f as fetchJSON } from './main.js';

function games(userId, filter = 'all', page = 1, feedback = false) {
    return fetchJSON(`/@/${userId}/${filter}`, {
        query: {
            page
        }
    }, feedback);
}
function following(userId, page = 1) {
    return fetchJSON(`/@/${userId}/following`, {
        query: {
            page
        }
    });
}
function follow(userId) {
    return fetchJSON('/rel/follow/' + userId, { method: 'POST' });
}
function unfollow(userId) {
    return fetchJSON('/rel/unfollow/' + userId, { method: 'POST' });
}
function block(userId) {
    return fetchJSON('/rel/block/' + userId, { method: 'POST' });
}
function unblock(userId) {
    return fetchJSON('/rel/unblock/' + userId, { method: 'POST' });
}
function user(id, feedback = true) {
    return fetchJSON(`/api/user/${id}`, undefined, feedback);
}
function tv(userId) {
    return fetchJSON(`/@/${userId}/tv`);
}
function variantperf(userId, perfKey) {
    return fetchJSON(`/@/${userId}/perf/${perfKey}?graph=1`, undefined, false);
}

export { following as a, user as b, unblock as c, block as d, follow as f, games as g, tv as t, unfollow as u, variantperf as v };
//# sourceMappingURL=userXhr-i6lHGN-w.js.map
