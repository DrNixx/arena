import { M as popup, m as h, O as formWidgets, g as settings, x as ontap, r as redraw, q as router, J as prop, aT as ontouch, F as viewFadeIn, ah as registerPlugin } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { c as clockSettingsView, a as clockSet, i as isStageClock, f as formatTime } from './clockSet-W9lsYtyZ.js';

var clockSettings = {
    controller(reload, clockObj) {
        let isOpen = false;
        function open() {
            if (clockObj().isRunning() && !clockObj().flagged())
                return;
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen: function () {
                return isOpen;
            },
            reload
        };
    },
    view(ctrl) {
        if (ctrl.isOpen()) {
            return popup('new_offline_game clock_settings', undefined, function () {
                return (h("div", null,
                    h("div", { className: "action" },
                        h("div", { className: "select_input" }, formWidgets.renderSelect('Clock', 'clock', settings.clock.availableClocks, settings.clock.clockType, false, onChange)),
                        clockSettingsView(settings.clock.clockType(), onChange)),
                    h("button", { className: "newClockButton", "data-icon": "E", oncreate: ontap(function () {
                            ctrl.reload();
                            ctrl.close();
                        }) }, "Set Clock")));
            }, ctrl.isOpen(), ctrl.close);
        }
        return null;
    }
};
function onChange() {
    redraw();
}

function noop() { }
function ChessClockCtrl() {
    const clockType = prop(settings.clock.clockType());
    const clockObj = prop(clockSet[clockType()](noop));
    let currentMove = 1;
    function reload() {
        if (clockObj() && clockObj().isRunning() && !clockObj().flagged())
            return;
        clockType(settings.clock.clockType());
        clockObj(clockSet[clockType()](noop));
        currentMove = 1;
    }
    const clockSettingsCtrl = clockSettings.controller(reload, clockObj);
    function clockTap(side) {
        clockObj().clockHit(side);
        currentMove += 0.5;
    }
    function startStop() {
        clockObj().startStop();
    }
    function goHome() {
        if (!clockObj().isRunning() || clockObj().flagged()) {
            router.set('/');
        }
    }
    function getMove() {
        return Math.floor(currentMove);
    }
    return {
        startStop,
        clockSettingsCtrl,
        clockObj,
        reload,
        goHome,
        clockTap,
        clockType,
        getMove
    };
}

function renderClockSettingsOverlay(ctrl) {
    return [
        clockSettings.view(ctrl.clockSettingsCtrl)
    ];
}
function clockBody(ctrl) {
    const clock = ctrl.clockObj();
    if (!clock)
        return null;
    const whiteActive = clock.activeSide() === 'white';
    const blackActive = clock.activeSide() === 'black';
    const whiteFlagged = clock.flagged() === 'white';
    const blackFlagged = clock.flagged() === 'black';
    const flagged = whiteFlagged || blackFlagged;
    const whiteClockClass = [
        'clockTapArea',
        'white',
        whiteActive ? 'active' : '',
        clock.isRunning() ? 'running' : '',
        whiteFlagged ? 'flagged' : ''
    ].join(' ');
    const blackClockClass = [
        'clockTapArea',
        'black',
        blackActive ? 'active' : '',
        clock.isRunning() ? 'running' : '',
        blackFlagged ? 'flagged' : ''
    ].join(' ');
    const whiteClockTimeClass = [
        'clockTime',
        whiteFlagged ? 'flagged' : '',
        clock.whiteTime() >= 3600 ? 'long' : ''
    ].join(' ');
    const whiteClockTimeShortClass = [
        'clockTime',
        clock.whiteTime() < 60000 && !whiteFlagged ? 'short' : 'noshort'
    ].join(' ');
    const blackClockTimeClass = [
        'clockTime',
        blackFlagged ? 'flagged' : '',
        clock.blackTime() >= 3600 ? 'long' : ''
    ].join(' ');
    const blackClockTimeShortClass = [
        'clockTime',
        clock.blackTime() < 60000 && !blackFlagged ? 'short' : 'noshort'
    ].join(' ');
    return (h("div", { className: "clockContainer" },
        h("div", { className: whiteClockClass, oncreate: ontouch(() => onClockTouch(ctrl, 'white')) },
            isStageClock(clock) ? renderStage(clock, 'white') : null,
            isStageClock(clock) ? renderMoves(clock.whiteMoves()) : null,
            h("div", { className: "clockTapAreaContent" },
                h("span", { className: whiteClockTimeClass }, whiteFlagged ? 'b' : formatTime(ctrl.clockType(), clock.whiteTime() / 1000)),
                h("span", { className: whiteClockTimeShortClass }, '.' + Math.trunc(clock.whiteTime() / 100 % 10)))),
        h("div", { className: "clockControls" },
            h("button", { className: 'fa' + (clock.isRunning() ? ' fa-pause' : ' fa-play'), oncreate: ontap(() => ctrl.startStop()), disabled: flagged || !clock.activeSide() }),
            h("button", { className: 'fa fa-refresh' + ((clock.isRunning() && !flagged) ? ' disabled' : ''), oncreate: ontap(ctrl.reload) }),
            h("button", { className: 'fa fa-cog' + ((clock.isRunning() && !flagged) ? ' disabled' : ''), oncreate: ontap(ctrl.clockSettingsCtrl.open) }),
            h("button", { hey: "home", className: 'fa fa-home' + ((clock.isRunning() && !flagged) ? ' disabled' : ''), oncreate: ontap(ctrl.goHome) }),
            h("span", { className: "moveNumber" }, ctrl.getMove())),
        h("div", { className: blackClockClass, oncreate: ontouch(() => onClockTouch(ctrl, 'black')) },
            h("div", { className: "clockTapAreaContent" },
                h("span", { className: blackClockTimeClass }, blackFlagged ? 'b' : formatTime(ctrl.clockType(), clock.blackTime() / 1000)),
                h("span", { className: blackClockTimeShortClass }, '.' + Math.trunc(clock.blackTime() / 100 % 10))),
            isStageClock(clock) ? renderStage(clock, 'black') : null,
            isStageClock(clock) ? renderMoves(clock.blackMoves()) : null)));
}
function renderStage(clock, color) {
    const clockState = clock.getState();
    const currentStageIndex = (color === 'white' ? clockState.whiteStage : clockState.blackStage);
    return (h("div", { className: "clockStageInfo" },
        h("span", null,
            "Stage ",
            currentStageIndex + 1)));
}
function renderMoves(moves) {
    if (moves !== null) {
        return (h("div", { className: "clockStageInfo" },
            h("span", null,
                "Moves remaining: ",
                moves)));
    }
    return null;
}
function onClockTouch(ctrl, side) {
    if (((ctrl.clockObj().activeSide() !== 'white') && (side === 'black')) || ((ctrl.clockObj().activeSide() !== 'black') && (side === 'white'))) {
        ctrl.clockTap(side);
    }
}

registerPlugin('FullScreen');
const ChessClockScreen = {
    oncreate: viewFadeIn,
    oninit() {
        this.ctrl = ChessClockCtrl();
    },
    onremove() {
        const c = this.ctrl.clockObj();
        if (c !== undefined) {
            c.clear();
        }
    },
    view() {
        const body = () => clockBody(this.ctrl);
        const clockSettingsOverlay = () => renderClockSettingsOverlay(this.ctrl);
        return layout.clock(body, clockSettingsOverlay);
    }
};

export { ChessClockScreen as default };
//# sourceMappingURL=clock-BDanqFnV.js.map
