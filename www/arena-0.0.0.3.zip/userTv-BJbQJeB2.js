import { F as viewFadeIn, m as h, s as socket, K as handleXhrError } from './main.js';
import { O as OnlineRound } from './OnlineRound-Buu5hzF8.js';
import { e as view, L as LoadingBoard } from './crazyValid-BQyVE87l.js';
import { t as tv } from './userXhr-i6lHGN-w.js';
import './vibrate-CyNrNHlt.js';
import './game-CgD9Ef6g.js';
import './perfs-BLfNpglP.js';
import './chat-Dbn1ft42.js';
import './toInteger-bGq5KERl.js';
import './fen-97CPMMDI.js';
import './layout-DoxuEk9x.js';
import './countries-D-Tn65Re.js';
import './GameTitle-CU8rmgNb.js';
import './CountdownTimer-sy6et_C9.js';
import './Board-UV3Z06Mn.js';
import './promotion-yOaF5Jgj.js';
import './index-r4T5Y9G7.js';
import './tournamentXhr-kOGDWEN6.js';

const UserTv = {
    oninit(vnode) {
        const userId = vnode.attrs.id;
        tv(userId)
            .then(data => {
            data.userTV = userId;
            this.round = new OnlineRound(false, data.game.id, data, false, undefined, userId);
        })
            .catch(handleXhrError);
    },
    oncreate: viewFadeIn,
    onremove() {
        socket.destroy();
        if (this.round) {
            this.round.unload();
        }
    },
    view() {
        if (this.round) {
            return view(this.round);
        }
        else {
            return h(LoadingBoard);
        }
    }
};

export { UserTv as default };
//# sourceMappingURL=userTv-BJbQJeB2.js.map
