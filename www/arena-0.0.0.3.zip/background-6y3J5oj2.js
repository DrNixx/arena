import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, r as redraw, g as settings, m as h, O as formWidgets, cp as isTransparent, cq as loadImage, cr as handleError } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

let timeoutId;
const ThemePrefScreen = {
    oncreate: viewSlideIn,
    oninit() {
        this.loading = false;
        this.progress = null;
        this.onProgress = (e) => {
            if (e.lengthComputable) {
                this.progress = e;
                redraw();
            }
        };
        this.stopLoading = () => {
            if (this.progress) {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => {
                    this.loading = false;
                    this.progress = null;
                    redraw();
                }, 1500);
            }
            else {
                this.loading = false;
                this.progress = null;
                redraw();
            }
        };
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('background')));
        return layout.free(header, renderBody(this));
    }
};
function renderBody(ctrl) {
    const list = settings.general.theme.availableBackgroundThemes;
    const current = settings.general.theme.background();
    return [
        h('div#bgThemes.native_scroller.page.settings_list.radio_list', {
            className: ctrl.loading ? 'loading' : ''
        }, [
            h('ul', list.map((t) => {
                const selected = current === t.key;
                return h('li.list_item', [
                    formWidgets.renderRadio(t.name, 'bg_theme', t.key, selected, e => {
                        const val = e.target.value;
                        const prevTheme = settings.general.theme.background();
                        settings.general.theme.background(val);
                        new Promise((resolve) => {
                            if (isTransparent(val)) {
                                ctrl.loading = true;
                                redraw();
                                loadImage('bg', val, ctrl.onProgress)
                                    .then(() => {
                                    ctrl.stopLoading();
                                    resolve(val);
                                })
                                    .catch((err) => {
                                    settings.general.theme.background(prevTheme);
                                    ctrl.stopLoading();
                                    handleError(err);
                                    resolve(prevTheme);
                                });
                            }
                            else {
                                redraw();
                                resolve(val);
                            }
                        });
                    }, ctrl.loading),
                    selected && ctrl.progress ? h('div.theme-progressBarContainer', [
                        h('div.theme-progressBar', { style: { transform: `translateX(-${100 - progressPercent(ctrl.progress)}%)` } }),
                    ]) : null
                ]);
            }))
        ])
    ];
}
function progressPercent(p) {
    return (p.loaded / p.total) * 100;
}

export { ThemePrefScreen as default };
//# sourceMappingURL=background-6y3J5oj2.js.map
