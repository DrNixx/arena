import { h as throttle, b6 as loadConvo, q as router, r as redraw, b7 as getMore, b8 as loadContacts, b9 as search, ba as del, bb as block, bc as unblock, k as hasNetwork, bd as MessageSocket, m as h, aI as userStatus, c as fromNow, be as closest, x as ontap, o as i18n, $ as Toast, aB as formatDate, bf as backArrow, p as ontapY, w as spinner, M as popup, bg as ontapXY, F as viewFadeIn, G as dropShadowHeader, K as handleXhrError } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { l as linkify } from './html-EBv26hf5.js';

class Scroller {
    constructor() {
        this.enabled = false;
        this.init = (e) => {
            this.enabled = true;
            this.element = e;
            this.element.addEventListener('scroll', throttle(() => {
                const el = this.element;
                this.enable(!!el && el.offsetHeight + el.scrollTop > el.scrollHeight - 20);
            }, 500), { passive: true });
        };
        this.auto = () => {
            if (this.element && this.enabled)
                requestAnimationFrame(() => this.element && (this.element.scrollTop = 9999999));
        };
        this.enable = (v) => { this.enabled = v; };
        this.setMarker = () => {
            this.marker = this.element && this.element.querySelector('mine,their');
        };
        this.toMarker = () => {
            if (this.marker && this.to(this.marker)) {
                this.marker = undefined;
                return true;
            }
            return false;
        };
        this.to = (target) => {
            if (this.element) {
                const top = target.offsetTop - this.element.offsetHeight / 2 + target.offsetHeight / 2;
                if (top > 0)
                    this.element.scrollTop = top;
                return top > 0;
            }
            return false;
        };
    }
}
const scroller = new Scroller;

class MsgCtrl {
    constructor(data) {
        this.search = {
            input: ''
        };
        this.loading = false;
        this.confirmDelete = null;
        this.msgsPerPage = 100;
        this.openConvo = (userId) => {
            if (this.data.convo?.user.id !== userId) {
                this.data.convo = undefined;
                this.loading = true;
            }
            loadConvo(userId).then(data => {
                this.data = data;
                this.search.result = undefined;
                this.loading = false;
                if (data.convo) {
                    router.History.pushState(`/inbox/${data.convo.user.name}`);
                    this.onLoadConvo(data.convo);
                    redraw();
                }
                else
                    this.showSide();
            });
            this.pane = 'convo';
            redraw();
        };
        this.showSide = () => {
            this.pane = 'side';
            router.History.pushState('/inbox');
            redraw();
        };
        this.getMore = () => {
            if (this.data.convo && this.canGetMoreSince)
                getMore(this.data.convo.user.id, this.canGetMoreSince)
                    .then(data => {
                    if (!this.data.convo || !data.convo || data.convo.user.id !== this.data.convo.user.id || !data.convo.msgs[0])
                        return;
                    if (data.convo.msgs[0].date >= this.data.convo.msgs[this.data.convo.msgs.length - 1].date)
                        return;
                    this.data.convo.msgs = this.data.convo.msgs.concat(data.convo.msgs);
                    this.onLoadMsgs(data.convo.msgs);
                    redraw();
                });
            this.canGetMoreSince = undefined;
            redraw();
        };
        this.onLoadConvo = (convo) => {
            this.onLoadMsgs(convo.msgs);
            if (this.typing) {
                clearTimeout(this.typing.timeout);
                this.typing = undefined;
            }
            setTimeout(this.setRead, 500);
        };
        this.onLoadMsgs = (msgs) => {
            const oldFirstMsg = msgs[this.msgsPerPage - 1];
            this.canGetMoreSince = oldFirstMsg?.date;
        };
        this.post = (text) => {
            if (this.data.convo) {
                this.socket.post(this.data.convo.user.id, text);
                const msg = {
                    text,
                    user: this.data.me.id,
                    date: new Date(),
                    read: true
                };
                this.data.convo.msgs.unshift(msg);
                const contact = this.currentContact();
                if (contact) {
                    this.addMsg(msg, contact);
                }
                else {
                    setTimeout(() => loadContacts().then(data => {
                        this.data.contacts = data.contacts;
                        redraw();
                    }), 1000);
                }
                scroller.enable(true);
                redraw();
            }
        };
        this.receive = (msg) => {
            const contact = this.findContact(msg.user);
            this.addMsg(msg, contact);
            if (contact) {
                let redrawn = false;
                if (msg.user === this.data.convo?.user.id) {
                    this.data.convo.msgs.unshift(msg);
                    redrawn = this.setRead();
                    this.receiveTyping(msg.user, true);
                }
                if (!redrawn)
                    redraw();
            }
            else {
                loadContacts().then(data => {
                    this.data.contacts = data.contacts;
                    redraw();
                });
            }
        };
        this.addMsg = (msg, contact) => {
            if (contact) {
                contact.lastMsg = msg;
                this.data.contacts = [contact].concat(this.data.contacts.filter(c => c.user.id !== contact.user.id));
            }
        };
        this.findContact = (userId) => this.data.contacts.find(c => c.user.id === userId);
        this.currentContact = () => this.data.convo && this.findContact(this.data.convo.user.id);
        this.searchInput = (q) => {
            this.search.input = q;
            if (q[1]) {
                search(q).then((res) => {
                    this.search.result = this.search.input[1] ? res : undefined;
                    redraw();
                });
            }
            else {
                this.search.result = undefined;
                redraw();
            }
        };
        this.setRead = () => {
            const msg = this.currentContact()?.lastMsg;
            if (msg && msg.user !== this.data.me.id) {
                if (msg.read)
                    return false;
                msg.read = true;
                this.socket.setRead(msg.user);
                redraw();
                return true;
            }
            return false;
        };
        this.delete = () => {
            const userId = this.data.convo?.user.id;
            if (userId)
                del(userId).then(data => {
                    this.data = data;
                    this.confirmDelete = null;
                    this.pane = 'side';
                    redraw();
                    router.History.pushState('/inbox');
                });
        };
        this.block = () => {
            const userId = this.data.convo?.user.id;
            if (userId)
                block(userId).then(() => this.openConvo(userId));
        };
        this.unblock = () => {
            const userId = this.data.convo?.user.id;
            if (userId)
                unblock(userId).then(() => this.openConvo(userId));
        };
        this.changeBlockBy = (userId) => {
            if (userId === this.data.convo?.user.id)
                this.openConvo(userId);
        };
        this.sendTyping = throttle((user) => {
            this.socket.typing(user);
        }, 3000);
        this.receiveTyping = (userId, cancel) => {
            if (this.typing) {
                clearTimeout(this.typing.timeout);
                this.typing = undefined;
            }
            if (cancel !== true && this.data.convo?.user.id === userId) {
                this.typing = {
                    user: userId,
                    timeout: setTimeout(() => {
                        if (this.data.convo?.user.id === userId)
                            this.typing = undefined;
                        redraw();
                    }, 3000)
                };
            }
            redraw();
        };
        this.onReconnect = () => {
            this.data.convo && this.openConvo(this.data.convo.user.id);
            redraw();
        };
        this.data = data;
        this.pane = data.convo ? 'convo' : 'side';
        this.connected = hasNetwork;
        this.socket = new MessageSocket(this);
        if (this.data.convo)
            this.onLoadConvo(this.data.convo);
        this.setRead();
    }
}

function renderContact(ctrl, contact, active) {
    const user = contact.user, msg = contact.lastMsg, isNew = !msg.read && msg.user !== ctrl.data.me.id;
    return h('div.msg-app__side__contact', {
        key: `${user.id}${active === user.id ? '-active' : ''}`,
        className: active === user.id ? 'active' : '',
        'data-userid': user.id,
    }, [
        h('div.msg-app__side__contact__user', [
            h('div.msg-app__side__contact__head', [
                userStatus({ ...user, username: user.name }),
                h('div.msg-app__side__contact__date', renderDate$1(msg))
            ]),
            h('div.msg-app__side__contact__body', [
                h('div.msg-app__side__contact__msg', {
                    className: isNew ? 'msg-app__side__contact__msg--new' : '',
                }, msg.text),
                isNew ? h('i.msg-app__side__contact__new', {
                    'data-icon': ''
                }) : null
            ])
        ])
    ]);
}
function getContact(e) {
    return closest(e, '.msg-app__side__contact');
}
function onContactTap(e, ctrl) {
    const el = getContact(e);
    const ds = el?.dataset;
    if (ds.userid) {
        ctrl.openConvo(ds.userid);
    }
}
function renderDate$1(msg) {
    return h('time.timeago', {
        key: msg.date.getTime(),
        title: msg.date.toLocaleString(),
        datetime: msg.date.getTime()
    }, fromNow(msg.date));
}

function renderActions(ctrl, convo) {
    if (convo.user.id === 'lichess')
        return [];
    return (h('button.msg-app__convo__action.button.button-empty.bad', {
        key: 'delete',
        'data-icon': 'q',
        title: i18n('delete'),
        oncreate: ontap(() => ctrl.confirmDelete = convo.user.id)
    }));
}

let prev = 0;
function renderInteract(ctrl, user) {
    const connected = ctrl.connected();
    return h('form.msg-app__convo__post', {
        onsubmit: (e) => {
            e.preventDefault();
            const now = Date.now();
            if (now - 1000 < prev)
                return;
            const form = e.target;
            const area = form[0];
            const body = area.value.trim();
            if (body.length > 8000) {
                Toast.show({ text: 'Message is too long', duration: 'short' });
            }
            else if (body.length > 0) {
                prev = now;
                ctrl.post(body);
                area.value = '';
                area.focus();
            }
        }
    }, [
        renderTextarea(ctrl, user),
        h('button.msg-app__convo__post__submit.button.fa.fa-telegram', {
            className: connected ? 'connected' : '',
            type: 'submit',
            disabled: !connected
        })
    ]);
}
function renderTextarea(ctrl, user) {
    return h('textarea.msg-app__convo__post__text', {
        rows: 1,
        oncreate: vnode => {
            const area = vnode.dom;
            area.addEventListener('input', throttle(() => {
                ctrl.sendTyping(user.id);
            }, 500));
        }
    });
}

function renderMsgs(ctrl, convo) {
    return h('div.msg-app__convo__msgs.native_scroller', {
        oncreate(vnode) {
            scroller.init(vnode.dom);
            scroller.auto();
        },
        onupdate() {
            scroller.auto();
        },
    }, [
        h('div.msg-app__convo__msgs__content', [
            ctrl.canGetMoreSince ? h('button.msg-app__convo__msgs__more.button.button-empty', {
                key: 'more',
                oncreate: ontap(() => {
                    scroller.setMarker();
                    ctrl.getMore();
                })
            }, 'Load more') : null,
            ...contentMsgs(ctrl, convo.msgs),
            ctrl.typing ? h('div.msg-app__convo__msgs__typing', `${convo.user.name} is typing...`) : null
        ])
    ]);
}
function contentMsgs(ctrl, msgs) {
    const dailies = groupMsgs(msgs);
    const nodes = [];
    dailies.forEach(daily => nodes.push(...renderDaily(ctrl, daily)));
    return nodes;
}
function renderDaily(ctrl, daily) {
    return [
        h('day', renderDate(daily.date)),
        ...daily.msgs.map(group => h('group', group.map(msg => renderMsg(ctrl, msg))))
    ];
}
function renderMsg(ctrl, msg) {
    const tag = msg.user === ctrl.data.me.id ? 'mine' : 'their';
    return h(tag, [
        renderText(msg),
        h('em', `${pad2(msg.date.getHours())}:${pad2(msg.date.getMinutes())}`)
    ]);
}
const pad2 = (num) => (num < 10 ? '0' : '') + num;
function groupMsgs(msgs) {
    let prev = msgs[0];
    if (!prev)
        return [{ date: new Date(), msgs: [] }];
    const dailies = [{
            date: prev.date,
            msgs: [[prev]]
        }];
    msgs.slice(1).forEach(msg => {
        if (sameDay(msg.date, prev.date)) {
            if (msg.user === prev.user)
                dailies[0].msgs[0].unshift(msg);
            else
                dailies[0].msgs.unshift([msg]);
        }
        else
            dailies.unshift({
                date: msg.date,
                msgs: [[msg]]
            });
        prev = msg;
    });
    return dailies;
}
const today = new Date();
const yesterday = new Date();
yesterday.setDate(yesterday.getDate() - 1);
function renderDate(date) {
    if (sameDay(date, today))
        return i18n('today').toUpperCase();
    if (sameDay(date, yesterday))
        return i18n('yesterday').toUpperCase();
    return formatDate(date);
}
const sameDay = (d, e) => d.getDate() === e.getDate() && d.getMonth() === e.getMonth() && d.getFullYear() === e.getFullYear();
const renderText = (msg) => h('t', h.trust(linkify(msg.text).replace(/\n/g, '<br>')));

function renderConvo(ctrl, convo) {
    const user = convo.user;
    return h('div.msg-app__convo', {
        key: 'convo-loaded',
    }, [
        h('div.msg-app__convo__head', [
            h('div.msg-app__convo__head__left', [
                h('button.msg-app__convo__head__back', {
                    oncreate: ontap(() => { ctrl.showSide(); })
                }, backArrow),
                h('div.user-link', {
                    oncreate: ontap(() => router.set(`/@/${user.name}`)),
                    className: user.online ? 'online' : 'offline'
                }, userStatus({ ...user, username: user.name }))
            ]),
            h('div.msg-app__convo__head__actions', renderActions(ctrl, convo))
        ]),
        renderMsgs(ctrl, convo),
        h('div.msg-app__convo__reply', [
            convo.relations.out === false || convo.relations.in === false ?
                h('div.msg-app__convo__reply__block.text', {
                    'data-icon': 'k'
                }, 'This conversation is blocked.') : (convo.postable ?
                renderInteract(ctrl, user) :
                h('div.msg-app__convo__reply__block.text', {
                    'data-icon': 'k'
                }, `${user.name} doesn't accept new messages.`))
        ])
    ]);
}

function renderInput(ctrl) {
    return h('div.msg-app__side__search', [
        ctrl.data.me.kid ? null : h('input', {
            placeholder: i18n('searchOrStartNewDiscussion'),
            oncreate: vnode => {
                const input = vnode.dom;
                input.addEventListener('input', throttle(() => ctrl.searchInput(input.value.trim()), 500));
            }
        })
    ]);
}
function renderResults(ctrl, res) {
    return h('div.msg-app__search.msg-app__side__content.native_scroller', {
        oncreate: ontapY(e => onContactTap(e, ctrl), undefined, getContact)
    }, [
        res.contacts[0] && h('section', [
            h('h2', i18n('discussions')),
            h('div.msg-app__search__contacts', res.contacts.map(t => renderContact(ctrl, t)))
        ]),
        res.friends[0] && h('section', [
            h('h2', i18n('friends')),
            h('div.msg-app__search__users', res.friends.map(renderUser))
        ]),
        res.users[0] && h('section', [
            h('h2', i18n('players')),
            h('div.msg-app__search__users', res.users.map(renderUser))
        ])
    ]);
}
function renderUser(user) {
    return h('div.msg-app__side__contact', {
        key: user.id,
        'data-userid': user.id,
    }, [
        h('div.msg-app__side__contact__user', [
            h('div.msg-app__side__contact__head', [
                userStatus({ ...user, username: user.name })
            ])
        ])
    ]);
}

function renderInbox(ctrl) {
    if (ctrl) {
        const activeId = ctrl.data.convo?.user.id;
        return h('main.box.msg-app', {
            className: `pane-${ctrl.pane}`
        }, [
            h('div.msg-app__side', {
                key: 'side',
            }, [
                renderInput(ctrl),
                ctrl.search.result ?
                    renderResults(ctrl, ctrl.search.result) :
                    h('div.msg-app__contacts.msg-app__side__content.native_scroller', {
                        oncreate: ontapY(e => onContactTap(e, ctrl), undefined, getContact)
                    }, ctrl.data.contacts.map(t => renderContact(ctrl, t, activeId)))
            ]),
            ctrl.data.convo ? renderConvo(ctrl, ctrl.data.convo) : (ctrl.loading ?
                h('div.msg-app__convo', {
                    key: 'convo-loading',
                }, [
                    h('div.msg-app__convo__head'),
                    spinner.getVdom(),
                ]) : h('div.msg-app__convo', { key: 'convo-empty' }))
        ]);
    }
    else {
        return spinner.getVdom();
    }
}

function renderOverlay(ctrl) {
    if (!ctrl?.confirmDelete)
        return null;
    return popup('go_or_cancel', () => `${i18n('delete')}?`, () => {
        return [
            action('L', i18n('cancel'), () => ctrl.confirmDelete = null),
            action('q', i18n('delete'), () => ctrl.delete())
        ];
    }, true, () => {
        ctrl.confirmDelete = null;
        redraw();
    });
}
function action(icon, text, handler, extraClass) {
    return h('button.withIcon.binary_choice', {
        className: extraClass,
        'data-icon': icon,
        oncreate: ontapXY(handler)
    }, text);
}

var msg = {
    oncreate: viewFadeIn,
    oninit({ attrs }) {
        const userId = attrs.id;
        if (userId) {
            loadConvo(userId).then(msgData => {
                this.ctrl = new MsgCtrl(msgData);
                redraw();
            }).catch((error) => {
                // no conversation with this user... _yet_
                if (error.status === 404) {
                    loadContacts().then(msgData => {
                        msgData.convo = {
                            user: {
                                id: userId,
                                name: userId.toLowerCase()
                            },
                            msgs: [],
                            relations: {},
                            postable: true
                        };
                        this.ctrl = new MsgCtrl(msgData);
                    });
                }
                else {
                    handleXhrError(error);
                    router.set('/inbox');
                }
            });
        }
        else {
            loadContacts().then(msgData => {
                this.ctrl = new MsgCtrl(msgData);
                redraw();
            }).catch(handleXhrError);
        }
    },
    view() {
        const headerEl = dropShadowHeader(i18n('inbox'));
        const body = renderInbox(this.ctrl);
        const overlay = renderOverlay(this.ctrl);
        return layout.free(headerEl, body, null, overlay);
    }
};

export { msg as default };
//# sourceMappingURL=msg-BryWQ465.js.map
