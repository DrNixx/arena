import { r as redraw, K as handleXhrError, $ as Toast, G as dropShadowHeader, I as backButton, m as h, o as i18n, y as plural, F as viewFadeIn, s as socket } from './main.js';
import { b as getTeam, j as joinTeam, l as leaveTeam } from './teamsXhr-Bkb9l9T6.js';
import { l as layout } from './layout-DoxuEk9x.js';

class TeamCtrl {
    constructor(teamId) {
        this.teamId = teamId;
        getTeam(teamId)
            .then(data => {
            this.team = data;
            redraw();
        })
            .catch(handleXhrError);
    }
    join(form) {
        const team = this.team;
        if (!team)
            return null;
        const message = team.open ? null : form[0].value;
        joinTeam(team.id, message)
            .then((data) => {
            if (!data.ok) {
                Toast.show({ text: 'Join failed', duration: 'short' });
            }
            this.reload(this.teamId);
        })
            .catch(handleXhrError);
    }
    leave() {
        const team = this.team;
        if (!team)
            return null;
        leaveTeam(team.id)
            .then((data) => {
            if (!data.ok) {
                Toast.show({ text: 'Leave failed', duration: 'short' });
            }
            this.reload(this.teamId);
        })
            .catch(handleXhrError);
    }
    reload(teamId) {
        getTeam(teamId, true)
            .then(data => {
            this.team = data;
            redraw();
        })
            .catch(handleXhrError);
    }
}

function header(ctrl) {
    const team = ctrl.team;
    if (!team)
        return null;
    return dropShadowHeader(null, backButton(h('div.main_header_title.withSub', [
        h('h1', [
            team.name
        ])
    ])));
}
function body(ctrl) {
    const team = ctrl.team;
    if (!team)
        return null;
    return h('div.teamPage.native_scroller.page', [
        h('section.teamInfos', [
            h('div.teamLeader', team.leaders.map(userStatus)),
            h('div.teamMembers', [team.nbMembers + ' ' + i18n('members')]),
            h('div.teamDescription', [team.description]),
        ]),
        h('section.teamJoinLeave', [
            team.requested ? requestPending() : (team.joined ? renderLeave(ctrl) : renderJoin(ctrl))
        ])
    ]);
}
function userStatus(leader) {
    const patron = leader.patron ? h('span.patron.userStatus', { 'data-icon': '' }, []) : null;
    const title = leader.title ? h('span.userTitle', [leader.title + ' ']) : null;
    return h('div.user', [
        h('span', [plural('teamLeaders', 1) + ': ']),
        patron,
        title,
        leader.name
    ]);
}
function renderJoin(ctrl) {
    const team = ctrl.team;
    if (!team)
        return null;
    const joinMessage = team.open ?
        null
        :
            h('textarea.joinMessage', { id: 'message', minLength: 30, maxLength: 2000 }, [
                'Hello, I would like to join the team!'
            ]);
    return h('div.teamJoinLeave', [
        h('form', { id: 'joinForm', onsubmit: (e) => {
                e.preventDefault();
                ctrl.join(e.target);
            } }, [
            joinMessage,
            h('button.fatButton.joinLeaveButton', { type: 'submit' }, [
                h('span.fa.fa-check'),
                i18n('joinTeam')
            ])
        ])
    ]);
}
function renderLeave(ctrl) {
    const team = ctrl.team;
    if (!team)
        return null;
    return h('div.teamJoinLeave', [
        h('form', { id: 'leaveForm', onsubmit: (e) => {
                e.preventDefault();
                ctrl.leave();
            } }, [
            h('button.fatButton.joinLeaveButton', { type: 'submit' }, [
                h('span.fa.fa-check'),
                i18n('quitTeam')
            ])
        ])
    ]);
}
function requestPending() {
    return h('div.teamRequestPending', [
        h('span', ['Your join request is being reviewed by the team leader.'])
    ]);
}

var teamDetail = {
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = new TeamCtrl(attrs.id);
    },
    oncreate: viewFadeIn,
    view() {
        const ctrl = this.ctrl;
        const headerCtrl = header(ctrl);
        const bodyCtrl = body(ctrl);
        return layout.free(headerCtrl, bodyCtrl, undefined);
    }
};

export { teamDetail as default };
//# sourceMappingURL=teamDetail-XoPuk9Vw.js.map
