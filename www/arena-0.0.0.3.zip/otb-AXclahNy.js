import { M as popup, m as h, x as ontap, o as i18n, O as formWidgets, g as settings, r as redraw, q as router, P as specialFenVariants, Q as getVariant, V as ViewOnlyBoard, J as prop, d as debounce, R as sound, A as App, S as oppositeColor, T as uciToMoveOrDrop, U as classSet, X as isPortrait, Y as viewportDim, _ as hasSpaceForInlineReplay, k as hasNetwork, $ as Toast, F as viewFadeIn, a0 as header, s as socket } from './main.js';
import { s as setCurrentOTBGame, g as getCurrentOTBGame } from './offlineGames-CDpjbNo0.js';
import { e as emptyFen, p as playerFromFen } from './fen-97CPMMDI.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { a as atomic, c as crazyValid, v as viewOnlyBoardContent } from './crazyValid-BQyVE87l.js';
import { G as GameTitle } from './GameTitle-CU8rmgNb.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { i as init } from './chess-B1K_bSdL.js';
import { g as gameStatus } from './game-CgD9Ef6g.js';
import { p as promotion, v as view } from './promotion-yOaF5Jgj.js';
import { r as renderEndedGameStatus, a as renderClaimDrawButton, g as ground, s as setResult, R as Replay, d as data, b as renderReplay, c as renderInlineReplay, e as renderAntagonist, f as renderBackwardButton, h as renderForwardButton } from './view-BWIKaE22.js';
import { c as clockSettingsView, a as clockSet } from './clockSet-W9lsYtyZ.js';
import { I as ImporterCtrl } from './ImporterCtrl-vAwyaRIl.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './CountdownTimer-sy6et_C9.js';
import './tournamentXhr-kOGDWEN6.js';
import './toInteger-bGq5KERl.js';
import './chat-Dbn1ft42.js';

function renderAlways(ctrl) {
    return [
        h('div', [
            h('button[data-icon=A]', {
                oncreate: ontap(ctrl.goToAnalysis)
            }, i18n('analysis'))
        ]),
        h('div.action', formWidgets.renderCheckbox(i18n('otbFlipPiecesAndInfoAfterMove'), 'flipPieces', settings.otb.flipPieces, (v) => ground.changeOTBMode(ctrl.chessground, v))),
        h('div.action', formWidgets.renderCheckbox(i18n('otbUseSymmetricPieces'), 'useSymmetric', settings.otb.useSymmetric, redraw))
    ];
}
var actions = {
    controller(root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open: open,
            close: close,
            isOpen: function () {
                return isOpen;
            },
            root: root
        };
    },
    view: function (ctrl) {
        if (ctrl.isOpen()) {
            return popup('offline_actions', undefined, function () {
                return [
                    renderEndedGameStatus(ctrl.root)
                ].concat(renderClaimDrawButton(ctrl.root), renderAlways(ctrl.root));
            }, ctrl.isOpen(), ctrl.close);
        }
        return null;
    }
};

var newGameMenu = {
    controller(root) {
        const isOpen = prop(false);
        function open() {
            router.backbutton.stack.push(close);
            isOpen(true);
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen() === true)
                router.backbutton.stack.pop();
            isOpen(false);
        }
        return {
            open,
            close,
            isOpen,
            root
        };
    },
    view: function (ctrl) {
        if (ctrl.isOpen()) {
            return popup('new_offline_game', undefined, function () {
                const availVariants = settings.otb.availableVariants;
                const variants = ctrl.root.vm.setupFen ?
                    availVariants.filter(i => !specialFenVariants.has(i[1])) :
                    availVariants;
                const setupVariant = settings.otb.variant();
                const hasSpecialSetup = ctrl.root.vm.setupFen && specialFenVariants.has(setupVariant);
                return (h("div", null,
                    h("div", { className: "action" },
                        hasSpecialSetup ?
                            h("div", { className: "select_input disabled" },
                                h("label", { for: "variant" }, i18n('variant')),
                                h("select", { disabled: true, id: "variant" },
                                    h("option", { value: setupVariant, selected: true }, getVariant(setupVariant).name))) :
                            h("div", { className: "select_input" }, formWidgets.renderSelect('variant', 'variant', variants, settings.otb.variant)),
                        ctrl.root.vm.setupFen ?
                            h("div", { className: "from_position_wrapper" },
                                h("p", null, i18n('fromPosition')),
                                h("div", { className: "from_position" },
                                    h("div", { style: {
                                            width: '130px',
                                            height: '130px'
                                        }, oncreate: ontap(() => {
                                            if (ctrl.root.vm.setupFen)
                                                router.set(`/editor/${encodeURIComponent(ctrl.root.vm.setupFen)}`);
                                        }) }, h(ViewOnlyBoard, { fen: ctrl.root.vm.setupFen, orientation: 'white' })))) : null,
                        h("div", { className: "select_input" }, formWidgets.renderSelect(i18n('clock'), 'clock', settings.otb.availableClocks, settings.otb.clockType, false, onChange)),
                        clockSettingsView(settings.otb.clockType(), onChange)),
                    h("div", { className: "popupActionWrapper" },
                        h("button", { className: "defaultButton", oncreate: ontap(() => {
                                ctrl.close();
                                ctrl.root.startNewGame(settings.otb.variant(), ctrl.root.vm.setupFen, settings.otb.clockType());
                            }) }, i18n('play')))));
            }, ctrl.isOpen(), () => {
                if (ctrl.root.vm.setupFen) {
                    router.set('/otb');
                }
                ctrl.close();
            });
        }
        return null;
    }
};
function onChange() {
    redraw();
}

var importGamePopup = {
    controller(root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen: function () {
                return isOpen;
            },
            root: root,
            importer: ImporterCtrl()
        };
    },
    view(ctrl) {
        return popup('OtbImportGamePopup', undefined, () => {
            const white = settings.otb.whitePlayer;
            const black = settings.otb.blackPlayer;
            return h('div', [
                h('p', 'Import current game state with following player names on lichess?'),
                h('form', [
                    h('div.exchange', {
                        oncreate: ontap(() => {
                            const w = white();
                            const b = black();
                            white(b);
                            black(w);
                        })
                    }, h('span.fa.fa-exchange.fa-rotate-90')),
                    h('div.importMeta.text_input_container', [
                        h('label', i18n('white')),
                        h('input[type=text]', {
                            value: white(),
                            oninput: debounce((e) => {
                                const val = e.target.value.trim();
                                white(val);
                            }, 300),
                            onfocus() {
                                this.select();
                            },
                            spellcheck: false
                        })
                    ]),
                    h('div.importMeta.text_input_container', [
                        h('label', i18n('black')),
                        h('input[type=text]', {
                            value: black(),
                            oninput: debounce((e) => {
                                const val = e.target.value.trim();
                                black(val);
                            }, 300),
                            onfocus() {
                                this.select();
                            },
                            spellcheck: false
                        })
                    ])
                ]),
                h('div.popupActionWrapper', [
                    ctrl.importer.importing() ?
                        h('div', [h('span.fa.fa-hourglass-half'), h('span', 'Importing...')]) :
                        h('button.popupAction.withIcon[data-icon=E]', {
                            oncreate: ontap(() => {
                                const white = settings.otb.whitePlayer;
                                const black = settings.otb.blackPlayer;
                                ctrl.root.replay?.pgn(white(), black())
                                    .then(data => {
                                    ctrl.importer.importGame(data.pgn);
                                });
                            })
                        }, 'Import on lichess')
                ])
            ]);
        }, ctrl.isOpen(), ctrl.close);
    }
};

class OtbRound {
    constructor(saved, setupFen, setupVariant) {
        this.promoting = null;
        this.goToAnalysis = () => {
            if (this.replay) {
                router.set(`/analyse/offline/otb/${this.data.player.color}?ply=${this.replay.ply}&curFen=${this.replay.situation().fen}`);
            }
        };
        this.save = () => {
            if (this.replay) {
                setCurrentOTBGame({
                    data: this.data,
                    situations: this.replay.situations,
                    ply: this.replay.ply
                });
            }
        };
        this.saveClock = () => {
            if (this.clock && this.clock.isRunning()) {
                this.clock.startStop();
            }
            this.save();
        };
        this.isClockEnabled = () => {
            return !!this.clock &&
                this.clock.flagged() === undefined && this.clock.activeSide() !== undefined;
        };
        this.toggleClockPlay = () => {
            if (this.clock && this.isClockEnabled()) {
                this.clock.startStop();
            }
        };
        this.sharePGN = () => {
            this.replay?.pgn('White', 'Black')
                .then((data) => Share.share({ text: data.pgn }));
        };
        this.onPromotion = (orig, dest, role) => {
            this.replay?.addMove(orig, dest, role);
        };
        this.userMove = (orig, dest) => {
            if (!promotion.start(this, orig, dest, this.onPromotion)) {
                this.replay?.addMove(orig, dest);
            }
        };
        this.onMove = (_, dest, capturedPiece) => {
            if (capturedPiece) {
                if (this.data.game.variant.key === 'atomic') {
                    atomic.capture(this.chessground, dest);
                    sound.explosion();
                }
                else
                    sound.capture();
            }
            else
                sound.move();
        };
        this.onUserNewPiece = (role, key) => {
            const sit = this.replay.situation();
            if (crazyValid.drop(this.data, role, key, sit.drops)) {
                this.replay?.addDrop(role, key);
            }
            else {
                this.apply(this.replay.situation());
            }
        };
        this.onNewPiece = () => {
            sound.move();
        };
        this.onFlag = (color) => {
            const winner = color === 'white' ? 'black' : 'white';
            setResult(this, { id: 35, name: 'outoftime' }, winner);
            sound.dong();
            this.onGameEnd();
            this.save();
        };
        this.onReplayAdded = (sit) => {
            const lastMovePlayer = sit.player === 'white' ? 'black' : 'white';
            if (this.clock) {
                this.clock.clockHit(lastMovePlayer);
            }
            this.data.game.fen = sit.fen;
            this.apply(sit);
            setResult(this, sit.status);
            if (gameStatus.finished(this.data)) {
                this.onGameEnd();
            }
            this.save();
            redraw();
        };
        this.onThreefoldRepetition = (newStatus) => {
            setResult(this, newStatus);
            this.save();
            this.onGameEnd();
        };
        this.onGameEnd = () => {
            if (this.clock && this.clock.isRunning()) {
                this.clock.startStop();
            }
            this.chessground.stop();
            setTimeout(() => {
                this.actions.open();
                redraw();
            }, 500);
        };
        this.player = () => {
            return this.replay?.situation().player || 'white';
        };
        this.jump = (ply) => {
            this.chessground.cancelMove();
            if (ply < 0 || ply >= this.replay.situations.length)
                return false;
            this.replay.ply = ply;
            this.apply(this.replay.situation());
            return false;
        };
        this.jumpNext = () => this.jump(this.replay.ply + 1);
        this.jumpPrev = () => this.jump(this.replay.ply - 1);
        this.jumpFirst = () => this.jump(this.firstPly());
        this.jumpLast = () => this.jump(this.lastPly());
        this.firstPly = () => 0;
        this.lastPly = () => this.replay.situations.length - 1;
        this.replaying = () => {
            return this.replay.ply !== this.lastPly();
        };
        this.canDrop = () => true;
        this.setupFen = setupFen;
        this.actions = actions.controller(this);
        this.importGamePopup = importGamePopup.controller(this);
        this.newGameMenu = newGameMenu.controller(this);
        this.vm = {
            flip: false,
            setupFen,
            savedFen: saved ? saved.data.game.fen : undefined
        };
        this.moveList = !!settings.game.moveList();
        if (setupFen) {
            this.newGameMenu.isOpen(true);
            if (setupVariant) {
                settings.otb.variant(setupVariant);
            }
            redraw();
        }
        else if (!saved || saved.ply === 0)
            this.newGameMenu.open();
        const currentVariant = settings.otb.variant();
        if (!setupFen) {
            if (saved) {
                try {
                    this.init(saved.data, saved.situations, saved.ply);
                }
                catch (e) {
                    this.startNewGame(currentVariant, undefined, settings.otb.clockType());
                }
            }
            else {
                this.startNewGame(currentVariant, undefined, settings.otb.clockType());
            }
        }
        this.appStateListener = App.addListener('appStateChange', (state) => {
            if (!state.isActive)
                this.saveClock();
        });
    }
    unload() {
        this.appStateListener.then((v) => v.remove);
        this.saveClock();
    }
    init(data, situations, ply) {
        this.actions.close();
        this.data = data;
        const variant = this.data.game.variant.key;
        const initialFen = this.data.game.initialFen;
        if (!this.replay) {
            this.replay = new Replay(variant, initialFen, situations, ply, this.onReplayAdded, this.onThreefoldRepetition);
        }
        else {
            this.replay.init(variant, initialFen, situations, ply);
        }
        if (data.offlineClock) {
            const clockType = data.offlineClock.clockType;
            this.clock = clockSet[clockType](this.onFlag);
            this.clock.setState(data.offlineClock);
        }
        else {
            this.clock = undefined;
        }
        if (!this.chessground) {
            this.chessground = ground.make(this.data, this.replay.situation(), this.userMove, this.onUserNewPiece, this.onMove, this.onNewPiece);
        }
        else {
            ground.reload(this.chessground, this.data, this.replay.situation());
        }
        redraw();
    }
    startNewGame(variant, setupFen, clockType) {
        const payload = {
            variant
        };
        if (setupFen) {
            payload.fen = setupFen;
        }
        const clock = clockType && clockType !== 'none' ?
            clockSet[clockType](this.onFlag) : null;
        init(payload)
            .then((data$1) => {
            this.init(data({
                id: 'offline_otb',
                variant: data$1.variant,
                initialFen: data$1.setup.fen,
                fen: data$1.setup.fen,
                player: data$1.setup.player,
                color: this.data && oppositeColor(this.data.player.color) || data$1.setup.player,
                pref: {
                    centerPiece: true
                },
                clock: clock ? clock.getState() : null
            }), [data$1.setup], 0);
        })
            .then(() => {
            if (setupFen) {
                this.vm.setupFen = undefined;
                router.History.replaceState(undefined, '/otb');
            }
        });
    }
    apply(sit) {
        if (sit) {
            if (this.clock && this.clock.activeSide() !== sit.player) {
                this.clock.toggleActiveSide();
            }
            const lastUci = sit.uciMoves.length ? sit.uciMoves[sit.uciMoves.length - 1] : null;
            this.chessground.set({
                fen: sit.fen,
                turnColor: sit.player,
                lastMove: lastUci ? uciToMoveOrDrop(lastUci) : null,
                dests: sit.dests,
                movableColor: sit.player,
                check: sit.check
            });
        }
    }
}

function overlay(ctrl) {
    return [
        actions.view(ctrl.actions),
        newGameMenu.view(ctrl.newGameMenu),
        importGamePopup.view(ctrl.importGamePopup),
        view(ctrl)
    ];
}
function renderContent(ctrl, pieceTheme) {
    const flip = settings.otb.flipPieces();
    const wrapperClasses = classSet({
        'otb': true,
        'mode_flip': flip,
        'mode_facing': !flip,
        'turn_white': ctrl.chessground.state.turnColor === 'white',
        'turn_black': ctrl.chessground.state.turnColor === 'black'
    });
    const material = ctrl.chessground.getMaterialDiff();
    const playerName = i18n(ctrl.data.player.color);
    const opponentName = i18n(ctrl.data.opponent.color);
    const replayTable = renderReplay(ctrl);
    const isPortrait$1 = isPortrait();
    const vd = viewportDim();
    const board = h(Board, {
        variant: ctrl.data.game.variant.key,
        chessground: ctrl.chessground,
        wrapperClasses,
        customPieceTheme: pieceTheme
    });
    const clock = ctrl.clock;
    if (isPortrait$1)
        return [
            hasSpaceForInlineReplay(vd, isPortrait$1) ? renderInlineReplay(ctrl) : null,
            renderAntagonist(ctrl, opponentName, material[ctrl.data.opponent.color], 'opponent', flip, pieceTheme, clock),
            board,
            renderAntagonist(ctrl, playerName, material[ctrl.data.player.color], 'player', flip, pieceTheme, clock),
            renderGameActionsBar(ctrl)
        ];
    else
        return [
            board,
            h("section", { className: "table" },
                renderAntagonist(ctrl, opponentName, material[ctrl.data.opponent.color], 'opponent', flip, pieceTheme, clock),
                replayTable,
                renderGameActionsBar(ctrl),
                renderAntagonist(ctrl, playerName, material[ctrl.data.player.color], 'player', flip, pieceTheme, clock))
        ];
}
function renderGameActionsBar(ctrl) {
    return (h("section", { className: "actions_bar" },
        h("button", { className: "action_bar_button fa fa-ellipsis-v", oncreate: ontap(ctrl.actions.open) }),
        h("button", { className: "action_bar_button fa fa-plus-circle", oncreate: ontap(() => { ctrl.saveClock(); ctrl.newGameMenu.open(); }, () => Toast.show({ text: i18n('createAGame'), duration: 'short', position: 'bottom' })) }),
        h("button", { className: "fa fa-share-alt action_bar_button", oncreate: ontap(ctrl.sharePGN, () => Toast.show({ text: i18n('sharePgn'), duration: 'short', position: 'bottom' })) }),
        ctrl.clock ?
            h("button", { className: 'fa action_bar_button ' + (ctrl.clock.isRunning() ? 'fa-pause' : 'fa-play') + (ctrl.isClockEnabled() ? '' : ' disabled'), oncreate: ontap(ctrl.toggleClockPlay, () => Toast.show({ text: i18n('chessClock'), duration: 'short', position: 'bottom' })) })
            : null,
        hasNetwork() ?
            h("button", { className: "fa fa-cloud-upload action_bar_button", oncreate: ontap(ctrl.importGamePopup.open, () => Toast.show({ text: i18n('Import game on lichess'), duration: 'short', position: 'bottom' })) }) : null,
        renderBackwardButton(ctrl),
        renderForwardButton(ctrl)));
}

var otb = {
    oninit({ attrs }) {
        socket.createDefault();
        getCurrentOTBGame().then(saved => {
            this.round = new OtbRound(saved, attrs.fen, attrs.variant);
            window.addEventListener('unload', this.round.saveClock);
        });
    },
    oncreate: viewFadeIn,
    onremove() {
        if (this.round) {
            this.round.unload();
            window.removeEventListener('unload', this.round.saveClock);
        }
    },
    view({ attrs }) {
        let content, header$1;
        const pieceTheme = settings.otb.useSymmetric() ? 'symmetric' : undefined;
        if (this.round && this.round.data && this.round.chessground) {
            header$1 = header(h(GameTitle, { data: this.round.data }));
            content = renderContent(this.round, pieceTheme);
        }
        else {
            const fen = attrs.fen || emptyFen;
            const color = playerFromFen(fen) ;
            header$1 = header(i18n('overTheBoard'));
            content = viewOnlyBoardContent(fen, color, undefined, 'standard', undefined, pieceTheme);
        }
        return layout.board(header$1, content, undefined, this.round && overlay(this.round), undefined, this.round && this.round.data && this.round.data.player.color || 'white');
    }
};

export { otb as default };
//# sourceMappingURL=otb-AXclahNy.js.map
