import { z as gameIcon, m as h, aJ as playerName, o as i18n, c as fromNow, aS as isGameData } from './main.js';
import { t as title, p as playable, g as gameStatus, q as isPlayerTurn } from './game-CgD9Ef6g.js';
import { C as CountdownTimer } from './CountdownTimer-sy6et_C9.js';

var GameTitle = {
    onbeforeupdate({ attrs }, { attrs: oldattrs }) {
        // careful with that, mutability doesn't help, but it should be easy to know
        // what changes here
        return attrs.data !== oldattrs.data || attrs.subTitle === 'corres' || attrs.subTitle !== oldattrs.subTitle ||
            attrs.kidMode !== oldattrs.kidMode;
    },
    view({ attrs }) {
        const { data, subTitle, kidMode } = attrs;
        const icon = data.game.source === 'import' ? '/' :
            gameIcon(data.game.perf || data.game.variant.key);
        const title$1 = title(data);
        let subEls = null;
        if (subTitle === 'players') {
            subEls = [
                h('span', playerName(data.player, true, true, 12)),
                h('span.swords', { 'data-icon': 'U' }),
                h('span', playerName(data.opponent, true, true, 12))
            ];
        }
        else if (subTitle === 'date') {
            if (playable(data)) {
                subEls = i18n('playingRightNow');
            }
            else if (gameStatus.aborted(data)) {
                subEls = i18n('gameAborted');
            }
            else if (data.game.createdAt) {
                subEls = fromNow(new Date(data.game.createdAt));
            }
        }
        else if (subTitle === 'corres' && isGameData(data)) {
            if (gameStatus.finished(data)) {
                subEls = i18n('gameOver');
            }
            else if (isPlayerTurn(data)) {
                subEls = i18n('yourTurn');
            }
            else {
                subEls = i18n('waitingForOpponent');
            }
        }
        else if (subTitle === 'tournament' && isGameData(data) && data.tournament) {
            const ttime = data.tournament.secondsToFinish;
            if (ttime) {
                subEls = [
                    h('span.fa.fa-trophy'),
                    h(CountdownTimer, { seconds: ttime }),
                    h('span', ' • ' + data.tournament.name)
                ];
            }
            else {
                subEls = [
                    h('span.fa.fa-trophy'),
                    h('span', [
                        data.tournament.name,
                        data.game.createdAt ?
                            (' (' + fromNow(new Date(data.game.createdAt)) + ')') : null
                    ])
                ];
            }
        }
        return h('div.main_header_title', {
            className: subTitle !== undefined ? 'withSub' : ''
        }, [
            h('h1.header-gameTitle', [
                kidMode ? h('span.kiddo', '😊') : null,
                h('span.withIcon', { 'data-icon': icon }),
                h('span', title$1)
            ]),
            subEls ? h('h2.header-subTitle', subEls) : null
        ]);
    }
};

export { GameTitle as G };
//# sourceMappingURL=GameTitle-CU8rmgNb.js.map
