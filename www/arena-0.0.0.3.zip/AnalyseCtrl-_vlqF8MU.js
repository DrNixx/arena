import { f as fetchJSON, bT as fetchText, M as popup, m as h, x as ontap, o as i18n, w as spinner, U as classSet, q as router, r as redraw, K as handleXhrError, b as session, g as settings, bX as loadCss, bY as loadScript, S as oppositeColor, O as formWidgets, bZ as isDrop, b_ as roleToChar, b$ as makeSquare, c0 as squareFile, c1 as SquareSet, c2 as squareRank, c3 as FILE_NAMES, c4 as RANK_NAMES, bg as ontapXY, E as getLI, a$ as parseFen, c5 as parseUci, $ as Toast, p as ontapY, J as prop, c6 as importMasterGame, y as plural, ab as fixCrazySan, aL as findParentBySelector, L as i18nVdom, ay as batchRequestAnimationFrame, aJ as playerName, aP as renderRatingDiff, c7 as shallowEqual, T as uciToMoveOrDrop, a2 as uciToDropPos, a3 as uciToDropRole, aF as uciToMove, a1 as uciToProm, c8 as opposite, z as gameIcon, b5 as isTablet, ak as loadingBackbutton, V as ViewOnlyBoard, c9 as Capacitor, bQ as requestIdleCallback, ca as altCastles, bU as SESSION_ID_KEY, d as debounce, a6 as Chessground, a7 as animationDuration, cb as currentSri, cc as SideMenuCtrl, s as socket, k as hasNetwork, R as sound, az as toggleGameBookmark, cd as decomposeUci, ce as sanToRole, cf as openingSensibleVariants, n as noop, cg as chessopRulesFromVariant, ch as formatDateTime, aq as Dialog, ci as readDests } from './main.js';
import { e as emptyFen, c as colorOf$1, r as readCheckCount } from './fen-97CPMMDI.js';
import { k as kingAttacks, q as queenAttacks, r as rookAttacks, b as bishopAttacks, a as knightAttacks, s as setupPosition, c as continuePopup } from './variant-Cl-7Z946.js';
import { v as view$1, p as promotion } from './promotion-yOaF5Jgj.js';
import { a as getPGN, C as CrazyPocket, t as toInteger, n as notesView, N as NotesCtrl } from './toInteger-bGq5KERl.js';
import { a as TabView, T as TabNavigation } from './TabView-CG79fzxt.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { c as chatView, C as Chat } from './chat-Dbn1ft42.js';
import { l as linkify } from './html-EBv26hf5.js';
import { p as playable, z as publicAnalyseUrl, A as publicGIFUrl, B as analysable, C as renderEval$1, D as getBestEval, E as nodeFullName, F as empty, G as plyToTurn$1, f as getPlayer, g as gameStatus, H as tablebaseGuaranteed, I as defined, J as isSynthetic, j as replayable, K as autoScroll, L as isEvalBetter, M as analysableVariants, N as plyColor } from './game-CgD9Ef6g.js';
import { h as hasBranching, c as contains, i as init, l as last, m as mainlineNodeList, r as root, b as build, a as reconstruct, f as fromNodeList, t as takePathWhile, d as countChildrenAndComments, w as withMainlineChild } from './tree-ByUN6R2a.js';
import { w as withPath, g as constant, h as curveLinear, x, y, j as array, d as line, s as select, l as linear, e as axisLeft } from './axis-iOnHMIBv.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import { p as pgnDump, m as move, d as drop, s as situation } from './chess-B1K_bSdL.js';
import { v as vibrate } from './vibrate-CyNrNHlt.js';
import { g as getNbCores, S as StockfishPlugin } from './index-CkC0Yhqy.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { s as studyPGN, a as studyChapterPGN } from './studyXhr-CPiJUv6u.js';

function gameAnalysis(gameId, color) {
    return fetchJSON(`/${gameId}/${color}/analysis`);
}
function requestComputerAnalysis(gameId) {
    return fetchText(`/${gameId}/request-analysis`, {
        method: 'POST'
    }, true);
}

function isOnlineAnalyseData(d) {
    return d.url !== undefined;
}

var analyseMenu = {
    controller(root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
            s.showShareMenu = false;
        }
        const s = {
            showShareMenu: false,
            computingPGN: false,
            computingPGNAnnotated: false,
        };
        return {
            open,
            close,
            isOpen: () => isOpen,
            root,
            s
        };
    },
    view(ctrl) {
        return popup('analyse_menu', undefined, () => ctrl.s.showShareMenu ? renderShareMenu$1(ctrl.root) : renderAnalyseMenu(ctrl.root), ctrl.isOpen(), ctrl.close);
    }
};
function renderAnalyseMenu(ctrl) {
    return h('div.analyseMenu', h.fragment({ key: 'analyseMenu' }, [
        h('button', {
            oncreate: ontap(() => {
                ctrl.menu.s.showShareMenu = true;
            })
        }, [h('span.fa.fa-share'), i18n('shareAndExport')]),
        ctrl.isOfflineOrNotPlayable() ? h('button[data-icon=U]', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.continuePopup.open(ctrl.node.fen, ctrl.data.game.variant.key, ctrl.data.player.color);
            })
        }, i18n('continueFromHere')) : null,
        ctrl.isOfflineOrNotPlayable() ? h('button', {
            oncreate: ontap(() => router.set(`/editor/${encodeURIComponent(ctrl.node.fen)}`))
        }, [h('span.fa.fa-pencil'), i18n('boardEditor')]) : null,
        ctrl.data.analysis ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.toggleRetro();
            }),
            disabled: !!ctrl.retro
        }, [h('span.fa.fa-play'), i18n('learnFromYourMistakes')]) : null,
        ctrl.ceval.allowed ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.togglePractice();
            }),
        }, [h('span.fa.fa-bullseye'), i18n('practiceWithComputer')]) : null,
        ctrl.ceval.allowed ? h('button', {
            className: classSet({
                on: ctrl.showThreat,
            }),
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.toggleShowThreat();
            }),
        }, [h('span.fa.fa-crosshairs'), i18n('showThreat')]) : null,
        ctrl.notes ? h('button', {
            oncreate: ontap(() => {
                if (ctrl.notes) {
                    ctrl.menu.close();
                    ctrl.notes.open();
                }
            })
        }, [h('span.fa.fa-pencil'), i18n('notes')]) : null
    ]));
}
function renderShareMenu$1(ctrl) {
    return h('div.analyseMenu', h.fragment({ key: 'shareMenu' }, [
        isOnlineAnalyseData(ctrl.data) ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                Share.share({ url: publicAnalyseUrl(ctrl.data) });
            })
        }, [i18n('shareGameUrl')]) : null,
        ctrl.source === 'offline' ? h('button', {
            oncreate: ontap(() => {
                offlinePgnExport(ctrl);
            }),
        }, ctrl.menu.s.computingPGN ? spinner.getVdom('monochrome') : [i18n('sharePgn')]) : null,
        ctrl.source === 'online' && !playable(ctrl.data) ? h('button', {
            oncreate: ontap(() => {
                onlinePGNExport(ctrl, false);
            }),
        }, ctrl.menu.s.computingPGNAnnotated ? spinner.getVdom('monochrome') : 'Share annotated PGN') : null,
        ctrl.source === 'online' && !playable(ctrl.data) ? h('button', {
            oncreate: ontap(() => {
                onlinePGNExport(ctrl, true);
            }),
        }, ctrl.menu.s.computingPGN ? spinner.getVdom('monochrome') : 'Share raw PGN') : null,
        isOnlineAnalyseData(ctrl.data) ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                Share.share({ url: publicGIFUrl(ctrl.data) });
            })
        }, ['Share game GIF']) : null,
        ctrl.isOfflineOrNotPlayable() ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                Share.share({ text: ctrl.node.fen });
            }),
        }, 'Share current FEN') : null,
    ]));
}
function onlinePGNExport(ctrl, raw) {
    if ((raw && !ctrl.menu.s.computingPGN) || (!raw && !ctrl.menu.s.computingPGNAnnotated)) {
        if (raw)
            ctrl.menu.s.computingPGN = true;
        else
            ctrl.menu.s.computingPGNAnnotated = true;
        getPGN(ctrl.data.game.id, raw)
            .then((pgn) => {
            ctrl.menu.s.computingPGN = false;
            ctrl.menu.s.computingPGNAnnotated = false;
            ctrl.menu.close();
            redraw();
            Share.share({ text: pgn });
        })
            .catch(e => {
            ctrl.menu.s.computingPGN = false;
            ctrl.menu.s.computingPGNAnnotated = false;
            redraw();
            handleXhrError(e);
        });
    }
}
function offlinePgnExport(ctrl) {
    if (!ctrl.menu.s.computingPGN) {
        ctrl.menu.s.computingPGN = true;
        const endSituation = ctrl.tree.lastNode();
        const white = ctrl.data.player.color === 'white' ?
            (ctrl.data.game.id === 'offline_ai' ? session.appUser('Anonymous') : 'Anonymous') :
            (ctrl.data.game.id === 'offline_ai' ? ctrl.data.opponent.username : 'Anonymous');
        const black = ctrl.data.player.color === 'black' ?
            (ctrl.data.game.id === 'offline_ai' ? session.appUser('Anonymous') : 'Anonymous') :
            (ctrl.data.game.id === 'offline_ai' ? ctrl.data.opponent.username : 'Anonymous');
        pgnDump({
            variant: ctrl.data.game.variant.key,
            initialFen: ctrl.data.game.initialFen,
            pgnMoves: endSituation.pgnMoves || [],
            white,
            black
        })
            .then((res) => {
            ctrl.menu.s.computingPGN = false;
            ctrl.menu.close();
            redraw();
            Share.share({ text: res.pgn });
        })
            .catch(e => {
            ctrl.menu.s.computingPGN = false;
            redraw();
            console.error(e);
        });
    }
}

function loadShepherd() {
    const theme = settings.general.theme.background();
    const shepherdTheme = theme === 'light' ?
        'shepherd-theme-dark' : 'shepherd-theme-default';
    return loadCss(`vendor/shepherd/css/${shepherdTheme}.css`)
        .then(() => loadCss('vendor/shepherd/css/shepherd.css'))
        .then(() => loadScript('vendor/shepherd/js/tether.js'))
        .then(() => loadScript('vendor/shepherd/js/shepherd.min.js'))
        .then(() => shepherdTheme);
}

function startTour(ctrl) {
    loadShepherd()
        .then(theme => {
        const tour = new window.Shepherd.Tour({
            defaults: {
                classes: 'shepherd-element ' + theme,
                showCancelLink: true,
            }
        });
        tour.addStep('welcome', {
            title: 'Welcome to lichess study!',
            text: 'This is a shared analysis board.<br><br>' +
                'Use it to analyse games,<br>' +
                'discuss positions with friends,<br>' +
                'and of course for chess lessons!',
        });
        tour.addStep('members', {
            title: 'Study members',
            text: '<i data-icon=\'v\'></i> Spectators can view the study and talk in the chat.<br>' +
                '<br><i class=\'fa fa-user\'></i> Contributors can make moves and update the study.' +
                '<br><br>Studies are for now read-only in the application, so you must go to lichess.org to contribute to them. More features will come later in lichess app.',
            when: {
                'before-show': () => {
                    ctrl.sideMenu.open();
                }
            }
        });
        tour.addStep('chapters', {
            title: 'Study chapters',
            text: 'A study can contain several chapters.<br>' +
                'Each chapter has a distinct initial position and move tree.',
            when: {
                'before-show': () => {
                    ctrl.sideMenu.open();
                }
            },
            buttons: [{
                    text: 'Done',
                    action: tour.next
                }]
        });
        tour.start();
    });
}

var actionMenu = {
    controller(root) {
        let isOpen = false;
        const s = {
            showShareMenu: false,
            loadingStudyPGN: false,
            loadingChapterPGN: false,
        };
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
            s.showShareMenu = false;
        }
        return {
            open,
            close,
            isOpen: () => isOpen,
            root,
            s
        };
    },
    view(ctrl) {
        return popup('analyse_menu', undefined, () => ctrl.s.showShareMenu ? renderShareMenu(ctrl.root) : renderStudyMenu(ctrl.root), ctrl.isOpen(), ctrl.close);
    }
};
const baseUrl = 'https://live.chess-online.com/';
function renderStudyMenu(ctrl) {
    return h('div.analyseMenu', { key: 'studyMenu' }, [
        h('button', {
            oncreate: ontap(() => {
                ctrl.study.actionMenu.s.showShareMenu = true;
            })
        }, [h('span.fa.fa-share'), i18n('shareAndExport')]),
        h('button', {
            oncreate: ontap(ctrl.study.toggleLike)
        }, [
            h.trust('&nbsp;'),
            h('span.fa', {
                className: ctrl.study.data.liked ? 'fa-heart' : 'fa-heart-o'
            }),
            `Like (${ctrl.study.data.likes})`
        ]),
        ctrl.study && ctrl.study.chat ? h('button[data-icon=B]', {
            oncreate: ontap(ctrl.settings.flip)
        }, i18n('flipBoard')) : null,
        h('button[data-icon=U]', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.continuePopup.open(ctrl.node.fen, ctrl.data.game.variant.key, ctrl.data.player.color);
            })
        }, i18n('continueFromHere')),
        ctrl.ceval.allowed ? h('button', {
            oncreate: ontap(() => {
                ctrl.menu.close();
                ctrl.togglePractice();
            }),
        }, [h('span.fa.fa-bullseye'), i18n('practiceWithComputer')]) : null,
        h('button', {
            oncreate: ontap(() => router.set(`/editor/${encodeURIComponent(ctrl.node.fen)}`))
        }, [h('span.fa.fa-pencil'), i18n('boardEditor')]),
        h('button', {
            oncreate: ontap(() => {
                ctrl.study.actionMenu.close();
                startTour(ctrl.study);
            }),
        }, [
            h('span.fa.fa-question-circle'),
            'Help'
        ]),
    ]);
}
function renderShareMenu(ctrl) {
    function onPgnSuccess(pgn) {
        ctrl.study.actionMenu.s.loadingChapterPGN = false;
        ctrl.study.actionMenu.s.loadingStudyPGN = false;
        redraw();
        Share.share({ text: pgn });
    }
    function onPgnError(e) {
        ctrl.study.actionMenu.s.loadingChapterPGN = false;
        ctrl.study.actionMenu.s.loadingStudyPGN = false;
        redraw();
        handleXhrError(e);
    }
    return h('div.analyseMenu', { key: 'shareMenu' }, [
        h('button', {
            oncreate: ontap(() => {
                const url = baseUrl + `study/${ctrl.study.data.id}`;
                Share.share({ url });
            })
        }, [i18n('studyUrl')]),
        h('button', {
            oncreate: ontap(() => {
                const url = baseUrl + `study/${ctrl.study.data.id}/${ctrl.study.data.chapter.id}`;
                Share.share({ url });
            })
        }, [i18n('currentChapterUrl')]),
        h('button', {
            oncreate: ontap(() => {
                ctrl.study.actionMenu.s.loadingStudyPGN = true;
                studyPGN(ctrl.study.data.id)
                    .then(onPgnSuccess)
                    .catch(onPgnError);
            })
        }, ctrl.study.actionMenu.s.loadingStudyPGN ? spinner.getVdom('monochrome') : [i18n('studyPgn')]),
        h('button', {
            oncreate: ontap(() => {
                ctrl.study.actionMenu.s.loadingChapterPGN = true;
                studyChapterPGN(ctrl.study.data.id, ctrl.study.data.chapter.id)
                    .then(onPgnSuccess)
                    .catch(onPgnError);
            })
        }, ctrl.study.actionMenu.s.loadingChapterPGN ? spinner.getVdom('monochrome') : [i18n('chapterPgn')]),
    ]);
}

const RichText = {
    view({ attrs: { text } }) {
        return text.split('\n').map(line => h.fragment({}, [h.trust(linkify(line)), h('br')]));
    }
};

function renderReadonlyComments(ctrl) {
    const comments = ctrl.node.comments || [];
    return h('div.native_scroller.study-comments', comments.map(c => h('div.study-comment', [
        h('div.by', (typeof c.by === 'string' ? c.by : c.by.name) + ':'),
        h('div', h(RichText, { text: c.text }))
    ])));
}
function renderPgnTags(ctrl) {
    const study = ctrl.study;
    if (!study)
        return h('div', 'oops! nothing to see here');
    return h('div.native_scroller', [
        h('table.study-tags', [
            h('tbody', study.data.chapter.tags.map(([tagName, tagValue]) => h('tr.study-tag', [
                h('th', tagName),
                h('td', h.trust(linkify(tagValue)))
            ])))
        ])
    ]);
}

var analyseSettings = {
    controller(root) {
        let isOpen = false;
        let cevalCoresOnOpen = settings.analyse.cevalCores();
        let cevalHashSizeOnOpen = settings.analyse.cevalHashSize();
        function open() {
            router.backbutton.stack.push(close);
            cevalCoresOnOpen = settings.analyse.cevalCores();
            cevalHashSizeOnOpen = settings.analyse.cevalHashSize();
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
            if ((settings.analyse.cevalCores() !== cevalCoresOnOpen) ||
                (settings.analyse.cevalHashSize() !== cevalHashSizeOnOpen)) {
                router.reload();
            }
        }
        const s = {
            smallBoard: settings.analyse.smallBoard(),
            showBestMove: settings.analyse.showBestMove(),
            showComments: settings.analyse.showComments(),
            flip: false,
        };
        return {
            root,
            open,
            close,
            isOpen: () => isOpen,
            s,
            toggleBoardSize() {
                const newVal = !s.smallBoard;
                settings.analyse.smallBoard(newVal);
                s.smallBoard = newVal;
            },
            toggleBestMove() {
                const newVal = !s.showBestMove;
                s.showBestMove = newVal;
            },
            toggleComments() {
                const newVal = !s.showComments;
                s.showComments = newVal;
            },
            flip() {
                s.flip = !s.flip;
                root.chessground.set({
                    orientation: s.flip ? oppositeColor(root.orientation) : root.orientation
                });
                if (root.retro)
                    root.toggleRetro();
                if (root.practice)
                    root.restartPractice();
            },
            cevalSetMultiPv(pv) {
                settings.analyse.cevalMultiPvs(pv);
                root.ceval.setMultiPv(pv);
            },
            cevalToggleInfinite() {
                root.ceval.toggleInfinite();
            },
        };
    },
    view(ctrl) {
        return popup('analyse_menu', undefined, () => renderAnalyseSettings(ctrl.root), ctrl.isOpen(), ctrl.close);
    }
};
function renderAnalyseSettings(ctrl) {
    const maxCores = getNbCores();
    const maxMem = window.deviceInfo.stockfishMaxMemory;
    return h('div.analyseSettings', [
        h('div.action', {
            className: !ctrl.ceval.allowed || !!ctrl.retro ? 'disabled' : ''
        }, [
            formWidgets.renderCheckbox(i18n('toggleLocalEvaluation'), 'allowCeval', settings.analyse.enableCeval, v => {
                ctrl.ceval.toggle();
                if (v)
                    ctrl.initCeval();
                else {
                    ctrl.ceval.destroy();
                    ctrl.resetTabs();
                    if (ctrl.retro) {
                        ctrl.retro.close();
                        ctrl.retro = null;
                    }
                }
            }, !ctrl.ceval.allowed || !!ctrl.retro),
            h('small.caution', i18n('localEvalCaution'))
        ]),
        ctrl.study || ctrl.ceval.allowed ? h('div.action', [
            formWidgets.renderCheckbox(i18n('bestMoveArrow'), 'showBestMove', settings.analyse.showBestMove, ctrl.settings.toggleBestMove)
        ]) : null,
        ctrl.study || (ctrl.source === 'online' && isOnlineAnalyseData(ctrl.data) && analysable(ctrl.data)) ? h('div.action', [
            formWidgets.renderCheckbox(i18n('keyShowOrHideComments'), 'showComments', settings.analyse.showComments, ctrl.settings.toggleComments)
        ]) : null,
        h('div.action', [
            formWidgets.renderCheckbox(i18n('infiniteAnalysis'), 'ceval.infinite', settings.analyse.cevalInfinite, ctrl.settings.cevalToggleInfinite, !ctrl.ceval.allowed),
        ]),
        h('div.action', [
            formWidgets.renderSlider(i18n('multipleLines'), 'ceval.multipv', 1, 5, 1, settings.analyse.cevalMultiPvs, ctrl.settings.cevalSetMultiPv, !ctrl.ceval.allowed)
        ]),
        maxCores > 1 ? h('div.action', [
            formWidgets.renderSlider(i18n('cpus'), 'ceval.cores', 1, maxCores, 1, settings.analyse.cevalCores, undefined, !ctrl.ceval.allowed)
        ]) : null,
        maxMem > 32 ? h('div.action', [
            formWidgets.renderSlider(i18n('memory'), 'ceval.hashSize', 16, maxMem, 16, settings.analyse.cevalHashSize, undefined, !ctrl.ceval.allowed)
        ]) : null,
    ]);
}

function makeSanWithoutSuffix(pos, move) {
    let san = '';
    if (isDrop(move)) {
        if (move.role !== 'pawn')
            san = roleToChar(move.role).toUpperCase();
        san += '@' + makeSquare(move.to);
    }
    else {
        const role = pos.board.getRole(move.from);
        if (!role)
            return '--';
        if (role === 'king' && (pos.board[pos.turn].has(move.to) || Math.abs(move.to - move.from) === 2)) {
            san = move.to > move.from ? 'O-O' : 'O-O-O';
        }
        else {
            const capture = pos.board.occupied.has(move.to) || (role === 'pawn' && squareFile(move.from) !== squareFile(move.to));
            if (role !== 'pawn') {
                san = roleToChar(role).toUpperCase();
                // Disambiguation
                let others;
                if (role === 'king')
                    others = kingAttacks(move.to).intersect(pos.board.king);
                else if (role === 'queen')
                    others = queenAttacks(move.to, pos.board.occupied).intersect(pos.board.queen);
                else if (role === 'rook')
                    others = rookAttacks(move.to, pos.board.occupied).intersect(pos.board.rook);
                else if (role === 'bishop')
                    others = bishopAttacks(move.to, pos.board.occupied).intersect(pos.board.bishop);
                else
                    others = knightAttacks(move.to).intersect(pos.board.knight);
                others = others.intersect(pos.board[pos.turn]).without(move.from);
                if (others.nonEmpty()) {
                    const ctx = pos.ctx();
                    for (const from of others) {
                        if (!pos.dests(from, ctx).has(move.to))
                            others = others.without(from);
                    }
                    if (others.nonEmpty()) {
                        let row = false;
                        let column = others.intersects(SquareSet.fromRank(squareRank(move.from)));
                        if (others.intersects(SquareSet.fromFile(squareFile(move.from))))
                            row = true;
                        else
                            column = true;
                        if (column)
                            san += FILE_NAMES[squareFile(move.from)];
                        if (row)
                            san += RANK_NAMES[squareRank(move.from)];
                    }
                }
            }
            else if (capture)
                san = FILE_NAMES[squareFile(move.from)];
            if (capture)
                san += 'x';
            san += makeSquare(move.to);
            if (move.promotion)
                san += '=' + roleToChar(move.promotion).toUpperCase();
        }
    }
    return san;
}
function makeSanAndPlay(pos, move) {
    var _a;
    const san = makeSanWithoutSuffix(pos, move);
    pos.play(move);
    if ((_a = pos.outcome()) === null || _a === void 0 ? void 0 : _a.winner)
        return san + '#';
    if (pos.isCheck())
        return san + '+';
    return san;
}
function makeSanVariation(pos, variation) {
    var _a;
    pos = pos.clone();
    const line = [];
    for (let i = 0; i < variation.length; i++) {
        if (i !== 0)
            line.push(' ');
        if (pos.turn === 'white')
            line.push(pos.fullmoves, '. ');
        else if (i === 0)
            line.push(pos.fullmoves, '... ');
        const san = makeSanWithoutSuffix(pos, variation[i]);
        pos.play(variation[i]);
        line.push(san);
        if (san === '--')
            return line.join('');
        if (i === variation.length - 1 && ((_a = pos.outcome()) === null || _a === void 0 ? void 0 : _a.winner))
            line.push('#');
        else if (pos.isCheck())
            line.push('+');
    }
    return line.join('');
}
function makeSan(pos, move) {
    return makeSanAndPlay(pos.clone(), move);
}

function lichessRules(variant) {
    switch (variant) {
        case 'standard':
        case 'chess960':
        case 'fromPosition':
            return 'chess';
        case 'threeCheck':
            return '3check';
        case 'kingOfTheHill':
            return 'kingofthehill';
        case 'racingKings':
            return 'racingkings';
        default:
            return variant;
    }
}

function renderCeval(ctrl) {
    if (!ctrl.ceval.enabled())
        return h('div.ceval-notEnabled', 'Computer eval is disabled');
    return h('div.ceval-Wrapper', [
        renderCevalInfos(ctrl),
        renderCevalPvs(ctrl)
    ]);
}
function renderCevalInfos(ctrl) {
    const node = ctrl.node;
    const ceval = node.threat || node.ceval;
    const isInfinite = settings.analyse.cevalInfinite();
    if (!ceval)
        return null;
    return h('div.analyse-fixedBar.ceval-infos', {
        className: ceval.cloud ? 'cloud' : ''
    }, [
        h('div.depth', [
            h('span', i18n('depthX', ceval.depth + (isInfinite || ceval.maxDepth === undefined ? '' : `/${ceval.maxDepth}`))),
            ctrl.ceval.canGoDeeper() ? h('button.fa.fa-plus-square', {
                oncreate: ontap(ctrl.ceval.goDeeper, () => {
                    Toast.show({ text: i18n('goDeeper'), position: 'center', duration: 'short' });
                })
            }) : null
        ]),
        ceval.millis !== undefined ? h('div.time', [
            i18n('time'), ' ', formatTime(ceval.millis)
        ]) : null,
        ceval.knps !== undefined ? h('div.knps', [
            'kn/s ', Math.round(ceval.knps)
        ]) : null,
        ceval.cloud ? h('span.ceval-cloud', 'Cloud') : null
    ]);
}
function formatTime(millis) {
    const s = Math.round(millis / 1000);
    if (s < 60) {
        return s + 's';
    }
    else {
        const min = Math.round(s / 60);
        const rs = s % 60;
        return `${min}min ${rs}s`;
    }
}
function onLineTap(ctrl, e) {
    const el = getLI(e);
    const uci = el && el.dataset['uci'];
    if (!ctrl.showThreat && uci)
        ctrl.playUci(uci);
}
function renderCevalPvs(ctrl) {
    const multiPv = ctrl.ceval.getMultiPv();
    const node = ctrl.node;
    const ceval = node.threat || node.ceval;
    if (ceval && !ctrl.gameOver()) {
        const pvs = ceval.pvs;
        return h('ul.ceval-pv_box.native_scroller', {
            oncreate: ontapXY(e => onLineTap(ctrl, e), undefined, getLI)
        }, [...Array(multiPv).keys()].map((i) => {
            if (!pvs[i])
                return h('li.pv');
            const pos = setupPosition(lichessRules(ctrl.ceval.variant), parseFen(node.fen).unwrap());
            return h('li.ceval-pv', {
                'data-uci': pvs[i].moves[0],
                className: (i % 2 === 0) ? 'even' : 'odd'
            }, [
                h('strong.ceval-pv_eval', pvs[i].mate !== undefined ? ('#' + pvs[i].mate) : renderEval$1(pvs[i].cp)),
                h('div.ceval-pv-line', pos.unwrap(pos => makeSanVariation(pos, pvs[i].moves.slice(0, 12).map(m => parseUci(m))), _ => '--'))
            ]);
        }));
    }
    else if (ctrl.gameOver()) {
        return h('div.ceval-pv_box.native_scroller.loading.gameOver', [h('i.withIcon[data-icon=]'), i18n('gameOver')]);
    }
    else {
        return h('div.ceval-pv_box.native_scroller.loading', spinnerPearl());
    }
}
const EvalBox = {
    onbeforeupdate({ attrs }) {
        return !attrs.ctrl.replaying;
    },
    view({ attrs }) {
        const { ctrl } = attrs;
        const node = ctrl.node;
        const threatMode = ctrl.showThreat;
        const threat = threatMode && ctrl.node.threat;
        const bestEv = threat || getBestEval({ client: node.ceval, server: node.eval });
        if (!ctrl.ceval.enabled() && !bestEv)
            return null;
        let pearl;
        if (bestEv && bestEv.cp !== undefined) {
            pearl = renderEval$1(bestEv.cp);
        }
        else if (bestEv && bestEv.mate !== undefined) {
            pearl = '#' + bestEv.mate;
        }
        else if (ctrl.gameOver()) {
            pearl = '-';
        }
        else {
            pearl = ctrl.replaying ? '' : spinnerPearl();
        }
        return (h("div", { className: "ceval-curEval" }, pearl));
    }
};
function spinnerPearl() {
    return h('div.spinner.fa.fa-hourglass-half');
}

var explorerConfig = {
    controller(variant, onClose) {
        const available = ['lichess'];
        if (variant.key === 'standard' || variant.key === 'fromPosition') {
            available.push('masters');
        }
        const open = prop(false);
        const data = {
            db: {
                available: available,
                selected: available.length > 1 ? settings.analyse.explorer.db : function () {
                    return available[0];
                }
            },
            rating: {
                available: settings.analyse.explorer.availableRatings,
                selected: settings.analyse.explorer.rating
            },
            speed: {
                available: settings.analyse.explorer.availableSpeeds,
                selected: settings.analyse.explorer.speed
            }
        };
        let openedWith;
        function serialize() {
            return JSON.stringify([
                data.db.selected(),
                data.rating.selected(),
                data.speed.selected()
            ]);
        }
        function doOpen() {
            router.backbutton.stack.push(doClose);
            openedWith = serialize();
            open(true);
        }
        function doClose(fromBB) {
            if (fromBB !== 'backbutton' && open())
                router.backbutton.stack.pop();
            open(false);
            onClose(openedWith !== serialize());
        }
        function toggleMany(c, value) {
            if (c().indexOf(value) === -1)
                c(c().concat([value]));
            else if (c().length > 1)
                c(c().filter((v) => {
                    return v !== value;
                }));
        }
        return {
            open,
            data,
            toggleOpen() {
                if (open())
                    doClose();
                else
                    doOpen();
            },
            toggleDb(db) {
                data.db.selected(db);
            },
            toggleRating: (v) => toggleMany(data.rating.selected, v),
            toggleSpeed: (v) => toggleMany(data.speed.selected, v),
            fullHouse() {
                return data.db.selected() === 'masters' || (data.rating.selected().length === data.rating.available.length &&
                    data.speed.selected().length === data.speed.available.length);
            },
            serialize
        };
    },
    view(ctrl) {
        const d = ctrl.data;
        return [
            h('section.db', [
                h('label', i18n('database')),
                h('div.form-multipleChoice', d.db.available.map(s => {
                    return h('div', {
                        className: d.db.selected() === s ? 'selected' : '',
                        oncreate: ontapY(() => ctrl.toggleDb(s))
                    }, s);
                }))
            ]),
            d.db.selected() === 'masters' ? h('div.masters.message', [
                h('i[data-icon=C]'),
                h('p', i18n('masterDbExplanation', '2200', '1952', '2020')),
            ]) : h('div', [
                h('section.rating', [
                    h('label', i18n('averageElo')),
                    h('div.form-multipleChoice', d.rating.available.map(r => {
                        return h('div', {
                            className: d.rating.selected().indexOf(r) > -1 ? 'selected' : '',
                            oncreate: ontapY(() => ctrl.toggleRating(r))
                        }, r);
                    }))
                ]),
                h('section.speed', [
                    h('label', i18n('timeControl')),
                    h('div.form-multipleChoice', d.speed.available.map(s => {
                        return h('div', {
                            className: d.speed.selected().indexOf(s) > -1 ? 'selected' : '',
                            oncreate: ontapY(() => ctrl.toggleSpeed(s))
                        }, s);
                    }))
                ])
            ]),
            h('section.save', h('button.text[data-icon=E]', {
                oncreate: ontapY(ctrl.toggleOpen)
            }, i18n('allSet')))
        ];
    }
};

function isOpeningData(data) {
    return !!data.isOpening;
}
function isTablebaseData(data) {
    return !!data.tablebase;
}

function colorOf(fen) {
    return fen.split(' ')[1] === 'w' ? 'white' : 'black';
}
function winnerBeforeMove(stm, category) {
    if (category === 'loss' || category === 'maybe-loss' || category === 'blessed-loss')
        return stm;
    if (category === 'win' || category === 'maybe-win' || category === 'cursed-win')
        return oppositeColor(stm);
}

const OpeningTable = {
    onbeforeupdate({ attrs }, { attrs: oldattrs }) {
        return attrs.data !== oldattrs.data;
    },
    view({ attrs }) {
        const { ctrl, data } = attrs;
        const moveTable = showMoveTable(ctrl, data.moves);
        const recentTable = showGameTable(ctrl, i18n('recentGames'), data.recentGames || []);
        const topTable = showGameTable(ctrl, i18n('topGames'), data.topGames || []);
        if (moveTable || recentTable || topTable) {
            return (h("div", { className: "explorer-data" },
                moveTable,
                topTable,
                recentTable));
        }
        else {
            return showEmpty(ctrl);
        }
    }
};
function showEmpty(ctrl) {
    return (h("div", { className: "explorer-data empty" },
        h("div", { className: "message" },
            h("h3", null,
                h("i", { className: "withIcon", "data-icon": "\uE005" }),
                i18n('noGameFound')),
            !ctrl.explorer.config.fullHouse() ?
                h("p", null, i18n('maybeIncludeMoreGamesFromThePreferencesMenu')) : null)));
}
function getTR(e) {
    const target = e.target;
    return target.tagName === 'TR' ? target : target.closest('tr');
}
function resultBar(move) {
    const sum = move.white + move.draws + move.black;
    function section(key) {
        const num = move[key];
        const percent = num * 100 / sum;
        const width = (Math.round(num * 1000 / sum) / 10) + '%';
        return percent === 0 ? null : (h("span", { className: 'explorerBar ' + key, style: { width } }, percent > 12 ? Math.round(percent) + (percent > 20 ? '%' : '') : null));
    }
    return ['white', 'draws', 'black'].map(section);
}
function onTableTap(ctrl, e) {
    const el = getTR(e);
    const uci = el && el.dataset['uci'];
    if (uci)
        ctrl.playUci(uci);
}
function showResult(w) {
    if (w === 'white')
        return h("result", { className: "white" }, "1-0");
    if (w === 'black')
        return h("result", { className: "black" }, "0-1");
    return h("result", { className: "draws" }, "\u00BD-\u00BD");
}
function link(ctrl, e) {
    const orientation = ctrl.chessground.state.orientation;
    const el = getTR(e);
    const gameId = el && el.dataset['id'];
    if (gameId && ctrl.explorer.config.data.db.selected() === 'lichess') {
        router.set(`/analyse/online/${gameId}/${orientation}`);
    }
    else if (gameId) {
        importMasterGame(gameId, orientation)
            .then((data) => router.set(`/analyse/online/${data.game.id}/${orientation}`));
    }
}
function showGameTable(ctrl, title, games) {
    if (!ctrl.explorer.withGames || !games.length)
        return null;
    return (h("table", { className: "games", oncreate: ontapXY(e => link(ctrl, e), undefined, getTR) },
        h("thead", null,
            h("tr", null,
                h("th", { colspan: "4" }, title))),
        h("tbody", null, games.map((game) => {
            return (h("tr", { key: game.id, "data-id": game.id },
                h("td", null, [game.white, game.black].map((p) => h("span", null, p.rating))),
                h("td", null, [game.white, game.black].map((p) => h("span", null, p.name))),
                h("td", null, showResult(game.winner)),
                h("td", null, game.year)));
        }))));
}
function showMoveTable(ctrl, moves) {
    if (!moves.length)
        return null;
    const pieceNotation = settings.game.pieceNotation();
    return (h("table", { className: "moves", oncreate: ontapXY(e => onTableTap(ctrl, e), undefined, getTR) },
        h("thead", null,
            h("tr", null,
                h("th", { className: "explorerMove-move" }, i18n('move')),
                h("th", { className: "explorerMove-games" }, i18n('games')),
                h("th", { className: "explorerMove-result" }, i18n('whiteDrawBlack')))),
        h("tbody", { className: pieceNotation ? 'displayPieces' : '' }, moves.map(move => {
            return (h("tr", { key: move.uci, "data-uci": move.uci },
                h("td", { className: "explorerMove-move" }, move.san[0] === 'P' ? move.san.slice(1) : move.san),
                h("td", { className: "explorerMove-games" }, move.white + move.draws + move.black),
                h("td", { className: "explorerMove-result" }, resultBar(move))));
        }))));
}

function renderExplorer(ctrl) {
    const data = ctrl.explorer.current();
    const config = ctrl.explorer.config;
    const configOpened = config.open();
    const loading = !configOpened && ctrl.explorer.loading();
    const className = classSet({
        explorerTable: true,
        loading
    });
    const opening = ctrl.tree.getOpening(ctrl.nodeList) || ctrl.data.game.opening;
    return (h("div", { id: "explorerTable", className: className },
        data && data.isOpening ?
            h("div", { className: "explorer-fixedTitle" },
                h("span", null, opening ? opening.eco + ' ' + opening.name : ''),
                configOpened || (data && data.isOpening) ?
                    h("div", { className: "toconf", "data-icon": configOpened ? 'L' : '%', oncreate: ontap(config.toggleOpen) }) : null) : null,
        loading ? h("div", { className: "spinner_overlay" },
            h("div", { className: "spinner fa fa-hourglass-half" })) : null,
        configOpened ? showConfig(ctrl) : null,
        !configOpened && ctrl.explorer.failing() ? failing() : null,
        !configOpened && !ctrl.explorer.failing() ? show(ctrl) : null));
}
function getTitle(ctrl) {
    if (ctrl.data.game.variant.key === 'standard' || ctrl.data.game.variant.key === 'fromPosition') {
        return i18n('openingExplorer');
    }
    else {
        return i18n('xOpeningExplorer', ctrl.data.game.variant.name);
    }
}
function onTablebaseTap(ctrl, e) {
    const el = getTR(e);
    const uci = el && el.dataset['uci'];
    if (uci)
        ctrl.playUci(uci);
}
function showTablebase(ctrl, title, moves, fen) {
    if (!moves.length)
        return null;
    const stm = colorOf(fen);
    return [
        h("div", { className: "title" }, title),
        h("table", { className: "explorerTablebase", oncreate: ontapXY(e => onTablebaseTap(ctrl, e), undefined, getTR) },
            h("tbody", null, moves.map((move) => {
                return h("tr", { "data-uci": move.uci, key: move.uci },
                    h("td", null, move.san),
                    h("td", null,
                        showDtz(stm, move),
                        showDtm(stm, move)));
            })))
    ];
}
function showDtm(stm, move) {
    if (move.dtm)
        return h('result.' + winnerBeforeMove(stm, move.category), {
            title: plural('mateInXHalfMoves', Math.abs(move.dtm)),
        }, 'DTM ' + Math.abs(move.dtm));
    else
        return null;
}
function showDtz(stm, move) {
    if (move.checkmate)
        return h('result.' + winnerBeforeMove(stm, move.category), i18n('checkmate'));
    else if (move.stalemate)
        return h('result.draws', i18n('stalemate'));
    else if (move.variant_win)
        return h('result.' + winnerBeforeMove(stm, move.category), i18n('variantWin'));
    else if (move.variant_loss)
        return h('result.' + winnerBeforeMove(stm, move.category), i18n('variantLoss'));
    else if (move.insufficient_material)
        return h('result.draws', i18n('insufficientMaterial'));
    else if (move.dtz === null)
        return null;
    else if (move.dtz === 0)
        return h('result.draws', i18n('draw'));
    else if (move.zeroing) {
        const capture = move.san.indexOf('x') !== -1;
        if (capture)
            return h('result.' + winnerBeforeMove(stm, move.category), i18n('capture'));
        else
            return h('result.' + winnerBeforeMove(stm, move.category), i18n('pawnMove'));
    }
    else
        return h('result.' + winnerBeforeMove(stm, move.category), {
            title: i18n('dtzWithRounding') + ' (Distance To Zeroing)'
        }, 'DTZ ' + Math.abs(move.dtz));
}
function showGameEnd(title) {
    return h('div.explorer-data.empty', [
        h('div.message', [
            h('h3', [
                h('i.withIcon[data-icon=]'),
                title
            ])
        ])
    ]);
}
function show(ctrl) {
    const data = ctrl.explorer.current();
    if (data && isOpeningData(data)) {
        return h(OpeningTable, { data, ctrl });
    }
    else if (data && isTablebaseData(data)) {
        const moves = data.moves;
        if (moves.length) {
            return (h("div", { className: "explorer-data" },
                showTablebase(ctrl, i18n('winning'), moves.filter((move) => move.category === 'loss'), data.fen),
                showTablebase(ctrl, i18n('unknown'), moves.filter((move) => move.category === 'unknown'), data.fen),
                showTablebase(ctrl, i18n('winOr50MovesByPriorMistake'), moves.filter((move) => move.category === 'maybe-loss'), data.fen),
                showTablebase(ctrl, i18n('winPreventedBy50MoveRule'), moves.filter((move) => move.category === 'blessed-loss'), data.fen),
                showTablebase(ctrl, i18n('drawn'), moves.filter((move) => move.category === 'draw'), data.fen),
                showTablebase(ctrl, i18n('lossSavedBy50MoveRule'), moves.filter((move) => move.category === 'cursed-win'), data.fen),
                showTablebase(ctrl, i18n('lossOr50MovesByPriorMistake'), moves.filter((move) => move.category === 'maybe-win'), data.fen),
                showTablebase(ctrl, i18n('losing'), moves.filter((move) => move.category === 'win'), data.fen)));
        }
        else if (data.checkmate)
            return showGameEnd(i18n('checkmate'));
        else if (data.stalemate)
            return showGameEnd(i18n('stalemate'));
        else if (data.variant_win || data.variant_loss)
            return showGameEnd(i18n('variantEnding'));
        else
            return showEmpty(ctrl);
    }
    return h("div", null);
}
function showConfig(ctrl) {
    return h('div.explorerConfig', {}, explorerConfig.view(ctrl.explorer.config));
}
function failing() {
    return h('div.explorer-data.empty', {}, h('div.failing.message', [
        h('h3', [
            h('i.withIcon[data-icon=,]'),
            'Oops, sorry!'
        ]),
        h('p', 'The explorer is temporarily'),
        h('p', 'out of service. Try again soon!')
    ]));
}

function renderCrazy(ctrl) {
    if (!ctrl.node.crazyhouse)
        return null;
    return h('div.analyse-crazyPockets', [
        renderPlayer(ctrl),
        renderOpponent(ctrl),
    ]);
}
function renderPlayer(ctrl) {
    const crazyData = ctrl.node.crazyhouse;
    if (!crazyData)
        return null;
    return h(CrazyPocket, {
        ctrl,
        crazyData,
        color: ctrl.orientation,
    });
}
function renderOpponent(ctrl) {
    const crazyData = ctrl.node.crazyhouse;
    if (!crazyData)
        return null;
    return h(CrazyPocket, {
        ctrl,
        crazyData,
        color: oppositeColor(ctrl.orientation)
    });
}

function view(ctrl) {
    if (!ctrl.contextMenu)
        return null;
    const path = ctrl.contextMenu;
    const node = ctrl.tree.nodeAtPath(path);
    const onMainline = ctrl.tree.pathIsMainline(path);
    return popup('analyse-cm', () => nodeFullName(node), () => {
        return [
            onMainline ? null : action('S', i18n('promoteVariation'), () => ctrl.promote(path, false)),
            onMainline ? null : action('E', i18n('makeMainLine'), () => ctrl.promote(path, true)),
            action('q', i18n('deleteFromHere'), () => ctrl.deleteNode(path))
        ];
    }, true, () => {
        ctrl.contextMenu = null;
        redraw();
    });
}
function action(icon, text, handler) {
    return h('button.withIcon', {
        'data-icon': icon,
        oncreate: ontapXY(handler)
    }, text);
}

// number of plies to show in variation lines
const LINES_PLIES = 6;
function renderTree(ctrl) {
    const root = ctrl.tree.root;
    const ctx = {
        ctrl,
        showComputer: ctrl.settings.s.showComments,
        showGlyphs: true};
    const commentTags = renderInlineCommentsOf(ctx, root);
    return h('div.analyse-moveList', {
        className: ''
    }, [
        commentTags,
        renderChildrenOf(ctx, root, {
            parentPath: '',
            isMainline: true
        }) || []
    ]);
}
function renderInlineCommentsOf(ctx, node) {
    if (!ctx.ctrl.settings.s.showComments || empty(node.comments))
        return [];
    return node.comments.map(comment => {
        if (comment.by === 'lichess' && !ctx.showComputer)
            return null;
        return h('comment', h(RichText, { text: comment.text }));
    }).filter(x => !!x);
}
function renderChildrenOf(ctx, node, opts) {
    const cs = node.children;
    const main = cs[0];
    if (!main)
        return null;
    if (opts.isMainline) {
        if (!cs[1])
            return renderMoveAndChildrenOf(ctx, main, {
                parentPath: opts.parentPath,
                isMainline: true,
                withIndex: opts.withIndex
            });
        return renderInlined(ctx, cs, opts) || [
            renderMoveOf(ctx, main, {
                parentPath: opts.parentPath,
                withIndex: opts.withIndex
            }),
            renderInlineCommentsOf(ctx, main),
            h('interrupt', renderLines(ctx, cs.slice(1), {
                parentPath: opts.parentPath})),
            renderChildrenOf(ctx, main, {
                parentPath: opts.parentPath + main.id,
                isMainline: true,
                withIndex: true
            }) || []
        ];
    }
    if (!cs[1])
        return renderMoveAndChildrenOf(ctx, main, opts);
    return renderInlined(ctx, cs, opts) || [renderLines(ctx, cs, opts)];
}
function renderInlined(ctx, nodes, opts) {
    // only 2 branches
    if (!nodes[1] || nodes[2])
        return null;
    // only if second branch has no sub-branches
    if (hasBranching(nodes[1], 6))
        return null;
    return renderMoveAndChildrenOf(ctx, nodes[0], {
        parentPath: opts.parentPath,
        isMainline: opts.isMainline,
        inline: nodes[1]
    });
}
function renderLines(ctx, nodes, opts) {
    return h('lines', nodes.map(n => {
        return h('line', renderMoveAndChildrenOf(ctx, n, {
            parentPath: opts.parentPath,
            isMainline: false,
            withIndex: true,
            truncate: n.comp && !contains(ctx.ctrl.path, opts.parentPath + n.id) ? LINES_PLIES : undefined
        }));
    }));
}
function renderMoveAndChildrenOf(ctx, node, opts) {
    const path = opts.parentPath + node.id, comments = renderInlineCommentsOf(ctx, node);
    if (opts.truncate === 0)
        return [
            h('move', { 'data-path': path }, '[...]')
        ];
    return [renderMoveOf(ctx, node, opts)]
        .concat(comments)
        .concat(opts.inline ? renderInline(ctx, opts.inline, opts) : null)
        .concat(renderChildrenOf(ctx, node, {
        parentPath: path,
        isMainline: opts.isMainline,
        truncate: opts.truncate ? opts.truncate - 1 : undefined,
        withIndex: !!comments[0]
    }) || []);
}
function renderInline(ctx, node, opts) {
    return h('inline', renderMoveAndChildrenOf(ctx, node, {
        withIndex: true,
        parentPath: opts.parentPath,
        isMainline: false
    }));
}
function nodeClasses(ctx, node, path) {
    const ctrl = ctx.ctrl;
    const currentPlayable = !ctrl.study && (path === ctrl.initialPath && playable(ctrl.data));
    const glyphIds = ctx.showGlyphs && node.glyphs ? node.glyphs.map(g => g.id) : [];
    return {
        current: path === ctrl.path,
        currentPlayable,
        nongame: !currentPlayable && !!ctrl.gamePath && contains(path, ctrl.gamePath) && path !== ctrl.gamePath,
        inaccuracy: glyphIds.includes(6),
        mistake: glyphIds.includes(2),
        blunder: glyphIds.includes(4),
    };
}
function renderGlyphs$1(glyphs) {
    return glyphs.map(glyph => h('glyph', glyph.symbol));
}
function renderIndexText$1(ply, withDots) {
    return plyToTurn$1(ply) + ((ply % 2 === 1 ? '.' : '...') );
}
function renderIndex$1(ply, withDots) {
    return h('index', renderIndexText$1(ply));
}
function renderMoveOf(ctx, node, opts) {
    const path = opts.parentPath + node.id;
    const content = [
        opts.withIndex || node.ply & 1 ? renderIndex$1(node.ply) : null,
        fixCrazySan(node.san)
    ];
    if (node.glyphs)
        renderGlyphs$1(node.glyphs).forEach(g => content.push(g));
    return h('move', {
        'data-path': path,
        className: classSet(nodeClasses(ctx, node, path))
    }, content);
}

var Replay = {
    onbeforeupdate({ attrs }) {
        return !attrs.ctrl.replaying;
    },
    view({ attrs }) {
        const { ctrl, rightTabActive } = attrs;
        const pieceNotation = settings.game.pieceNotation();
        const className = [
            pieceNotation ? 'displayPieces' : '',
            rightTabActive ? 'rta' : '',
        ].join(' ');
        return h('div#replay.analyse-replay.native_scroller', {
            className,
            oncreate: ontapXY(e => onReplayTap(ctrl, e), (e) => {
                const el = getMoveEl(e);
                const ds = el.dataset;
                if (el && ds.path) {
                    ctrl.contextMenu = ds.path;
                    redraw();
                }
            }, getMoveEl, false)
        }, renderTree(ctrl));
    }
};
function onReplayTap(ctrl, e) {
    const el = getMoveEl(e);
    if (el && el.dataset.path) {
        ctrl.jump(el.dataset.path);
    }
}
function getMoveEl(e) {
    const target = e.target;
    return target.tagName === 'MOVE' ? target :
        findParentBySelector(target, 'move');
}

function plyToTurn(ply) {
    return Math.floor((ply - 1) / 2) + 1;
}
function renderGlyphs(glyphs) {
    return glyphs.map(glyph => h('glyph', {
        title: glyph.name,
    }, glyph.symbol));
}
function renderEval(e) {
    return h('eval', e);
}
function renderIndexText(ply, withDots) {
    return plyToTurn(ply) + (withDots ? (ply % 2 === 1 ? '.' : '...') : '');
}
function renderIndex(ply, withDots) {
    return h('index', renderIndexText(ply, withDots));
}
function renderMove(ctx, node) {
    const ev = getBestEval({ client: node.ceval, server: node.eval }) || {};
    return [h('san', fixCrazySan(node.san))]
        .concat((node.glyphs && ctx.showGlyphs) ? renderGlyphs(node.glyphs) : [])
        .concat(ctx.showEval ? (ev.cp !== undefined ? [renderEval(renderEval$1(ev.cp))] : (ev.mate !== undefined ? [renderEval('#' + ev.mate)] : [])) : []);
}
function renderIndexAndMove(ctx, node) {
    return node.uci ?
        [renderIndex(node.ply, ctx.withDots)].concat(renderMove(ctx, node)) :
        [h('span.init', 'Initial position')];
}

function retroView(root) {
    const ctrl = root.retro;
    if (!ctrl)
        return;
    const fb = ctrl.vm.feedback;
    return h('div.analyse-training_box.analyse-retro_box.box', {
        className: ctrl.vm.minimized ? 'minimized' : ''
    }, [
        renderTitle$2(ctrl),
        h('div.analyse-training_feedback.native_scroller.' + fb, renderFeedback(root, fb))
    ]);
}
function skipOrViewSolution(ctrl) {
    return h('div.choices', [
        h('button', {
            oncreate: ontap(ctrl.viewSolution)
        }, i18n('viewTheSolution')),
        h('button', {
            oncreate: ontap(ctrl.nextMistake)
        }, i18n('skipThisMove'))
    ]);
}
function jumpToNext(ctrl) {
    return h('div.li-button.retro-half.retro-continue', {
        oncreate: ontap(ctrl.nextMistake)
    }, [
        h('i[data-icon=G]'),
        i18n('next')
    ]);
}
const minDepth$1 = 8;
const maxDepth = 18;
function renderEvalProgress$1(node) {
    return h('div.analyse-training_progress', h('div', {
        style: {
            width: `${node.ceval ? (100 * Math.max(0, node.ceval.depth - minDepth$1) / (maxDepth - minDepth$1)) + '%' : 0}`
        }
    }));
}
const feedback = {
    find(ctrl) {
        return [
            h('div.analyse-training_player', [
                h('div.piece-no-square', {
                    className: ctrl.pieceTheme
                }, h('piece.king.' + ctrl.vm.color)),
                h('div.retro-instruction', [
                    h('strong', [
                        i18nVdom('xWasPlayed', h('span', renderIndexAndMove({
                            withDots: true,
                            showGlyphs: true,
                            showEval: false
                        }, ctrl.vm.current.fault.node)))
                    ]),
                    h('em', i18n(ctrl.vm.color === 'white' ?
                        'findBetterMoveForWhite' :
                        'findBetterMoveForBlack')),
                    skipOrViewSolution(ctrl)
                ])
            ])
        ];
    },
    // user has browsed away from the move to solve
    offTrack(ctrl) {
        return [
            h('div.analyse-training_player', [
                h('div.retro-icon.off', '!'),
                h('div.retro-instruction', [
                    h('strong', 'You browsed away'),
                    h('div.choices.off', [
                        h('button', {
                            oncreate: ontap(ctrl.jumpToCurrent)
                        }, 'Resume learning')
                    ])
                ])
            ])
        ];
    },
    fail(ctrl) {
        return [
            h('div.analyse-training_player', [
                h('div.retro-icon', '✗'),
                h('div.retro-instruction', [
                    h('strong', i18n('youCanDoBetter')),
                    h('em', i18n(ctrl.vm.color === 'white' ?
                        'tryAnotherMoveForWhite' : 'tryAnotherMoveForBlack')),
                    skipOrViewSolution(ctrl)
                ])
            ])
        ];
    },
    win(ctrl) {
        return [
            h('div.retro-half.top', h('div.analyse-training_player', [
                h('div.retro-icon', '✓'),
                h('div.retro-instruction', h('strong', i18n('goodMove')))
            ])),
            jumpToNext(ctrl)
        ];
    },
    view(ctrl) {
        return [
            h('div.retro-half.top', h('div.analyse-training_player', [
                h('div.retro-icon', '✓'),
                h('div.retro-instruction', [
                    h('strong', i18n('solution')),
                    h('em', [
                        h('strong', renderIndexAndMove({
                            withDots: true,
                            showEval: false
                        }, ctrl.vm.current.solution.node))
                    ])
                ])
            ])),
            jumpToNext(ctrl)
        ];
    },
    eval(ctrl) {
        return [
            h('div.retro-half.top', h('div.analyse-training_player.center', [
                h('div.retro-instruction', [
                    h('strong', i18n('evaluatingYourMove')),
                    renderEvalProgress$1(ctrl.node())
                ])
            ]))
        ];
    },
    end(ctrl, hasFullComputerAnalysis) {
        if (!hasFullComputerAnalysis())
            return [
                h('div.retro-half.top', h('div.analyse-training_player', [
                    h('div.retro-icon', spinner.getVdom()),
                    h('div.retro-instruction', i18n('waitingForAnalysis'))
                ]))
            ];
        const nothing = !ctrl.completion()[1];
        return [
            h('div.analyse-training_player', [
                h('div.piece-no-square', {
                    className: ctrl.pieceTheme
                }, h('piece.king.' + ctrl.vm.color)),
                h('div.retro-instruction', [
                    h('em', nothing ?
                        i18n(ctrl.vm.color === 'white' ?
                            'noMistakesFoundForWhite' : 'noMistakesFoundForBlack') :
                        i18n(ctrl.vm.color === 'white' ?
                            'doneReviewingWhiteMistakes' : 'doneReviewingBlackMistakes')),
                    h('div.choices.end', [
                        nothing ? null : h('button', {
                            oncreate: ontap(ctrl.reset)
                        }, i18n('doItAgain')),
                        h('button', {
                            oncreate: ontap(ctrl.flip)
                        }, i18n(ctrl.vm.color === 'white' ?
                            'reviewBlackMistakes' : 'reviewWhiteMistakes'))
                    ])
                ])
            ])
        ];
    }
};
function renderFeedback(root, fb) {
    const ctrl = root.retro;
    const current = ctrl.vm.current;
    if (ctrl.isSolving() && current && root.path !== current.prev.path) {
        return feedback.offTrack(ctrl);
    }
    if (fb === 'find') {
        return current ? feedback.find(ctrl) :
            feedback.end(ctrl, root.hasFullComputerAnalysis);
    }
    return feedback[fb](ctrl);
}
function renderTitle$2(ctrl) {
    const completion = ctrl.completion();
    return h('div.titleWrapper', [
        h('div.title', i18n('learnFromYourMistakes')),
        h('div.mistakeNb', Math.min(completion[0] + 1, completion[1]) + ' / ' + completion[1]),
        h('div.actions', [
            h('button.window-button', {
                oncreate: ontap(ctrl.toggleWindow)
            }, h('span.fa', {
                className: ctrl.vm.minimized ? 'fa-window-maximize' : 'fa-window-minimize'
            })),
            h('button.window-button', {
                oncreate: ontap(ctrl.close)
            }, h('span.fa.fa-window-close'))
        ])
    ]);
}

function commentBest(c, ctrl) {
    return c.best ? i18nVdom(c.verdict === 'goodMove' ? 'anotherWasX' : 'bestWasX', h('move', {
        oncreate: ontap(ctrl.playCommentBest),
    }, c.best.san)) : [];
}
function renderOffTrack(ctrl) {
    return h('div.analyse-training_player.off', [
        h('div.icon.off', '!'),
        h('div.analyse-training_box_instruction', [
            h('strong', i18n('youBrowsedAway')),
            h('div.choices', [
                h('button', {
                    oncreate: ontap(ctrl.resume)
                }, i18n('resumePractice'))
            ])
        ])
    ]);
}
function renderEnd(root, ctrl, end) {
    const isMate = end === 'checkmate';
    const color = isMate ? oppositeColor(root.turnColor()) : root.turnColor();
    return h('div.analyse-training_player', [
        color ? h('div.piece-no-square', {
            className: ctrl.pieceTheme
        }, h('piece.king.' + color)) : h('div.icon.off', '!'),
        h('div.analyse-training_box_instruction', [
            h('strong', i18n(end)),
            isMate ?
                h('em', h('color', i18n(color === 'white' ? 'whiteWinsGame' : 'blackWinsGame'))) :
                h('em', i18n('theGameIsADraw'))
        ])
    ]);
}
const minDepth = 8;
function renderEvalProgress(node, maxDepth) {
    const width = node.ceval ?
        (100 * Math.max(0, node.ceval.depth - minDepth) / (maxDepth - minDepth)) + '%' :
        0;
    return h('div.analyse-training_progress', h('div', { style: `width: ${width}` }));
}
function renderRunning(root, ctrl) {
    const hint = ctrl.hinting();
    return h('div.analyse-training_player.running', [
        h('div.piece-no-square', {
            className: ctrl.pieceTheme
        }, h('piece.king.' + root.turnColor())),
        h('div.analyse-training_box_instruction', (ctrl.isMyTurn() ? [h('strong', i18n('yourTurn'))] : [
            h('strong', i18n('computerThinking')),
            renderEvalProgress(ctrl.currentNode(), ctrl.playableDepth())
        ]).concat(h('div.choices', [
            ctrl.isMyTurn() ? h('button', {
                oncreate: ontap(ctrl.hint),
            }, i18n(hint ? (hint.mode === 'piece' ? 'seeBestMove' : 'hideBestMove') : 'getAHint')) : ''
        ])))
    ]);
}
function renderTitle$1(root, ctrl) {
    return h('div.titleWrapper', [
        h('div.title', i18n('practiceWithComputer')),
        h('div.actions', [
            h('button.window-button', {
                oncreate: ontap(ctrl.toggleWindow)
            }, h('span.fa', {
                className: ctrl.minimized() ? 'fa-window-maximize' : 'fa-window-minimize'
            })),
            h('button.window-button', {
                oncreate: ontap(root.togglePractice)
            }, h('span.fa.fa-window-close'))
        ])
    ]);
}
function practiceView (root) {
    const ctrl = root.practice;
    if (!ctrl)
        return;
    const comment = ctrl.comment();
    const running = ctrl.running();
    const end = ctrl.currentNode().threefold ? 'threefoldRepetition' : root.gameOver();
    return h('div.analyse-practice_box.analyse-training_box.box.' + (comment ? comment.verdict : 'no-verdict'), {
        className: ctrl.minimized() ? 'minimized' : ''
    }, [
        renderTitle$1(root, ctrl),
        h('div.analyse-training_feedback.native_scroller', !running ? renderOffTrack(ctrl) : (end ? renderEnd(root, ctrl, end) : renderRunning(root, ctrl))),
        running ? h('div.comment', comment ? [
            h('span.verdict', i18n(comment.verdict)),
            ' '
        ].concat(commentBest(comment, ctrl)) : [ctrl.isMyTurn() || end ? '' : h('span.wait', i18n('evaluatingYourMove'))]) : (running ? h('div.comment') : null)
    ]);
}

function findTag(study, name) {
    const t = study.chapter.tags.find(t => t[0].toLowerCase() === name);
    return t && t[1];
}
function gameResult(study, isWhite) {
    switch (findTag(study, 'result')) {
        case '1-0': return isWhite ? '1' : '0';
        case '0-1': return isWhite ? '0' : '1';
        case '1/2-1/2': return '1/2';
        default: return undefined;
    }
}

function d3Area(x0, y0, y1) {
  var x1 = null,
      defined = constant(true),
      context = null,
      curve = curveLinear,
      output = null,
      path = withPath(area);

  x0 = typeof x0 === "function" ? x0 : (x0 === undefined) ? x : constant(+x0);
  y0 = typeof y0 === "function" ? y0 : (y0 === undefined) ? constant(0) : constant(+y0);
  y1 = typeof y1 === "function" ? y1 : (y1 === undefined) ? y : constant(+y1);

  function area(data) {
    var i,
        j,
        k,
        n = (data = array(data)).length,
        d,
        defined0 = false,
        buffer,
        x0z = new Array(n),
        y0z = new Array(n);

    if (context == null) output = curve(buffer = path());

    for (i = 0; i <= n; ++i) {
      if (!(i < n && defined(d = data[i], i, data)) === defined0) {
        if (defined0 = !defined0) {
          j = i;
          output.areaStart();
          output.lineStart();
        } else {
          output.lineEnd();
          output.lineStart();
          for (k = i - 1; k >= j; --k) {
            output.point(x0z[k], y0z[k]);
          }
          output.lineEnd();
          output.areaEnd();
        }
      }
      if (defined0) {
        x0z[i] = +x0(d, i, data), y0z[i] = +y0(d, i, data);
        output.point(x1 ? +x1(d, i, data) : x0z[i], y1 ? +y1(d, i, data) : y0z[i]);
      }
    }

    if (buffer) return output = null, buffer + "" || null;
  }

  function arealine() {
    return line().defined(defined).curve(curve).context(context);
  }

  area.x = function(_) {
    return arguments.length ? (x0 = typeof _ === "function" ? _ : constant(+_), x1 = null, area) : x0;
  };

  area.x0 = function(_) {
    return arguments.length ? (x0 = typeof _ === "function" ? _ : constant(+_), area) : x0;
  };

  area.x1 = function(_) {
    return arguments.length ? (x1 = _ == null ? null : typeof _ === "function" ? _ : constant(+_), area) : x1;
  };

  area.y = function(_) {
    return arguments.length ? (y0 = typeof _ === "function" ? _ : constant(+_), y1 = null, area) : y0;
  };

  area.y0 = function(_) {
    return arguments.length ? (y0 = typeof _ === "function" ? _ : constant(+_), area) : y0;
  };

  area.y1 = function(_) {
    return arguments.length ? (y1 = _ == null ? null : typeof _ === "function" ? _ : constant(+_), area) : y1;
  };

  area.lineX0 =
  area.lineY0 = function() {
    return arealine().x(x0).y(y0);
  };

  area.lineY1 = function() {
    return arealine().x(x0).y(y1);
  };

  area.lineX1 = function() {
    return arealine().x(x1).y(y0);
  };

  area.defined = function(_) {
    return arguments.length ? (defined = typeof _ === "function" ? _ : constant(!!_), area) : defined;
  };

  area.curve = function(_) {
    return arguments.length ? (curve = _, context != null && (output = curve(context)), area) : curve;
  };

  area.context = function(_) {
    return arguments.length ? (_ == null ? context = output = null : output = curve(context = _), area) : context;
  };

  return area;
}

function drawAcplChart(element, aData, curPly) {
    const division = aData.game.division;
    const rect = element.getBoundingClientRect();
    const svg = select(element)
        .append('svg')
        .attr('viewBox', `0 0 ${rect.width} ${rect.height}`);
    const graphData = makeSerieData$1(aData);
    const margin = { top: 10, right: 10, bottom: 10, left: 10 };
    const width = rect.width - margin.left - margin.right;
    const height = rect.height - margin.top - margin.bottom;
    const g = svg.append('g').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
    function addDivisionLine(xPos, name) {
        g.append('line')
            .attr('class', 'division ' + name)
            .attr('x1', xPos)
            .attr('x2', xPos)
            .attr('y1', y(-1))
            .attr('y2', y(1));
        g.append('text')
            .attr('class', 'chart-legend')
            .attr('transform', 'rotate(90)')
            .attr('y', -xPos)
            .attr('dy', '-0.4em')
            .text(i18n(name));
    }
    const firstPly = aData.treeParts[0].ply || 0;
    function setCurrentPly(ply) {
        g.selectAll('.dot').remove();
        if (ply !== null) {
            const xply = ply - 1 - firstPly;
            const p = graphData[xply];
            if (p) {
                g.append('circle')
                    .attr('class', 'dot')
                    .attr('cx', x(xply))
                    .attr('cy', y(p.acpl))
                    .attr('r', 3);
            }
        }
    }
    const x = linear()
        .domain([0, graphData.length])
        .rangeRound([0, width]);
    const y = linear()
        .domain([-1, 1])
        .rangeRound([height, 0]);
    const line = d3Area()
        .x((_, i) => x(i))
        .y(d => y(d.acpl));
    const area = d3Area()
        .x((_, i) => x(i))
        .y1(d => d.acpl >= 0 ? y(d.acpl) : y(0));
    g.datum(graphData);
    g.append('line')
        .attr('class', 'zeroline')
        .attr('x1', 0)
        .attr('x2', width)
        .attr('y1', y(0))
        .attr('y2', y(0));
    g.append('clipPath')
        .attr('id', 'clip-below')
        .append('path')
        .attr('d', area.y0(d => y(d.acpl)));
    g.append('clipPath')
        .attr('id', 'clip-above')
        .append('path')
        .attr('d', area.y0(y(0)));
    g.append('path')
        .attr('class', 'area above')
        .attr('clip-path', 'url(#clip-above)')
        .attr('d', area);
    g.append('path')
        .attr('class', 'area below')
        .attr('clip-path', 'url(#clip-below)')
        .attr('d', area.y0(d => d.acpl <= 0 ? y(d.acpl) : y(0)));
    g.append('path')
        .attr('class', 'line')
        .attr('d', line);
    if (division && (division.middle || division.end)) {
        addDivisionLine(x(0), 'opening');
        if (division.middle) {
            addDivisionLine(x(division.middle), 'middlegame');
        }
        if (division.end) {
            addDivisionLine(x(division.end), 'endgame');
        }
    }
    setCurrentPly(curPly);
    return setCurrentPly;
}
function makeSerieData$1(d) {
    return d.treeParts.slice(1).reduce((acc, node) => {
        const ply = node.ply;
        const color = ply & 1;
        let cp;
        if (node.eval && node.eval.mate) {
            cp = node.eval.mate > 0 ? Infinity : -Infinity;
        }
        else if (node.san && node.san.indexOf('#') > 0) {
            cp = color === 1 ? Infinity : -Infinity;
            if (d.game.variant.key === 'antichess')
                cp = -cp;
        }
        else if (node.eval && node.eval.cp !== undefined) {
            cp = node.eval.cp;
        }
        else
            return acc;
        const point = {
            acpl: 2 / (1 + Math.exp(-4e-3 * cp)) - 1
        };
        return acc.concat([point]);
    }, []);
}

function drawMoveTimesChart(element, aData, moveCentis, curPly) {
    const division = aData.game.division;
    const rect = element.getBoundingClientRect();
    const svg = select(element)
        .append('svg')
        .attr('viewBox', `0 0 ${rect.width} ${rect.height}`);
    const margin = { top: 10, right: 10, bottom: 10, left: 25 };
    const width = rect.width - margin.left - margin.right;
    const height = rect.height - margin.top - margin.bottom;
    const g = svg.append('g').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
    const { max, series } = makeSerieData(aData, moveCentis);
    function addDivisionLine(xPos, name) {
        g.append('line')
            .attr('class', 'division ' + name)
            .attr('x1', xPos)
            .attr('x2', xPos)
            .attr('y1', y(-max))
            .attr('y2', y(max));
        g.append('text')
            .attr('class', 'chart-legend')
            .attr('transform', 'rotate(90)')
            .attr('y', -xPos)
            .attr('dy', '-0.4em')
            .text(i18n(name));
    }
    function setCurrentPly(ply) {
        g.selectAll('.dot').remove();
        if (ply !== null) {
            const isWhite = !!(ply & 1);
            const p = isWhite ? series.white.find(p => p.ply === ply) : series.black.find(p => p.ply === ply);
            if (p) {
                g.append('circle')
                    .attr('class', 'dot')
                    .attr('cx', x(ply))
                    .attr('cy', y(p.y))
                    .attr('r', 3);
            }
        }
    }
    const x = linear()
        .domain([0, series.white.length + series.black.length])
        .rangeRound([0, width]);
    const y = linear()
        .domain([-max, max])
        .rangeRound([height, 0]);
    const line = d3Area()
        .x(d => x(d.ply))
        .y(d => y(d.y));
    const area = d3Area()
        .x(d => x(d.ply))
        .y0(y(0))
        .y1(d => y(d.y));
    const maxCentis = Math.max(...moveCentis) / 100;
    const legendScale = linear()
        .domain([-maxCentis, maxCentis])
        .rangeRound([height, 0]);
    const yAxis = axisLeft(legendScale)
        .tickFormat(d => String(Math.abs(d)));
    g.append('g')
        .call(yAxis)
        .append('text')
        .attr('class', 'legend')
        .attr('transform', 'rotate(-90)')
        .attr('y', 6)
        .attr('dy', '0.71em')
        .attr('text-anchor', 'end')
        .text('Seconds');
    g.append('path')
        .datum(series.white)
        .attr('class', 'area above')
        .attr('d', area);
    g.append('path')
        .datum(series.black)
        .attr('class', 'area below')
        .attr('d', area);
    g.append('path')
        .attr('class', 'line')
        .datum(series.white)
        .attr('d', line);
    g.append('path')
        .attr('class', 'line')
        .datum(series.black)
        .attr('d', line);
    if (division && (division.middle || division.end)) {
        if (division.middle) {
            addDivisionLine(x(division.middle), 'middlegame');
        }
        if (division.end) {
            addDivisionLine(x(division.end), 'endgame');
        }
    }
    setCurrentPly(curPly);
    return setCurrentPly;
}
function makeSerieData(data, moveCentis) {
    const series = {
        white: [],
        black: []
    };
    const tree = data.treeParts;
    const logC = Math.pow(Math.log(3), 2);
    let ply = 0, max = 0;
    moveCentis.forEach((time, i) => {
        const node = tree[i + 1];
        ply = node ? node.ply : ply + 1;
        const isWhite = !!(ply & 1);
        const y = Math.pow(Math.log(.005 * Math.min(time, 12e4) + 3), 2) - logC;
        max = Math.max(y, max);
        const point = {
            ply,
            y: isWhite ? y : -y
        };
        if (isWhite)
            series.white.push(point);
        else
            series.black.push(point);
    });
    return { max, series };
}

function renderAnalysis(ctrl) {
    const d = ctrl.data;
    return h('div.analyse-gameAnalysis.native_scroller', [
        d.analysis ? renderAnalysisGraph(ctrl) :
            ctrl.study ? renderStudyAnalysisRequest(ctrl) : renderGameAnalysisRequest(ctrl),
        d.game.moveCentis ? renderMoveTimes(ctrl, d.game.moveCentis) : null
    ]);
}
function renderAnalysisGraph(ctrl) {
    return h('div.analyse-computerAnalysis', [
        h('strong.title', i18n('computerAnalysis')),
        ctrl.analysisProgress ?
            h('div.analyse-gameAnalysis_chartPlaceholder', spinner.getVdom('monochrome')) :
            h('div.analyse-chart', {
                oncreate({ dom }) {
                    batchRequestAnimationFrame(() => {
                        this.updateCurPly = drawAcplChart(dom, ctrl.data, ctrl.node.ply);
                    });
                },
                onupdate({ dom }) {
                    if (this.updateCurPly) {
                        batchRequestAnimationFrame(() => {
                            this.updateCurPly(ctrl.onMainline ? ctrl.node.ply : null);
                        });
                    }
                    else {
                        batchRequestAnimationFrame(() => {
                            const el = dom;
                            while (el.lastElementChild) {
                                el.removeChild(el.lastElementChild);
                            }
                            this.updateCurPly = drawAcplChart(el, ctrl.data, ctrl.node.ply);
                        });
                    }
                }
            }),
        h(AcplSummary, {
            d: ctrl.data,
            analysis: ctrl.data.analysis,
            study: ctrl.study && ctrl.study.data
        })
    ]);
}
const AcplSummary = {
    onbeforeupdate({ attrs }, { attrs: oldattrs }) {
        return !shallowEqual(attrs.analysis, oldattrs.analysis);
    },
    view({ attrs }) {
        const { d, analysis, study } = attrs;
        const colors = ['white', 'black'];
        return h('div.analyse-evalSummary', colors.map((color) => {
            const p = getPlayer(d, color);
            const pName = study ? findTag(study, color) || 'Anonymous' : playerName(p);
            return h('div.analyse-evalSummary__side', [
                h('div.analyse-evalSummary__player', [
                    h('span.color-icon.' + color),
                    h('span', [pName, p ? renderRatingDiff(p) : null])
                ]),
                h('div', [
                    advices.map(a => {
                        const nb = analysis && analysis[color][a[0]];
                        return h('div.analyse-evalSummary__summary', [
                            h.trust(plural(a[1], nb, `<strong>${nb}</strong>`)),
                        ]);
                    }),
                    h('div.analyse-evalSummary__summary', [
                        h('strong', analysis && analysis[color].acpl),
                        h('span', i18n('averageCentipawnLoss'))
                    ])
                ])
            ]);
        }));
    }
};
function renderGameAnalysisRequest(ctrl) {
    return h('div.analyse-computerAnalysis.request', [
        ctrl.analysisProgress ? h('div.analyse-requestProgress', [
            h('span', i18n('waitingForAnalysis')),
            spinner.getVdom('monochrome')
        ]) : h('button.fatButton', {
            oncreate: ontapXY(() => {
                return requestComputerAnalysis(ctrl.data.game.id)
                    .then(() => {
                    ctrl.analysisProgress = true;
                    redraw();
                })
                    .catch(handleXhrError);
            })
        }, [i18n('requestAComputerAnalysis')])
    ]);
}
function renderStudyAnalysisRequest(ctrl) {
    return h('div.analyse-computerAnalysis.request', ctrl.mainline.length < 5 ? h('p', 'The study is too short to be analysed.') :
        !ctrl.study.canContribute() ? h('p', 'Only the study contributors can request a computer analysis') : [
            h('p', [
                'Get a full server-side computer analysis of the main line.',
                h('br'),
                'Make sure the chapter is complete, for you can only request analysis once.'
            ]),
            ctrl.analysisProgress ? h('div.analyse-requestProgress', [
                h('span', i18n('waitingForAnalysis')),
                spinner.getVdom('monochrome')
            ]) : h('button.fatButton', {
                oncreate: ontapXY(() => {
                    ctrl.socket.send('requestAnalysis', ctrl.study.data.chapter.id);
                    ctrl.analysisProgress = true;
                    redraw();
                })
            }, [i18n('requestAComputerAnalysis')])
        ]);
}
function renderMoveTimes(ctrl, moveCentis) {
    return h('div.analyse-moveTimes', [
        h('strong.title', i18n('moveTimes')),
        h('div.analyse-chart', {
            oncreate({ dom }) {
                setTimeout(() => {
                    this.updateCurPly = drawMoveTimesChart(dom, ctrl.data, moveCentis, ctrl.node.ply);
                }, 200);
            },
            onupdate() {
                if (this.updateCurPly)
                    batchRequestAnimationFrame(() => {
                        if (ctrl.onMainline)
                            this.updateCurPly(ctrl.node.ply);
                        else
                            this.updateCurPly(null);
                    });
            }
        })
    ]);
}
const advices = [
    ['inaccuracy', 'nbInaccuracies'],
    ['mistake', 'nbMistakes'],
    ['blunder', 'nbBlunders']
];

var Clock = {
    onbeforeupdate({ attrs }, { attrs: oldAttrs }) {
        return attrs.color !== oldAttrs.color || !attrs.ctrl.replaying;
    },
    view({ attrs }) {
        const { ctrl, color } = attrs;
        const node = ctrl.node, clock = node.clock;
        if (clock === undefined)
            return;
        const parentClock = ctrl.tree.getParentClock(node, ctrl.path);
        let whiteCentis, blackCentis;
        const isWhiteTurn = node.ply % 2 === 0;
        if (isWhiteTurn) {
            whiteCentis = parentClock;
            blackCentis = clock;
        }
        else {
            whiteCentis = clock;
            blackCentis = parentClock;
        }
        const centis = color === 'white' ? whiteCentis : blackCentis;
        const current = color === 'white' ? isWhiteTurn : !isWhiteTurn;
        return h('span.analyse-clock', {
            className: current ? 'current' : '',
        }, clockContent(centis));
    }
};
function clockContent(centis) {
    if (centis === undefined)
        return h('span.time', ['-']);
    const date = new Date(centis * 10), millis = date.getUTCMilliseconds(), sep = ':', baseStr = pad2(date.getUTCMinutes()) + sep + pad2(date.getUTCSeconds());
    if (centis >= 360000)
        return h('span.time', [Math.floor(centis / 360000) + sep + baseStr]);
    const tenthsStr = Math.floor(millis / 100).toString();
    return h('span.time', [
        baseStr,
        h('tenths', '.' + tenthsStr)
    ]);
}
function pad2(num) {
    return (num < 10 ? '0' : '') + num;
}

// winning chances for a color
// 1  infinitely winning
// -1 infinitely losing
function povChances(color, ev) {
    return toPov(color, evalWinningChances(ev));
}
// computes the difference, in winning chances, between two evaluations
// 1  = e1 is infinately better than e2
// -1 = e1 is infinately worse  than e2
function povDiff(color, e1, e2) {
    return (povChances(color, e1) - povChances(color, e2)) / 2;
}
function toPov(color, diff) {
    return color === 'white' ? diff : -diff;
}
/**
 * https://graphsketch.com/?eqn1_color=1&eqn1_eqn=100+*+%282+%2F+%281+%2B+exp%28-0.005+*+x%29%29+-+1%29&eqn2_color=2&eqn2_eqn=100+*+%282+%2F+%281+%2B+exp%28-0.004+*+x%29%29+-+1%29&eqn3_color=3&eqn3_eqn=&eqn4_color=4&eqn4_eqn=&eqn5_color=5&eqn5_eqn=&eqn6_color=6&eqn6_eqn=&x_min=-1000&x_max=1000&y_min=-100&y_max=100&x_tick=100&y_tick=10&x_label_freq=2&y_label_freq=2&do_grid=0&do_grid=1&bold_labeled_lines=0&bold_labeled_lines=1&line_width=4&image_w=850&image_h=525
 */
function rawWinningChances(cp) {
    return 2 / (1 + Math.exp(-4e-3 * cp)) - 1;
}
function cpWinningChances(cp) {
    return rawWinningChances(Math.min(Math.max(-1e3, cp), 1000));
}
function mateWinningChances(mate) {
    const cp = (21 - Math.min(10, Math.abs(mate))) * 100;
    const signed = cp * (mate > 0 ? 1 : -1);
    return rawWinningChances(signed);
}
function evalWinningChances(ev) {
    return ev.mate !== undefined ? mateWinningChances(ev.mate) : cpWinningChances(ev.cp);
}

function renderBoard(ctrl) {
    return h('div.analyse-boardWrapper', [
        playerBar(ctrl, ctrl.topColor()),
        h(Board, {
            variant: ctrl.data.game.variant.key,
            chessground: ctrl.chessground,
            shapes: computeShapes(ctrl),
            clearableShapes: ctrl.node.shapes,
            wrapperClasses: ctrl.settings.s.smallBoard ? 'halfsize' : '',
            canClearShapes: true,
        }),
        playerBar(ctrl, ctrl.bottomColor()),
    ]);
}
function playerBar(ctrl, color) {
    const pName = ctrl.playerName(color);
    const isAnonymous = pName === 'Anonymous';
    // Assumes studies without player info do not have clock info
    if ((ctrl.study && isAnonymous) || (!ctrl.study && ctrl.synthetic)) {
        return null;
    }
    const study = ctrl.study && ctrl.study.data;
    let title, elo, result;
    if (study) {
        title = findTag(study, `${color}title`);
        elo = findTag(study, `${color}elo`);
        result = gameResult(study, color === 'white');
    }
    else if (gameStatus.finished(ctrl.data)) {
        const winner = ctrl.data.game.winner;
        result = winner === undefined ? '½' : winner === color ? '1' : '0';
    }
    const checkCount = ctrl.node.checkCount;
    const showRight = ctrl.node.clock || checkCount;
    return h('div.analyse-player_bar', {
        className: ctrl.settings.s.smallBoard ? 'halfsize' : ''
    }, [
        h('div.info', isAnonymous ? h.trust('&nbsp') : [
            result ? h('span.result', result) : null,
            h('span.name', (title ? title + ' ' : '') + pName + (elo ? ` (${elo})` : '')),
        ]),
        showRight ? h('div.player_bar_clock', [
            h(Clock, { ctrl, color }),
            checkCount ? renderCheckCount(ctrl.bottomColor() === 'white', checkCount) : null
        ]) : null,
    ]);
}
function computeShapes(ctrl) {
    const player = ctrl.data.game.player;
    const ceval = ctrl.node && ctrl.node.ceval;
    const rEval = ctrl.node && ctrl.node.eval;
    const threat = ctrl.node && ctrl.node.threat;
    let curBestShapes = [];
    let pastBestShape = [];
    let annotationShape = [];
    let threatShape = [];
    if (ctrl.practice) {
        const hint = ctrl.practice.hinting();
        if (hint) {
            if (hint.mode === 'move')
                curBestShapes = moveOrDropShape(hint.uci, 'paleBlue', player);
            else
                curBestShapes = [{
                        orig: uciToMoveOrDrop(hint.uci)[0],
                        brush: 'paleBlue'
                    }];
        }
    }
    if (!ctrl.retro && !ctrl.practice && ctrl.settings.s.showBestMove) {
        const nextBest = ctrl.nextNodeBest() || (ceval && ceval.best);
        if (nextBest) {
            curBestShapes = moveOrDropShape(nextBest, 'paleBlue', player);
        }
        if (ceval && ceval.pvs.length > 1) {
            ceval.pvs.slice(1).forEach(pv => {
                const shift = povDiff(player, ceval.pvs[0], pv);
                if (shift >= 0 && shift < 0.2) {
                    const linewidth = Math.round(12 - shift * 50); // 12 to 2
                    curBestShapes = curBestShapes.concat(moveOrDropShape(pv.moves[0], 'paleBlue' + linewidth, player));
                }
            });
        }
        if (rEval && rEval.best) {
            pastBestShape = moveOrDropShape(rEval.best, 'paleGreen', opposite(player));
        }
    }
    if (!ctrl.retro && !ctrl.practice && ctrl.showThreat && threat) {
        threatShape = moveOrDropShape(threat.pvs[0].moves[0], 'paleRed', opposite(player));
    }
    const { uci, glyphs } = ctrl.node;
    if (uci && glyphs && glyphs.length > 0) {
        const glyph = glyphs[0];
        annotationShape = [{
                orig: uciToMoveOrDrop(uci)[1],
                glyph,
            }];
    }
    const badNode = ctrl.retro && ctrl.retro.showBadNode();
    const badMoveShape = badNode && badNode.uci ?
        moveOrDropShape(badNode.uci, 'paleRed2', player) : [];
    return [
        ...pastBestShape, ...curBestShapes, ...threatShape, ...badMoveShape, ...annotationShape
    ];
}
function renderCheckCount(whitePov, checkCount) {
    const w = h('span.color-icon.white', '+' + checkCount.black);
    const b = h('span.color-icon.black', '+' + checkCount.white);
    return h('div.analyse-checkCount', whitePov ? [w, b] : [b, w]);
}
function moveOrDropShape(uci, brush, player) {
    if (uci.includes('@')) {
        const pos = uciToDropPos(uci);
        return [
            {
                brush,
                orig: pos
            },
            {
                orig: pos,
                piece: {
                    role: uciToDropRole(uci),
                    color: player
                },
                brush
            }
        ];
    }
    else {
        const move = uciToMove(uci);
        const prom = uciToProm(uci);
        const shapes = [{
                brush,
                orig: move[0],
                dest: move[1]
            }];
        if (prom)
            shapes.push({
                brush,
                orig: move[1],
                piece: {
                    role: prom,
                    color: player
                }
            });
        return shapes;
    }
}

const baseSpeeds = [{
        name: 'fast',
        delay: 1000
    }, {
        name: 'slow',
        delay: 5000
    }];
const realtimeSpeed = {
    name: 'realtimeReplay',
    delay: 'realtime'
};
const cplSpeed = {
    name: 'byCPL',
    delay: 'cpl'
};
function renderGameInfos(ctrl) {
    const player = ctrl.data.player;
    const opponent = ctrl.data.opponent;
    if (!player || !opponent)
        return null;
    return (h("div", { className: "analyse-gameInfos native_scroller" },
        h("div", { className: "analyseOpponent li-button", oncreate: ontapXY(() => player.user && router.set(`/@/${player.user.id}/`)) },
            h("div", { className: "analysePlayerName" },
                h("span", { className: 'color-icon ' + player.color }),
                playerName(player, true),
                renderRatingDiff(player),
                player.berserk ? h("span", { "data-icon": "`" }) : null)),
        h("div", { className: "analyseOpponent li-button", oncreate: ontapXY(() => opponent.user && router.set(`/@/${opponent.user.id}/`)) },
            h("div", { className: "analysePlayerName" },
                h("span", { className: 'color-icon ' + opponent.color }),
                playerName(opponent, true),
                renderRatingDiff(opponent),
                opponent.berserk ? h("span", { "data-icon": "`" }) : null)),
        h("div", { className: "gameInfos" },
            ctrl.formattedDate ? ctrl.formattedDate : null,
            ctrl.data.game.source === 'import' && ctrl.data.game.importedBy ?
                h("div", null,
                    "Imported by ",
                    ctrl.data.game.importedBy) : null),
        gameStatus.finished(ctrl.data) ? renderStatus(ctrl) : null,
        ctrl.data.tournament ?
            h("div", { className: "analyse-tournamentInfo li-button", oncreate: ontapXY(() => ctrl.data.tournament && router.set(`/tournament/${ctrl.data.tournament.id}`)) },
                h("span", { className: "fa fa-trophy" }),
                ctrl.data.tournament.name + ' Arena') : null,
        h("h2", { className: "analyse-tabContentTitle" }, i18n('replayMode')),
        autoplayButtons(ctrl)));
}
function renderStatus(ctrl) {
    const winner = getPlayer(ctrl.data, ctrl.data.game.winner);
    return (h("div", { className: "status" },
        gameStatus.toLabel(ctrl.data.game.status.name, ctrl.data.game.turns, ctrl.data.game.winner, ctrl.data.game.variant.key),
        winner ? '. ' + i18n(winner.color === 'white' ? 'whiteIsVictorious' : 'blackIsVictorious') + '.' : null));
}
function autoplayButtons(ctrl) {
    const d = ctrl.data;
    const hasRealtime = d.game.speed !== 'correspondence' && d.game.moveCentis
        && d.game.moveCentis.length !== 0;
    const speeds = [
        ...baseSpeeds,
        ...(hasRealtime ? [realtimeSpeed] : []),
        ...(d.analysis ? [cplSpeed] : [])
    ];
    return h('div.analyse-autoplay', speeds.map(speed => {
        return h('button.buttonMetal', {
            oncreate: ontap(() => ctrl.autoplay.toggle(speed.delay)),
        }, i18n(speed.name));
    }));
}

function renderActionsBar(ctrl, isPortrait) {
    return (h("section", { className: "actions_bar analyse_actions_bar" },
        h("button", { className: 'action_bar_button fa ' + (ctrl.retroGlowing ? 'fa-play glow' : 'fa-list'), oncreate: ontap(ctrl.study ? ctrl.study.actionMenu.open : ctrl.menu.open) }),
        h("button", { className: "action_bar_button fa fa-gear", oncreate: ontap(ctrl.settings.open) }),
        !ctrl.study || !ctrl.study.chat ?
            h("button", { className: "action_bar_button", "data-icon": "B", oncreate: ontap(ctrl.settings.flip) }) : null,
        ctrl.study && ctrl.study.chat ?
            h("button", { className: "action_bar_button fa fa-comments withChip", oncreate: ontap(ctrl.study.chat.open) }, ctrl.study.chat.nbUnread > 0 ?
                h("span", { className: "chip" }, ctrl.study.chat.nbUnread <= 99 ? ctrl.study.chat.nbUnread : 99) : null) : null,
        isPortrait ?
            h("button", { className: 'action_bar_button fa fa-' + (ctrl.settings.s.smallBoard ? 'expand' : 'compress'), oncreate: ontap(ctrl.settings.toggleBoardSize, () => Toast.show({ text: 'Expand/compress board', duration: 'short', position: 'bottom' })) }) : null,
        h("button", { className: "action_bar_button fa fa-backward", oncreate: ontap(ctrl.stoprewind, undefined, ctrl.rewind) }),
        h("button", { className: "action_bar_button fa fa-forward", disabled: !!ctrl.retro, oncreate: ontap(ctrl.stopff, undefined, ctrl.fastforward) }),
        ctrl.study ?
            h("button", { className: "action_bar_button fa fa-bars", oncreate: ontap(ctrl.study.sideMenu.open) }) : null));
}

function saveForecasts(gameId, playerId, forecasts) {
    return fetchJSON(`/${gameId}${playerId}/forecasts`, {
        method: 'POST',
        body: JSON.stringify(forecasts),
    });
}
function playAndSaveForecasts(gameId, playerId, moveToPlay, forecasts) {
    return fetchJSON(`/${gameId}${playerId}/forecasts/${moveToPlay.uci}`, {
        method: 'POST',
        body: JSON.stringify(forecasts),
    });
}

const MAX_FORECAST_PLIES = 30;
function linesToSanMap(lines) {
    return lines.reduce((map, line) => {
        return map.set(keyOf(line), line);
    }, new Map());
}
function keyOf(fc) {
    return fc.map((node) => node.ply + ':' + node.uci).join(',');
}
class ForecastCtrl {
    constructor(data) {
        this.focusKey = null;
        this.loading = false;
        this._minimized = false;
        const forecastData = data.forecast;
        this._lines = linesToSanMap(forecastData?.steps || []);
        const onMyTurn = forecastData?.onMyTurn;
        this.isMyTurn = !!onMyTurn;
        this._gameId = data.game.id;
        this._playerId = data.player?.id || null;
    }
    /**
     * @returns the given line forecast steps, truncated to a reasonable length and ending
     *          with the viewing player's move.
     */
    truncate(nodes) {
        const requiredPlyMod = this.isMyTurn ? 1 : 0;
        // must end with player move
        return (nodes.length % 2 !== requiredPlyMod ? nodes.slice(0, -1) : nodes).slice(0, MAX_FORECAST_PLIES);
    }
    /**
     * @returns whether the given forecast nodes are part of a new candidate premove line that is not
     *          a prefix of the other saved conditional premove lines.
     */
    isCandidate(nodes) {
        const forecastCandidate = this.truncate(nodes);
        if (!this.isLongEnough(forecastCandidate))
            return false;
        for (const existingForecast of this._lines.values()) {
            if (this.isPrefix(existingForecast, forecastCandidate)) {
                return false;
            }
        }
        return true;
    }
    removeForecast(key) {
        this._lines.delete(key);
        this.focusKey = null;
        this.save();
    }
    add(line) {
        const candidate = this.truncate(line);
        if (!this.isCandidate(candidate))
            return;
        this._lines.set(keyOf(candidate), candidate);
        this.fixAll();
        this.save();
    }
    save() {
        const playerId = this._playerId;
        const gameId = this._gameId;
        if (this.isMyTurn || !playerId)
            return;
        this.loading = true;
        redraw();
        saveForecasts(gameId, playerId, this.lines).then(data => {
            if (data.reload) {
                this.reloadToLastPly();
            }
            else {
                this.loading = false;
                this._lines = linesToSanMap(data.steps || []);
                redraw();
            }
        });
    }
    playAndSave(moveToPlay) {
        const playerId = this._playerId;
        const gameId = this._gameId;
        if (!this.isMyTurn || !playerId)
            return;
        const forecasts = this.findStartingWithNode(moveToPlay)
            .filter(forecast => forecast.length > 0)
            .map(forecast => forecast.slice(1));
        this.loading = true;
        redraw();
        playAndSaveForecasts(gameId, playerId, moveToPlay, forecasts)
            .then(data => {
            if (data.reload) {
                this.reloadToLastPly();
            }
            else {
                this.loading = false;
                this._lines = linesToSanMap(data.steps || []);
                redraw();
            }
        });
    }
    findStartingWithNode(node) {
        return this.lines.filter((candidate) => {
            return this.isPrefix(candidate, [node]);
        });
    }
    reloadToLastPly() {
        router.deleteQueryParam('ply', true);
    }
    get lines() {
        return Array.from(this._lines.values());
    }
    /**
     * @returns whether the given forecast line is a prefix (up to equality) of the other line.
     *          For example, the line (1. e4) and (1. e4 e5) are prefixes of (1. e4 e5).
     */
    isPrefix(line, possiblePrefix) {
        return (line.length >= possiblePrefix.length && keyOf(line).startsWith(keyOf(possiblePrefix)));
    }
    /**
     * Two forecasts are considered to collide if the current player cannot theoretically play both of them.
     * For example, for black, 1. e4 e5 and 1. e4 c5 are colliding forecasts, as black cannot play both e5 and c5
     * in response to e4. However, for white, 1. e4 e5 and 1. e4 c5 are not colliding forecasts.
     *
     * If it is the current player's turn, divergences on the first forecasted move are not considered to collide.
     * For example, 2. e4 and 2. d4 are not collisions on white's turn.
     */
    collides(fc1, fc2) {
        for (let i = 0, max = Math.min(fc1.length, fc2.length); i < max; i++) {
            if (fc1[i].uci !== fc2[i].uci) {
                if (this.isMyTurn) {
                    return i !== 0 && i % 2 === 0;
                }
                return i % 2 === 1;
            }
        }
        /**
         * If the two forecast lines are the same up to the length of the smaller one, they are not considered
         * to be contradictory, but the smaller is considered a prefix of the larger. @see {isPrefix}
         */
        return false;
    }
    toggleMinimized() {
        this._minimized = !(this._minimized);
    }
    get minimized() {
        return this._minimized;
    }
    isLongEnough(fc) {
        return fc.length >= (this.isMyTurn ? 1 : 2);
    }
    /**
     * Consolidates all forecasts such that none of them are contradictory and none of them are prefixes of another.
     */
    fixAll() {
        for (const [key, line] of this._lines.entries()) {
            // Since iteration occurs in the order of insertion, if a newer entry conflicts with an older one,
            // the older one will be removed.
            for (const [otherKey, otherLine] of this._lines.entries()) {
                if (key !== otherKey && this.isPrefix(otherLine, line) || this.collides(line, otherLine)) {
                    this._lines.delete(key);
                    break;
                }
            }
        }
    }
}

/**
 * The base implementation of `_.slice` without an iteratee call guard.
 *
 * @private
 * @param {Array} array The array to slice.
 * @param {number} [start=0] The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the slice of `array`.
 */
function baseSlice(array, start, end) {
  var index = -1,
      length = array.length;

  if (start < 0) {
    start = -start > length ? 0 : (length + start);
  }
  end = end > length ? length : end;
  if (end < 0) {
    end += length;
  }
  length = start > end ? 0 : ((end - start) >>> 0);
  start >>>= 0;

  var result = Array(length);
  while (++index < length) {
    result[index] = array[index + start];
  }
  return result;
}

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeCeil = Math.ceil,
    nativeMax = Math.max;

/**
 * Creates an array of elements split into groups the length of `size`.
 * If `array` can't be split evenly, the final chunk will be the remaining
 * elements.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Array
 * @param {Array} array The array to process.
 * @param {number} [size=1] The length of each chunk
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the new array of chunks.
 * @example
 *
 * _.chunk(['a', 'b', 'c', 'd'], 2);
 * // => [['a', 'b'], ['c', 'd']]
 *
 * _.chunk(['a', 'b', 'c', 'd'], 3);
 * // => [['a', 'b', 'c'], ['d']]
 */
function chunk(array, size, guard) {
  if ((size === undefined)) {
    size = 1;
  } else {
    size = nativeMax(toInteger(size), 0);
  }
  var length = array == null ? 0 : array.length;
  if (!length || size < 1) {
    return [];
  }
  var index = 0,
      resIndex = 0,
      result = Array(nativeCeil(length / size));

  while (index < length) {
    result[resIndex++] = baseSlice(array, index, (index += size));
  }
  return result;
}

function groupMoves(nodes) {
    const moves = [];
    if (nodes[0].ply % 2 === 0) {
        // black is the first move
        moves.push({
            index: Math.floor((nodes[0].ply + 1) / 2),
            black: nodes[0].san,
            white: null,
        });
        nodes = nodes.slice(1);
    }
    chunk(nodes, 2).forEach(([white, black]) => {
        moves.push({
            index: (white.ply + 1) / 2,
            white: white.san,
            black: black?.san,
        });
    });
    return moves;
}

function renderForecasts(ctrl) {
    const fctrl = ctrl.forecast;
    if (!fctrl || ctrl.synthetic || !playable(ctrl.data))
        return null;
    const candidateNodes = makeCandidateNodes(ctrl, fctrl);
    const isCandidate = fctrl.isCandidate(candidateNodes);
    return (h('div.analyse-training_box.analyse-forecast_box.box', {
        className: fctrl.minimized ? 'minimized' : '',
        oncreate: ontap(() => { fctrl.focusKey = null; }),
    }, [
        renderTitle(fctrl),
        h('div.forecasts-wrapper.native_scroller', [
            h('div.forecasts-list', {
                className: settings.game.pieceNotation() ? 'displayPieces' : '',
            }, [
                ...fctrl.lines.map(nodes => {
                    const key = keyOf(nodes);
                    return h('div.forecast[data-icon=G]', {
                        key: key,
                        oncreate: ontap((e) => {
                            e.stopPropagation();
                            fctrl.focusKey = key;
                        }),
                    }, [
                        h('sans', renderNodesHtml(nodes)),
                        fctrl.focusKey === key ? h('span.fa.fa-times-circle.delete', {
                            oncreate: ontap(e => {
                                e.stopPropagation();
                                fctrl.removeForecast(key);
                            })
                        }) : null,
                    ]);
                }),
            ]),
            h('div.add', {
                className: isCandidate ? 'enabled' : '',
                'data-icon': isCandidate ? 'O' : '',
                oncreate: ontap(() => {
                    const candidateNodes = makeCandidateNodes(ctrl, fctrl);
                    fctrl.add(candidateNodes);
                })
            }, [
                isCandidate ? h('div', [
                    h('span', i18n('addCurrentVariation')),
                    h('sans', renderNodesHtml(candidateNodes)),
                ]) :
                    h('span', i18n('playVariationToCreateConditionalPremoves'))
            ]),
            renderOnMyTurnView(ctrl, candidateNodes),
            fctrl.loading ? renderSpinner() : null,
        ]),
    ]));
}
function makeCandidateNodes(ctrl, fctrl) {
    const afterPly = ctrl.tree.getCurrentNodesAfterPly(ctrl.nodeList, ctrl.mainline, ctrl.data.game.turns);
    return fctrl.truncate(afterPly.map((node) => ({
        ply: node.ply,
        fen: node.fen,
        uci: node.uci,
        san: node.san,
    })));
}
function renderNodesHtml(nodes) {
    if (!nodes[0])
        return [];
    if (!nodes[0].san)
        nodes = nodes.slice(1);
    if (!nodes[0])
        return [];
    return groupMoves(nodes).map(({ black, white, index }) => {
        return h('move', [
            h('index', index + (white ? '.' : '...')),
            white ? h('san', white) : null,
            black ? h('san', black) : null,
        ]);
    });
}
function renderOnMyTurnView(ctrl, candidate) {
    if (!ctrl.forecast?.isMyTurn)
        return;
    const firstNode = candidate[0];
    if (!firstNode)
        return;
    const candidates = ctrl.forecast.findStartingWithNode(firstNode);
    if (!candidates.length)
        return;
    const lineCount = candidates.filter((candidate) => {
        return candidate.length > 1;
    }).length;
    return (h('div.on-my-turn', h('button.defaultButton', {
        oncreate: ontap(() => ctrl.forecast.playAndSave(firstNode))
    }, [
        h('span.fa.fa-check'),
        h('span', [
            h('strong', i18n('playX', candidate[0].san)),
            ' ',
            lineCount ? h('span', plural('andSaveNbPremoveLines', lineCount)) : null
        ])
    ])));
}
function renderSpinner() {
    return h('div.spinner_overlay', h('div.spinner.fa.fa-hourglass-half'));
}
function renderTitle(ctrl) {
    return h('div.titleWrapper', [
        h('div.title', [i18n('conditionalPremoves'), ctrl.lines.length > 0 ? ` (${ctrl.lines.length})` : null]),
        h('div.actions', [
            h('button.window-button', {
                oncreate: ontap(() => ctrl.toggleMinimized())
            }, h('span.fa', {
                className: ctrl.minimized ? 'fa-window-maximize' : 'fa-window-minimize'
            })),
        ])
    ]);
}

function loadingScreen(isPortrait, color, curFen) {
    const isSmall = settings.analyse.smallBoard();
    return layout.board(loadingBackbutton(), [
        viewOnlyBoard(color || 'white', isSmall, curFen || emptyFen),
        h('div.analyse-tableWrapper', spinner.getVdom('monochrome')),
        isPortrait ? h('section.analyse_actions_bar') : null,
    ]);
}
function renderContent(ctrl, isPortrait) {
    const availTabs = ctrl.availableTabs();
    const tablet = isTablet();
    return h.fragment({
        key: 'size' + ctrl.settings.s.smallBoard,
    }, [
        renderBoard(ctrl),
        h('div.analyse-tableWrapper', [
            ctrl.data.game.variant.key === 'crazyhouse' && (isPortrait || !tablet) ? renderCrazy(ctrl) : null,
            !isPortrait && tablet ? renderPlayer(ctrl) : null,
            renderAnalyseTable(ctrl, availTabs),
            !isPortrait ? renderActionsBar(ctrl, isPortrait) : null,
            !isPortrait && tablet ? renderOpponent(ctrl) : null,
        ]),
        isPortrait ? renderActionsBar(ctrl, isPortrait) : null,
    ]);
}
function overlay(ctrl) {
    return [
        view$1(ctrl),
        ctrl.study ? actionMenu.view(ctrl.study.actionMenu) : analyseMenu.view(ctrl.menu),
        ctrl.study && ctrl.study.chat ? chatView(ctrl.study.chat) : null,
        analyseSettings.view(ctrl.settings),
        ctrl.notes ? notesView(ctrl.notes) : null,
        continuePopup.view(ctrl.continuePopup),
        view(ctrl),
    ];
}
function renderVariantSelector(ctrl) {
    const variant = ctrl.data.game.variant.key;
    const icon = gameIcon(variant);
    let availVariants = settings.analyse.availableVariants;
    if (variant === 'fromPosition') {
        availVariants = availVariants.concat([['From position', 'fromPosition']]);
    }
    return (h('div.select_input.main_header-selector.header-subTitle', [
        h('label', {
            'for': 'variant_selector'
        }, h(`i[data-icon=${icon}]`)),
        h('select', {
            id: 'variant_selector',
            value: variant,
            onchange: (e) => {
                const val = e.target.value;
                settings.analyse.syntheticVariant(val);
                router.set(`/analyse/variant/${val}`);
            }
        }, availVariants.map(v => h('option', {
            key: v[1], value: v[1]
        }, v[0])))
    ]));
}
function viewOnlyBoard(color, isSmall, fen) {
    return h('section.board_wrapper.analyse-boardWrapper', {
        className: isSmall ? 'halfsize ' : ''
    }, h(ViewOnlyBoard, { orientation: color, fen }));
}
function renderOpening(ctrl) {
    const opening = ctrl.tree.getOpening(ctrl.nodeList) || ctrl.data.game.opening;
    if (opening)
        return h('div', [
            h('strong', opening.eco),
            ' ' + opening.name
        ]);
}
function renderAnalyseTabs(ctrl, availTabs) {
    const curTab = ctrl.currentTab(availTabs);
    const buttons = availTabs.map(b => {
        if (b.id === 'comments' && ctrl.node.comments && ctrl.node.comments.length > 0) {
            return {
                ...b,
                chip: ctrl.node.comments.length
            };
        }
        else if (b.id === 'forecasts' && ctrl.forecast?.lines && ctrl.forecast.lines.length > 0) {
            return {
                ...b,
                chip: ctrl.forecast.lines.length,
            };
        }
        return b;
    });
    return h('div.analyse-header', [
        curTab.id !== 'ceval' ? h(EvalBox, { ctrl }) : null,
        h('div.analyse-tabs', [
            h('div.tab-title', renderTabTitle(ctrl, curTab)),
            h(TabNavigation, {
                buttons,
                selectedIndex: ctrl.currentTabIndex(availTabs),
                onTabChange: ctrl.onTabChange,
                wrapperClass: 'analyse'
            })
        ])
    ]);
}
function renderTabTitle(ctrl, curTab) {
    const defaultTitle = i18n(curTab.title);
    let children;
    if (curTab.id === 'moves') {
        const op = renderOpening(ctrl);
        children = [op || defaultTitle];
    }
    else if (curTab.id === 'ceval') {
        children = [
            h('span', ctrl.ceval.getEngineName() + (ctrl.ceval.getEngineEvaluation() ?
                ` (${ctrl.ceval.getEngineEvaluation()})` : '')),
            ctrl.ceval.isSearching() ? h('div.ceval-spinner', h('span.fa.fa-spinner.fa-pulse')) : null
        ];
    }
    else if (curTab.id === 'explorer') {
        children = [getTitle(ctrl)];
    }
    else {
        children = [defaultTitle];
    }
    return h.fragment({}, children);
}
function renderReplay(ctrl) {
    // TODO enable when study has write support
    // if (ctrl.study && ctrl.study.canContribute()) {
    //   return h('div.study-replayWrapper', [
    //     h('div.analyse-replayWrapper', [
    //       h(Replay, { ctrl, rightTabActive: ctrl.study.vm.showComments }),
    //       ctrl.study.vm.showComments ? renderComments(ctrl.study) : null
    //     ]),
    //     renderReplayActions(ctrl.study)
    //   ])
    // } else {
    // }
    return h('div.analyse-replayWrapper', [
        h(Replay, { ctrl, rightTabActive: false }),
    ]);
}
const TabsContentRendererMap = {
    infos: renderGameInfos,
    moves: renderReplay,
    explorer: renderExplorer,
    analysis: renderAnalysis,
    ceval: renderCeval,
    pgnTags: renderPgnTags,
    comments: renderReadonlyComments,
};
function renderAnalyseTable(ctrl, availTabs) {
    const withTrainingBox = ctrl.retro || ctrl.practice || ctrl.forecast;
    return h('div.analyse-table.box', [
        renderAnalyseTabs(ctrl, availTabs),
        h(TabView, {
            className: 'analyse-tabsContent' + (withTrainingBox ? ' withTrainingBox' : ''),
            selectedIndex: ctrl.currentTabIndex(availTabs),
            tabs: availTabs.map(t => ({
                id: t.id,
                f: () => TabsContentRendererMap[t.id](ctrl)
            })),
            onTabChange: ctrl.onTabChange,
            boardView: true,
        }),
        ctrl.retro ? retroView(ctrl) : null,
        ctrl.practice ? practiceView(ctrl) : null,
        ctrl.forecast ? renderForecasts(ctrl) : null,
    ]);
}

class Autoplay {
    constructor(ctrl) {
        this.ctrl = ctrl;
    }
    move() {
        if (this.ctrl.canGoForward()) {
            this.ctrl.next();
            redraw();
            return true;
        }
        this.stop();
        redraw();
        return false;
    }
    evalToCp(node) {
        if (!node.eval)
            return node.ply % 2 ? 990 : -990; // game over
        if (node.eval.mate)
            return (node.eval.mate > 0) ? 990 : -990;
        return node.eval.cp;
    }
    nextDelay() {
        if (typeof this.delay === 'string' && !this.ctrl.onMainline)
            return 1500;
        else if (this.delay === 'realtime') {
            if (this.ctrl.node.ply < 2)
                return 1000;
            const centis = this.ctrl.data.game.moveCentis;
            if (!centis)
                return 1500;
            const time = centis[this.ctrl.node.ply - this.ctrl.tree.root.ply];
            // estimate 130ms of lag to improve playback.
            return time * 10 + 130 || 2000;
        }
        else if (this.delay === 'cpl') {
            const slowDown = 30;
            if (this.ctrl.node.ply >= this.ctrl.mainline.length - 1)
                return 0;
            const currPlyCp = this.evalToCp(this.ctrl.node);
            const nextPlyCp = this.evalToCp(this.ctrl.node.children[0]);
            return Math.max(500, Math.min(10000, Math.abs(currPlyCp - nextPlyCp) * slowDown));
        }
        else
            return this.delay;
    }
    schedule() {
        this.timeoutId = setTimeout(() => {
            if (this.move())
                this.schedule();
        }, this.nextDelay());
    }
    start(delay) {
        this.delay = delay;
        this.stop();
        this.schedule();
    }
    stop() {
        clearTimeout(this.timeoutId);
        this.timeoutId = undefined;
    }
    toggle(delay) {
        if (this.active(delay))
            this.stop();
        else {
            if (!this.active() && !this.move())
                this.ctrl.jump('');
            this.start(delay);
        }
    }
    active(delay) {
        return (!delay || delay === this.delay) && !!this.timeoutId;
    }
}

function defer() {
    const deferred = {
        state: 'pending'
    };
    deferred.promise = new Promise((resolve, reject) => {
        deferred.resolve = (v) => {
            deferred.state = 'fulfilled';
            resolve(v);
        };
        deferred.reject = () => {
            deferred.state = 'rejected';
            reject();
        };
    });
    return deferred;
}

const EVAL_REGEX = new RegExp(''
    + /^info depth (\d+) seldepth \d+ multipv (\d+) /.source
    + /score (cp|mate) ([-\d]+) /.source
    + /(?:(upper|lower)bound )?nodes (\d+) nps \S+ /.source
    + /(?:hashfull \d+ )?(?:tbhits \d+ )?time (\S+) /.source
    + /pv (.+)/.source);
class StockfishClient {
    constructor(variant, threads, hash) {
        this.threads = threads;
        this.hash = hash;
        this.expectedPvs = 1;
        // we may have several start requests queued while we wait for previous
        // eval to complete
        this.startQueue = [];
        // stopped flag is true when a search has been interrupted before its end
        this.stopped = false;
        this.engineName = 'Stockfish';
        /*
         * Init engine with default options and variant
         */
        this.init = async () => {
            try {
                window.addEventListener('stockfish', this.listener, { passive: true });
                const obj = await this.stockfish.start();
                this.engineName = obj.engineName;
                await this.stockfish.setVariant();
                await this.stockfish.setOption('UCI_AnalyseMode', 'true');
                await this.stockfish.setOption('Threads', this.threads);
                if (Capacitor.getPlatform() !== 'web') {
                    await this.stockfish.setOption('Hash', this.hash);
                }
            }
            catch (err) {
                console.error('stockfish init error', err);
            }
        };
        /*
         * Stop current command if not already stopped, then add a search command to
         * the queue.
         * The search will start when stockfish is ready (after reinit if it takes more
         * than 10s to stop current search)
         */
        this.start = (work) => {
            this.stop();
            this.startQueue.push(work);
            clearTimeout(this.stopTimeoutId);
            const timeout = new Promise((_, reject) => {
                this.stopTimeoutId = setTimeout(reject, 10 * 1000);
            });
            return Promise.race([this.ready.promise, timeout])
                .then(this.search)
                .catch(() => {
                this.reset().then(this.search);
            });
        };
        /*
         * Sends 'stop' command to stockfish if not already stopped
         */
        this.stop = () => {
            if (!this.stopped) {
                this.stopped = true;
                this.stockfish.send('stop');
            }
        };
        this.exit = () => {
            window.removeEventListener('stockfish', this.listener, false);
            return this.stockfish.exit();
        };
        this.reset = () => {
            return this.exit().then(this.init);
        };
        /*
         * Actual search is launched here, according to work opts, using the last work
         * queued
         */
        this.search = async () => {
            const work = this.startQueue.pop();
            if (work) {
                this.work = work;
                this.curEval = undefined;
                this.expectedPvs = 1;
                this.stopped = false;
                this.startQueue = [];
                this.ready = defer();
                await this.stockfish.setOption('MultiPV', work.multiPv);
                await this.stockfish.send(['position', 'fen', work.initialFen, 'moves'].concat(work.moves).join(' '));
                if (work.maxDepth >= 99) {
                    await this.stockfish.send('go depth 99');
                }
                else {
                    await this.stockfish.send('go movetime 90000 depth ' + work.maxDepth);
                }
            }
        };
        this.listener = (e) => {
            this.processOutput(e.output);
        };
        this.stockfish = new StockfishPlugin(variant);
        this.ready = defer();
        this.ready.resolve();
    }
    isSearching() {
        return this.ready.state === 'pending';
    }
    /*
     * Stockfish output processing done here
     * Calls the 'resolve' function of the 'ready' Promise when 'bestmove' uci
     * command is sent by stockfish
     */
    processOutput(text) {
        console.debug('[stockfish >>] ' + text);
        const evalMatch = /^info string (classical|NNUE) evaluation/.exec(text);
        if (evalMatch) {
            this.evaluation = evalMatch[1];
        }
        if (text.indexOf('bestmove') === 0) {
            this.ready.resolve();
            this.work?.emit();
        }
        if (this.stopped || this.work === undefined)
            return;
        const matches = EVAL_REGEX.exec(text);
        if (!matches)
            return;
        const depth = parseInt(matches[1]), multiPv = parseInt(matches[2]), isMate = matches[3] === 'mate', povEv = parseInt(matches[4]), evalType = matches[5], nodes = parseInt(matches[6]), elapsedMs = parseInt(matches[7]), moves = matches[8].split(' ');
        // Sometimes we get #0. Let's just skip it.
        if (isMate && !povEv)
            return;
        // Track max pv index to determine when pv prints are done.
        if (this.expectedPvs < multiPv)
            this.expectedPvs = multiPv;
        const pivot = this.work.threatMode ? 0 : 1;
        const ev = (this.work.ply % 2 === pivot) ? -povEv : povEv;
        // For now, ignore most upperbound/lowerbound messages.
        // The exception is for multiPV, sometimes non-primary PVs
        // only have an upperbound.
        // See: https://github.com/ddugovic/Stockfish/issues/228
        if (evalType && multiPv === 1)
            return;
        const pvData = {
            moves,
            cp: isMate ? undefined : ev,
            mate: isMate ? ev : undefined,
            depth
        };
        if (multiPv === 1) {
            this.curEval = {
                fen: this.work.currentFen,
                maxDepth: this.work.maxDepth,
                depth,
                knps: nodes / elapsedMs,
                nodes,
                cp: pvData.cp,
                mate: pvData.mate,
                pvs: [pvData],
                millis: elapsedMs,
            };
        }
        else if (this.curEval) {
            this.curEval.pvs.push(pvData);
            this.curEval.depth = Math.min(this.curEval.depth, depth);
        }
        if (multiPv === this.expectedPvs && this.curEval) {
            this.work.emit(this.curEval);
        }
    }
}

class CevalCtrl {
    constructor(opts, emit) {
        this.opts = opts;
        this.emit = emit;
        this.minDepth = 6;
        this.initialized = false;
        this.started = false;
        this.isDeeper = false;
        this.lastStarted = undefined;
        this.init = () => {
            return this.engine.init().then(() => {
                this.initialized = true;
            });
        };
        this.destroy = () => {
            if (this.initialized) {
                this.engine.exit()
                    .then(() => {
                    this.initialized = false;
                    this.started = false;
                })
                    .catch(() => {
                    this.initialized = false;
                    this.started = false;
                });
            }
        };
        this.stop = () => {
            if (!this.enabled() || !this.started)
                return;
            this.engine.stop();
            this.started = false;
        };
        this.toggle = () => {
            this.isEnabled = !this.isEnabled;
        };
        this.disable = () => {
            this.isEnabled = false;
        };
        this.toggleInfinite = () => {
            this.opts.infinite = !this.opts.infinite;
            this.restart();
        };
        this.goDeeper = () => {
            if (this.lastStarted) {
                this.start(this.lastStarted.threatMode, this.lastStarted.path, this.lastStarted.nodes, false, true);
            }
        };
        this.onEmit = (work, ev) => {
            if (ev)
                sortPvsInPlace(ev.pvs, (work.ply % 2 === 0) ? 'white' : 'black');
            if (ev)
                npsRecorder(ev);
            this.emit(work.path, ev, work.threatMode);
        };
        this.allowed = opts.allowed;
        this.variant = opts.variant;
        this.isEnabled = settings.analyse.enableCeval();
        this.engine = new StockfishClient(opts.variant, opts.cores, opts.hashSize);
    }
    enabled() {
        return this.opts.allowed && this.isEnabled;
    }
    async start(threatMode, path, nodes, forceMaxLevel, deeper) {
        if (!this.enabled()) {
            return;
        }
        this.isDeeper = deeper;
        const step = nodes[nodes.length - 1];
        const maxDepth = this.effectiveMaxDepth(deeper);
        const existing = threatMode ? step.threat : step.ceval;
        if (existing && existing.depth >= maxDepth) {
            return;
        }
        const work = {
            initialFen: nodes[0].fen,
            currentFen: step.fen,
            moves: [],
            maxDepth: forceMaxLevel ? settings.analyse.cevalMaxDepth() : this.effectiveMaxDepth(deeper),
            path,
            ply: step.ply,
            multiPv: forceMaxLevel ? 1 : this.opts.multiPv,
            threatMode,
            emit: (ev) => {
                if (this.enabled())
                    this.onEmit(work, ev);
            },
        };
        if (threatMode) {
            const c = step.ply % 2 === 1 ? 'w' : 'b';
            const fen = step.fen.replace(/ (w|b) /, ' ' + c + ' ');
            work.currentFen = fen;
            work.initialFen = fen;
        }
        else {
            // send fen after latest castling move and the following moves
            for (let i = 1; i < nodes.length; i++) {
                const s = nodes[i];
                if (sanIrreversible(this.variant, s.san)) {
                    work.moves = [];
                    work.initialFen = s.fen;
                }
                else
                    work.moves.push(s.uci);
            }
        }
        this.engine.start(work);
        this.started = true;
        this.lastStarted = {
            threatMode,
            path,
            nodes,
        };
    }
    // Useful if/when options change while analysis is running.
    restart() {
        if (this.lastStarted) {
            void this.start(this.lastStarted.threatMode, this.lastStarted.path, this.lastStarted.nodes, false, false);
        }
    }
    isInit() {
        return this.initialized;
    }
    isSearching() {
        return this.engine.isSearching();
    }
    setMultiPv(pv) {
        this.opts.multiPv = pv;
        this.restart();
    }
    getMultiPv() {
        return this.opts.multiPv;
    }
    canGoDeeper() {
        return !this.isDeeper && !this.opts.infinite && !this.engine.isSearching();
    }
    getEngineName() {
        return this.engine.engineName;
    }
    getEngineEvaluation() {
        return this.engine.evaluation;
    }
    effectiveMaxDepth(deeper = false) {
        return (deeper || this.opts.infinite) ? 99 : settings.analyse.cevalMaxDepth();
    }
}
function median(values) {
    values.sort((a, b) => a - b);
    const half = Math.floor(values.length / 2);
    return values.length % 2 ? values[half] : (values[half - 1] + values[half]) / 2.0;
}
// stockfish does not always sort pvs
function sortPvsInPlace(pvs, color) {
    return pvs.sort((a, b) => {
        return povChances(color, b) - povChances(color, a);
    });
}
const npsRecorder = (() => {
    const values = [];
    const applies = (ev) => {
        return ev.knps && ev.depth >= 16 &&
            ev.cp !== undefined && Math.abs(ev.cp) < 500 &&
            (ev.fen.split(/\s/)[0].split(/[nbrqkp]/i).length - 1) >= 10;
    };
    return (ev) => {
        if (!applies(ev))
            return;
        values.push(ev.knps);
        if (values.length > 9) {
            const knps = median(values) || 0;
            let depth = 18;
            if (knps > 100)
                depth = 19;
            if (knps > 150)
                depth = 20;
            if (knps > 250)
                depth = 21;
            if (knps > 500)
                depth = 22;
            if (knps > 1000)
                depth = 23;
            if (knps > 2000)
                depth = 24;
            if (knps > 3500)
                depth = 25;
            if (knps > 5000)
                depth = 26;
            if (knps > 7000)
                depth = 27;
            if (settings.analyse.cevalMaxDepth() !== depth) {
                settings.analyse.cevalMaxDepth(depth);
            }
            if (values.length > 40)
                values.shift();
        }
    };
})();
function sanIrreversible(variant, san) {
    if (san.startsWith('O-O'))
        return true;
    if (variant === 'crazyhouse')
        return false;
    if (san.includes('x'))
        return true; // capture
    if (san.toLowerCase() === san)
        return true; // pawn move
    return variant === 'threeCheck' && san.includes('+');
}

function hasCompChild(node) {
    return !!node.children.find(function (c) {
        return !!c.comp;
    });
}
function evalSwings(mainline, nodeFilter) {
    const found = [];
    const threshold = 0.075;
    for (let i = 1; i < mainline.length; i++) {
        const node = mainline[i];
        const prev = mainline[i - 1];
        if (nodeFilter(node) && node.eval && prev.eval) {
            const diff = Math.abs(povDiff('white', prev.eval, node.eval));
            if (diff > threshold && hasCompChild(prev))
                found.push(node);
        }
    }
    return found;
}
function threefoldFen(fen) {
    return fen.split(' ').slice(0, 4).join(' ');
}
function detectThreefold(nodeList, node) {
    if (node.threefold !== undefined)
        return;
    const currentFen = threefoldFen(node.fen);
    let nbSimilarPositions = 0;
    for (const i in nodeList)
        if (threefoldFen(nodeList[i].fen) === currentFen)
            nbSimilarPositions++;
    node.threefold = nbSimilarPositions > 2;
}

function RetroCtrl(root) {
    const game = root.data.game;
    let candidateNodes = [];
    const explorerCancelPlies = [];
    let solvedPlies = [];
    const vm = {
        current: null,
        feedback: 'find',
        minimized: false,
        color: root.bottomColor()
    };
    function isPlySolved(ply) {
        return solvedPlies.includes(ply);
    }
    function findNextNode() {
        const colorModulo = root.bottomColor() === 'white' ? 1 : 0;
        candidateNodes = evalSwings(root.mainline, n => n.ply % 2 === colorModulo && !explorerCancelPlies.includes(n.ply));
        return candidateNodes.find(n => !isPlySolved(n.ply));
    }
    function jumpToCurrent() {
        vm.feedback = 'find';
        const node = findNextNode();
        if (!node) {
            vm.current = null;
            return redraw();
        }
        const fault = {
            node,
            path: root.mainlinePathToPly(node.ply)
        };
        const prevPath = init(fault.path);
        const prev = {
            node: root.tree.nodeAtPath(prevPath),
            path: prevPath
        };
        const solutionNode = prev.node.children.find(n => !!n.comp);
        vm.current = {
            fault,
            prev,
            solution: {
                node: solutionNode,
                path: prevPath + solutionNode.id
            },
            openingUcis: []
        };
        // fetch opening explorer moves
        if (game.variant.key === 'standard' && game.division && (!game.division.middle || fault.node.ply < game.division.middle)) {
            root.explorer.fetchMasterOpening(prev.node.fen).then((res) => {
                const cur = vm.current;
                const ucis = [];
                res.moves.forEach((m) => {
                    if (m.white + m.draws + m.black > 1)
                        ucis.push(m.uci);
                });
                if (ucis.find((uci) => {
                    return fault.node.uci === uci;
                })) {
                    explorerCancelPlies.push(fault.node.ply);
                    setTimeout(jumpToCurrent, 100);
                }
                else {
                    cur.openingUcis = ucis;
                    vm.current = cur;
                }
            });
        }
        root.userJump(prev.path);
        redraw();
    }
    function onJump() {
        const node = root.node, fb = vm.feedback, cur = vm.current;
        if (!cur)
            return;
        if (fb === 'eval' && cur.fault.node.ply !== node.ply) {
            vm.feedback = 'find';
            return;
        }
        if (isSolving() && cur.fault.node.ply === node.ply) {
            if (cur.openingUcis.some((uci) => node.uci === uci))
                onWin(); // found in opening explorer
            else if (node.comp)
                onWin(); // the computer solution line
            else if (node.eval)
                onFail(); // the move that was played in the game
            else {
                vm.feedback = 'eval';
                if (!root.ceval.enabled()) {
                    root.ceval.toggle();
                    root.initCeval();
                }
                checkCeval();
            }
        }
    }
    function isCevalReady(node) {
        return node.ceval ? (node.ceval.depth >= 18 ||
            (node.ceval.depth >= 14 && node.ceval.millis !== undefined && node.ceval.millis > 7000)) : false;
    }
    function checkCeval() {
        const node = root.node, cur = vm.current;
        if (!cur || vm.feedback !== 'eval' || cur.fault.node.ply !== node.ply)
            return;
        if (isCevalReady(node)) {
            root.stopCevalImmediately();
            const diff = povDiff(vm.color, node.ceval, cur.prev.node.eval);
            if (diff > -0.035)
                onWin();
            else
                onFail();
        }
    }
    function onWin() {
        vm.feedback = 'win';
        redraw();
    }
    function onFail() {
        vm.feedback = 'fail';
        const bad = {
            node: root.node,
            path: root.path
        };
        root.userJump(vm.current.prev.path);
        if (!root.tree.pathIsMainline(bad.path) && empty(bad.node.children))
            root.tree.deleteNodeAt(bad.path);
        redraw();
    }
    function viewSolution() {
        vm.feedback = 'view';
        root.userJump(vm.current.solution.path);
    }
    function nextMistake() {
        solvedPlies.push(vm.current.fault.node.ply);
        jumpToCurrent();
    }
    function hideComputerLine(node) {
        return (node.ply % 2 === 0) !== (vm.color === 'white') && !isPlySolved(node.ply);
    }
    function showBadNode() {
        const cur = vm.current;
        if (cur && isSolving() && cur.prev.path === root.path)
            return cur.fault.node;
    }
    function isSolving() {
        const fb = vm.feedback;
        return fb === 'find' || fb === 'fail';
    }
    function onMergeAnalysisData() {
        if (isSolving() && !vm.current)
            jumpToCurrent();
    }
    function reset() {
        solvedPlies = [];
        jumpToCurrent();
    }
    return {
        vm,
        isPlySolved,
        onJump,
        jumpToCurrent,
        nextMistake,
        viewSolution,
        hideComputerLine,
        showBadNode,
        onCeval: checkCeval,
        onMergeAnalysisData,
        isSolving,
        completion: () => [solvedPlies.length, candidateNodes.length],
        flip() {
            root.settings.flip();
            vm.color = root.bottomColor();
            reset();
        },
        reset,
        pieceTheme: settings.general.theme.piece(),
        close: root.toggleRetro,
        toggleWindow() {
            vm.minimized = !vm.minimized;
        },
        node: () => root.node
    };
}

function make$1(root, playableDepth) {
    const variant = root.data.game.variant.key, minimized = prop(false), running = prop(true), comment = prop(null), hinting = prop(null), played = prop(false);
    function ensureCevalRunning() {
        if (!root.ceval.enabled()) {
            root.ceval.toggle();
            root.initCeval();
        }
    }
    function commentable(node, bonus = 0) {
        if (root.gameOver(node) || node.tbhit)
            return true;
        const ceval = node.ceval;
        return ceval ? ((ceval.depth + bonus) >= 15 || (ceval.depth >= 13 && Number(ceval.millis) > 3000)) : false;
    }
    function playable(node) {
        const ceval = node.ceval;
        return ceval ? (ceval.depth >= Math.min(ceval.maxDepth || 99, playableDepth()) ||
            (ceval.depth >= 15 && (ceval.cloud || Number(ceval.millis) > 5000))) : false;
    }
    function tbhitToEval(hit) {
        return hit && (hit.winner ? {
            mate: hit.winner === 'white' ? 10 : -10
        } : { cp: 0 });
    }
    function nodeBestUci(node) {
        return (node.tbhit && node.tbhit.best) || (node.ceval && node.ceval.pvs[0].moves[0]);
    }
    function makeComment(prev, node, path) {
        let verdict;
        let best;
        const over = root.gameOver(node);
        if (over === 'checkmate')
            verdict = 'goodMove';
        else {
            const nodeEval = tbhitToEval(node.tbhit) || ((node.threefold || over === 'draw') ? { cp: 0 } : node.ceval);
            const prevEval = tbhitToEval(prev.tbhit) || prev.ceval;
            const shift = -povDiff(root.bottomColor(), nodeEval, prevEval);
            best = nodeBestUci(prev);
            if (best === node.uci || (node.san.startsWith('O-O') && best === altCastles[node.uci]))
                best = null;
            if (!best)
                verdict = 'goodMove';
            else if (shift < 0.025)
                verdict = 'goodMove';
            else if (shift < 0.06)
                verdict = 'inaccuracy';
            else if (shift < 0.14)
                verdict = 'mistake';
            else
                verdict = 'blunder';
        }
        return {
            prev,
            node,
            path,
            verdict,
            best: best ? {
                uci: best,
                san: position(prev).unwrap(pos => makeSan(pos, parseUci(best)), _ => '--'),
            } : undefined
        };
    }
    function position(node) {
        const setup = parseFen(node.fen).unwrap();
        return setupPosition(lichessRules(root.data.game.variant.key), setup);
    }
    function isMyTurn() {
        return root.turnColor() === root.bottomColor();
    }
    function checkCeval() {
        const node = root.node;
        if (!running()) {
            comment(null);
            return redraw();
        }
        if (tablebaseGuaranteed(variant, node.fen) && !defined(node.tbhit))
            return;
        ensureCevalRunning();
        if (isMyTurn()) {
            const h = hinting();
            if (h) {
                h.uci = nodeBestUci(node) || h.uci;
            }
        }
        else {
            comment(null);
            if (node.san && commentable(node)) {
                const parentNode = root.tree.parentNode(root.path);
                if (commentable(parentNode, 1))
                    comment(makeComment(parentNode, node, root.path));
                else {
                    /*
                     * Looks like the parent node didn't get enough analysis time
                     * to be commentable :-/ it can happen if the player premoves
                     * or just makes a move before the position is sufficiently analysed.
                     * In this case, fall back to comparing to the position before,
                     * Since computer moves are supposed to preserve eval anyway.
                     */
                    const olderNode = root.tree.parentNode(init(root.path));
                    if (commentable(olderNode, 1))
                        comment(makeComment(olderNode, node, root.path));
                }
            }
            if (!played() && playable(node)) {
                root.playUci(nodeBestUci(node));
                played(true);
            }
            else
                redraw();
        }
    }
    function checkCevalOrTablebase() {
        ensureCevalRunning();
        if (tablebaseGuaranteed(variant, root.node.fen)) {
            root.explorer.fetchTablebaseHit(root.node.fen)
                .then(hit => {
                if (hit && root.node.fen === hit.fen)
                    root.node.tbhit = hit;
                checkCeval();
            })
                .catch(() => {
                if (!defined(root.node.tbhit))
                    root.node.tbhit = null;
                checkCeval();
            });
        }
        else
            checkCeval();
    }
    function resume() {
        running(true);
        checkCevalOrTablebase();
        redraw();
    }
    requestIdleCallback(checkCevalOrTablebase);
    return {
        onCeval: checkCeval,
        onJump() {
            played(false);
            hinting(null);
            detectThreefold(root.nodeList, root.node);
            checkCevalOrTablebase();
        },
        isMyTurn,
        comment,
        running,
        hinting,
        resume,
        playableDepth,
        reset() {
            comment(null);
            hinting(null);
        },
        preUserJump(from, to) {
            if (from !== to) {
                running(false);
                comment(null);
            }
        },
        postUserJump(from, to) {
            if (from !== to && isMyTurn())
                resume();
        },
        onUserMove() {
            running(true);
        },
        playCommentBest() {
            const c = comment();
            if (!c)
                return;
            root.jump(init(c.path));
            if (c.best)
                root.playUci(c.best.uci);
        },
        hint() {
            const best = root.node.ceval ? root.node.ceval.pvs[0].moves[0] : null, prev = hinting();
            if (!best || (prev && prev.mode === 'move'))
                hinting(null);
            else
                hinting({
                    mode: prev ? 'move' : 'piece',
                    uci: best
                });
            redraw();
        },
        currentNode: () => root.node,
        bottomColor: root.bottomColor,
        pieceTheme: settings.general.theme.piece(),
        minimized,
        toggleWindow() {
            minimized(!minimized());
        },
    };
}

var crazyValid = {
    drop(role, key, possibleDrops) {
        if (role === 'pawn' && (key[1] === '1' || key[1] === '8'))
            return false;
        if (possibleDrops === undefined || possibleDrops === null)
            return true;
        const drops = Array.isArray(possibleDrops) ?
            possibleDrops : possibleDrops.match(/.{2}/g) || [];
        return drops.indexOf(key) !== -1;
    }
};

const explorerEndpoint = 'https://explorer.lichess.ovh';
const tablebaseEndpoint = 'https://tablebase.lichess.ovh';
function openingXhr(variant, fen, config, withGames) {
    const query = { fen, variant };
    if (!withGames) {
        query.topGames = 0;
        query.recentGames = 0;
    }
    if (config.db === 'lichess') {
        if (config.speeds)
            query.speeds = config.speeds.join(',');
        if (config.ratings)
            query.ratings = config.ratings.join(',');
    }
    return fetchJSON(explorerEndpoint + '/' + config.db, {
        headers: {
            'Accept': 'application/json',
            'X-Requested-With': '__delete',
            [SESSION_ID_KEY]: '__delete',
        },
        credentials: 'omit',
        query
    });
}
function tablebaseXhr(variant, fen, timeout) {
    return fetchJSON(tablebaseEndpoint + '/' + variant, {
        headers: {
            'Accept': 'application/json, text/*',
            'X-Requested-With': '__delete',
            [SESSION_ID_KEY]: '__delete',
        },
        credentials: 'omit',
        query: {
            fen: fen
        },
        timeout
    });
}

function ExplorerCtrl(root, allowed) {
    const loading = prop(true);
    const failing = prop(false);
    const current = prop({
        moves: []
    });
    let cache = {};
    function setResult(fen, data) {
        cache[fen] = data;
        current(data);
    }
    function onConfigClose(changed) {
        if (changed) {
            cache = {};
            setStep();
        }
    }
    const withGames = !!(isSynthetic(root.data) || replayable(root.data) || root.data.game.offline);
    const effectiveVariant = root.data.game.variant.key === 'fromPosition' ? 'standard' : root.data.game.variant.key;
    const config = explorerConfig.controller(root.data.game.variant, onConfigClose);
    const debouncedScroll = debounce(() => {
        const table = document.getElementById('explorerTable');
        if (table)
            table.scrollTop = 0;
    }, 200);
    function handleFetchError() {
        loading(false);
        failing(true);
        redraw();
    }
    const fetchOpening = debounce((fen) => {
        const conf = {
            db: config.data.db.selected(),
            speeds: config.data.speed.selected(),
            ratings: config.data.rating.selected()
        };
        return openingXhr(effectiveVariant, fen, conf, withGames)
            .then((res) => {
            res.isOpening = true;
            res.fen = fen;
            setResult(fen, res);
            loading(false);
            failing(false);
            redraw();
        })
            .catch(handleFetchError);
    }, 1000, { leading: true, trailing: true });
    const fetchTablebase = debounce((fen) => {
        return tablebaseXhr(effectiveVariant, fen)
            .then((res) => {
            res.tablebase = true;
            res.fen = fen;
            setResult(fen, res);
            loading(false);
            failing(false);
            redraw();
        })
            .catch(handleFetchError);
    }, 500, { leading: true, trailing: true });
    function fetch(fen) {
        if (withGames && tablebaseRelevant(effectiveVariant, fen))
            return fetchTablebase(fen);
        else
            return fetchOpening(fen);
    }
    const empty = {
        isOpening: true,
        moves: []
    };
    function setStep() {
        if (root.currentTab(root.availableTabs()).id !== 'explorer')
            return;
        const node = root.node;
        if (node.ply > 50 && !tablebaseRelevant(effectiveVariant, node.fen)) {
            setResult(node.fen, empty);
        }
        const fromCache = cache[node.fen];
        if (!fromCache) {
            loading(true);
            fetch(node.fen);
        }
        else {
            current(fromCache);
            loading(false);
            failing(false);
        }
        redraw();
        debouncedScroll();
    }
    return {
        allowed,
        setStep,
        loading,
        failing,
        config,
        withGames,
        current,
        fetchMasterOpening: (function () {
            const masterCache = {};
            return function (fen) {
                if (masterCache[fen])
                    return Promise.resolve(masterCache[fen]);
                return openingXhr('standard', fen, { db: 'masters' }, false)
                    .then((res) => {
                    masterCache[fen] = res;
                    return res;
                });
            };
        })(),
        fetchTablebaseHit(fen) {
            return tablebaseXhr(effectiveVariant, fen, 2000).then((res) => {
                if (res.category === 'unknown')
                    throw 'unknown tablebase position';
                const after = colorOf$1(fen);
                return {
                    fen: fen,
                    best: res.moves[0]?.uci,
                    winner: winnerBeforeMove(oppositeColor(after), res.category)
                };
            });
        }
    };
}
function tablebaseRelevant(variant, fen) {
    const parts = fen.split(/\s/);
    const pieceCount = parts[0].split(/[nbrqkp]/i).length - 1;
    if (variant === 'standard' || variant === 'chess960')
        return pieceCount <= 8;
    else if (variant === 'atomic' || variant === 'antichess')
        return pieceCount <= 7;
    else
        return false;
}

function makeConfig(config, orientation, onMove, onNewPiece) {
    const pieceMoveConf = settings.game.pieceMove();
    return {
        fen: config.fen,
        check: config.check,
        lastMove: config.lastMove,
        turnColor: config.turnColor,
        orientation,
        coordinates: settings.game.coords(),
        movable: {
            free: false,
            color: config.movableColor,
            dests: config.dests,
            showDests: settings.game.pieceDestinations(),
            rookCastle: settings.game.rookCastle() === 1,
        },
        draggable: {
            enabled: pieceMoveConf === 'drag' || pieceMoveConf === 'both',
            magnified: settings.game.magnified()
        },
        selectable: {
            enabled: pieceMoveConf === 'tap' || pieceMoveConf === 'both'
        },
        events: {
            move: onMove,
            dropNewPiece: onNewPiece
        },
        premovable: {
            enabled: false
        },
        highlight: {
            lastMove: settings.game.highlights(),
            check: settings.game.highlights()
        },
        animation: {
            enabled: !!settings.game.animations(),
            duration: animationDuration(settings.game.animations()),
        }
    };
}
var ground = {
    make(config, orientation, onMove, onNewPiece) {
        return new Chessground(makeConfig(config, orientation, onMove, onNewPiece));
    },
};

function socketHandler$1 (ctrl) {
    return {
        analysisProgress(data) {
            ctrl.mergeAnalysisData(data);
        },
        evalHit(data) {
            ctrl.evalCache.onCloudEval(data);
        },
        fen(e) {
            if (ctrl.forecast &&
                e.id === ctrl.data.game.id &&
                last(ctrl.mainline).fen.indexOf(e.fen) !== 0) {
                ctrl.forecast.reloadToLastPly();
            }
        },
    };
}

function toCeval(e) {
    const res = {
        fen: e.fen,
        nodes: e.knodes * 1000,
        depth: e.depth,
        pvs: e.pvs.map(pv => {
            const to = {
                moves: pv.moves.split(' ')
            };
            if (pv.cp !== undefined)
                to.cp = pv.cp;
            else
                to.mate = pv.mate;
            return to;
        }),
        cloud: true
    };
    if (res.pvs[0].cp !== undefined)
        res.cp = res.pvs[0].cp;
    else
        res.mate = res.pvs[0].mate;
    res.cloud = true;
    return res;
}
function make({ variant, canGet, getNode, receive, socketIface }) {
    const fenFetched = new Set();
    return {
        fetch(path, multiPv) {
            const node = getNode();
            if ((node.ceval && node.ceval.cloud) || !canGet(node))
                return;
            if (fenFetched.has(node.fen))
                return;
            fenFetched.add(node.fen);
            const obj = {
                fen: node.fen,
                path
            };
            if (variant !== 'standard')
                obj.variant = variant;
            if (multiPv > 1)
                obj.mpv = multiPv;
            socketIface.send('evalGet', obj);
        },
        onCloudEval(cloudEval) {
            receive(cloudEval.path, toCeval(cloudEval));
        }
    };
}

const gameInfos = {
    id: 'infos',
    title: i18n('gameInformation'),
    className: 'fa fa-info-circle',
};
const moves = {
    id: 'moves',
    title: i18n('movesPlayed'),
    className: 'fa fa-list-alt'
};
const ceval = {
    id: 'ceval',
    title: 'Stockfish',
    className: 'fa fa-cogs'
};
const explorer = {
    id: 'explorer',
    title: i18n('openingExplorer'),
    className: 'fa fa-book'
};
const charts = {
    id: 'analysis',
    title: i18n('gameAnalysis'),
    className: 'fa fa-area-chart'
};
const pgnTags = {
    id: 'pgnTags',
    title: i18n('pgnTags'),
    className: 'fa fa-tags'
};
const comments = {
    id: 'comments',
    title: i18n('comments'),
    className: 'fa fa-comment-o'
};

function socketHandler (ctrl) {
    return {
        ...socketHandler$1(ctrl.rootCtrl),
        liking(d) {
            ctrl.data.likes = d.l.likes;
            if (d.w && d.w.s === currentSri())
                ctrl.data.liked = d.l.me;
            redraw();
        },
        message(msg) {
            if (ctrl.chat)
                ctrl.chat.append(msg);
        },
    };
}

class StudyCtrl {
    constructor(data, rootCtrl) {
        this.data = data;
        this.rootCtrl = rootCtrl;
        this.toggleLike = () => {
            this.rootCtrl.socket.send('like', {
                liked: !this.data.liked
            });
        };
        this.toggleShowComments = () => {
            this.vm.showComments = !this.vm.showComments;
        };
        this.actionMenu = actionMenu.controller(this.rootCtrl);
        this.sideMenu = new SideMenuCtrl('right', 'studyMenu', 'studyMenu-backdrop');
        this.analyseCtrl = rootCtrl;
        if (data.features.chat && data.chat) {
            this.chat = new Chat(rootCtrl.socket, data.id, data.chat.lines, undefined, data.chat.writeable, session.isShadowban(), 'Study');
        }
        this.vm = {
            showComments: false,
        };
        if (settings.study.tour() === null) {
            startTour(this);
            settings.study.tour(window.deviceInfo.appVersion);
        }
    }
    canContribute() {
        const myId = session.getUserId();
        const meMember = myId && this.data.members[myId];
        return meMember ? meMember.role === 'w' : false;
    }
    createSocket() {
        return socket.createStudy(this.data.id, socketHandler(this));
    }
}

class AnalyseCtrl {
    constructor(data, studyData, source, orientation, shouldGoBack, ply, tabId) {
        this.data = data;
        this.source = source;
        this.orientation = orientation;
        this.shouldGoBack = shouldGoBack;
        this.promoting = null;
        // state flags
        this.onMainline = true;
        this.contextMenu = null;
        // various view state flags
        this.replaying = false;
        this.analysisProgress = false;
        this.retroGlowing = false;
        this.showThreat = false;
        this._currentTabIndex = 0;
        this.canDrop = () => {
            return true;
        };
        this.player = () => {
            return this.data.game.player;
        };
        this.availableTabs = () => {
            let val = [moves];
            if (this.study && this.study.data.chapter.tags.length > 0)
                val = [pgnTags, ...val];
            if (!this.synthetic)
                val = [gameInfos, ...val];
            // TODO enable only when study.canContribute() is false with write support
            if (this.study)
                val = [...val, comments];
            if (!this.retro && !this.practice && this.ceval.enabled())
                val = [...val, ceval];
            if (this.study || (isOnlineAnalyseData(this.data) && analysable(this.data))) {
                val = [...val, charts];
            }
            if (hasNetwork() && this.explorer.allowed)
                val = [...val, explorer];
            return val;
        };
        this.currentTabIndex = (avail) => {
            if (this._currentTabIndex > avail.length - 1)
                return avail.length - 1;
            else
                return this._currentTabIndex;
        };
        this.currentTab = (avail) => {
            return avail[this.currentTabIndex(avail)];
        };
        this.onTabChange = (index) => {
            this._currentTabIndex = index;
            const cur = this.currentTab(this.availableTabs());
            this.updateHref();
            if (cur.id === 'moves')
                this.debouncedScroll();
            else if (cur.id === 'explorer')
                this.explorer.setStep();
            redraw();
        };
        // call this when removing a tab, to avoid a lazy tab loading indefinitely
        this.resetTabs = () => this.onTabChange(this.currentTabIndex(this.availableTabs()));
        this.setPath = (path) => {
            this.path = path;
            this.nodeList = this.tree.getNodeList(path);
            this.node = last(this.nodeList);
            this.mainline = mainlineNodeList(this.tree.root);
            this.onMainline = this.tree.pathIsMainline(path);
        };
        this.initCeval = () => {
            if (this.ceval.enabled()) {
                if (this.ceval.isInit()) {
                    this.debouncedStartCeval();
                }
                else {
                    this.ceval.init().then(this.debouncedStartCeval);
                }
            }
        };
        this.startCeval = () => {
            if (this.ceval.enabled() && this.canUseCeval()) {
                const forceMaxLv = !!this.retro || !!this.practice;
                this.ceval.start(this.showThreat, this.path, this.nodeList, forceMaxLv, false);
                this.evalCache.fetch(this.path, forceMaxLv ? 1 : this.ceval.getMultiPv());
            }
        };
        this.stopCevalImmediately = () => {
            this.ceval.stop();
            this.debouncedStartCeval.cancel();
        };
        this.toggleRetro = (fromBB) => {
            if (this.retro) {
                if (fromBB !== 'backbutton')
                    router.backbutton.stack.pop();
                this.retro = null;
                // start ceval after retro close only if enabled by stored settings
                if (settings.analyse.enableCeval()) {
                    this.startCeval();
                }
                // else disable it
                else {
                    this.ceval.disable();
                }
            }
            else {
                this.stopCevalImmediately();
                if (this.practice)
                    this.practice = null;
                this.retro = RetroCtrl(this);
                router.backbutton.stack.push(this.toggleRetro);
                this.retro.jumpToCurrent();
            }
        };
        this.togglePractice = () => {
            if (this.practice || !this.ceval.allowed)
                this.practice = null;
            else {
                if (this.retro)
                    this.retro = null;
                this.practice = make$1(this, () => {
                    return 18;
                });
            }
        };
        this.toggleShowThreat = () => {
            if (!this.ceval.allowed)
                return;
            if (!this.ceval.enabled())
                this.ceval.toggle();
            this.showThreat = !this.showThreat;
            this.startCeval();
        };
        this.debouncedScroll = debounce(() => autoScroll(document.getElementById('replay')), 200);
        this.jump = (path, direction) => {
            const pathChanged = path !== this.path;
            this.setPath(path);
            this.updateBoard();
            this.fetchOpening();
            if (this.node && this.node.san && direction === 'forward') {
                if (this.node.san.indexOf('x') !== -1)
                    sound.throttledCapture();
                else
                    sound.throttledMove();
            }
            this.ceval.stop();
            this.debouncedExplorerSetStep();
            this.updateHref();
            if (pathChanged) {
                if (this.retro)
                    this.retro.onJump();
                if (this.practice)
                    this.practice.onJump();
                this.debouncedStartCeval();
            }
        };
        this.userJump = (path, direction) => {
            this.autoplay.stop();
            if (this.practice) {
                const prev = this.path;
                this.practice.preUserJump(prev, path);
                this.jump(path, direction);
                this.practice.postUserJump(prev, this.path);
            }
            else
                this.jump(path, direction);
        };
        this.jumpToMain = (ply) => {
            this.userJump(this.mainlinePathToPly(ply));
        };
        this.jumpToIndex = (index) => {
            this.jumpToMain(index + 1 + (this.data.game.startedAtTurn || 0));
        };
        this.canGoForward = () => {
            return this.node.children.length > 0;
        };
        this.next = () => {
            if (!this.canGoForward())
                return false;
            const child = this.node.children[0];
            if (child)
                this.userJump(this.path + child.id, 'forward');
            return true;
        };
        this.fastforward = () => {
            this.replaying = true;
            const more = this.next();
            if (!more) {
                this.replaying = false;
                this.debouncedScroll();
            }
            return more;
        };
        this.stopff = () => {
            this.replaying = false;
            this.next();
            this.debouncedScroll();
        };
        this.rewind = () => {
            this.replaying = true;
            const more = this.prev();
            if (!more) {
                this.replaying = false;
                this.debouncedScroll();
            }
            return more;
        };
        this.stoprewind = () => {
            this.replaying = false;
            this.prev();
            this.debouncedScroll();
        };
        this.toggleBookmark = () => {
            return toggleGameBookmark(this.data.game.id).then(() => {
                this.data.bookmarked = !this.data.bookmarked;
                redraw();
            })
                .catch(handleXhrError);
        };
        this.playUci = (uci) => {
            const move = decomposeUci(uci);
            if (uci[1] === '@') {
                this.chessground.apiNewPiece({
                    color: this.chessground.state.movable.color,
                    role: sanToRole[uci[0]]
                }, move[1]);
            }
            else if (!move[2]) {
                this.sendMove(move[0], move[1]);
            }
            else {
                this.sendMove(move[0], move[1], sanToRole[move[2].toUpperCase()]);
            }
            this.explorer.loading(true);
        };
        this.canUseCeval = () => {
            return !this.gameOver();
        };
        this.hasAnyComputerAnalysis = () => {
            return this.data.analysis || this.ceval.enabled();
        };
        this.hasFullComputerAnalysis = () => {
            return Object.keys(this.mainline[0].eval || {}).length > 0;
        };
        this.isOfflineOrNotPlayable = () => {
            return this.source === 'offline' ||
                !!(this.study && this.study.data) ||
                !playable(this.data);
        };
        this.unload = () => {
            this.autoplay.stop();
            if (this.ceval)
                this.ceval.destroy();
        };
        // ---
        this._deleteNode = (path) => {
            this.tree.deleteNodeAt(path);
            this.contextMenu = null;
            if (contains(this.path, path))
                this.userJump(init(path));
            else
                this.jump(this.path);
        };
        this.updateHref = debounce(() => {
            router.setQueryParams({
                tabId: this.currentTab(this.availableTabs()).id,
                ply: String(this.node.ply),
                curFen: this.node.fen
            });
        }, 200);
        this.canEvalGet = (node) => node.ply < 15;
        this.sendMove = (orig, dest, prom) => {
            const move$1 = {
                orig,
                dest,
                variant: this.data.game.variant.key,
                fen: this.node.fen,
                path: this.path
            };
            if (prom)
                move$1.promotion = prom;
            if (this.practice)
                this.practice.onUserMove();
            move(move$1)
                .then(this.addNode)
                .catch(err => console.error('send move error', move$1, err));
        };
        this.userMove = (orig, dest, captured) => {
            if (captured)
                sound.capture();
            else
                sound.move();
            if (!promotion.start(this, orig, dest, this.sendMove))
                this.sendMove(orig, dest);
        };
        this.userNewPiece = (piece, pos) => {
            if (crazyValid.drop(piece.role, pos, this.node.drops)) {
                sound.move();
                const drop$1 = {
                    role: piece.role,
                    pos,
                    variant: this.data.game.variant.key,
                    fen: this.node.fen,
                    path: this.path
                };
                drop(drop$1)
                    .then(this.addNode)
                    .catch(err => {
                    // catching false drops here
                    console.error('wrong drop', err);
                    this.jump(this.path);
                });
            }
            else
                this.jump(this.path);
        };
        this.addNode = ({ situation, path }) => {
            const curNode = this.node;
            const node = {
                id: situation.id,
                ply: situation.ply,
                fen: situation.fen,
                children: [],
                dests: situation.dests,
                drops: situation.drops,
                check: situation.check,
                end: situation.end,
                player: situation.player,
                checkCount: situation.checkCount,
                uci: situation.uci,
                san: situation.san,
                crazyhouse: situation.crazyhouse,
                pgnMoves: curNode && curNode.pgnMoves ? curNode.pgnMoves.concat(situation.pgnMoves) : situation.pgnMoves
            };
            if (path === undefined) {
                console.error('Cannot addNode, missing path', node);
                return;
            }
            const newPath = this.tree.addNode(node, path);
            if (!newPath) {
                console.error('Cannot addNode', node, path);
                return;
            }
            this.jump(newPath);
            this.debouncedScroll();
            redraw();
        };
        this.onCevalMsg = (path, ev, isThreat) => {
            if (ev) {
                this.tree.updateAt(path, (node) => {
                    if (node.fen !== ev.fen && !isThreat)
                        return;
                    if (isThreat) {
                        const threat = ev;
                        if (!node.threat || isEvalBetter(threat, node.threat) || node.threat?.maxDepth < threat.maxDepth)
                            node.threat = threat;
                    }
                    else if (!node.ceval || isEvalBetter(ev, node.ceval))
                        node.ceval = ev;
                    else if (!ev.cloud) {
                        if (node.ceval.cloud && this.ceval.isDeeper)
                            node.ceval = ev;
                        else if (ev.maxDepth > node.ceval.maxDepth)
                            node.ceval.maxDepth = ev.maxDepth;
                    }
                    if (node.ceval && node.ceval.pvs.length > 0) {
                        node.ceval.best = node.ceval.pvs[0].moves[0];
                    }
                    if (path === this.path) {
                        if (this.retro)
                            this.retro.onCeval();
                        if (this.practice)
                            this.practice.onCeval();
                        if (ev.cloud && ev.depth >= this.ceval.effectiveMaxDepth()) {
                            this.ceval.stop();
                        }
                        redraw();
                    }
                });
            }
            // no ceval means stockfish has finished, just redraw
            else {
                if (this.currentTab(this.availableTabs()).id === 'ceval')
                    redraw();
            }
        };
        this.debouncedStartCeval = debounce(this.startCeval, 500, { trailing: true });
        this.getNodeSituation = debounce(() => {
            if (this.node && !this.node.dests) {
                situation({
                    variant: this.data.game.variant.key,
                    fen: this.node.fen,
                    path: this.path
                })
                    .then(({ situation, path }) => {
                    this.tree.updateAt(path, (node) => {
                        node.dests = situation.dests;
                        node.end = situation.end;
                        node.player = situation.player;
                    });
                    if (path === this.path) {
                        this.updateBoard();
                        redraw();
                        if (this.gameOver())
                            this.stopCevalImmediately();
                    }
                })
                    .catch(err => console.error('get dests error', err));
            }
        }, 50);
        this.fetchOpening = debounce(() => {
            if (hasNetwork() && this.node && this.node.opening === undefined &&
                this.node.ply <= 20 && this.node.ply > 0 &&
                openingSensibleVariants.has(this.data.game.variant.key)) {
                const msg = {
                    fen: this.node.fen,
                    path: this.path
                };
                const variant = this.data.game.variant.key;
                if (variant !== 'standard')
                    msg.variant = variant;
                this.tree.updateAt(this.path, (node) => {
                    // flag opening as null in any case to not request twice
                    node.opening = null;
                    this.socket.ask('opening', 'opening', msg)
                        .then(d => {
                        if (d.opening && d.path) {
                            node.opening = d.opening;
                            if (d.path === this.path)
                                redraw();
                        }
                    })
                        .catch(noop);
                });
            }
        }, 50);
        this.synthetic = isSynthetic(data);
        this.ongoing = !this.synthetic && playable(data);
        this.initialPath = root;
        this.study = studyData !== undefined ? new StudyCtrl(studyData, this) : undefined;
        this.forecast = data.forecast ? new ForecastCtrl(data) : undefined;
        this._currentTabIndex = (!this.study || this.study.data.chapter.tags.length === 0) && this.synthetic ? 0 : 1;
        if (settings.analyse.supportedVariants.indexOf(this.data.game.variant.key) === -1) {
            Toast.show({ text: `Analysis board does not support ${this.data.game.variant.name} variant.`, position: 'center', duration: 'short' });
            router.set('/');
        }
        this.tree = build(reconstruct(this.data.treeParts));
        this.settings = analyseSettings.controller(this);
        this.menu = analyseMenu.controller(this);
        this.continuePopup = continuePopup.controller();
        this.autoplay = new Autoplay(this);
        this.notes = session.isConnected() && this.data.game.speed === 'correspondence' ? new NotesCtrl(this.data) : null;
        this.retro = null;
        this.practice = null;
        const cevalAllowed = (() => {
            const study = this.study && this.study.data;
            if (!analysableVariants.includes(this.data.game.variant.key)) {
                return false;
            }
            if (study && !(study.chapter.features.computer || study.chapter.practice)) {
                return false;
            }
            const isPosValid = parseFen(this.data.game.fen).unwrap(setup => setupPosition(chessopRulesFromVariant(this.data.game.variant.key), setup).unwrap(() => true, () => false), () => false);
            if (!isPosValid) {
                return false;
            }
            return this.isOfflineOrNotPlayable();
        })();
        this.ceval = new CevalCtrl({
            allowed: cevalAllowed,
            variant: this.data.game.variant.key,
            multiPv: settings.analyse.cevalMultiPvs(),
            cores: settings.analyse.cevalCores(),
            hashSize: settings.analyse.cevalHashSize(),
            infinite: settings.analyse.cevalInfinite(),
        }, this.onCevalMsg);
        const explorerAllowed = !this.study || this.study.data.chapter.features.explorer;
        this.explorer = ExplorerCtrl(this, explorerAllowed);
        this.debouncedExplorerSetStep = debounce(this.explorer.setStep, animationDuration(settings.game.animations()) + 50);
        const initPly = ply !== undefined ? ply : this.tree.lastPly();
        this.gamePath = (this.synthetic || this.ongoing) ? undefined :
            fromNodeList(mainlineNodeList(this.tree.root));
        const mainline = mainlineNodeList(this.tree.root);
        this.initialPath = takePathWhile(mainline, n => n.ply <= initPly);
        this.setPath(this.initialPath);
        if (this.data.game.createdAt) {
            this.formattedDate = formatDateTime(new Date(this.data.game.createdAt));
        }
        if (this.study) {
            this.socket = this.study.createSocket();
        }
        else if (!this.data.analysis &&
            session.isConnected() &&
            isOnlineAnalyseData(this.data) &&
            analysable(this.data) &&
            this.data.url !== undefined &&
            this.data.player.version !== undefined) {
            this.socket = socket.createGame(this.data.url.socket, this.data.player.version, socketHandler$1(this), this.data.url.round);
        }
        else {
            this.socket = socket.createAnalysis(socketHandler$1(this));
        }
        // forecast mode: reload when opponent moves
        if (!this.synthetic) {
            setTimeout(() => {
                this.socket.send('startWatching', this.data.game.id);
            }, 1000);
        }
        this.evalCache = make({
            variant: this.data.game.variant.key,
            canGet: this.canEvalGet,
            getNode: () => this.node,
            receive: this.onCevalMsg,
            socketIface: this.socket,
        });
        this.updateBoard();
        if (tabId) {
            const curTabIndex = this.currentTabIndex(this.availableTabs());
            const newTabIndex = this.availableTabs().findIndex(tab => tab.id === tabId);
            if (newTabIndex >= 0 && curTabIndex !== newTabIndex) {
                this.onTabChange(newTabIndex);
            }
        }
        if (this.currentTab(this.availableTabs()).id === 'explorer') {
            this.debouncedExplorerSetStep();
        }
        setTimeout(this.debouncedScroll, 250);
        setTimeout(this.initCeval, 1000);
    }
    playerName(color) {
        const p = getPlayer(this.data, color);
        return this.study ? findTag(this.study.data, color) || 'Anonymous' : playerName(p);
    }
    topColor() {
        return oppositeColor(this.bottomColor());
    }
    bottomColor() {
        return this.settings.s.flip ? oppositeColor(this.data.orientation) : this.data.orientation;
    }
    turnColor() {
        return plyColor(this.node.ply);
    }
    promote(path, toMainline) {
        this.tree.promoteAt(path, toMainline);
        this.contextMenu = null;
        this.jump(path);
    }
    deleteNode(path) {
        const node = this.tree.nodeAtPath(path);
        if (!node)
            return;
        const count = countChildrenAndComments(node);
        if (count.nodes >= 10 || count.comments > 0) {
            Dialog.confirm({
                title: 'Confirm',
                message: `Delete ${count.nodes} move(s)` + (count.comments ? ` and ${count.comments} comment(s)` : '') + '?',
            })
                .then(() => this._deleteNode(path));
        }
        else {
            this._deleteNode(path);
        }
    }
    restartPractice() {
        this.practice = null;
        this.togglePractice();
    }
    mergeAnalysisData(data) {
        if (!this.analysisProgress) {
            this.analysisProgress = true;
            redraw();
        }
        this.tree.merge(data.tree);
        this.data.analysis = data.analysis;
        const anaMainline = mainlineNodeList(data.tree);
        const analysisComplete = anaMainline.every(n => n.eval !== undefined || !!(n.san && n.san.includes('#')));
        if (analysisComplete) {
            this.data.treeParts = anaMainline;
            this.analysisProgress = false;
            this.retroGlowing = true;
            setTimeout(() => {
                this.retroGlowing = false;
                redraw();
            }, 1000 * 8);
            sound.dong();
            vibrate.quick();
            redraw();
        }
        if (this.retro)
            this.retro.onMergeAnalysisData();
        redraw();
    }
    gameOver(node) {
        const n = node || this.node;
        if (!n)
            return false;
        if (n.end === undefined) {
            if (n.check) {
                const san = n.san;
                const checkmate = !!(san && san[san.length - 1] === '#');
                if (checkmate)
                    return 'checkmate';
                else
                    return false;
            }
            return false;
        }
        else {
            if (!n.end)
                return false;
            else if (n.check)
                return 'checkmate';
            else
                return 'draw';
        }
    }
    nextNodeBest() {
        return withMainlineChild(this.node, (n) => n.eval ? n.eval.best : undefined);
    }
    mainlinePathToPly(ply) {
        return takePathWhile(this.mainline, n => n.ply <= ply);
    }
    prev() {
        this.userJump(init(this.path), 'backward');
        return true;
    }
    updateBoard() {
        const node = this.node;
        if (this.data.game.variant.key === 'threeCheck' && !node.checkCount) {
            node.checkCount = readCheckCount(node.fen);
        }
        const color = plyColor(node.ply);
        const dests = readDests(node.dests);
        const config = {
            fen: node.fen,
            turnColor: color,
            orientation: this.settings.s.flip ? oppositeColor(this.orientation) : this.orientation,
            movableColor: this.gameOver() ? null : color,
            dests: dests || null,
            check: !!node.check,
            lastMove: node.uci ? uciToMoveOrDrop(node.uci) : null
        };
        this.cgConfig = config;
        this.data.game.player = color;
        if (!this.chessground) {
            this.chessground = ground.make(config, this.orientation, this.userMove, this.userNewPiece);
        }
        else {
            this.chessground.set(config);
        }
        if (!dests)
            this.getNodeSituation();
    }
}

export { AnalyseCtrl as A, renderContent as a, gameAnalysis as g, loadingScreen as l, overlay as o, renderVariantSelector as r };
//# sourceMappingURL=AnalyseCtrl-_vlqF8MU.js.map
