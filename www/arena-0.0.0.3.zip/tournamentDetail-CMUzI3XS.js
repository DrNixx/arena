import { m as h, bR as slidesInUp, x as ontap, bO as slidesOutDown, bC as closeIcon, o as i18n, y as plural, q as router, cC as slidesInLeft, cD as slidesOutRight, p as ontapY, J as prop, r as redraw, K as handleXhrError, cE as getTR, M as popup, O as formWidgets, g as settings, b as session, bJ as formatTournamentTimeControl, bK as formatTournamentDuration, $ as Toast, aL as findParentBySelector, h as throttle, s as socket, c as fromNow, A as App, aA as viewSlideIn, G as dropShadowHeader, I as backButton, cF as connectingDropShadowHeader, cG as noNull } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { p as playerInfo$1, j as join$1, w as withdraw, l as loadPage, r as reload, t as tournament } from './tournamentXhr-kOGDWEN6.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { M as MiniBoard } from './miniBoard-_GdiTw1G.js';
import { C as CountdownTimer } from './CountdownTimer-sy6et_C9.js';
import { c as chatView, C as Chat } from './chat-Dbn1ft42.js';

var faq = {
    controller(root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen() {
                return isOpen;
            },
            root
        };
    },
    view: function (ctrl) {
        if (!ctrl.isOpen())
            return null;
        const tournament = ctrl.root.tournament;
        if (!tournament)
            return null;
        return (h("div", { className: "modal", id: "tournamentFaqModal", oncreate: slidesInUp },
            h("header", null,
                h("button", { className: "modal_close", oncreate: ontap(slidesOutDown(ctrl.close, 'tournamentFaqModal')) }, closeIcon),
                h("h2", null, i18n('tournamentFAQ'))),
            h("div", { className: "modal_content" },
                h("div", { className: "tournamentFaq" },
                    h("p", null, i18n('willBeNotified')),
                    h("h2", null, i18n('isItRated')),
                    h("p", null, i18n('someRated')),
                    h("h2", null, i18n('howAreScoresCalculated')),
                    h("p", null, i18n('howAreScoresCalculatedAnswer')),
                    h("h2", null, i18n('berserk')),
                    h("p", null, i18n('berserkAnswer')),
                    h("h2", null, i18n('howIsTheWinnerDecided')),
                    h("p", null, i18n('howIsTheWinnerDecidedAnswer')),
                    h("h2", null, i18n('howDoesPairingWork')),
                    h("p", null, i18n('howDoesPairingWorkAnswer')),
                    h("h2", null, i18n('howDoesItEnd')),
                    h("p", null, i18n('howDoesItEndAnswer')),
                    h("h2", null, i18n('otherRules')),
                    h("p", null, i18n('thereIsACountdown')),
                    h("p", null, plural('drawingWithinNbMoves', 10))))));
    }
};

var playerInfo = {
    controller(root) {
        let isOpen = false;
        const playerData = prop(null);
        function open(playerId) {
            playerInfo$1(root.tournament.id, playerId)
                .then(data => {
                playerData(data);
                router.backbutton.stack.push(slidesOutRight(close, 'tournamentPlayerInfoModal'));
                isOpen = true;
                redraw();
            })
                .catch(handleXhrError);
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen() {
                return isOpen;
            },
            root,
            playerData
        };
    },
    view: function (ctrl) {
        if (!ctrl.isOpen())
            return null;
        const tournament = ctrl.root.tournament;
        if (!tournament)
            return null;
        const playerData = ctrl.playerData();
        if (!playerData)
            return null;
        const player = playerData.player;
        const pairings = playerData.pairings;
        const avgOpRating = pairings.length ? (pairings.reduce((prev, x) => prev + x.op.rating, 0) / pairings.length).toFixed(0) : '0';
        let streak = 0;
        const scoreClasses = [...pairings].reverse().map(v => {
            const s = v.score;
            if (s !== null) {
                const win = s === 2 ? streak < 2 : s > 2;
                const klass = streak > 1 && s > 1 ? 'double' : win ? 'streak' : 'score';
                if (win)
                    streak++;
                else
                    streak = 0;
                return klass;
            }
            return s;
        }).reverse();
        function renderPlayerGame(game, index) {
            let outcome;
            let outcomeClass = 'oppOutcome';
            if (game.score === undefined || game.score === null) {
                outcome = '*';
            }
            else {
                outcome = game.score;
            }
            if (scoreClasses[index] !== null) {
                outcomeClass += ' ' + scoreClasses[index];
            }
            return (h("tr", { className: "list_item", "data-id": game.id, "data-color": game.color, key: game.id },
                h("td", { className: "oppRank" },
                    " ",
                    pairings.length - index,
                    " "),
                h("td", { className: "oppName" },
                    " ",
                    game.op.name,
                    " "),
                h("td", { className: "oppRating" },
                    " ",
                    game.op.rating,
                    " "),
                h("td", { className: "oppColor" },
                    " ",
                    h("span", { className: 'color-icon ' + game.color }, " "),
                    " "),
                h("td", { className: outcomeClass },
                    " ",
                    outcome,
                    " ")));
        }
        return (h("div", { className: "modal tournamentInfoModal", id: "tournamentPlayerInfoModal", oncreate: slidesInLeft },
            h("header", null,
                h("button", { className: "modal_close", oncreate: ontap(slidesOutRight(ctrl.close, 'tournamentPlayerInfoModal')) }, closeIcon),
                h("h2", { className: "tournamentModalHeader" },
                    player.rank + '. ',
                    renderPlayerTitle(player),
                    player.name + ' (' + player.rating + ') ')),
            h("div", { className: "modal_content" },
                h("div", { className: "tournamentPlayerInfo" },
                    h("table", { className: "tournamentModalStats" },
                        h("tr", null,
                            h("td", { className: "statName" }, i18n('gamesPlayed')),
                            h("td", { className: "statData" }, player.nb.game)),
                        h("tr", null,
                            h("td", { className: "statName" }, i18n('winRate')),
                            h("td", { className: "statData" }, player.nb.game ? ((player.nb.win / player.nb.game) * 100).toFixed(0) + '%' : '0%')),
                        h("tr", null,
                            h("td", { className: "statName" }, i18n('berserkRate')),
                            h("td", { className: "statData" }, player.nb.game ? ((player.nb.berserk / player.nb.game) * 100).toFixed(0) + '%' : '0%')),
                        h("tr", null,
                            h("td", { className: "statName" }, "Average Opponent"),
                            h("td", { className: "statData" }, avgOpRating)),
                        h("tr", { className: player.performance ? '' : 'invisible' },
                            h("td", { className: "statName" }, i18n('performance')),
                            h("td", { className: "statData" }, player.performance)))),
                h("div", { className: "tournamentPlayerGames" },
                    h("table", { className: "tournamentModalTable", oncreate: ontapY(e => {
                            const el = getTR(e);
                            if (el) {
                                const id = el.dataset.id;
                                const color = el.dataset.color;
                                router.set(`/game/${id}?color=${color}&goingBack=1`);
                            }
                        }, undefined, getTR) }, pairings.map(renderPlayerGame))))));
    }
};

var teamInfo = {
    controller(root) {
        let isOpen = false;
        const teamId = prop(null);
        function open(tId) {
            router.backbutton.stack.push(slidesOutRight(close, 'tournamentTeamInfoModal'));
            teamId(tId);
            isOpen = true;
            redraw();
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen() {
                return isOpen;
            },
            root,
            teamId
        };
    },
    view: function (ctrl) {
        if (!ctrl.isOpen())
            return null;
        const t = ctrl.root.tournament;
        const teamId = ctrl.teamId();
        if (!t || !t.teamBattle || !t.teamStanding || !teamId)
            return null;
        const teamName = t.teamBattle.teams[teamId];
        const teamStanding = t.teamStanding.find(a => a.id === teamId);
        if (!teamName || !teamStanding)
            return null;
        function renderPlayer(player, index) {
            return (h('tr.list_item.bglight', { key: player.user.id }, [
                h('td.teamPlayerRank', index + 1),
                h('td.teamPlayerName', player.user.name),
                h('td.teamPlayerScore', player.score)
            ]));
        }
        return (h('div.modal.tournamentInfoModal', { id: 'tournamentTeamInfoModal', oncreate: slidesInLeft }, [
            h('header', [
                h('buton.modal_close', { oncreate: ontap(slidesOutRight(ctrl.close, 'tournamentTeamInfoModal')) }, [
                    closeIcon
                ]),
                h('h2.tournamentModalHeader', [
                    h('span', [
                        teamStanding.rank + '. '
                    ]),
                    h('span.ttc-' + ctrl.root.teamColorMap[teamId], [
                        teamName + ' '
                    ]),
                    h('span', [
                        '(' + teamStanding.score + ')'
                    ])
                ])
            ]),
            h('div.modal_content', [
                h('div.tournamentTeamPlayers', [
                    h('table.tournamentModalTable', [
                        teamStanding.players.map(renderPlayer)
                    ])
                ])
            ])
        ]));
    }
};

let isOpen = false;
let tournamentCtrl;
var joinForm = {
    open,
    close,
    view() {
        return popup('tournament_addtl_info_popup', undefined, () => renderForm(), isOpen, close);
    }
};
function open(ctrl) {
    router.backbutton.stack.push(close);
    isOpen = true;
    tournamentCtrl = ctrl;
}
function close(fromBB) {
    if (fromBB !== 'backbutton' && isOpen)
        router.backbutton.stack.pop();
    isOpen = false;
}
function renderForm() {
    const t = tournamentCtrl.tournament;
    const tb = t.teamBattle;
    const teamList = tb ?
        tb.joinWith.map(x => [tb.teams[x], x]).filter(x => x[0])
        :
            [];
    return (h("form", { id: "tournamentPasswordForm", class: "tournamentForm", onsubmit: function (e) {
            e.preventDefault();
            return join(e.target);
        } },
        h("fieldset", null,
            h("div", { className: 'select_input no_arrow_after' + (t.private ? '' : ' notVisible') },
                h("div", { className: "text_input_container" },
                    h("label", null, "Password: "),
                    h("input", { type: "text", id: "tournamentPassword", className: "passwordField" }))),
            h("div", { className: 'select_input no_arrow_after' + (t.teamBattle ? '' : ' notVisible') }, formWidgets.renderSelect('Team', 'team', teamList, settings.tournament.join.lastTeam, false))),
        h("div", { className: "popupActionWrapper" },
            h("button", { className: "popupAction", type: "submit" },
                h("span", { className: "fa fa-check" }),
                i18n('join')))));
}
function join(form) {
    const elements = form[0].elements;
    const password = elements[0].value;
    const team = elements[1].value;
    tournamentCtrl.join(password, team);
    close();
}

function isIn(data) {
    return !!(data.me && !data.me.withdraw);
}
function previouslyJoined(data) {
    return data.me != null;
}

function renderOverlay(ctrl) {
    return [
        faq.view(ctrl.faqCtrl),
        playerInfo.view(ctrl.playerInfoCtrl),
        teamInfo.view(ctrl.teamInfoCtrl),
        ctrl.chat ? chatView(ctrl.chat) : null,
    ];
}
function tournamentBody(ctrl) {
    const data = ctrl.tournament;
    if (!data)
        return null;
    return h('div.tournamentContainer.native_scroller.page', {
        className: (data.podium ? 'finished ' : '') + (data.teamBattle ? 'teamBattle' : ''),
    }, [
        tournamentHeader(data, ctrl),
        data.podium && !data.teamBattle ? tournamentPodium(data.podium) : null,
        data.teamBattle ? tournamentTeamLeaderboard(ctrl) : null,
        tournamentLeaderboard(ctrl),
        data.featured ? tournamentFeaturedGame(ctrl) : null
    ]);
}
function renderFooter(ctrl) {
    const t = ctrl.tournament;
    if (!t)
        return null;
    const tUrl = 'https://lichess.org/tournament/' + t.id;
    return (h("div", { className: "actions_bar" },
        h("button", { key: "faqButton", className: "action_bar_button fa fa-question-circle", oncreate: ontap(ctrl.faqCtrl.open, () => Toast.show({ text: i18n('tournamentFAQ'), duration: 'short', position: 'bottom' })) }),
        h("button", { key: "shareButton", className: "action_bar_button fa fa-share-alt", oncreate: ontap(() => Share.share({ url: tUrl }), () => Toast.show({ text: i18n('shareGameUrl'), duration: 'short', position: 'bottom' })) }),
        ctrl.chat ?
            h("button", { key: "chatButton", className: "action_bar_button fa fa-comments withChip", oncreate: ontap(ctrl.chat.open, () => Toast.show({ text: i18n('chatRoom'), duration: 'short', position: 'bottom' })) }, ctrl.chat.nbUnread > 0 ?
                h("span", { className: "chip" }, ctrl.chat.nbUnread <= 99 ? ctrl.chat.nbUnread : 99) : null) : h.fragment({ key: 'noChat' }, []),
        ctrl.hasJoined ? withdrawButton(ctrl, t) : joinButton(ctrl, t)));
}
function timeInfo(seconds, preceedingText) {
    if (seconds === undefined)
        return null;
    return [
        preceedingText ? (preceedingText + ' ') : null,
        h(CountdownTimer, { seconds })
    ];
}
function tournamentHeader(data, ctrl) {
    return (h("div", { className: "tournamentHeader" },
        tournamentTimeInfo(data),
        data.spotlight ? tournamentSpotlightInfo(data.spotlight) : null,
        tournamentCreatorInfo(data, ctrl.startsAt),
        data.position ? tournamentPositionInfo(data.position) : null,
        data.verdicts.list.length > 0 ? tournamentConditions(data.verdicts) : null,
        teamBattleNoTeam(data)));
}
function tournamentTimeInfo(data) {
    const variant = data.perf.name;
    const control = formatTournamentTimeControl(data.clock);
    return (h("div", { className: "tournamentTimeInfo" },
        h("strong", { className: "tournamentInfo withIcon", "data-icon": data.perf.icon }, variant + ' • ' + control + ' • ' + formatTournamentDuration(data.minutes))));
}
function tournamentCreatorInfo(data, startsAt) {
    return (h("div", { className: "tournamentCreatorInfo" },
        data.createdBy === 'lichess' ? i18n('lichessTournaments') : i18n('by', data.createdBy),
        "\u2009\u2022\u2009",
        startsAt));
}
function tournamentPositionInfo(position) {
    return (h("div", { className: 'tournamentPositionInfo' + (position.url ? ' withLink' : ''), oncreate: ontapY(() => position && position.url &&
            window.open(position.url, '_blank')) }, position.eco + ' ' + position.name));
}
function tournamentConditions(verdicts) {
    const conditionsClass = [
        'tournamentConditions',
        session.isConnected() ? '' : 'anonymous',
        verdicts.accepted ? 'accepted' : 'rejected'
    ].join(' ');
    return (h("div", { className: conditionsClass },
        h("span", { className: "withIcon", "data-icon": "7" }),
        h("div", { className: "conditions_list" }, verdicts.list.map(o => {
            return (h("p", { className: 'condition ' + (o.verdict === 'ok' ? 'accepted' : 'rejected') }, o.condition));
        }))));
}
function teamBattleNoTeam(t) {
    if (t.isFinished || !t.teamBattle || t.teamBattle.joinWith.length > 0) {
        return null;
    }
    else {
        return (h("div", { className: "tournamentNoTeam" },
            h("span", { className: "withIcon", "data-icon": "7" }),
            h("p", null, "You must join one of these teams to participate!")));
    }
}
function tournamentSpotlightInfo(spotlight) {
    return (h("div", { className: "tournamentSpotlightInfo" }, spotlight.description));
}
function joinButton(ctrl, t) {
    if (!session.isConnected() ||
        t.isFinished ||
        settings.game.supportedVariants.indexOf(t.variant) < 0 ||
        !t.verdicts.accepted ||
        (t.teamBattle && t.teamBattle.joinWith.length === 0)) {
        return h.fragment({ key: 'noJoinButton' }, []);
    }
    const action = ((t.private || t.teamBattle) && !previouslyJoined(t)) ?
        () => joinForm.open(ctrl) :
        () => ctrl.join();
    return (h("button", { key: "joinButton", className: "action_bar_button fa fa-play", oncreate: ontap(action, () => Toast.show({ text: i18n('join'), duration: 'short', position: 'bottom' })) }));
}
function withdrawButton(ctrl, t) {
    if (t.isFinished || settings.game.supportedVariants.indexOf(t.variant) < 0) {
        return h.fragment({ key: 'noWithdrawButton' }, []);
    }
    return (h("button", { key: "withdrawButton", className: "action_bar_button fa fa-flag", oncreate: ontap(ctrl.withdraw, () => Toast.show({ text: i18n('withdraw'), duration: 'short', position: 'bottom' })) }));
}
function getLeaderboardItemEl(e) {
    const target = e.target;
    return target.classList.contains('list_item') ? target :
        findParentBySelector(target, '.list_item');
}
function handlePlayerInfoTap(ctrl, e) {
    const el = getLeaderboardItemEl(e);
    const playerId = el.dataset['player']?.toLowerCase();
    if (playerId)
        ctrl.playerInfoCtrl.open(playerId);
}
function tournamentLeaderboard(ctrl) {
    const data = ctrl.tournament;
    const players = ctrl.currentPageResults;
    const page = ctrl.page;
    const firstPlayer = (players.length > 0) ? players[0].rank : 0;
    const lastPlayer = (players.length > 0) ? players[players.length - 1].rank : 0;
    const backEnabled = page > 1;
    const forwardEnabled = page < data.nbPlayers / 10;
    const user = session.get();
    const userName = user ? user.username : '';
    const tb = data.teamBattle;
    return (h("div", { className: "tournamentLeaderboard" },
        h("ul", { className: 'tournamentStandings box' + (ctrl.isLoadingPage ? ' loading' : ''), oncreate: ontap(e => handlePlayerInfoTap(ctrl, e), undefined, undefined, getLeaderboardItemEl) }, players.map((p, i) => renderPlayerEntry(userName, p, i, p.team ? ctrl.teamColorMap[p.team] : 0, p.team && tb ? tb.teams[p.team] : ''))),
        h("div", { className: 'navigationButtons' + (players.length < 1 ? ' invisible' : '') },
            renderNavButton('W', !ctrl.isLoadingPage && backEnabled, ctrl.first),
            renderNavButton('Y', !ctrl.isLoadingPage && backEnabled, ctrl.prev),
            h("span", { class: "pageInfo" },
                " ",
                firstPlayer + '-' + lastPlayer + ' / ' + data.nbPlayers,
                " "),
            renderNavButton('X', !ctrl.isLoadingPage && forwardEnabled, ctrl.next),
            renderNavButton('V', !ctrl.isLoadingPage && forwardEnabled, ctrl.last),
            data.me ?
                h("button", { className: 'navigationButton tournament-me' + (ctrl.focusOnMe ? ' activated' : ''), "data-icon": "7", oncreate: ontap(ctrl.toggleFocusOnMe) },
                    h("span", null, "Me")) : null)));
}
function renderNavButton(icon, isEnabled, action) {
    return h('button.navigationButton', {
        'data-icon': icon,
        oncreate: ontap(action),
        disabled: !isEnabled
    });
}
function renderPlayerTitle(player) {
    if (player.title == null) {
        return null;
    }
    return h('span.userTitle', [player.title, h.trust('&nbsp;')]);
}
function renderPlayerEntry(userName, player, i, teamColor, teamName) {
    const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
    const isMe = player.name === userName;
    const ttc = teamColor ?? 0;
    return (h("li", { key: player.name, "data-player": player.name, className: `list_item tournament-list-item ${evenOrOdd}` + (isMe ? ' tournament-me' : '') },
        h("div", { className: "tournamentIdentity" },
            h("span", { className: "flagRank", "data-icon": player.withdraw === true ? 'b' : '' },
                " ",
                player.withdraw === true ? '' : (`${player.rank}.`),
                " \u2009 "),
            h("span", { className: "playerName" },
                renderPlayerTitle(player),
                `${player.name} (${player.rating})`),
            h("span", { className: `playerTeam ttc-${ttc}` },
                " ",
                teamName ?? '',
                " ")),
        h("div", { className: 'tournamentPoints ' + (player.sheet.fire ? 'on-fire' : 'off-fire'), "data-icon": "Q" }, player.score)));
}
function tournamentFeaturedGame(ctrl) {
    const data = ctrl.tournament;
    const featured = data.featured;
    if (!featured)
        return null;
    return (h("div", { className: "tournamentGames" },
        h("div", { className: "tournamentMiniBoard" }, h(MiniBoard, {
            fixed: false,
            fen: featured.fen,
            lastMove: featured.lastMove,
            orientation: featured.orientation,
            link: () => router.set(`/tournament/${data.id}/game/${featured.id}?color=${featured.orientation}&goingBack=1`),
            gameObj: featured,
        }))));
}
function tournamentPodium(podium) {
    return (h("div", { className: "podium" },
        renderPlace(podium[1]),
        renderPlace(podium[0]),
        renderPlace(podium[2])));
}
function renderPlace(data) {
    // tournament can exist with only 2 players
    if (!data)
        return null;
    const rank = data.rank;
    return (h("div", { className: 'place' + rank },
        h("div", { className: "trophy" }, " "),
        h("div", { className: "username", oncreate: ontap(() => router.set('/@/' + data.name)) },
            renderPlayerTitle(data),
            data.name),
        h("div", { className: "rating" },
            " ",
            data.rating,
            " "),
        h("table", { className: "stats" },
            h("tr", null,
                h("td", { className: "statName" }, i18n('performance')),
                h("td", { className: "statData" }, data.performance)),
            h("tr", null,
                h("td", { className: "statName" }, i18n('gamesPlayed')),
                h("td", { className: "statData" }, data.nb.game)),
            h("tr", null,
                h("td", { className: "statName" }, i18n('winRate')),
                h("td", { className: "statData" }, ((data.nb.win / data.nb.game) * 100).toFixed(0) + '%')),
            h("tr", null,
                h("td", { className: "statName" }, i18n('berserkRate')),
                h("td", { className: "statData" }, ((data.nb.berserk / data.nb.game) * 100).toFixed(0) + '%')))));
}
function tournamentTeamLeaderboard(ctrl) {
    const t = ctrl.tournament;
    const tb = t.teamBattle;
    const standings = t.teamStanding;
    if (!tb || !standings)
        return null;
    return (h("div", { className: "tournamentTeamLeaderboard" },
        h("ul", { className: 'tournamentTeamStandings box', oncreate: ontap(e => handleTeamInfoTap(ctrl, e), undefined, undefined, getTeamLeaderboardItemEl) }, standings.map((team, i) => renderTeamEntry(tb.teams[team.id], ctrl.teamColorMap[team.id], team, i)))));
}
function renderTeamEntry(teamName, teamColor, team, i) {
    if (!teamName)
        return null;
    const ttc = teamColor ? teamColor : 0;
    const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
    return (h("li", { key: team.id, "data-team": team.id, className: `list_item tournament-list-item ${evenOrOdd}` },
        h("div", { className: "tournamentIdentity" },
            h("span", null,
                " ",
                team.rank + '.',
                " \u2009 "),
            h("span", { className: 'ttc-' + ttc },
                " ",
                teamName,
                " ")),
        h("div", { className: 'tournamentPoints' }, team.score)));
}
function getTeamLeaderboardItemEl(e) {
    const target = e.target;
    return target.classList.contains('list_item') ? target :
        findParentBySelector(target, '.list_item');
}
function handleTeamInfoTap(ctrl, e) {
    const el = getTeamLeaderboardItemEl(e);
    const teamId = el.dataset['team'];
    if (teamId)
        ctrl.teamInfoCtrl.open(teamId);
}

function socketHandler (ctrl) {
    return {
        reload: ctrl.reload,
        resync: ctrl.reload,
        redirect(gameId) {
            router.set('/tournament/' + ctrl.tournament.id + '/game/' + gameId, true);
        },
        fen(d) {
            const featured = ctrl.tournament.featured;
            if (!featured)
                return;
            if (featured.id !== d.id)
                return;
            featured.fen = d.fen;
            featured.lastMove = d.lm;
            redraw();
        },
        message(msg) {
            if (ctrl.chat)
                ctrl.chat.append(msg);
        },
    };
}

/***
 * From https://github.com/lichess-org/lila/blob/master/ui/common/src/throttle.ts
 * Wraps an asynchronous function to ensure only one call at a time is in
 * flight. Any extra calls are dropped, except the last one, which waits for
 * the previous call to complete.
 */
function throttlePromise(wrapped) {
    let current;
    let afterCurrent;
    return function (...args) {
        const self = this;
        const exec = () => {
            afterCurrent = undefined;
            current = wrapped
                .apply(self, args)
                .then(() => {
                current = undefined;
                if (afterCurrent)
                    afterCurrent();
            })
                .catch(() => {
                current = undefined;
                if (afterCurrent)
                    afterCurrent();
            });
        };
        if (current)
            afterCurrent = exec;
        else
            exec();
    };
}
/**
 * Wraps an asynchronous function to return a promise that resolves
 * after completion plus a delay (regardless if the wrapped function resolves
 * or rejects).
 */
function finallyDelay(delay, wrapped) {
    return function (...args) {
        const self = this;
        return new Promise(resolve => {
            wrapped
                .apply(self, args)
                .then(() => setTimeout(resolve, delay()))
                .catch(() => setTimeout(resolve, delay()));
        });
    };
}

const MAX_PER_PAGE = 10;
class TournamentCtrl {
    constructor(data) {
        this.page = 1;
        this.hasJoined = false;
        this.focusOnMe = false;
        this.isLoadingPage = false;
        this.pagesCache = {};
        this.join = throttle((password, team) => {
            join$1(this.tournament.id, password, team)
                .then(() => {
                this.hasJoined = true;
                this.focusOnMe = true;
                redraw();
            })
                .catch((e) => {
                if (e.body != null && 'error' in e.body) {
                    void Toast.show({ text: e.body.error, duration: 'short' });
                }
                else {
                    handleXhrError(e);
                }
            });
        }, 1000);
        this.withdraw = throttle(() => {
            withdraw(this.tournament.id)
                .then(() => {
                this.hasJoined = false;
                this.focusOnMe = false;
                redraw();
            })
                .catch(handleXhrError);
        }, 1000);
        this.reload = throttlePromise(finallyDelay(() => 5000 + Math.floor(Math.random() * 1000), () => reload(this.id, this.focusOnMe ? undefined : this.page)
            .then(this.onReload)
            .catch(handleXhrError)));
        this.loadPage = throttle((page) => {
            loadPage(this.id, page)
                .then((data) => {
                this.isLoadingPage = false;
                if (this.page === data.page) {
                    this.loadCurrentPage(data);
                }
                else {
                    this.setPageCache(data);
                }
                redraw();
            })
                .catch(err => {
                this.isLoadingPage = false;
                handleXhrError(err);
            });
        }, 1000);
        this.first = () => {
            if (this.page > 1)
                this.userSetPage(1);
        };
        this.prev = () => {
            if (this.page > 1)
                this.userSetPage(this.page - 1);
        };
        this.next = () => {
            const nbPlayers = this.tournament.nbPlayers;
            if (this.page < nbPlayers / MAX_PER_PAGE)
                this.userSetPage(this.page + 1);
        };
        this.last = () => {
            const nbPlayers = this.tournament.nbPlayers;
            if (this.page < nbPlayers / MAX_PER_PAGE)
                this.userSetPage(Math.ceil(nbPlayers / MAX_PER_PAGE));
        };
        this.toggleFocusOnMe = () => {
            if (!this.tournament.me)
                return;
            this.focusOnMe = !this.focusOnMe;
            if (this.focusOnMe)
                this.scrollToMe();
            redraw();
        };
        this.myPage = () => {
            return (this.tournament.me) ?
                Math.floor((this.tournament.me.rank - 1) / MAX_PER_PAGE) + 1 :
                undefined;
        };
        this.unload = () => {
            this.appStateListener.then((v) => v.remove());
        };
        this.scrollToMe = () => {
            const myPage = this.myPage();
            if (myPage !== undefined && myPage !== this.page)
                this.setPage(myPage);
        };
        this.onReload = (data) => {
            const oldData = this.tournament;
            if (data.featured && (!oldData || !oldData.featured || (data.featured.id !== oldData.featured.id))) {
                this.socketIface.send('startWatching', data.featured.id);
            }
            this.tournament = { ...this.tournament, ...data, ...{ me: data.me } }; // to account for removal on withdraw
            this.setPageCache(data.standing);
            if (this.pagesCache[this.page] !== undefined) {
                this.currentPageResults = this.pagesCache[this.page];
            }
            this.hasJoined = !!(data.me && !data.me.withdraw);
            if (this.focusOnMe)
                this.scrollToMe();
            if (data.socketVersion) {
                socket.setVersion(data.socketVersion);
            }
            this.teamColorMap = data.teamBattle ? this.createTeamColorMap(data.teamBattle) : {};
            const tb = data.teamBattle;
            if (tb && !tb.joinWith.includes(settings.tournament.join.lastTeam())) {
                if (tb.joinWith.length > 0)
                    settings.tournament.join.lastTeam(tb.joinWith[0]);
            }
            redraw();
        };
        this.id = data.id;
        this.faqCtrl = faq.controller(this);
        this.playerInfoCtrl = playerInfo.controller(this);
        this.teamInfoCtrl = teamInfo.controller(this);
        this.tournament = data;
        this.startsAt = fromNow(new Date(data.startsAt));
        this.page = this.tournament.standing.page;
        this.loadCurrentPage(this.tournament.standing);
        this.hasJoined = !!(data.me && !data.me.withdraw);
        this.focusOnMe = isIn(this.tournament);
        this.scrollToMe();
        const featuredGame = data.featured ? data.featured.id : undefined;
        this.socketIface = socket.createTournament(this.id, this.tournament.socketVersion, socketHandler(this), featuredGame);
        if (data.chat) {
            this.chat = new Chat(this.socketIface, data.id, data.chat.lines, undefined, data.chat.writeable, session.isShadowban(), 'Tournament');
        }
        this.appStateListener = App.addListener('appStateChange', (state) => {
            if (state.isActive)
                this.reload();
        });
        this.teamColorMap = data.teamBattle ? this.createTeamColorMap(data.teamBattle) : {};
        redraw();
    }
    userSetPage(page) {
        if (this.isLoadingPage)
            return;
        this.focusOnMe = false;
        this.setPage(page);
    }
    setPage(page) {
        this.page = page;
        const fromCache = this.pagesCache[this.page];
        if (fromCache) {
            this.currentPageResults = fromCache;
        }
        else {
            this.isLoadingPage = true;
        }
        this.loadPage(page);
        redraw();
    }
    setPageCache(data) {
        this.pagesCache[data.page] = data.players;
    }
    loadCurrentPage(data) {
        this.setPageCache(data);
        this.currentPageResults = data.players;
    }
    createTeamColorMap(tb) {
        return Object.keys(tb.teams).reduce((acc, team, i) => ({ ...acc, [team]: i }), {});
    }
}

var tournamentDetail = {
    oninit({ attrs }) {
        tournament(attrs.id)
            .then(data => {
            this.ctrl = new TournamentCtrl(data);
        })
            .catch((err) => {
            if (err.status === 404) {
                this.notFound = true;
                redraw();
            }
            else {
                handleXhrError(err);
            }
        });
    },
    oncreate: viewSlideIn,
    onremove() {
        socket.destroy();
        if (this.ctrl) {
            this.ctrl.unload();
        }
    },
    view() {
        if (this.notFound) {
            return layout.free(dropShadowHeader(null, backButton(i18n('tournamentNotFound'))), h('div.tournamentNotFound', [
                h('p', i18n('tournamentDoesNotExist')),
                h('p', i18n('tournamentMayHaveBeenCanceled'))
            ]));
        }
        if (!this.ctrl) {
            return layout.free(connectingDropShadowHeader(), null);
        }
        const tournament = this.ctrl.tournament;
        const header = dropShadowHeader(null, backButton(h('div.main_header_title.withSub', [
            h('h1', [
                h('span.fa.fa-trophy'),
                this.ctrl.tournament.fullName
            ]),
            h('h2.header-subTitle.tournament-subtTitle', !tournament.isFinished && !tournament.isStarted ?
                timeInfo(tournament.secondsToStart, 'Starting in') :
                timeInfo(tournament.secondsToFinish, ''))
        ])));
        const body = tournamentBody(this.ctrl);
        const footer = renderFooter(this.ctrl);
        const overlay = [
            ...renderOverlay(this.ctrl),
            joinForm.view(),
        ].filter(noNull);
        return layout.free(header, body, footer, overlay);
    }
};

export { tournamentDetail as default };
//# sourceMappingURL=tournamentDetail-CMUzI3XS.js.map
