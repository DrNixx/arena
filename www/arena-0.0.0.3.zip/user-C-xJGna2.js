import { ak as loadingBackbutton, an as elFadeIn, am as pageSlideIn, s as socket } from './main.js';
import { h as header, p as profile, U as UserCtrl } from './userView-BRulENS5.js';
import { l as layout } from './layout-DoxuEk9x.js';
import './html-EBv26hf5.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './userXhr-i6lHGN-w.js';

const UserScreen = {
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = UserCtrl(attrs.id);
    },
    oncreate(vnode) {
        if (this.ctrl.isMe()) {
            elFadeIn(vnode.dom);
        }
        else {
            pageSlideIn(vnode.dom);
        }
    },
    view() {
        const user = this.ctrl.user();
        if (user) {
            return layout.free(header(user, this.ctrl), profile(user, this.ctrl));
        }
        else {
            return layout.free(loadingBackbutton(), null);
        }
    }
};

export { UserScreen as default };
//# sourceMappingURL=user-C-xJGna2.js.map
