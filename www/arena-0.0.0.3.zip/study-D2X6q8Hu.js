import { a0 as header, I as backButton, m as h, x as ontap, $ as Toast, bg as ontapXY, cH as expandLess, cI as expandMore, y as plural, bk as lightPlayerName, E as getLI, q as router, X as isPortrait, s as socket, an as elFadeIn, am as pageSlideIn, H as safeStringToNum, r as redraw, K as handleXhrError } from './main.js';
import { l as layout, C as CloseSlideHandler, E as EdgeOpenHandler } from './layout-DoxuEk9x.js';
import { a as renderContent, o as overlay, l as loadingScreen, A as AnalyseCtrl } from './AnalyseCtrl-_vlqF8MU.js';
import { c as load } from './studyXhr-CPiJUv6u.js';
import './fen-97CPMMDI.js';
import './variant-Cl-7Z946.js';
import './promotion-yOaF5Jgj.js';
import './toInteger-bGq5KERl.js';
import './TabView-CG79fzxt.js';
import './chat-Dbn1ft42.js';
import './html-EBv26hf5.js';
import './game-CgD9Ef6g.js';
import './perfs-BLfNpglP.js';
import './tree-ByUN6R2a.js';
import './axis-iOnHMIBv.js';
import './Board-UV3Z06Mn.js';
import './chess-B1K_bSdL.js';
import './vibrate-CyNrNHlt.js';
import './index-CkC0Yhqy.js';
import './index-r4T5Y9G7.js';

function notFound() {
    return layout.free(header(null, backButton('Not Found')), h('div'));
}
function studyHeader(study) {
    const title = study.name;
    const subTitle = study.chapters.find(c => c.id === study.chapter.id).name;
    return header(null, backButton(h('div.main_header_title.withSub', {}, [
        h('h1.header-gameTitle', {
            oncreate: ontap(() => {
                Toast.show({ text: `${title}: ${subTitle}`, duration: 'long', position: 'top' });
            })
        }, title),
        h('h2.header-subTitle', subTitle)
    ])));
}

var RightSideMenu = {
    oninit({ attrs }) {
        const { studyCtrl } = attrs;
        const nbMembers = Object.keys(studyCtrl.data.members).length;
        this.showMembers = nbMembers <= 5;
    },
    onbeforeupdate({ attrs }) {
        const sm = attrs.studyCtrl.sideMenu;
        return sm.isOpen;
    },
    view({ attrs }) {
        const { studyCtrl } = attrs;
        const study = studyCtrl.data;
        const members = sortMembers(study.members);
        return h('aside#studyMenu', {
            oncreate: ({ dom }) => {
                CloseSlideHandler(dom, studyCtrl.sideMenu);
            }
        }, [
            h('div.native_scroller', [
                h('h2.study-menu-title.study-members', {
                    oncreate: ontapXY(() => this.showMembers = !this.showMembers)
                }, [
                    h('span', plural('nbMembers', members.length)),
                    this.showMembers ? expandLess : expandMore
                ]),
                this.showMembers ? h('ul', members.map(memb => h('li.study-menu-link', {
                    className: memb.role === 'w' ? 'contrib' : 'viewer'
                }, [
                    h('span.bullet.fa', {
                        className: memb.role === 'w' ? 'fa-user' : 'fa-eye'
                    }),
                    h('span', memb.user ? lightPlayerName(memb.user) : '?')
                ]))) : null,
                h('h2.study-menu-title.study-chapters', plural('nbChapters', study.chapters.length)),
                h('ol', {
                    oncreate: ontapXY(e => {
                        const el = getLI(e);
                        const id = el && el.dataset.id;
                        if (id) {
                            studyCtrl.sideMenu.close()
                                .then(() => {
                                const tab = studyCtrl.analyseCtrl.currentTab(studyCtrl.analyseCtrl.availableTabs()).id;
                                router.set(`/study/${study.id}/${id}?tabId=${tab}`, true);
                            });
                        }
                    }, undefined, getLI)
                }, study.chapters.map((c, i) => {
                    return h('li.study-menu-link', {
                        'data-id': c.id,
                        className: study.chapter.id === c.id ? 'current' : ''
                    }, [
                        h('span.bullet', i + 1),
                        h('span', c.name)
                    ]);
                }))
            ])
        ]);
    }
};
function sortMembers(members) {
    return Object.keys(members).map(id => members[id]).sort((a, b) => {
        if (a.role === 'r' && b.role === 'w')
            return 1;
        if (a.role === 'w' && b.role === 'r')
            return -1;
        return a.addedAt > b.addedAt ? 1 : -1;
    });
}

var study = {
    oninit(vnode) {
        const studyId = vnode.attrs.id;
        const studyChapterId = vnode.attrs.chapterId;
        const now = performance.now();
        const ply = safeStringToNum(vnode.attrs.ply);
        const tabId = vnode.attrs.tabId;
        load(studyId, studyChapterId)
            .then(data => {
            const elapsed = performance.now() - now;
            setTimeout(() => {
                this.ctrl = new AnalyseCtrl(data.analysis, data.study, 'online', data.study.chapter.setup.orientation, true, ply || 0, tabId);
                this.handlers = EdgeOpenHandler(this.ctrl.study.sideMenu);
                redraw();
            }, Math.max(400 - elapsed, 0));
        })
            .catch(err => {
            if (err.status === 404) {
                this.notFound = true;
                redraw();
            }
            else {
                handleXhrError(err);
            }
        });
    },
    oncreate(vnode) {
        // don't want to slide when changing chapter
        if (router.getPreviousPath().startsWith('/study/')) {
            elFadeIn(vnode.dom);
        }
        else {
            pageSlideIn(vnode.dom);
        }
    },
    onremove() {
        socket.destroy();
        if (this.ctrl) {
            this.ctrl.unload();
            this.ctrl = undefined;
        }
    },
    view(vnode) {
        if (this.notFound) {
            return notFound();
        }
        const isPortrait$1 = isPortrait();
        const ctrl = this.ctrl;
        if (ctrl) {
            return layout.board(studyHeader(ctrl.study.data), renderContent(ctrl, isPortrait$1), undefined, [
                ...overlay(ctrl),
                h(RightSideMenu, { studyCtrl: ctrl.study }),
                h('div#studyMenu-backdrop.menu-backdrop', {
                    oncreate: ontap(() => ctrl.study.sideMenu.close())
                })
            ], this.handlers);
        }
        else {
            return loadingScreen(isPortrait$1, undefined, vnode.attrs.curFen);
        }
    }
};

export { study as default };
//# sourceMappingURL=study-D2X6q8Hu.js.map
