import { M as popup, k as hasNetwork, q as router, b as session, r as redraw, m as h, o as i18n, x as ontap, ai as loginModal, al as connectingHeader, a0 as header, y as plural, g as settings, an as elFadeIn, $ as Toast, ca as altCastles, cd as decomposeUci, ce as sanToRole, R as sound, h as throttle, d as debounce, K as handleXhrError, a as signals, ci as readDests, aF as uciToMove, a6 as Chessground, F as viewFadeIn, X as isPortrait, V as ViewOnlyBoard, H as safeStringToNum, cB as base62ToNumber, s as socket } from './main.js';
import { e as emptyFen } from './fen-97CPMMDI.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import { v as view, p as promotion } from './promotion-yOaF5Jgj.js';
import { s as syncAndClearCache, p as puzzleLoadFailure, a as syncAndLoadNewPuzzle, n as newPuzzle, v as vote, g as getUnsolved, b as syncPuzzleResult, c as nbRemainingPuzzles, r as round, e as loadPuzzle, d as db } from './offlineService-COoOyrIU.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { c as contains, s as size, t as takePathWhile, l as last, m as mainlineNodeList, i as init, b as build, a as reconstruct, f as fromNodeList, u as updateAll, e as childById, g as merge } from './tree-ByUN6R2a.js';
import { s as situation, m as move } from './chess-B1K_bSdL.js';

var menu = {
    controller(root) {
        let isOpen = false;
        let puzzleUser = null;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
            const user = session.get();
            if (user) {
                root.database.fetch(user.id)
                    .then(data => {
                    if (data) {
                        puzzleUser = {
                            username: user.username,
                            data: data.user,
                        };
                        redraw();
                    }
                });
            }
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open,
            close,
            isOpen: () => isOpen,
            user: () => puzzleUser,
            root,
        };
    },
    view(ctrl) {
        return popup('trainingMenu', undefined, () => renderTrainingMenu(ctrl), ctrl.isOpen(), ctrl.close);
    }
};
function renderTrainingMenu(ctrl) {
    const puzzleUser = ctrl.user();
    if (ctrl.root.data && ctrl.root.data.user && hasNetwork()) {
        return renderUserInfosOnline(ctrl.root.data.user);
    }
    else if (puzzleUser !== null && hasNetwork()) {
        return renderUserInfosOnline(puzzleUser.data);
    }
    else if (puzzleUser !== null) {
        return renderUserInfosOffline(puzzleUser, ctrl);
    }
    else {
        return renderSigninBox();
    }
}
function renderSigninBox() {
    return h('div.trainingMenuContent', [
        h('p', i18n('toGetPersonalizedPuzzles')),
        h('p.signin', h('button.defaultButton', {
            oncreate: ontap(loginModal.open)
        }, [h('span.fa.fa-user'), i18n('signIn')])),
    ]);
}
function renderUserInfosOffline(user, ctrl) {
    const rating = user.data.rating;
    return h('div.training-offlineInfos', [
        h('p', ['You are currently offline. Your last recorded rating as ', h('strong', user.username), ' is ', h('strong', rating), '.']),
        h('p', 'You still have ', h('strong', ctrl.root.nbUnsolved), ' saved puzzles to solve.'),
        h('p', 'Puzzles are automatically downloaded by batches so you can solve them seamlessly while having bad network conditions or when you are offline.'),
        h('p', 'Your puzzle history and rating will be updated as soon as you are back online.'),
    ]);
}
function renderUserInfosOnline(user) {
    const rating = user.rating;
    return [
        h('p.trainingRatingHeader', h.trust(i18n('xRating', `<strong>${rating}</strong>`)))
    ];
}

function renderHeader(ctrl) {
    const maxPuzzles = settings.training.puzzleBufferLen;
    return ctrl.vm.loading ?
        connectingHeader() : header(h('div.main_header_title.withSub', [
        h('h1', i18n('puzzleId', ctrl.data.puzzle.id)),
        h('h2.header-subTitle', [
            i18n('rating'), ' ' + (ctrl.vm.mode === 'view' ? ctrl.data.puzzle.rating : '?'),
            ' • ', plural('playedXTimes', ctrl.data.puzzle.attempts)
        ].concat(!hasNetwork() ? [
            ' • ',
            h('span.fa.fa-database'),
            `${ctrl.nbUnsolved}/${maxPuzzles}`
        ] : [])),
    ]));
}
function renderContent(ctrl, key) {
    const board = h(Board, {
        variant: ctrl.data.game.variant.key,
        chessground: ctrl.chessground
    });
    return h.fragment({ key }, [
        board,
        h('div.table.training-tableWrapper', [
            h('div.training-table.native_scroller.box', ctrl.vm.mode === 'view' ? renderResult(ctrl) : renderFeedback(ctrl)),
            renderActionsBar(ctrl)
        ])
    ]);
}
function overlay(ctrl) {
    return [
        view(ctrl),
        menu.view(ctrl.menu)
    ];
}
function renderActionsBar(ctrl) {
    return h('section#training_actions.actions_bar', [
        h('button.action_bar_button.training_action.fa.fa-area-chart', {
            oncreate: ontap(ctrl.menu.open)
        }),
        h('button.action_bar_button.training_action.fa.fa-share-alt', {
            oncreate: ontap(ctrl.share, () => Toast.show({ text: 'Share this puzzle', duration: 'short', position: 'bottom' }))
        }),
        h('button.action_bar_button.training_action[data-icon=A]', {
            oncreate: ontap(ctrl.goToAnalysis, () => Toast.show({ text: i18n('analysis'), duration: 'short', position: 'bottom' })),
            disabled: ctrl.vm.mode !== 'view'
        }),
        session.isConnected() ? h('button.action_bar_button.training_action.fa.fa-random', {
            oncreate: ontap(ctrl.resync, () => Toast.show({ text: 'Sync and refresh saved puzzles', duration: 'short', position: 'bottom' }))
        }) : null,
        h('button.action_bar_button.training_action.fa.fa-backward', {
            oncreate: ontap(ctrl.rewind, undefined, ctrl.rewind),
            disabled: !ctrl.canGoBackward()
        }),
        h('button.action_bar_button.training_action.fa.fa-forward', {
            oncreate: ontap(ctrl.fastforward, undefined, ctrl.fastforward),
            disabled: !ctrl.canGoForward()
        })
    ]);
}
function renderViewControls(ctrl) {
    return [
        h('button.li-button.training-control.retry', {
            oncreate: ontap(ctrl.retry),
            className: ctrl.vm.loading ? 'disabled' : ''
        }, [h('span.fa.fa-refresh'), h('span', i18n('retry'))]),
        h('button.li-button.training-control.continue', {
            oncreate: ontap(ctrl.newPuzzle),
            className: ctrl.vm.loading ? 'disabled' : ''
        }, [h('span.fa.fa-play'), h('span', i18n('continueTraining'))])
    ];
}
function renderFeedback(ctrl) {
    switch (ctrl.vm.lastFeedback) {
        case 'init':
            return h('div.training-explanation', [
                h('div.player', [
                    h('div.piece-no-square', {
                        className: settings.general.theme.piece(),
                    }, h('piece.king.' + ctrl.data.puzzle.color)),
                    h('div.training-instruction', [
                        h('strong', i18n('yourTurn')),
                        h('p', i18n(ctrl.data.puzzle.color === 'white' ? 'findTheBestMoveForWhite' : 'findTheBestMoveForBlack')),
                    ])
                ]),
                renderViewSolution(ctrl)
            ]);
        case 'retry':
            return h('div.training-explanation', [
                h('div.player', [
                    h('div.training-icon', '!'),
                    h('div.training-instruction', [
                        h('strong', i18n('goodMove')),
                        h('span', 'But you can do better')
                    ]),
                ]),
                renderViewSolution(ctrl)
            ]);
        case 'good':
            return h('div.training-explanation', [
                h('div.player', [
                    h('div.training-icon.win', '✓'),
                    h('div.training-instruction', [
                        h('strong', i18n('bestMove')),
                        h('span', i18n('keepGoing'))
                    ]),
                ]),
                renderViewSolution(ctrl)
            ]);
        case 'fail':
            return h('div.training-explanation', [
                h('div.player', [
                    h('div.training-icon.loss', '✗'),
                    h('div.training-instruction', [
                        h('strong', i18n('notTheMove')),
                        h('span', i18n('trySomethingElse'))
                    ])
                ]),
                renderViewSolution(ctrl)
            ]);
    }
}
function renderViewSolution(ctrl) {
    return ctrl.vm.canViewSolution ? h('button.fatButton', {
        oncreate: (vnode) => {
            elFadeIn(vnode.dom, 1500, '0', '0.8');
            ontap(ctrl.viewSolution)(vnode);
        }
    }, i18n('viewTheSolution')) : h('div.buttonPlaceholder', '');
}
function renderVoteControls(ctrl) {
    return [
        h('div.buttons', [
            h('span.fa.fa-caret-up', {
                oncreate: ontap(ctrl.upvote),
                className: ctrl.vm.voted === true ? 'voted' : ''
            }),
            h('span.fa.fa-caret-down', {
                oncreate: ontap(ctrl.downvote),
                className: ctrl.vm.voted === false ? 'voted' : ''
            })
        ])
    ];
}
function renderResult(ctrl) {
    if (ctrl.vm.lastFeedback === 'win') {
        return [
            h('div.training-half', [
                h('div.training-icon.win', '✓'),
                h('strong', [i18n('puzzleSuccess')]),
                session.isConnected() ?
                    h('div.training-vote', renderVoteControls(ctrl)) : null
            ]),
            h('div.training-half', renderViewControls(ctrl))
        ];
    }
    else {
        return [
            h('div.training-half', [
                h('strong', i18n('puzzleComplete')),
                session.isConnected() ?
                    h('div.training-vote', renderVoteControls(ctrl)) : null
            ]),
            h('div.training-half', renderViewControls(ctrl))
        ];
    }
}

function moveTest(mode, node, path, initialPath, nodeList, puzzle) {
    if (mode === 'view')
        return null;
    if (!contains(path, initialPath))
        return null;
    // puzzle moves so far
    const progress = nodeList
        .slice(size(initialPath) + 1)
        // at this point we know node has uci and san (every node except first has)
        .map(node => ({ uci: node.uci, castle: (node.san).startsWith('O-O') }));
    // search in puzzle lines with current progress
    const curLine = progress.reduce((acc, step) => {
        if (!acc)
            return undefined;
        if (isLineFeedback(acc))
            return acc;
        // trick typescript into thinking altCastles[step.uci] is defined to avoid
        // Error TS2538: Type 'undefined' cannot be used as an index type
        // actually we don't care if it's undefined since acc[undefined] don't
        // throw and return undefined
        return acc[step.uci] || (step.castle && acc[altCastles[step.uci]]);
    }, puzzle.lines);
    if (node.san?.endsWith('#')) {
        const feedback = 'win';
        node.puzzle = feedback;
        return feedback;
    }
    if (!curLine) {
        const feedback = 'fail';
        node.puzzle = feedback;
        return feedback;
    }
    else if (isLineFeedback(curLine)) {
        node.puzzle = curLine;
        return curLine;
    }
    else {
        // next opponent move from line
        const nextUci = Object.keys(curLine)[0];
        if (curLine[nextUci] === 'win') {
            node.puzzle = 'win';
            return 'win';
        }
        else {
            node.puzzle = 'good';
            const opponentUci = decomposeUci(nextUci);
            const promotion = opponentUci[2] ? sanToRole[opponentUci[2].toUpperCase()] : null;
            const move = {
                variant: 'standard',
                orig: opponentUci[0],
                dest: opponentUci[1],
                fen: node.fen,
                path: path
            };
            if (promotion)
                move.promotion = promotion;
            return move;
        }
    }
}
function isLineFeedback(v) {
    return typeof v === 'string';
}

function makeConfig(ctrl, userMove) {
    const pieceMoveConf = settings.game.pieceMove();
    return {
        fen: ctrl.data.puzzle.fen,
        orientation: ctrl.data.puzzle.color,
        coordinates: settings.game.coords(),
        turnColor: ctrl.node.ply % 2 === 0 ? 'white' : 'black',
        highlight: {
            lastMove: settings.game.highlights(),
            check: settings.game.highlights()
        },
        movable: {
            free: false,
            color: ctrl.data.puzzle.color,
            showDests: settings.game.pieceDestinations(),
            rookCastle: settings.game.rookCastle() === 1,
        },
        events: {
            move: userMove
        },
        animation: {
            enabled: true,
            duration: 300
        },
        premovable: {
            enabled: false
        },
        draggable: {
            enabled: pieceMoveConf === 'drag' || pieceMoveConf === 'both',
            distance: 3,
            magnified: settings.game.magnified()
        },
        selectable: {
            enabled: pieceMoveConf === 'tap' || pieceMoveConf === 'both'
        },
    };
}

class TrainingCtrl {
    constructor(cfg, database) {
        this.promoting = null;
        this.player = () => this.data.puzzle.color;
        this.viewSolution = () => {
            if (!this.vm.canViewSolution)
                return;
            this.sendResult(false);
            this.vm.mode = 'view';
            this.mergeSolution(this.data.puzzle.branch, this.data.puzzle.color);
            // try and play the solution next move
            const next = this.node.children[0];
            if (next && next.puzzle === 'good')
                this.userJump(this.path + next.id, true);
            else {
                const firstGoodPath = takePathWhile(this.mainline, node => {
                    return node.puzzle !== 'good';
                });
                if (firstGoodPath) {
                    this.userJump(firstGoodPath + this.tree.nodeAtPath(firstGoodPath).children[0].id, true);
                }
            }
            redraw();
        };
        this.setPath = (path) => {
            this.path = path;
            this.nodeList = this.tree.getNodeList(path);
            this.node = last(this.nodeList);
            this.mainline = mainlineNodeList(this.tree.root);
        };
        this.jump = (path, withSound = false) => {
            const pathChanged = path !== this.path;
            this.setPath(path);
            this.updateBoard();
            if (pathChanged && withSound) {
                if (this.node.san && this.node.san.indexOf('x') !== -1)
                    sound.throttledCapture();
                else
                    sound.throttledMove();
            }
            promotion.cancel(this);
        };
        this.userJump = (path, withSound) => {
            this.jump(path, withSound);
        };
        this.canGoForward = () => {
            return !this.vm.initializing && this.node.children.length > 0;
        };
        this.fastforward = () => {
            if (this.node.children.length === 0)
                return false;
            const child = this.node.children[0];
            this.userJump(this.path + child.id, true);
            return true;
        };
        this.canGoBackward = () => {
            if (this.vm.moveValidationPending)
                return false;
            if (this.path === '')
                return false;
            return true;
        };
        this.resync = () => {
            const user = session.get();
            if (hasNetwork() && user) {
                if (this.vm.loading) {
                    return;
                }
                this.vm.loading = true;
                redraw();
                const onSuccess = (cfg) => {
                    this.vm.loading = false;
                    this.init(cfg);
                    redraw();
                };
                syncAndClearCache(this.database, user)
                    .then(onSuccess)
                    .catch(error => {
                    this.vm.loading = false;
                    redraw();
                    puzzleLoadFailure(error);
                });
            }
        };
        this.rewind = () => {
            if (this.canGoBackward()) {
                this.userJump(init(this.path), false);
                return true;
            }
            return false;
        };
        this.newPuzzle = () => {
            if (this.vm.loading) {
                return;
            }
            this.vm.loading = true;
            redraw();
            const onSuccess = (cfg) => {
                this.vm.loading = false;
                this.init(cfg);
                redraw();
            };
            const user = session.get();
            if (user) {
                syncAndLoadNewPuzzle(this.database, user)
                    .then(onSuccess)
                    .catch(error => {
                    this.vm.loading = false;
                    redraw();
                    puzzleLoadFailure(error);
                });
            }
            else {
                newPuzzle()
                    .then(onSuccess)
                    .catch(this.onXhrError);
            }
        };
        this.retry = () => {
            if (!this.vm.loading) {
                this.init(this.initialData);
            }
        };
        this.upvote = () => {
            this.vote(true);
        };
        this.downvote = () => {
            this.vote(false);
        };
        this.vote = throttle((v) => {
            this.vm.voted = v;
            vote(this.data.puzzle.id, v).then(redraw);
        }, 1000);
        this.share = () => {
            Share.share({ url: `https://lichess.org/training/${this.data.puzzle.id}` });
        };
        this.goToAnalysis = () => {
            const puzzle = this.data.puzzle;
            if (hasNetwork()) {
                router.set(`/analyse/online/${puzzle.gameId}/${puzzle.color}?ply=${puzzle.initialPly}&curFen=${this.initialNode.fen}&color=${puzzle.color}&fallback=1`);
            }
            else {
                router.set(`/analyse/variant/standard/fen/${encodeURIComponent(this.initialNode.fen)}?color=${puzzle.color}&goBack=1`);
            }
        };
        this.getNodeSituation = debounce(() => {
            if (this.node && !this.node.dests) {
                situation({
                    variant: this.data.game.variant.key,
                    fen: this.node.fen,
                    path: this.path
                })
                    .then(({ situation, path }) => {
                    this.tree.updateAt(path, (node) => {
                        node.dests = situation.dests;
                        node.end = situation.end;
                        node.player = situation.player;
                    });
                    if (path === this.path) {
                        this.updateBoard();
                        redraw();
                    }
                })
                    .catch(err => console.error('get dests error', err));
            }
        }, 50);
        this.sendMove = (orig, dest, prom) => {
            const move = {
                orig,
                dest,
                variant: this.data.game.variant.key,
                fen: this.node.fen,
                path: this.path,
                pgnMoves: this.node.pgnMoves
            };
            if (prom)
                move.promotion = prom;
            this.sendMoveRequest(move, true);
        };
        this.sendMoveRequest = (move$1, userMove = false) => {
            move(move$1)
                .then(({ situation, path }) => {
                const node = {
                    id: situation.id,
                    ply: situation.ply,
                    fen: situation.fen,
                    uci: situation.uci,
                    children: [],
                    dests: situation.dests,
                    check: situation.check,
                    end: situation.end,
                    player: situation.player,
                    san: situation.san,
                    pgnMoves: situation.pgnMoves
                };
                if (path === undefined) {
                    console.error('Cannot addNode, missing path', node);
                    return;
                }
                const newPath = this.tree.addNode(node, path);
                if (!newPath) {
                    console.error('Cannot addNode', node, path);
                    return;
                }
                if (userMove)
                    this.vm.moveValidationPending = true;
                this.jump(newPath, !userMove);
                redraw();
                const playedByColor = this.node.ply % 2 === 1 ? 'white' : 'black';
                if (playedByColor === this.data.puzzle.color) {
                    const progress = moveTest(this.vm.mode, this.node, this.path, this.initialPath, this.nodeList, this.data.puzzle);
                    if (progress)
                        this.applyProgress(progress);
                }
            })
                .catch(err => console.error('send move error', move$1, err));
        };
        this.userMove = (orig, dest, captured) => {
            if (captured)
                sound.capture();
            else
                sound.move();
            if (!promotion.start(this, orig, dest, this.sendMove)) {
                this.sendMove(orig, dest);
            }
        };
        this.revertUserMove = (path) => {
            setTimeout(() => {
                this.vm.moveValidationPending = false;
                this.userJump(init(path), false);
                this.tree.deleteNodeAt(path);
                redraw();
            }, 500);
        };
        this.applyProgress = (progress) => {
            if (progress === 'fail') {
                this.vm.lastFeedback = 'fail';
                this.revertUserMove(this.path);
                if (this.vm.mode === 'play') {
                    this.vm.canViewSolution = true;
                    this.vm.mode = 'try';
                    this.sendResult(false);
                }
            }
            else if (progress === 'retry') {
                this.vm.lastFeedback = 'retry';
                this.revertUserMove(this.path);
            }
            else if (progress === 'win') {
                this.vm.moveValidationPending = false;
                if (this.vm.mode !== 'view') {
                    if (this.vm.mode === 'play')
                        this.sendResult(true);
                    this.vm.lastFeedback = 'win';
                    this.vm.mode = 'view';
                }
            }
            else if (isMoveRequest(progress)) {
                this.vm.moveValidationPending = false;
                this.vm.lastFeedback = 'good';
                setTimeout(() => {
                    // play opponent move
                    this.sendMoveRequest(progress);
                }, 500);
            }
        };
        this.sendResult = (win) => {
            if (this.vm.resultSent)
                return;
            this.vm.resultSent = true;
            const user = session.get();
            const outcome = { id: this.data.puzzle.id, win };
            const roundReq = () => {
                round(outcome)
                    .then((res) => {
                    this.vm.voted = res.voted;
                    this.data.user = res.user;
                    redraw();
                })
                    .catch(err => {
                    if (hasNetwork()) {
                        handleXhrError(err);
                    }
                    this.vm.resultSent = false;
                });
            };
            if (user) {
                getUnsolved(this.database, user)
                    .then(puzzles => {
                    // if puzzle is in the unsolved queue let's sync it using batch endpoint
                    // a puzzle may have been loaded from database, or from xhr if it has
                    // been loaded by id
                    if (puzzles.find(p => p.puzzle.id === this.data.puzzle.id)) {
                        syncPuzzleResult(this.database, user, outcome)
                            .then(newData => {
                            if (newData && newData.user) {
                                this.data.user = newData.user;
                                redraw();
                            }
                        });
                    }
                    else {
                        roundReq();
                    }
                });
            }
            else {
                roundReq();
            }
        };
        this.onXhrError = (res) => {
            this.vm.loading = false;
            redraw();
            handleXhrError(res);
        };
        this.menu = menu.controller(this);
        this.database = database;
        this.init(cfg);
        signals.afterLogin.add(this.retry);
    }
    // --
    init(cfg) {
        this.initialData = cfg;
        router.History.replaceState({ puzzleId: cfg.puzzle.id }, `/training/${cfg.puzzle.id}`);
        this.vm = {
            mode: 'play',
            initializing: true,
            lastFeedback: 'init',
            moveValidationPending: false,
            loading: false,
            canViewSolution: false,
            resultSent: false,
            voted: null,
        };
        const user = session.get();
        if (user) {
            nbRemainingPuzzles(this.database, user)
                .then(nb => {
                this.nbUnsolved = nb;
                redraw();
            });
        }
        const data = JSON.parse(JSON.stringify(cfg));
        const variant = {
            key: 'standard'
        };
        const pimpedGame = { ...data.game, variant };
        const pimpedData = { ...data, game: pimpedGame };
        this.data = pimpedData;
        this.tree = build(reconstruct([
            // make root node with puzzle initial state
            {
                fen: this.data.puzzle.fen,
                ply: this.data.puzzle.initialPly - 1,
                id: ''
            },
            this.data.game.treeParts
        ]));
        this.initialPath = fromNodeList(mainlineNodeList(this.tree.root));
        this.initialNode = this.tree.nodeAtPath(this.initialPath);
        this.setPath(init(this.initialPath));
        this.updateBoard();
        // play opponent first move with delay
        setTimeout(() => {
            this.jump(this.initialPath, true);
            this.vm.initializing = false;
        }, 1000);
        setTimeout(() => {
            this.vm.canViewSolution = true;
            redraw();
        }, 5000);
        redraw();
    }
    updateBoard() {
        const node = this.node;
        const color = node.ply % 2 === 0 ? 'white' : 'black';
        const dests = readDests(node.dests);
        const config = {
            fen: node.fen,
            turnColor: color,
            orientation: this.data.puzzle.color,
            movableColor: this.gameOver() ? null : this.data.puzzle.color,
            dests: dests || null,
            check: !!(node.check || node.san?.endsWith('+')),
            lastMove: node.uci ? uciToMove(node.uci) : null
        };
        if (!this.chessground) {
            this.chessground = new Chessground(makeConfig(this, this.userMove));
        }
        else {
            this.chessground.set(config);
        }
        if (!dests)
            this.getNodeSituation();
    }
    gameOver() {
        if (!this.node)
            return false;
        if (this.vm.mode === 'view')
            return true;
        return !!this.node.end;
    }
    mergeSolution(solution, color) {
        updateAll(solution, (node) => {
            if ((color === 'white') === (node.ply % 2 === 1))
                node.puzzle = 'good';
        });
        const solutionNode = childById(this.initialNode, solution.id);
        if (solutionNode)
            merge(solutionNode, solution);
        else
            this.initialNode.children.push(solution);
    }
}
function isMoveRequest(v) {
    return v.variant !== undefined;
}

// cache last state to retrieve it when navigating back
const cachedState = {};
var training = {
    oninit({ attrs }) {
        const loadNewPuzzle = () => {
            const user = session.get();
            if (user) {
                syncAndLoadNewPuzzle(db, user)
                    .catch(newPuzzle)
                    .then((cfg) => {
                    this.ctrl = new TrainingCtrl(cfg, db);
                    cachedState.ctrl = this.ctrl;
                })
                    .catch(puzzleLoadFailure);
            }
            else {
                newPuzzle()
                    .then((cfg) => {
                    this.ctrl = new TrainingCtrl(cfg, db);
                    cachedState.ctrl = this.ctrl;
                })
                    .catch(handleXhrError);
            }
        };
        const numId = safeStringToNum(attrs.id) ?? base62ToNumber(attrs.id);
        if (numId !== undefined) {
            if (cachedState.ctrl && window.history.state.puzzleId === numId) {
                this.ctrl = cachedState.ctrl;
                redraw();
            }
            else {
                loadPuzzle(numId)
                    .then(cfg => {
                    this.ctrl = new TrainingCtrl(cfg, db);
                    cachedState.ctrl = this.ctrl;
                })
                    .catch((e) => {
                    if (e.status === 404) {
                        Toast.show({ text: 'Puzzle not found.', duration: 'short' });
                        loadNewPuzzle();
                    }
                    else {
                        handleXhrError(e);
                    }
                });
            }
        }
        else {
            loadNewPuzzle();
        }
        socket.createDefault();
    },
    oncreate: viewFadeIn,
    onremove() {
        if (this.ctrl) {
            signals.afterLogin.remove(this.ctrl.retry);
        }
    },
    view({ attrs }) {
        const isPortrait$1 = isPortrait();
        const key = isPortrait$1 ? 'o-portrait' : 'o-landscape';
        if (this.ctrl) {
            return layout.board(renderHeader(this.ctrl), renderContent(this.ctrl, key), undefined, overlay(this.ctrl));
        }
        else {
            return layout.board(connectingHeader(), [
                h('section.board_wrapper', [
                    h(ViewOnlyBoard, {
                        fen: attrs.initFen || emptyFen,
                        orientation: attrs.initColor || 'white',
                    })
                ]),
                h('div.table.training-tableWrapper')
            ], undefined);
        }
    }
};

export { training as default };
//# sourceMappingURL=training-Dm_Jp5vj.js.map
