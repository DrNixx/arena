/*! Capacitor: https://capacitorjs.com/ - MIT License */
var ExceptionCode;
(function (ExceptionCode) {
    /**
     * API is not implemented.
     *
     * This usually means the API can't be used because it is not implemented for
     * the current platform.
     */
    ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
    /**
     * API is not available.
     *
     * This means the API can't be used right now because:
     *   - it is currently missing a prerequisite, such as network connectivity
     *   - it requires a particular platform or browser version
     */
    ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));
class CapacitorException extends Error {
    constructor(message, code, data) {
        super(message);
        this.message = message;
        this.code = code;
        this.data = data;
    }
}
const getPlatformId = (win) => {
    var _a, _b;
    if (win === null || win === void 0 ? void 0 : win.androidBridge) {
        return 'android';
    }
    else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
        return 'ios';
    }
    else {
        return 'web';
    }
};

const createCapacitor = (win) => {
    const capCustomPlatform = win.CapacitorCustomPlatform || null;
    const cap = win.Capacitor || {};
    const Plugins = (cap.Plugins = cap.Plugins || {});
    const getPlatform = () => {
        return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
    };
    const isNativePlatform = () => getPlatform() !== 'web';
    const isPluginAvailable = (pluginName) => {
        const plugin = registeredPlugins.get(pluginName);
        if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            // JS implementation available for the current platform.
            return true;
        }
        if (getPluginHeader(pluginName)) {
            // Native implementation available.
            return true;
        }
        return false;
    };
    const getPluginHeader = (pluginName) => { var _a; return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName); };
    const handleError = (err) => win.console.error(err);
    const registeredPlugins = new Map();
    const registerPlugin = (pluginName, jsImplementations = {}) => {
        const registeredPlugin = registeredPlugins.get(pluginName);
        if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
        }
        const platform = getPlatform();
        const pluginHeader = getPluginHeader(pluginName);
        let jsImplementation;
        const loadPluginImplementation = async () => {
            if (!jsImplementation && platform in jsImplementations) {
                jsImplementation =
                    typeof jsImplementations[platform] === 'function'
                        ? (jsImplementation = await jsImplementations[platform]())
                        : (jsImplementation = jsImplementations[platform]);
            }
            else if (capCustomPlatform !== null && !jsImplementation && 'web' in jsImplementations) {
                jsImplementation =
                    typeof jsImplementations['web'] === 'function'
                        ? (jsImplementation = await jsImplementations['web']())
                        : (jsImplementation = jsImplementations['web']);
            }
            return jsImplementation;
        };
        const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
                const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
                if (methodHeader) {
                    if (methodHeader.rtype === 'promise') {
                        return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                    }
                    else {
                        return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                    }
                }
                else if (impl) {
                    return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
                }
            }
            else if (impl) {
                return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            }
            else {
                throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
        };
        const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
                const p = loadPluginImplementation().then((impl) => {
                    const fn = createPluginMethod(impl, prop);
                    if (fn) {
                        const p = fn(...args);
                        remove = p === null || p === void 0 ? void 0 : p.remove;
                        return p;
                    }
                    else {
                        throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
                    }
                });
                if (prop === 'addListener') {
                    p.remove = async () => remove();
                }
                return p;
            };
            // Some flair ✨
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, 'name', {
                value: prop,
                writable: false,
                configurable: false,
            });
            return wrapper;
        };
        const addListener = createPluginMethodWrapper('addListener');
        const removeListener = createPluginMethodWrapper('removeListener');
        const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback);
            const remove = async () => {
                const callbackId = await call;
                removeListener({
                    eventName,
                    callbackId,
                }, callback);
            };
            const p = new Promise((resolve) => call.then(() => resolve({ remove })));
            p.remove = async () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                await remove();
            };
            return p;
        };
        const proxy = new Proxy({}, {
            get(_, prop) {
                switch (prop) {
                    // https://github.com/facebook/react/issues/20030
                    case '$$typeof':
                        return undefined;
                    case 'toJSON':
                        return () => ({});
                    case 'addListener':
                        return pluginHeader ? addListenerNative : addListener;
                    case 'removeListener':
                        return removeListener;
                    default:
                        return createPluginMethodWrapper(prop);
                }
            },
        });
        Plugins[pluginName] = proxy;
        registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: new Set([...Object.keys(jsImplementations), ...(pluginHeader ? [platform] : [])]),
        });
        return proxy;
    };
    // Add in convertFileSrc for web, it will already be available in native context
    if (!cap.convertFileSrc) {
        cap.convertFileSrc = (filePath) => filePath;
    }
    cap.getPlatform = getPlatform;
    cap.handleError = handleError;
    cap.isNativePlatform = isNativePlatform;
    cap.isPluginAvailable = isPluginAvailable;
    cap.registerPlugin = registerPlugin;
    cap.Exception = CapacitorException;
    cap.DEBUG = !!cap.DEBUG;
    cap.isLoggingEnabled = !!cap.isLoggingEnabled;
    return cap;
};
const initCapacitorGlobal = (win) => (win.Capacitor = createCapacitor(win));

const Capacitor = /*#__PURE__*/ initCapacitorGlobal(typeof globalThis !== 'undefined'
    ? globalThis
    : typeof self !== 'undefined'
        ? self
        : typeof window !== 'undefined'
            ? window
            : typeof global !== 'undefined'
                ? global
                : {});
const registerPlugin = Capacitor.registerPlugin;

/**
 * Base class web plugins should extend.
 */
class WebPlugin {
    constructor() {
        this.listeners = {};
        this.retainedEventArguments = {};
        this.windowListeners = {};
    }
    addListener(eventName, listenerFunc) {
        let firstListener = false;
        const listeners = this.listeners[eventName];
        if (!listeners) {
            this.listeners[eventName] = [];
            firstListener = true;
        }
        this.listeners[eventName].push(listenerFunc);
        // If we haven't added a window listener for this event and it requires one,
        // go ahead and add it
        const windowListener = this.windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
        }
        if (firstListener) {
            this.sendRetainedArgumentsForEvent(eventName);
        }
        const remove = async () => this.removeListener(eventName, listenerFunc);
        const p = Promise.resolve({ remove });
        return p;
    }
    async removeAllListeners() {
        this.listeners = {};
        for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
        }
        this.windowListeners = {};
    }
    notifyListeners(eventName, data, retainUntilConsumed) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            if (retainUntilConsumed) {
                let args = this.retainedEventArguments[eventName];
                if (!args) {
                    args = [];
                }
                args.push(data);
                this.retainedEventArguments[eventName] = args;
            }
            return;
        }
        listeners.forEach((listener) => listener(data));
    }
    hasListeners(eventName) {
        return !!this.listeners[eventName].length;
    }
    registerWindowListener(windowEventName, pluginEventName) {
        this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: (event) => {
                this.notifyListeners(pluginEventName, event);
            },
        };
    }
    unimplemented(msg = 'not implemented') {
        return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
    }
    unavailable(msg = 'not available') {
        return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
    }
    async removeListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            return;
        }
        const index = listeners.indexOf(listenerFunc);
        this.listeners[eventName].splice(index, 1);
        // If there are no more listeners for this type of event,
        // remove the window listener
        if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
        }
    }
    addWindowListener(handle) {
        window.addEventListener(handle.windowEventName, handle.handler);
        handle.registered = true;
    }
    removeWindowListener(handle) {
        if (!handle) {
            return;
        }
        window.removeEventListener(handle.windowEventName, handle.handler);
        handle.registered = false;
    }
    sendRetainedArgumentsForEvent(eventName) {
        const args = this.retainedEventArguments[eventName];
        if (!args) {
            return;
        }
        delete this.retainedEventArguments[eventName];
        args.forEach((arg) => {
            this.notifyListeners(eventName, arg);
        });
    }
}
/******** END WEB VIEW PLUGIN ********/
/******** COOKIES PLUGIN ********/
/**
 * Safely web encode a string value (inspired by js-cookie)
 * @param str The string value to encode
 */
const encode = (str) => encodeURIComponent(str)
    .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
    .replace(/[()]/g, escape);
/**
 * Safely web decode a string value (inspired by js-cookie)
 * @param str The string value to decode
 */
const decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
class CapacitorCookiesPluginWeb extends WebPlugin {
    async getCookies() {
        const cookies = document.cookie;
        const cookieMap = {};
        cookies.split(';').forEach((cookie) => {
            if (cookie.length <= 0)
                return;
            // Replace first "=" with CAP_COOKIE to prevent splitting on additional "="
            let [key, value] = cookie.replace(/=/, 'CAP_COOKIE').split('CAP_COOKIE');
            key = decode(key).trim();
            value = decode(value).trim();
            cookieMap[key] = value;
        });
        return cookieMap;
    }
    async setCookie(options) {
        try {
            // Safely Encoded Key/Value
            const encodedKey = encode(options.key);
            const encodedValue = encode(options.value);
            // Clean & sanitize options
            const expires = `; expires=${(options.expires || '').replace('expires=', '')}`; // Default is "; expires="
            const path = (options.path || '/').replace('path=', ''); // Default is "path=/"
            const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : '';
            document.cookie = `${encodedKey}=${encodedValue || ''}${expires}; path=${path}; ${domain};`;
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    async deleteCookie(options) {
        try {
            document.cookie = `${options.key}=; Max-Age=0`;
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    async clearCookies() {
        try {
            const cookies = document.cookie.split(';') || [];
            for (const cookie of cookies) {
                document.cookie = cookie.replace(/^ +/, '').replace(/=.*/, `=;expires=${new Date().toUTCString()};path=/`);
            }
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    async clearAllCookies() {
        try {
            await this.clearCookies();
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
}
registerPlugin('CapacitorCookies', {
    web: () => new CapacitorCookiesPluginWeb(),
});
// UTILITY FUNCTIONS
/**
 * Read in a Blob value and return it as a base64 string
 * @param blob The blob value to convert to a base64 string
 */
const readBlobAsBase64 = async (blob) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
        const base64String = reader.result;
        // remove prefix "data:application/pdf;base64,"
        resolve(base64String.indexOf(',') >= 0 ? base64String.split(',')[1] : base64String);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(blob);
});
/**
 * Normalize an HttpHeaders map by lowercasing all of the values
 * @param headers The HttpHeaders object to normalize
 */
const normalizeHttpHeaders = (headers = {}) => {
    const originalKeys = Object.keys(headers);
    const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
    const normalized = loweredKeys.reduce((acc, key, index) => {
        acc[key] = headers[originalKeys[index]];
        return acc;
    }, {});
    return normalized;
};
/**
 * Builds a string of url parameters that
 * @param params A map of url parameters
 * @param shouldEncode true if you should encodeURIComponent() the values (true by default)
 */
const buildUrlParams = (params, shouldEncode = true) => {
    if (!params)
        return null;
    const output = Object.entries(params).reduce((accumulator, entry) => {
        const [key, value] = entry;
        let encodedValue;
        let item;
        if (Array.isArray(value)) {
            item = '';
            value.forEach((str) => {
                encodedValue = shouldEncode ? encodeURIComponent(str) : str;
                item += `${key}=${encodedValue}&`;
            });
            // last character will always be "&" so slice it off
            item.slice(0, -1);
        }
        else {
            encodedValue = shouldEncode ? encodeURIComponent(value) : value;
            item = `${key}=${encodedValue}`;
        }
        return `${accumulator}&${item}`;
    }, '');
    // Remove initial "&" from the reduce
    return output.substr(1);
};
/**
 * Build the RequestInit object based on the options passed into the initial request
 * @param options The Http plugin options
 * @param extra Any extra RequestInit values
 */
const buildRequestInit = (options, extra = {}) => {
    const output = Object.assign({ method: options.method || 'GET', headers: options.headers }, extra);
    // Get the content-type
    const headers = normalizeHttpHeaders(options.headers);
    const type = headers['content-type'] || '';
    // If body is already a string, then pass it through as-is.
    if (typeof options.data === 'string') {
        output.body = options.data;
    }
    // Build request initializers based off of content-type
    else if (type.includes('application/x-www-form-urlencoded')) {
        const params = new URLSearchParams();
        for (const [key, value] of Object.entries(options.data || {})) {
            params.set(key, value);
        }
        output.body = params.toString();
    }
    else if (type.includes('multipart/form-data') || options.data instanceof FormData) {
        const form = new FormData();
        if (options.data instanceof FormData) {
            options.data.forEach((value, key) => {
                form.append(key, value);
            });
        }
        else {
            for (const key of Object.keys(options.data)) {
                form.append(key, options.data[key]);
            }
        }
        output.body = form;
        const headers = new Headers(output.headers);
        headers.delete('content-type'); // content-type will be set by `window.fetch` to includy boundary
        output.headers = headers;
    }
    else if (type.includes('application/json') || typeof options.data === 'object') {
        output.body = JSON.stringify(options.data);
    }
    return output;
};
// WEB IMPLEMENTATION
class CapacitorHttpPluginWeb extends WebPlugin {
    /**
     * Perform an Http request given a set of options
     * @param options Options to build the HTTP request
     */
    async request(options) {
        const requestInit = buildRequestInit(options, options.webFetchExtra);
        const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
        const url = urlParams ? `${options.url}?${urlParams}` : options.url;
        const response = await fetch(url, requestInit);
        const contentType = response.headers.get('content-type') || '';
        // Default to 'text' responseType so no parsing happens
        let { responseType = 'text' } = response.ok ? options : {};
        // If the response content-type is json, force the response to be json
        if (contentType.includes('application/json')) {
            responseType = 'json';
        }
        let data;
        let blob;
        switch (responseType) {
            case 'arraybuffer':
            case 'blob':
                blob = await response.blob();
                data = await readBlobAsBase64(blob);
                break;
            case 'json':
                data = await response.json();
                break;
            case 'document':
            case 'text':
            default:
                data = await response.text();
        }
        // Convert fetch headers to Capacitor HttpHeaders
        const headers = {};
        response.headers.forEach((value, key) => {
            headers[key] = value;
        });
        return {
            data,
            headers,
            status: response.status,
            url: response.url,
        };
    }
    /**
     * Perform an Http GET request given a set of options
     * @param options Options to build the HTTP request
     */
    async get(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: 'GET' }));
    }
    /**
     * Perform an Http POST request given a set of options
     * @param options Options to build the HTTP request
     */
    async post(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: 'POST' }));
    }
    /**
     * Perform an Http PUT request given a set of options
     * @param options Options to build the HTTP request
     */
    async put(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: 'PUT' }));
    }
    /**
     * Perform an Http PATCH request given a set of options
     * @param options Options to build the HTTP request
     */
    async patch(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: 'PATCH' }));
    }
    /**
     * Perform an Http DELETE request given a set of options
     * @param options Options to build the HTTP request
     */
    async delete(options) {
        return this.request(Object.assign(Object.assign({}, options), { method: 'DELETE' }));
    }
}
registerPlugin('CapacitorHttp', {
    web: () => new CapacitorHttpPluginWeb(),
});

const App = registerPlugin('App', {
    web: () => import('./web-B8YFCQgT.js').then(m => new m.AppWeb()),
});

const SplashScreen = registerPlugin('SplashScreen', {
    web: () => import('./web-aFjPH8MG.js').then(m => new m.SplashScreenWeb()),
});

const Network = registerPlugin('Network', {
    web: () => import('./NetworkWeb-BCQOcP-g.js').then(m => new m.NetworkWeb()),
});

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject$1(value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
}

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/** Used to match a single whitespace character. */
var reWhitespace = /\s/;

/**
 * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
 * character of `string`.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {number} Returns the index of the last non-whitespace character.
 */
function trimmedEndIndex(string) {
  var index = string.length;

  while (index-- && reWhitespace.test(string.charAt(index))) {}
  return index;
}

/** Used to match leading whitespace. */
var reTrimStart = /^\s+/;

/**
 * The base implementation of `_.trim`.
 *
 * @private
 * @param {string} string The string to trim.
 * @returns {string} Returns the trimmed string.
 */
function baseTrim(string) {
  return string
    ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, '')
    : string;
}

/** Built-in value references. */
var Symbol$1 = root.Symbol;

/** Used for built-in method references. */
var objectProto$1 = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty$1 = objectProto$1.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString$1 = objectProto$1.toString;

/** Built-in value references. */
var symToStringTag$1 = Symbol$1 ? Symbol$1.toStringTag : undefined;

/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */
function getRawTag(value) {
  var isOwn = hasOwnProperty$1.call(value, symToStringTag$1),
      tag = value[symToStringTag$1];

  try {
    value[symToStringTag$1] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString$1.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag$1] = tag;
    } else {
      delete value[symToStringTag$1];
    }
  }
  return result;
}

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */
function objectToString(value) {
  return nativeObjectToString.call(value);
}

/** `Object#toString` result references. */
var nullTag = '[object Null]',
    undefinedTag = '[object Undefined]';

/** Built-in value references. */
var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : undefined;

/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }
  return (symToStringTag && symToStringTag in Object(value))
    ? getRawTag(value)
    : objectToString(value);
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return value != null && typeof value == 'object';
}

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && baseGetTag(value) == symbolTag);
}

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject$1(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject$1(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

/** Error message constants. */
var FUNC_ERROR_TEXT$1 = 'Expected a function';

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT$1);
  }
  wait = toNumber(wait) || 0;
  if (isObject$1(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        timeWaiting = wait - timeSinceLastCall;

    return maxing
      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
      : timeWaiting;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

const Toast = registerPlugin('Toast', {
    web: () => import('./web-BPnREJdF.js').then(m => new m.ToastWeb()),
});

const Device = registerPlugin('Device', {
    web: () => import('./web-DH2_hQ5o.js').then(m => new m.DeviceWeb()),
});

/**
 * @module constants
 * @summary Useful constants
 * @description
 * Collection of useful date constants.
 *
 * The constants could be imported from `date-fns/constants`:
 *
 * ```ts
 * import { maxTime, minTime } from "./constants/date-fns/constants";
 *
 * function isAllowedTime(time) {
 *   return time <= maxTime && time >= minTime;
 * }
 * ```
 */


/**
 * @constant
 * @name millisecondsInWeek
 * @summary Milliseconds in 1 week.
 */
const millisecondsInWeek = 604800000;

/**
 * @constant
 * @name millisecondsInDay
 * @summary Milliseconds in 1 day.
 */
const millisecondsInDay = 86400000;

/**
 * @constant
 * @name millisecondsInMinute
 * @summary Milliseconds in 1 minute
 */
const millisecondsInMinute = 60000;

/**
 * @constant
 * @name minutesInYear
 * @summary Minutes in 1 year.
 */
const minutesInYear = 525600;

/**
 * @constant
 * @name minutesInMonth
 * @summary Minutes in 1 month.
 */
const minutesInMonth = 43200;

/**
 * @constant
 * @name minutesInDay
 * @summary Minutes in 1 day.
 */
const minutesInDay = 1440;

/**
 * @constant
 * @name constructFromSymbol
 * @summary Symbol enabling Date extensions to inherit properties from the reference date.
 *
 * The symbol is used to enable the `constructFrom` function to construct a date
 * using a reference date and a value. It allows to transfer extra properties
 * from the reference date to the new date. It's useful for extensions like
 * [`TZDate`](https://github.com/date-fns/tz) that accept a time zone as
 * a constructor argument.
 */
const constructFromSymbol = Symbol.for("constructDateFrom");

/**
 * @name constructFrom
 * @category Generic Helpers
 * @summary Constructs a date using the reference date and the value
 *
 * @description
 * The function constructs a new date using the constructor from the reference
 * date and the given value. It helps to build generic functions that accept
 * date extensions.
 *
 * It defaults to `Date` if the passed reference date is a number or a string.
 *
 * Starting from v3.7.0, it allows to construct a date using `[Symbol.for("constructDateFrom")]`
 * enabling to transfer extra properties from the reference date to the new date.
 * It's useful for extensions like [`TZDate`](https://github.com/date-fns/tz)
 * that accept a time zone as a constructor argument.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 *
 * @param date - The reference date to take constructor from
 * @param value - The value to create the date
 *
 * @returns Date initialized using the given date and value
 *
 * @example
 * import { constructFrom } from "./constructFrom/date-fns";
 *
 * // A function that clones a date preserving the original type
 * function cloneDate<DateType extends Date>(date: DateType): DateType {
 *   return constructFrom(
 *     date, // Use constructor from the given date
 *     date.getTime() // Use the date value to create a new date
 *   );
 * }
 */
function constructFrom(date, value) {
  if (typeof date === "function") return date(value);

  if (date && typeof date === "object" && constructFromSymbol in date)
    return date[constructFromSymbol](value);

  if (date instanceof Date) return new date.constructor(value);

  return new Date(value);
}

/**
 * @name toDate
 * @category Common Helpers
 * @summary Convert the given argument to an instance of Date.
 *
 * @description
 * Convert the given argument to an instance of Date.
 *
 * If the argument is an instance of Date, the function returns its clone.
 *
 * If the argument is a number, it is treated as a timestamp.
 *
 * If the argument is none of the above, the function returns Invalid Date.
 *
 * Starting from v3.7.0, it clones a date using `[Symbol.for("constructDateFrom")]`
 * enabling to transfer extra properties from the reference date to the new date.
 * It's useful for extensions like [`TZDate`](https://github.com/date-fns/tz)
 * that accept a time zone as a constructor argument.
 *
 * **Note**: *all* Date arguments passed to any *date-fns* function is processed by `toDate`.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param argument - The value to convert
 *
 * @returns The parsed date in the local time zone
 *
 * @example
 * // Clone the date:
 * const result = toDate(new Date(2014, 1, 11, 11, 30, 30))
 * //=> Tue Feb 11 2014 11:30:30
 *
 * @example
 * // Convert the timestamp to date:
 * const result = toDate(1392098430000)
 * //=> Tue Feb 11 2014 11:30:30
 */
function toDate(argument, context) {
  // [TODO] Get rid of `toDate` or `constructFrom`?
  return constructFrom(context || argument, argument);
}

/**
 * The {@link addMilliseconds} function options.
 */

/**
 * @name addMilliseconds
 * @category Millisecond Helpers
 * @summary Add the specified number of milliseconds to the given date.
 *
 * @description
 * Add the specified number of milliseconds to the given date.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The date to be changed
 * @param amount - The amount of milliseconds to be added.
 * @param options - The options object
 *
 * @returns The new date with the milliseconds added
 *
 * @example
 * // Add 750 milliseconds to 10 July 2014 12:45:30.000:
 * const result = addMilliseconds(new Date(2014, 6, 10, 12, 45, 30, 0), 750)
 * //=> Thu Jul 10 2014 12:45:30.750
 */
function addMilliseconds(date, amount, options) {
  return constructFrom(date, +toDate(date) + amount);
}

let defaultOptions = {};

function getDefaultOptions() {
  return defaultOptions;
}

/**
 * The {@link startOfWeek} function options.
 */

/**
 * @name startOfWeek
 * @category Week Helpers
 * @summary Return the start of a week for the given date.
 *
 * @description
 * Return the start of a week for the given date.
 * The result will be in the local timezone.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The original date
 * @param options - An object with options
 *
 * @returns The start of a week
 *
 * @example
 * // The start of a week for 2 September 2014 11:55:00:
 * const result = startOfWeek(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Sun Aug 31 2014 00:00:00
 *
 * @example
 * // If the week starts on Monday, the start of the week for 2 September 2014 11:55:00:
 * const result = startOfWeek(new Date(2014, 8, 2, 11, 55, 0), { weekStartsOn: 1 })
 * //=> Mon Sep 01 2014 00:00:00
 */
function startOfWeek(date, options) {
  const defaultOptions = getDefaultOptions();
  const weekStartsOn =
    options?.weekStartsOn ??
    options?.locale?.options?.weekStartsOn ??
    defaultOptions.weekStartsOn ??
    defaultOptions.locale?.options?.weekStartsOn ??
    0;

  const _date = toDate(date, options?.in);
  const day = _date.getDay();
  const diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;

  _date.setDate(_date.getDate() - diff);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

/**
 * The {@link startOfISOWeek} function options.
 */

/**
 * @name startOfISOWeek
 * @category ISO Week Helpers
 * @summary Return the start of an ISO week for the given date.
 *
 * @description
 * Return the start of an ISO week for the given date.
 * The result will be in the local timezone.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The original date
 * @param options - An object with options
 *
 * @returns The start of an ISO week
 *
 * @example
 * // The start of an ISO week for 2 September 2014 11:55:00:
 * const result = startOfISOWeek(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Mon Sep 01 2014 00:00:00
 */
function startOfISOWeek(date, options) {
  return startOfWeek(date, { ...options, weekStartsOn: 1 });
}

/**
 * The {@link getISOWeekYear} function options.
 */

/**
 * @name getISOWeekYear
 * @category ISO Week-Numbering Year Helpers
 * @summary Get the ISO week-numbering year of the given date.
 *
 * @description
 * Get the ISO week-numbering year of the given date,
 * which always starts 3 days before the year's first Thursday.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * @param date - The given date
 *
 * @returns The ISO week-numbering year
 *
 * @example
 * // Which ISO-week numbering year is 2 January 2005?
 * const result = getISOWeekYear(new Date(2005, 0, 2))
 * //=> 2004
 */
function getISOWeekYear(date, options) {
  const _date = toDate(date, options?.in);
  const year = _date.getFullYear();

  const fourthOfJanuaryOfNextYear = constructFrom(_date, 0);
  fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = startOfISOWeek(fourthOfJanuaryOfNextYear);

  const fourthOfJanuaryOfThisYear = constructFrom(_date, 0);
  fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
  fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = startOfISOWeek(fourthOfJanuaryOfThisYear);

  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}

/**
 * Google Chrome as of 67.0.3396.87 introduced timezones with offset that includes seconds.
 * They usually appear for dates that denote time before the timezones were introduced
 * (e.g. for 'Europe/Prague' timezone the offset is GMT+00:57:44 before 1 October 1891
 * and GMT+01:00:00 after that date)
 *
 * Date#getTimezoneOffset returns the offset in minutes and would return 57 for the example above,
 * which would lead to incorrect calculations.
 *
 * This function returns the timezone offset in milliseconds that takes seconds in account.
 */
function getTimezoneOffsetInMilliseconds(date) {
  const _date = toDate(date);
  const utcDate = new Date(
    Date.UTC(
      _date.getFullYear(),
      _date.getMonth(),
      _date.getDate(),
      _date.getHours(),
      _date.getMinutes(),
      _date.getSeconds(),
      _date.getMilliseconds(),
    ),
  );
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

function normalizeDates(context, ...dates) {
  const normalize = constructFrom.bind(
    null,
    context || dates.find((date) => typeof date === "object"),
  );
  return dates.map(normalize);
}

/**
 * The {@link startOfDay} function options.
 */

/**
 * @name startOfDay
 * @category Day Helpers
 * @summary Return the start of a day for the given date.
 *
 * @description
 * Return the start of a day for the given date.
 * The result will be in the local timezone.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The original date
 * @param options - The options
 *
 * @returns The start of a day
 *
 * @example
 * // The start of a day for 2 September 2014 11:55:00:
 * const result = startOfDay(new Date(2014, 8, 2, 11, 55, 0))
 * //=> Tue Sep 02 2014 00:00:00
 */
function startOfDay(date, options) {
  const _date = toDate(date, options?.in);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

/**
 * The {@link differenceInCalendarDays} function options.
 */

/**
 * @name differenceInCalendarDays
 * @category Day Helpers
 * @summary Get the number of calendar days between the given dates.
 *
 * @description
 * Get the number of calendar days between the given dates. This means that the times are removed
 * from the dates and then the difference in days is calculated.
 *
 * @param laterDate - The later date
 * @param earlierDate - The earlier date
 * @param options - The options object
 *
 * @returns The number of calendar days
 *
 * @example
 * // How many calendar days are between
 * // 2 July 2011 23:00:00 and 2 July 2012 00:00:00?
 * const result = differenceInCalendarDays(
 *   new Date(2012, 6, 2, 0, 0),
 *   new Date(2011, 6, 2, 23, 0)
 * )
 * //=> 366
 * // How many calendar days are between
 * // 2 July 2011 23:59:00 and 3 July 2011 00:01:00?
 * const result = differenceInCalendarDays(
 *   new Date(2011, 6, 3, 0, 1),
 *   new Date(2011, 6, 2, 23, 59)
 * )
 * //=> 1
 */
function differenceInCalendarDays(laterDate, earlierDate, options) {
  const [laterDate_, earlierDate_] = normalizeDates(
    options?.in,
    laterDate,
    earlierDate,
  );

  const laterStartOfDay = startOfDay(laterDate_);
  const earlierStartOfDay = startOfDay(earlierDate_);

  const laterTimestamp =
    +laterStartOfDay - getTimezoneOffsetInMilliseconds(laterStartOfDay);
  const earlierTimestamp =
    +earlierStartOfDay - getTimezoneOffsetInMilliseconds(earlierStartOfDay);

  // Round the number of days to the nearest integer because the number of
  // milliseconds in a day is not constant (e.g. it's different in the week of
  // the daylight saving time clock shift).
  return Math.round((laterTimestamp - earlierTimestamp) / millisecondsInDay);
}

/**
 * The {@link startOfISOWeekYear} function options.
 */

/**
 * @name startOfISOWeekYear
 * @category ISO Week-Numbering Year Helpers
 * @summary Return the start of an ISO week-numbering year for the given date.
 *
 * @description
 * Return the start of an ISO week-numbering year,
 * which always starts 3 days before the year's first Thursday.
 * The result will be in the local timezone.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The original date
 * @param options - An object with options
 *
 * @returns The start of an ISO week-numbering year
 *
 * @example
 * // The start of an ISO week-numbering year for 2 July 2005:
 * const result = startOfISOWeekYear(new Date(2005, 6, 2))
 * //=> Mon Jan 03 2005 00:00:00
 */
function startOfISOWeekYear(date, options) {
  const year = getISOWeekYear(date, options);
  const fourthOfJanuary = constructFrom(date, 0);
  fourthOfJanuary.setFullYear(year, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  return startOfISOWeek(fourthOfJanuary);
}

/**
 * The {@link addSeconds} function options.
 */

/**
 * @name addSeconds
 * @category Second Helpers
 * @summary Add the specified number of seconds to the given date.
 *
 * @description
 * Add the specified number of seconds to the given date.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The date to be changed
 * @param amount - The amount of seconds to be added.
 * @param options - An object with options
 *
 * @returns The new date with the seconds added
 *
 * @example
 * // Add 30 seconds to 10 July 2014 12:45:00:
 * const result = addSeconds(new Date(2014, 6, 10, 12, 45, 0), 30)
 * //=> Thu Jul 10 2014 12:45:30
 */
function addSeconds(date, amount, options) {
  return addMilliseconds(date, amount * 1000);
}

/**
 * @name compareAsc
 * @category Common Helpers
 * @summary Compare the two dates and return -1, 0 or 1.
 *
 * @description
 * Compare the two dates and return 1 if the first date is after the second,
 * -1 if the first date is before the second or 0 if dates are equal.
 *
 * @param dateLeft - The first date to compare
 * @param dateRight - The second date to compare
 *
 * @returns The result of the comparison
 *
 * @example
 * // Compare 11 February 1987 and 10 July 1989:
 * const result = compareAsc(new Date(1987, 1, 11), new Date(1989, 6, 10))
 * //=> -1
 *
 * @example
 * // Sort the array of dates:
 * const result = [
 *   new Date(1995, 6, 2),
 *   new Date(1987, 1, 11),
 *   new Date(1989, 6, 10)
 * ].sort(compareAsc)
 * //=> [
 * //   Wed Feb 11 1987 00:00:00,
 * //   Mon Jul 10 1989 00:00:00,
 * //   Sun Jul 02 1995 00:00:00
 * // ]
 */
function compareAsc(dateLeft, dateRight) {
  const diff = +toDate(dateLeft) - +toDate(dateRight);

  if (diff < 0) return -1;
  else if (diff > 0) return 1;

  // Return 0 if diff is 0; return NaN if diff is NaN
  return diff;
}

/**
 * @name constructNow
 * @category Generic Helpers
 * @summary Constructs a new current date using the passed value constructor.
 * @pure false
 *
 * @description
 * The function constructs a new current date using the constructor from
 * the reference date. It helps to build generic functions that accept date
 * extensions and use the current date.
 *
 * It defaults to `Date` if the passed reference date is a number or a string.
 *
 * @param date - The reference date to take constructor from
 *
 * @returns Current date initialized using the given date constructor
 *
 * @example
 * import { constructNow, isSameDay } from 'date-fns'
 *
 * function isToday<DateType extends Date>(
 *   date: DateArg<DateType>,
 * ): boolean {
 *   // If we were to use `new Date()` directly, the function would  behave
 *   // differently in different timezones and return false for the same date.
 *   return isSameDay(date, constructNow(date));
 * }
 */
function constructNow(date) {
  return constructFrom(date, Date.now());
}

/**
 * @name isDate
 * @category Common Helpers
 * @summary Is the given value a date?
 *
 * @description
 * Returns true if the given value is an instance of Date. The function works for dates transferred across iframes.
 *
 * @param value - The value to check
 *
 * @returns True if the given value is a date
 *
 * @example
 * // For a valid date:
 * const result = isDate(new Date())
 * //=> true
 *
 * @example
 * // For an invalid date:
 * const result = isDate(new Date(NaN))
 * //=> true
 *
 * @example
 * // For some value:
 * const result = isDate('2014-02-31')
 * //=> false
 *
 * @example
 * // For an object:
 * const result = isDate({})
 * //=> false
 */
function isDate(value) {
  return (
    value instanceof Date ||
    (typeof value === "object" &&
      Object.prototype.toString.call(value) === "[object Date]")
  );
}

/**
 * @name isValid
 * @category Common Helpers
 * @summary Is the given date valid?
 *
 * @description
 * Returns false if argument is Invalid Date and true otherwise.
 * Argument is converted to Date using `toDate`. See [toDate](https://date-fns.org/docs/toDate)
 * Invalid Date is a Date, whose time value is NaN.
 *
 * Time value of Date: http://es5.github.io/#x15.9.1.1
 *
 * @param date - The date to check
 *
 * @returns The date is valid
 *
 * @example
 * // For the valid date:
 * const result = isValid(new Date(2014, 1, 31))
 * //=> true
 *
 * @example
 * // For the value, convertible into a date:
 * const result = isValid(1393804800000)
 * //=> true
 *
 * @example
 * // For the invalid date:
 * const result = isValid(new Date(''))
 * //=> false
 */
function isValid(date) {
  return !((!isDate(date) && typeof date !== "number") || isNaN(+toDate(date)));
}

function getRoundingMethod(method) {
  return (number) => {
    const round = method ? Math[method] : Math.trunc;
    const result = round(number);
    // Prevent negative zero
    return result === 0 ? 0 : result;
  };
}

/**
 * The {@link startOfYear} function options.
 */

/**
 * @name startOfYear
 * @category Year Helpers
 * @summary Return the start of a year for the given date.
 *
 * @description
 * Return the start of a year for the given date.
 * The result will be in the local timezone.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type, it is the type returned from the context function if it is passed, or inferred from the arguments.
 *
 * @param date - The original date
 * @param options - The options
 *
 * @returns The start of a year
 *
 * @example
 * // The start of a year for 2 September 2014 11:55:00:
 * const result = startOfYear(new Date(2014, 8, 2, 11, 55, 00))
 * //=> Wed Jan 01 2014 00:00:00
 */
function startOfYear(date, options) {
  const date_ = toDate(date, options?.in);
  date_.setFullYear(date_.getFullYear(), 0, 1);
  date_.setHours(0, 0, 0, 0);
  return date_;
}

const formatDistanceLocale = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds",
  },

  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds",
  },

  halfAMinute: "half a minute",

  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes",
  },

  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes",
  },

  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours",
  },

  xHours: {
    one: "1 hour",
    other: "{{count}} hours",
  },

  xDays: {
    one: "1 day",
    other: "{{count}} days",
  },

  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks",
  },

  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks",
  },

  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months",
  },

  xMonths: {
    one: "1 month",
    other: "{{count}} months",
  },

  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years",
  },

  xYears: {
    one: "1 year",
    other: "{{count}} years",
  },

  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years",
  },

  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years",
  },
};

const formatDistance = (token, count, options) => {
  let result;

  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", count.toString());
  }

  if (options?.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "in " + result;
    } else {
      return result + " ago";
    }
  }

  return result;
};

function buildFormatLongFn(args) {
  return (options = {}) => {
    // TODO: Remove String()
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

const dateFormats = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy",
};

const timeFormats = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a",
};

const dateTimeFormats = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}",
};

const formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full",
  }),

  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full",
  }),

  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full",
  }),
};

const formatRelativeLocale = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P",
};

const formatRelative$1 = (token, _date, _baseDate, _options) =>
  formatRelativeLocale[token];

/**
 * The localize function argument callback which allows to convert raw value to
 * the actual type.
 *
 * @param value - The value to convert
 *
 * @returns The converted value
 */

/**
 * The map of localized values for each width.
 */

/**
 * The index type of the locale unit value. It types conversion of units of
 * values that don't start at 0 (i.e. quarters).
 */

/**
 * Converts the unit value to the tuple of values.
 */

/**
 * The tuple of localized era values. The first element represents BC,
 * the second element represents AD.
 */

/**
 * The tuple of localized quarter values. The first element represents Q1.
 */

/**
 * The tuple of localized day values. The first element represents Sunday.
 */

/**
 * The tuple of localized month values. The first element represents January.
 */

function buildLocalizeFn(args) {
  return (value, options) => {
    const context = options?.context ? String(options.context) : "standalone";

    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = options?.width ? String(options.width) : defaultWidth;

      valuesArray =
        args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = options?.width ? String(options.width) : args.defaultWidth;

      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;

    // @ts-expect-error - For some reason TypeScript just don't want to match it, no matter how hard we try. I challenge you to try to remove it!
    return valuesArray[index];
  };
}

const eraValues = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"],
};

const quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"],
};

// Note: in English, the names of days of the week and months are capitalized.
// If you are making a new locale based on this one, check if the same is true for the language you're working on.
// Generally, formatted dates should look like they are in the middle of a sentence,
// e.g. in Spanish language the weekdays and months should be in the lowercase.
const monthValues = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ],

  wide: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ],
};

const dayValues = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ],
};

const dayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night",
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night",
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night",
  },
};

const formattingDayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night",
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night",
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night",
  },
};

const ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);

  // If ordinal numbers depend on context, for example,
  // if they are different for different grammatical genders,
  // use `options.unit`.
  //
  // `unit` can be 'year', 'quarter', 'month', 'week', 'date', 'dayOfYear',
  // 'day', 'hour', 'minute', 'second'.

  const rem100 = number % 100;
  if (rem100 > 20 || rem100 < 10) {
    switch (rem100 % 10) {
      case 1:
        return number + "st";
      case 2:
        return number + "nd";
      case 3:
        return number + "rd";
    }
  }
  return number + "th";
};

const localize = {
  ordinalNumber,

  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide",
  }),

  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: (quarter) => quarter - 1,
  }),

  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide",
  }),

  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide",
  }),

  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide",
  }),
};

function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;

    const matchPattern =
      (width && args.matchPatterns[width]) ||
      args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);

    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];

    const parsePatterns =
      (width && args.parsePatterns[width]) ||
      args.parsePatterns[args.defaultParseWidth];

    const key = Array.isArray(parsePatterns)
      ? findIndex(parsePatterns, (pattern) => pattern.test(matchedString))
      : // [TODO] -- I challenge you to fix the type
        findKey(parsePatterns, (pattern) => pattern.test(matchedString));

    let value;

    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback
      ? // [TODO] -- I challenge you to fix the type
        options.valueCallback(value)
      : value;

    const rest = string.slice(matchedString.length);

    return { value, rest };
  };
}

function findKey(object, predicate) {
  for (const key in object) {
    if (
      Object.prototype.hasOwnProperty.call(object, key) &&
      predicate(object[key])
    ) {
      return key;
    }
  }
  return undefined;
}

function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return undefined;
}

function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];

    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback
      ? args.valueCallback(parseResult[0])
      : parseResult[0];

    // [TODO] I challenge you to fix the type
    value = options.valueCallback ? options.valueCallback(value) : value;

    const rest = string.slice(matchedString.length);

    return { value, rest };
  };
}

const matchOrdinalNumberPattern = /^(\d+)(th|st|nd|rd)?/i;
const parseOrdinalNumberPattern = /\d+/i;

const matchEraPatterns = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i,
};
const parseEraPatterns = {
  any: [/^b/i, /^(a|c)/i],
};

const matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i,
};
const parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i],
};

const matchMonthPatterns = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i,
};
const parseMonthPatterns = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i,
  ],

  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i,
  ],
};

const matchDayPatterns = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i,
};
const parseDayPatterns = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i],
};

const matchDayPeriodPatterns = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i,
};
const parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i,
  },
};

const match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: (value) => parseInt(value, 10),
  }),

  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any",
  }),

  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: (index) => index + 1,
  }),

  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any",
  }),

  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any",
  }),

  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any",
  }),
};

/**
 * @category Locales
 * @summary English locale (United States).
 * @language English
 * @iso-639-2 eng
 * @author Sasha Koss [@kossnocorp](https://github.com/kossnocorp)
 * @author Lesha Koss [@leshakoss](https://github.com/leshakoss)
 */
const enUS = {
  code: "en-US",
  formatDistance: formatDistance,
  formatLong: formatLong,
  formatRelative: formatRelative$1,
  localize: localize,
  match: match,
  options: {
    weekStartsOn: 0 /* Sunday */,
    firstWeekContainsDate: 1,
  },
};

/**
 * The {@link getDayOfYear} function options.
 */

/**
 * @name getDayOfYear
 * @category Day Helpers
 * @summary Get the day of the year of the given date.
 *
 * @description
 * Get the day of the year of the given date.
 *
 * @param date - The given date
 * @param options - The options
 *
 * @returns The day of year
 *
 * @example
 * // Which day of the year is 2 July 2014?
 * const result = getDayOfYear(new Date(2014, 6, 2))
 * //=> 183
 */
function getDayOfYear(date, options) {
  const _date = toDate(date, options?.in);
  const diff = differenceInCalendarDays(_date, startOfYear(_date));
  const dayOfYear = diff + 1;
  return dayOfYear;
}

/**
 * The {@link getISOWeek} function options.
 */

/**
 * @name getISOWeek
 * @category ISO Week Helpers
 * @summary Get the ISO week of the given date.
 *
 * @description
 * Get the ISO week of the given date.
 *
 * ISO week-numbering year: http://en.wikipedia.org/wiki/ISO_week_date
 *
 * @param date - The given date
 * @param options - The options
 *
 * @returns The ISO week
 *
 * @example
 * // Which week of the ISO-week numbering year is 2 January 2005?
 * const result = getISOWeek(new Date(2005, 0, 2))
 * //=> 53
 */
function getISOWeek(date, options) {
  const _date = toDate(date, options?.in);
  const diff = +startOfISOWeek(_date) - +startOfISOWeekYear(_date);

  // Round the number of weeks to the nearest integer because the number of
  // milliseconds in a week is not constant (e.g. it's different in the week of
  // the daylight saving time clock shift).
  return Math.round(diff / millisecondsInWeek) + 1;
}

/**
 * The {@link getWeekYear} function options.
 */

/**
 * @name getWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Get the local week-numbering year of the given date.
 *
 * @description
 * Get the local week-numbering year of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
 *
 * @param date - The given date
 * @param options - An object with options.
 *
 * @returns The local week-numbering year
 *
 * @example
 * // Which week numbering year is 26 December 2004 with the default settings?
 * const result = getWeekYear(new Date(2004, 11, 26))
 * //=> 2005
 *
 * @example
 * // Which week numbering year is 26 December 2004 if week starts on Saturday?
 * const result = getWeekYear(new Date(2004, 11, 26), { weekStartsOn: 6 })
 * //=> 2004
 *
 * @example
 * // Which week numbering year is 26 December 2004 if the first week contains 4 January?
 * const result = getWeekYear(new Date(2004, 11, 26), { firstWeekContainsDate: 4 })
 * //=> 2004
 */
function getWeekYear(date, options) {
  const _date = toDate(date, options?.in);
  const year = _date.getFullYear();

  const defaultOptions = getDefaultOptions();
  const firstWeekContainsDate =
    options?.firstWeekContainsDate ??
    options?.locale?.options?.firstWeekContainsDate ??
    defaultOptions.firstWeekContainsDate ??
    defaultOptions.locale?.options?.firstWeekContainsDate ??
    1;

  const firstWeekOfNextYear = constructFrom(options?.in || date, 0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = startOfWeek(firstWeekOfNextYear, options);

  const firstWeekOfThisYear = constructFrom(options?.in || date, 0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = startOfWeek(firstWeekOfThisYear, options);

  if (+_date >= +startOfNextYear) {
    return year + 1;
  } else if (+_date >= +startOfThisYear) {
    return year;
  } else {
    return year - 1;
  }
}

/**
 * The {@link startOfWeekYear} function options.
 */

/**
 * @name startOfWeekYear
 * @category Week-Numbering Year Helpers
 * @summary Return the start of a local week-numbering year for the given date.
 *
 * @description
 * Return the start of a local week-numbering year.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 * @typeParam ResultDate - The result `Date` type.
 *
 * @param date - The original date
 * @param options - An object with options
 *
 * @returns The start of a week-numbering year
 *
 * @example
 * // The start of an a week-numbering year for 2 July 2005 with default settings:
 * const result = startOfWeekYear(new Date(2005, 6, 2))
 * //=> Sun Dec 26 2004 00:00:00
 *
 * @example
 * // The start of a week-numbering year for 2 July 2005
 * // if Monday is the first day of week
 * // and 4 January is always in the first week of the year:
 * const result = startOfWeekYear(new Date(2005, 6, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> Mon Jan 03 2005 00:00:00
 */
function startOfWeekYear(date, options) {
  const defaultOptions = getDefaultOptions();
  const firstWeekContainsDate =
    options?.firstWeekContainsDate ??
    options?.locale?.options?.firstWeekContainsDate ??
    defaultOptions.firstWeekContainsDate ??
    defaultOptions.locale?.options?.firstWeekContainsDate ??
    1;

  const year = getWeekYear(date, options);
  const firstWeek = constructFrom(options?.in || date, 0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  const _date = startOfWeek(firstWeek, options);
  return _date;
}

/**
 * The {@link getWeek} function options.
 */

/**
 * @name getWeek
 * @category Week Helpers
 * @summary Get the local week index of the given date.
 *
 * @description
 * Get the local week index of the given date.
 * The exact calculation depends on the values of
 * `options.weekStartsOn` (which is the index of the first day of the week)
 * and `options.firstWeekContainsDate` (which is the day of January, which is always in
 * the first week of the week-numbering year)
 *
 * Week numbering: https://en.wikipedia.org/wiki/Week#The_ISO_week_date_system
 *
 * @param date - The given date
 * @param options - An object with options
 *
 * @returns The week
 *
 * @example
 * // Which week of the local week numbering year is 2 January 2005 with default options?
 * const result = getWeek(new Date(2005, 0, 2))
 * //=> 2
 *
 * @example
 * // Which week of the local week numbering year is 2 January 2005,
 * // if Monday is the first day of the week,
 * // and the first week of the year always contains 4 January?
 * const result = getWeek(new Date(2005, 0, 2), {
 *   weekStartsOn: 1,
 *   firstWeekContainsDate: 4
 * })
 * //=> 53
 */
function getWeek(date, options) {
  const _date = toDate(date, options?.in);
  const diff = +startOfWeek(_date, options) - +startOfWeekYear(_date, options);

  // Round the number of weeks to the nearest integer because the number of
  // milliseconds in a week is not constant (e.g. it's different in the week of
  // the daylight saving time clock shift).
  return Math.round(diff / millisecondsInWeek) + 1;
}

function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

/*
 * |     | Unit                           |     | Unit                           |
 * |-----|--------------------------------|-----|--------------------------------|
 * |  a  | AM, PM                         |  A* |                                |
 * |  d  | Day of month                   |  D  |                                |
 * |  h  | Hour [1-12]                    |  H  | Hour [0-23]                    |
 * |  m  | Minute                         |  M  | Month                          |
 * |  s  | Second                         |  S  | Fraction of second             |
 * |  y  | Year (abs)                     |  Y  |                                |
 *
 * Letters marked by * are not implemented but reserved by Unicode standard.
 */

const lightFormatters = {
  // Year
  y(date, token) {
    // From http://www.unicode.org/reports/tr35/tr35-31/tr35-dates.html#Date_Format_tokens
    // | Year     |     y | yy |   yyy |  yyyy | yyyyy |
    // |----------|-------|----|-------|-------|-------|
    // | AD 1     |     1 | 01 |   001 |  0001 | 00001 |
    // | AD 12    |    12 | 12 |   012 |  0012 | 00012 |
    // | AD 123   |   123 | 23 |   123 |  0123 | 00123 |
    // | AD 1234  |  1234 | 34 |  1234 |  1234 | 01234 |
    // | AD 12345 | 12345 | 45 | 12345 | 12345 | 12345 |

    const signedYear = date.getFullYear();
    // Returns 1 for 1 BC (which is year 0 in JavaScript)
    const year = signedYear > 0 ? signedYear : 1 - signedYear;
    return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
  },

  // Month
  M(date, token) {
    const month = date.getMonth();
    return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
  },

  // Day of the month
  d(date, token) {
    return addLeadingZeros(date.getDate(), token.length);
  },

  // AM or PM
  a(date, token) {
    const dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";

    switch (token) {
      case "a":
      case "aa":
        return dayPeriodEnumValue.toUpperCase();
      case "aaa":
        return dayPeriodEnumValue;
      case "aaaaa":
        return dayPeriodEnumValue[0];
      case "aaaa":
      default:
        return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
    }
  },

  // Hour [1-12]
  h(date, token) {
    return addLeadingZeros(date.getHours() % 12 || 12, token.length);
  },

  // Hour [0-23]
  H(date, token) {
    return addLeadingZeros(date.getHours(), token.length);
  },

  // Minute
  m(date, token) {
    return addLeadingZeros(date.getMinutes(), token.length);
  },

  // Second
  s(date, token) {
    return addLeadingZeros(date.getSeconds(), token.length);
  },

  // Fraction of second
  S(date, token) {
    const numberOfDigits = token.length;
    const milliseconds = date.getMilliseconds();
    const fractionalSeconds = Math.trunc(
      milliseconds * Math.pow(10, numberOfDigits - 3),
    );
    return addLeadingZeros(fractionalSeconds, token.length);
  },
};

const dayPeriodEnum = {
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night",
};

/*
 * |     | Unit                           |     | Unit                           |
 * |-----|--------------------------------|-----|--------------------------------|
 * |  a  | AM, PM                         |  A* | Milliseconds in day            |
 * |  b  | AM, PM, noon, midnight         |  B  | Flexible day period            |
 * |  c  | Stand-alone local day of week  |  C* | Localized hour w/ day period   |
 * |  d  | Day of month                   |  D  | Day of year                    |
 * |  e  | Local day of week              |  E  | Day of week                    |
 * |  f  |                                |  F* | Day of week in month           |
 * |  g* | Modified Julian day            |  G  | Era                            |
 * |  h  | Hour [1-12]                    |  H  | Hour [0-23]                    |
 * |  i! | ISO day of week                |  I! | ISO week of year               |
 * |  j* | Localized hour w/ day period   |  J* | Localized hour w/o day period  |
 * |  k  | Hour [1-24]                    |  K  | Hour [0-11]                    |
 * |  l* | (deprecated)                   |  L  | Stand-alone month              |
 * |  m  | Minute                         |  M  | Month                          |
 * |  n  |                                |  N  |                                |
 * |  o! | Ordinal number modifier        |  O  | Timezone (GMT)                 |
 * |  p! | Long localized time            |  P! | Long localized date            |
 * |  q  | Stand-alone quarter            |  Q  | Quarter                        |
 * |  r* | Related Gregorian year         |  R! | ISO week-numbering year        |
 * |  s  | Second                         |  S  | Fraction of second             |
 * |  t! | Seconds timestamp              |  T! | Milliseconds timestamp         |
 * |  u  | Extended year                  |  U* | Cyclic year                    |
 * |  v* | Timezone (generic non-locat.)  |  V* | Timezone (location)            |
 * |  w  | Local week of year             |  W* | Week of month                  |
 * |  x  | Timezone (ISO-8601 w/o Z)      |  X  | Timezone (ISO-8601)            |
 * |  y  | Year (abs)                     |  Y  | Local week-numbering year      |
 * |  z  | Timezone (specific non-locat.) |  Z* | Timezone (aliases)             |
 *
 * Letters marked by * are not implemented but reserved by Unicode standard.
 *
 * Letters marked by ! are non-standard, but implemented by date-fns:
 * - `o` modifies the previous token to turn it into an ordinal (see `format` docs)
 * - `i` is ISO day of week. For `i` and `ii` is returns numeric ISO week days,
 *   i.e. 7 for Sunday, 1 for Monday, etc.
 * - `I` is ISO week of year, as opposed to `w` which is local week of year.
 * - `R` is ISO week-numbering year, as opposed to `Y` which is local week-numbering year.
 *   `R` is supposed to be used in conjunction with `I` and `i`
 *   for universal ISO week-numbering date, whereas
 *   `Y` is supposed to be used in conjunction with `w` and `e`
 *   for week-numbering date specific to the locale.
 * - `P` is long localized date format
 * - `p` is long localized time format
 */

const formatters = {
  // Era
  G: function (date, token, localize) {
    const era = date.getFullYear() > 0 ? 1 : 0;
    switch (token) {
      // AD, BC
      case "G":
      case "GG":
      case "GGG":
        return localize.era(era, { width: "abbreviated" });
      // A, B
      case "GGGGG":
        return localize.era(era, { width: "narrow" });
      // Anno Domini, Before Christ
      case "GGGG":
      default:
        return localize.era(era, { width: "wide" });
    }
  },

  // Year
  y: function (date, token, localize) {
    // Ordinal number
    if (token === "yo") {
      const signedYear = date.getFullYear();
      // Returns 1 for 1 BC (which is year 0 in JavaScript)
      const year = signedYear > 0 ? signedYear : 1 - signedYear;
      return localize.ordinalNumber(year, { unit: "year" });
    }

    return lightFormatters.y(date, token);
  },

  // Local week-numbering year
  Y: function (date, token, localize, options) {
    const signedWeekYear = getWeekYear(date, options);
    // Returns 1 for 1 BC (which is year 0 in JavaScript)
    const weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;

    // Two digit year
    if (token === "YY") {
      const twoDigitYear = weekYear % 100;
      return addLeadingZeros(twoDigitYear, 2);
    }

    // Ordinal number
    if (token === "Yo") {
      return localize.ordinalNumber(weekYear, { unit: "year" });
    }

    // Padding
    return addLeadingZeros(weekYear, token.length);
  },

  // ISO week-numbering year
  R: function (date, token) {
    const isoWeekYear = getISOWeekYear(date);

    // Padding
    return addLeadingZeros(isoWeekYear, token.length);
  },

  // Extended year. This is a single number designating the year of this calendar system.
  // The main difference between `y` and `u` localizers are B.C. years:
  // | Year | `y` | `u` |
  // |------|-----|-----|
  // | AC 1 |   1 |   1 |
  // | BC 1 |   1 |   0 |
  // | BC 2 |   2 |  -1 |
  // Also `yy` always returns the last two digits of a year,
  // while `uu` pads single digit years to 2 characters and returns other years unchanged.
  u: function (date, token) {
    const year = date.getFullYear();
    return addLeadingZeros(year, token.length);
  },

  // Quarter
  Q: function (date, token, localize) {
    const quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      // 1, 2, 3, 4
      case "Q":
        return String(quarter);
      // 01, 02, 03, 04
      case "QQ":
        return addLeadingZeros(quarter, 2);
      // 1st, 2nd, 3rd, 4th
      case "Qo":
        return localize.ordinalNumber(quarter, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "QQQ":
        return localize.quarter(quarter, {
          width: "abbreviated",
          context: "formatting",
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "QQQQQ":
        return localize.quarter(quarter, {
          width: "narrow",
          context: "formatting",
        });
      // 1st quarter, 2nd quarter, ...
      case "QQQQ":
      default:
        return localize.quarter(quarter, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // Stand-alone quarter
  q: function (date, token, localize) {
    const quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      // 1, 2, 3, 4
      case "q":
        return String(quarter);
      // 01, 02, 03, 04
      case "qq":
        return addLeadingZeros(quarter, 2);
      // 1st, 2nd, 3rd, 4th
      case "qo":
        return localize.ordinalNumber(quarter, { unit: "quarter" });
      // Q1, Q2, Q3, Q4
      case "qqq":
        return localize.quarter(quarter, {
          width: "abbreviated",
          context: "standalone",
        });
      // 1, 2, 3, 4 (narrow quarter; could be not numerical)
      case "qqqqq":
        return localize.quarter(quarter, {
          width: "narrow",
          context: "standalone",
        });
      // 1st quarter, 2nd quarter, ...
      case "qqqq":
      default:
        return localize.quarter(quarter, {
          width: "wide",
          context: "standalone",
        });
    }
  },

  // Month
  M: function (date, token, localize) {
    const month = date.getMonth();
    switch (token) {
      case "M":
      case "MM":
        return lightFormatters.M(date, token);
      // 1st, 2nd, ..., 12th
      case "Mo":
        return localize.ordinalNumber(month + 1, { unit: "month" });
      // Jan, Feb, ..., Dec
      case "MMM":
        return localize.month(month, {
          width: "abbreviated",
          context: "formatting",
        });
      // J, F, ..., D
      case "MMMMM":
        return localize.month(month, {
          width: "narrow",
          context: "formatting",
        });
      // January, February, ..., December
      case "MMMM":
      default:
        return localize.month(month, { width: "wide", context: "formatting" });
    }
  },

  // Stand-alone month
  L: function (date, token, localize) {
    const month = date.getMonth();
    switch (token) {
      // 1, 2, ..., 12
      case "L":
        return String(month + 1);
      // 01, 02, ..., 12
      case "LL":
        return addLeadingZeros(month + 1, 2);
      // 1st, 2nd, ..., 12th
      case "Lo":
        return localize.ordinalNumber(month + 1, { unit: "month" });
      // Jan, Feb, ..., Dec
      case "LLL":
        return localize.month(month, {
          width: "abbreviated",
          context: "standalone",
        });
      // J, F, ..., D
      case "LLLLL":
        return localize.month(month, {
          width: "narrow",
          context: "standalone",
        });
      // January, February, ..., December
      case "LLLL":
      default:
        return localize.month(month, { width: "wide", context: "standalone" });
    }
  },

  // Local week of year
  w: function (date, token, localize, options) {
    const week = getWeek(date, options);

    if (token === "wo") {
      return localize.ordinalNumber(week, { unit: "week" });
    }

    return addLeadingZeros(week, token.length);
  },

  // ISO week of year
  I: function (date, token, localize) {
    const isoWeek = getISOWeek(date);

    if (token === "Io") {
      return localize.ordinalNumber(isoWeek, { unit: "week" });
    }

    return addLeadingZeros(isoWeek, token.length);
  },

  // Day of the month
  d: function (date, token, localize) {
    if (token === "do") {
      return localize.ordinalNumber(date.getDate(), { unit: "date" });
    }

    return lightFormatters.d(date, token);
  },

  // Day of year
  D: function (date, token, localize) {
    const dayOfYear = getDayOfYear(date);

    if (token === "Do") {
      return localize.ordinalNumber(dayOfYear, { unit: "dayOfYear" });
    }

    return addLeadingZeros(dayOfYear, token.length);
  },

  // Day of week
  E: function (date, token, localize) {
    const dayOfWeek = date.getDay();
    switch (token) {
      // Tue
      case "E":
      case "EE":
      case "EEE":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting",
        });
      // T
      case "EEEEE":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting",
        });
      // Tu
      case "EEEEEE":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting",
        });
      // Tuesday
      case "EEEE":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // Local day of week
  e: function (date, token, localize, options) {
    const dayOfWeek = date.getDay();
    const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      // Numerical value (Nth day of week with current locale or weekStartsOn)
      case "e":
        return String(localDayOfWeek);
      // Padded numerical value
      case "ee":
        return addLeadingZeros(localDayOfWeek, 2);
      // 1st, 2nd, ..., 7th
      case "eo":
        return localize.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "eee":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting",
        });
      // T
      case "eeeee":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting",
        });
      // Tu
      case "eeeeee":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting",
        });
      // Tuesday
      case "eeee":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // Stand-alone local day of week
  c: function (date, token, localize, options) {
    const dayOfWeek = date.getDay();
    const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      // Numerical value (same as in `e`)
      case "c":
        return String(localDayOfWeek);
      // Padded numerical value
      case "cc":
        return addLeadingZeros(localDayOfWeek, token.length);
      // 1st, 2nd, ..., 7th
      case "co":
        return localize.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "ccc":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "standalone",
        });
      // T
      case "ccccc":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "standalone",
        });
      // Tu
      case "cccccc":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "standalone",
        });
      // Tuesday
      case "cccc":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "standalone",
        });
    }
  },

  // ISO day of week
  i: function (date, token, localize) {
    const dayOfWeek = date.getDay();
    const isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
    switch (token) {
      // 2
      case "i":
        return String(isoDayOfWeek);
      // 02
      case "ii":
        return addLeadingZeros(isoDayOfWeek, token.length);
      // 2nd
      case "io":
        return localize.ordinalNumber(isoDayOfWeek, { unit: "day" });
      // Tue
      case "iii":
        return localize.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting",
        });
      // T
      case "iiiii":
        return localize.day(dayOfWeek, {
          width: "narrow",
          context: "formatting",
        });
      // Tu
      case "iiiiii":
        return localize.day(dayOfWeek, {
          width: "short",
          context: "formatting",
        });
      // Tuesday
      case "iiii":
      default:
        return localize.day(dayOfWeek, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // AM or PM
  a: function (date, token, localize) {
    const hours = date.getHours();
    const dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";

    switch (token) {
      case "a":
      case "aa":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting",
        });
      case "aaa":
        return localize
          .dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting",
          })
          .toLowerCase();
      case "aaaaa":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting",
        });
      case "aaaa":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // AM, PM, midnight, noon
  b: function (date, token, localize) {
    const hours = date.getHours();
    let dayPeriodEnumValue;
    if (hours === 12) {
      dayPeriodEnumValue = dayPeriodEnum.noon;
    } else if (hours === 0) {
      dayPeriodEnumValue = dayPeriodEnum.midnight;
    } else {
      dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    }

    switch (token) {
      case "b":
      case "bb":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting",
        });
      case "bbb":
        return localize
          .dayPeriod(dayPeriodEnumValue, {
            width: "abbreviated",
            context: "formatting",
          })
          .toLowerCase();
      case "bbbbb":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting",
        });
      case "bbbb":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // in the morning, in the afternoon, in the evening, at night
  B: function (date, token, localize) {
    const hours = date.getHours();
    let dayPeriodEnumValue;
    if (hours >= 17) {
      dayPeriodEnumValue = dayPeriodEnum.evening;
    } else if (hours >= 12) {
      dayPeriodEnumValue = dayPeriodEnum.afternoon;
    } else if (hours >= 4) {
      dayPeriodEnumValue = dayPeriodEnum.morning;
    } else {
      dayPeriodEnumValue = dayPeriodEnum.night;
    }

    switch (token) {
      case "B":
      case "BB":
      case "BBB":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting",
        });
      case "BBBBB":
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting",
        });
      case "BBBB":
      default:
        return localize.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting",
        });
    }
  },

  // Hour [1-12]
  h: function (date, token, localize) {
    if (token === "ho") {
      let hours = date.getHours() % 12;
      if (hours === 0) hours = 12;
      return localize.ordinalNumber(hours, { unit: "hour" });
    }

    return lightFormatters.h(date, token);
  },

  // Hour [0-23]
  H: function (date, token, localize) {
    if (token === "Ho") {
      return localize.ordinalNumber(date.getHours(), { unit: "hour" });
    }

    return lightFormatters.H(date, token);
  },

  // Hour [0-11]
  K: function (date, token, localize) {
    const hours = date.getHours() % 12;

    if (token === "Ko") {
      return localize.ordinalNumber(hours, { unit: "hour" });
    }

    return addLeadingZeros(hours, token.length);
  },

  // Hour [1-24]
  k: function (date, token, localize) {
    let hours = date.getHours();
    if (hours === 0) hours = 24;

    if (token === "ko") {
      return localize.ordinalNumber(hours, { unit: "hour" });
    }

    return addLeadingZeros(hours, token.length);
  },

  // Minute
  m: function (date, token, localize) {
    if (token === "mo") {
      return localize.ordinalNumber(date.getMinutes(), { unit: "minute" });
    }

    return lightFormatters.m(date, token);
  },

  // Second
  s: function (date, token, localize) {
    if (token === "so") {
      return localize.ordinalNumber(date.getSeconds(), { unit: "second" });
    }

    return lightFormatters.s(date, token);
  },

  // Fraction of second
  S: function (date, token) {
    return lightFormatters.S(date, token);
  },

  // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
  X: function (date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();

    if (timezoneOffset === 0) {
      return "Z";
    }

    switch (token) {
      // Hours and optional minutes
      case "X":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);

      // Hours, minutes and optional seconds without `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `XX`
      case "XXXX":
      case "XX": // Hours and minutes without `:` delimiter
        return formatTimezone(timezoneOffset);

      // Hours, minutes and optional seconds with `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `XXX`
      case "XXXXX":
      case "XXX": // Hours and minutes with `:` delimiter
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },

  // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
  x: function (date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();

    switch (token) {
      // Hours and optional minutes
      case "x":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);

      // Hours, minutes and optional seconds without `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `xx`
      case "xxxx":
      case "xx": // Hours and minutes without `:` delimiter
        return formatTimezone(timezoneOffset);

      // Hours, minutes and optional seconds with `:` delimiter
      // Note: neither ISO-8601 nor JavaScript supports seconds in timezone offsets
      // so this token always has the same output as `xxx`
      case "xxxxx":
      case "xxx": // Hours and minutes with `:` delimiter
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },

  // Timezone (GMT)
  O: function (date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();

    switch (token) {
      // Short
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      // Long
      case "OOOO":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },

  // Timezone (specific non-location)
  z: function (date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();

    switch (token) {
      // Short
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      // Long
      case "zzzz":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },

  // Seconds timestamp
  t: function (date, token, _localize) {
    const timestamp = Math.trunc(+date / 1000);
    return addLeadingZeros(timestamp, token.length);
  },

  // Milliseconds timestamp
  T: function (date, token, _localize) {
    return addLeadingZeros(+date, token.length);
  },
};

function formatTimezoneShort(offset, delimiter = "") {
  const sign = offset > 0 ? "-" : "+";
  const absOffset = Math.abs(offset);
  const hours = Math.trunc(absOffset / 60);
  const minutes = absOffset % 60;
  if (minutes === 0) {
    return sign + String(hours);
  }
  return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
}

function formatTimezoneWithOptionalMinutes(offset, delimiter) {
  if (offset % 60 === 0) {
    const sign = offset > 0 ? "-" : "+";
    return sign + addLeadingZeros(Math.abs(offset) / 60, 2);
  }
  return formatTimezone(offset, delimiter);
}

function formatTimezone(offset, delimiter = "") {
  const sign = offset > 0 ? "-" : "+";
  const absOffset = Math.abs(offset);
  const hours = addLeadingZeros(Math.trunc(absOffset / 60), 2);
  const minutes = addLeadingZeros(absOffset % 60, 2);
  return sign + hours + delimiter + minutes;
}

const dateLongFormatter = (pattern, formatLong) => {
  switch (pattern) {
    case "P":
      return formatLong.date({ width: "short" });
    case "PP":
      return formatLong.date({ width: "medium" });
    case "PPP":
      return formatLong.date({ width: "long" });
    case "PPPP":
    default:
      return formatLong.date({ width: "full" });
  }
};

const timeLongFormatter = (pattern, formatLong) => {
  switch (pattern) {
    case "p":
      return formatLong.time({ width: "short" });
    case "pp":
      return formatLong.time({ width: "medium" });
    case "ppp":
      return formatLong.time({ width: "long" });
    case "pppp":
    default:
      return formatLong.time({ width: "full" });
  }
};

const dateTimeLongFormatter = (pattern, formatLong) => {
  const matchResult = pattern.match(/(P+)(p+)?/) || [];
  const datePattern = matchResult[1];
  const timePattern = matchResult[2];

  if (!timePattern) {
    return dateLongFormatter(pattern, formatLong);
  }

  let dateTimeFormat;

  switch (datePattern) {
    case "P":
      dateTimeFormat = formatLong.dateTime({ width: "short" });
      break;
    case "PP":
      dateTimeFormat = formatLong.dateTime({ width: "medium" });
      break;
    case "PPP":
      dateTimeFormat = formatLong.dateTime({ width: "long" });
      break;
    case "PPPP":
    default:
      dateTimeFormat = formatLong.dateTime({ width: "full" });
      break;
  }

  return dateTimeFormat
    .replace("{{date}}", dateLongFormatter(datePattern, formatLong))
    .replace("{{time}}", timeLongFormatter(timePattern, formatLong));
};

const longFormatters = {
  p: timeLongFormatter,
  P: dateTimeLongFormatter,
};

const dayOfYearTokenRE = /^D+$/;
const weekYearTokenRE = /^Y+$/;

const throwTokens = ["D", "DD", "YY", "YYYY"];

function isProtectedDayOfYearToken(token) {
  return dayOfYearTokenRE.test(token);
}

function isProtectedWeekYearToken(token) {
  return weekYearTokenRE.test(token);
}

function warnOrThrowProtectedError(token, format, input) {
  const _message = message(token, format, input);
  console.warn(_message);
  if (throwTokens.includes(token)) throw new RangeError(_message);
}

function message(token, format, input) {
  const subject = token[0] === "Y" ? "years" : "days of the month";
  return `Use \`${token.toLowerCase()}\` instead of \`${token}\` (in \`${format}\`) for formatting ${subject} to the input \`${input}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
}

// This RegExp consists of three parts separated by `|`:
// - [yYQqMLwIdDecihHKkms]o matches any available ordinal number token
//   (one of the certain letters followed by `o`)
// - (\w)\1* matches any sequences of the same letter
// - '' matches two quote characters in a row
// - '(''|[^'])+('|$) matches anything surrounded by two quote characters ('),
//   except a single quote symbol, which ends the sequence.
//   Two quote characters do not end the sequence.
//   If there is no matching single quote
//   then the sequence will continue until the end of the string.
// - . matches any single character unmatched by previous parts of the RegExps
const formattingTokensRegExp =
  /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;

// This RegExp catches symbols escaped by quotes, and also
// sequences of symbols P, p, and the combinations like `PPPPPPPppppp`
const longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;

const escapedStringRegExp = /^'([^]*?)'?$/;
const doubleQuoteRegExp = /''/g;
const unescapedLatinCharacterRegExp = /[a-zA-Z]/;

/**
 * The {@link format} function options.
 */

/**
 * @name format
 * @alias formatDate
 * @category Common Helpers
 * @summary Format the date.
 *
 * @description
 * Return the formatted date string in the given format. The result may vary by locale.
 *
 * > ⚠️ Please note that the `format` tokens differ from Moment.js and other libraries.
 * > See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 *
 * The characters wrapped between two single quotes characters (') are escaped.
 * Two single quotes in a row, whether inside or outside a quoted sequence, represent a 'real' single quote.
 * (see the last example)
 *
 * Format of the string is based on Unicode Technical Standard #35:
 * https://www.unicode.org/reports/tr35/tr35-dates.html#Date_Field_Symbol_Table
 * with a few additions (see note 7 below the table).
 *
 * Accepted patterns:
 * | Unit                            | Pattern | Result examples                   | Notes |
 * |---------------------------------|---------|-----------------------------------|-------|
 * | Era                             | G..GGG  | AD, BC                            |       |
 * |                                 | GGGG    | Anno Domini, Before Christ        | 2     |
 * |                                 | GGGGG   | A, B                              |       |
 * | Calendar year                   | y       | 44, 1, 1900, 2017                 | 5     |
 * |                                 | yo      | 44th, 1st, 0th, 17th              | 5,7   |
 * |                                 | yy      | 44, 01, 00, 17                    | 5     |
 * |                                 | yyy     | 044, 001, 1900, 2017              | 5     |
 * |                                 | yyyy    | 0044, 0001, 1900, 2017            | 5     |
 * |                                 | yyyyy   | ...                               | 3,5   |
 * | Local week-numbering year       | Y       | 44, 1, 1900, 2017                 | 5     |
 * |                                 | Yo      | 44th, 1st, 1900th, 2017th         | 5,7   |
 * |                                 | YY      | 44, 01, 00, 17                    | 5,8   |
 * |                                 | YYY     | 044, 001, 1900, 2017              | 5     |
 * |                                 | YYYY    | 0044, 0001, 1900, 2017            | 5,8   |
 * |                                 | YYYYY   | ...                               | 3,5   |
 * | ISO week-numbering year         | R       | -43, 0, 1, 1900, 2017             | 5,7   |
 * |                                 | RR      | -43, 00, 01, 1900, 2017           | 5,7   |
 * |                                 | RRR     | -043, 000, 001, 1900, 2017        | 5,7   |
 * |                                 | RRRR    | -0043, 0000, 0001, 1900, 2017     | 5,7   |
 * |                                 | RRRRR   | ...                               | 3,5,7 |
 * | Extended year                   | u       | -43, 0, 1, 1900, 2017             | 5     |
 * |                                 | uu      | -43, 01, 1900, 2017               | 5     |
 * |                                 | uuu     | -043, 001, 1900, 2017             | 5     |
 * |                                 | uuuu    | -0043, 0001, 1900, 2017           | 5     |
 * |                                 | uuuuu   | ...                               | 3,5   |
 * | Quarter (formatting)            | Q       | 1, 2, 3, 4                        |       |
 * |                                 | Qo      | 1st, 2nd, 3rd, 4th                | 7     |
 * |                                 | QQ      | 01, 02, 03, 04                    |       |
 * |                                 | QQQ     | Q1, Q2, Q3, Q4                    |       |
 * |                                 | QQQQ    | 1st quarter, 2nd quarter, ...     | 2     |
 * |                                 | QQQQQ   | 1, 2, 3, 4                        | 4     |
 * | Quarter (stand-alone)           | q       | 1, 2, 3, 4                        |       |
 * |                                 | qo      | 1st, 2nd, 3rd, 4th                | 7     |
 * |                                 | qq      | 01, 02, 03, 04                    |       |
 * |                                 | qqq     | Q1, Q2, Q3, Q4                    |       |
 * |                                 | qqqq    | 1st quarter, 2nd quarter, ...     | 2     |
 * |                                 | qqqqq   | 1, 2, 3, 4                        | 4     |
 * | Month (formatting)              | M       | 1, 2, ..., 12                     |       |
 * |                                 | Mo      | 1st, 2nd, ..., 12th               | 7     |
 * |                                 | MM      | 01, 02, ..., 12                   |       |
 * |                                 | MMM     | Jan, Feb, ..., Dec                |       |
 * |                                 | MMMM    | January, February, ..., December  | 2     |
 * |                                 | MMMMM   | J, F, ..., D                      |       |
 * | Month (stand-alone)             | L       | 1, 2, ..., 12                     |       |
 * |                                 | Lo      | 1st, 2nd, ..., 12th               | 7     |
 * |                                 | LL      | 01, 02, ..., 12                   |       |
 * |                                 | LLL     | Jan, Feb, ..., Dec                |       |
 * |                                 | LLLL    | January, February, ..., December  | 2     |
 * |                                 | LLLLL   | J, F, ..., D                      |       |
 * | Local week of year              | w       | 1, 2, ..., 53                     |       |
 * |                                 | wo      | 1st, 2nd, ..., 53th               | 7     |
 * |                                 | ww      | 01, 02, ..., 53                   |       |
 * | ISO week of year                | I       | 1, 2, ..., 53                     | 7     |
 * |                                 | Io      | 1st, 2nd, ..., 53th               | 7     |
 * |                                 | II      | 01, 02, ..., 53                   | 7     |
 * | Day of month                    | d       | 1, 2, ..., 31                     |       |
 * |                                 | do      | 1st, 2nd, ..., 31st               | 7     |
 * |                                 | dd      | 01, 02, ..., 31                   |       |
 * | Day of year                     | D       | 1, 2, ..., 365, 366               | 9     |
 * |                                 | Do      | 1st, 2nd, ..., 365th, 366th       | 7     |
 * |                                 | DD      | 01, 02, ..., 365, 366             | 9     |
 * |                                 | DDD     | 001, 002, ..., 365, 366           |       |
 * |                                 | DDDD    | ...                               | 3     |
 * | Day of week (formatting)        | E..EEE  | Mon, Tue, Wed, ..., Sun           |       |
 * |                                 | EEEE    | Monday, Tuesday, ..., Sunday      | 2     |
 * |                                 | EEEEE   | M, T, W, T, F, S, S               |       |
 * |                                 | EEEEEE  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
 * | ISO day of week (formatting)    | i       | 1, 2, 3, ..., 7                   | 7     |
 * |                                 | io      | 1st, 2nd, ..., 7th                | 7     |
 * |                                 | ii      | 01, 02, ..., 07                   | 7     |
 * |                                 | iii     | Mon, Tue, Wed, ..., Sun           | 7     |
 * |                                 | iiii    | Monday, Tuesday, ..., Sunday      | 2,7   |
 * |                                 | iiiii   | M, T, W, T, F, S, S               | 7     |
 * |                                 | iiiiii  | Mo, Tu, We, Th, Fr, Sa, Su        | 7     |
 * | Local day of week (formatting)  | e       | 2, 3, 4, ..., 1                   |       |
 * |                                 | eo      | 2nd, 3rd, ..., 1st                | 7     |
 * |                                 | ee      | 02, 03, ..., 01                   |       |
 * |                                 | eee     | Mon, Tue, Wed, ..., Sun           |       |
 * |                                 | eeee    | Monday, Tuesday, ..., Sunday      | 2     |
 * |                                 | eeeee   | M, T, W, T, F, S, S               |       |
 * |                                 | eeeeee  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
 * | Local day of week (stand-alone) | c       | 2, 3, 4, ..., 1                   |       |
 * |                                 | co      | 2nd, 3rd, ..., 1st                | 7     |
 * |                                 | cc      | 02, 03, ..., 01                   |       |
 * |                                 | ccc     | Mon, Tue, Wed, ..., Sun           |       |
 * |                                 | cccc    | Monday, Tuesday, ..., Sunday      | 2     |
 * |                                 | ccccc   | M, T, W, T, F, S, S               |       |
 * |                                 | cccccc  | Mo, Tu, We, Th, Fr, Sa, Su        |       |
 * | AM, PM                          | a..aa   | AM, PM                            |       |
 * |                                 | aaa     | am, pm                            |       |
 * |                                 | aaaa    | a.m., p.m.                        | 2     |
 * |                                 | aaaaa   | a, p                              |       |
 * | AM, PM, noon, midnight          | b..bb   | AM, PM, noon, midnight            |       |
 * |                                 | bbb     | am, pm, noon, midnight            |       |
 * |                                 | bbbb    | a.m., p.m., noon, midnight        | 2     |
 * |                                 | bbbbb   | a, p, n, mi                       |       |
 * | Flexible day period             | B..BBB  | at night, in the morning, ...     |       |
 * |                                 | BBBB    | at night, in the morning, ...     | 2     |
 * |                                 | BBBBB   | at night, in the morning, ...     |       |
 * | Hour [1-12]                     | h       | 1, 2, ..., 11, 12                 |       |
 * |                                 | ho      | 1st, 2nd, ..., 11th, 12th         | 7     |
 * |                                 | hh      | 01, 02, ..., 11, 12               |       |
 * | Hour [0-23]                     | H       | 0, 1, 2, ..., 23                  |       |
 * |                                 | Ho      | 0th, 1st, 2nd, ..., 23rd          | 7     |
 * |                                 | HH      | 00, 01, 02, ..., 23               |       |
 * | Hour [0-11]                     | K       | 1, 2, ..., 11, 0                  |       |
 * |                                 | Ko      | 1st, 2nd, ..., 11th, 0th          | 7     |
 * |                                 | KK      | 01, 02, ..., 11, 00               |       |
 * | Hour [1-24]                     | k       | 24, 1, 2, ..., 23                 |       |
 * |                                 | ko      | 24th, 1st, 2nd, ..., 23rd         | 7     |
 * |                                 | kk      | 24, 01, 02, ..., 23               |       |
 * | Minute                          | m       | 0, 1, ..., 59                     |       |
 * |                                 | mo      | 0th, 1st, ..., 59th               | 7     |
 * |                                 | mm      | 00, 01, ..., 59                   |       |
 * | Second                          | s       | 0, 1, ..., 59                     |       |
 * |                                 | so      | 0th, 1st, ..., 59th               | 7     |
 * |                                 | ss      | 00, 01, ..., 59                   |       |
 * | Fraction of second              | S       | 0, 1, ..., 9                      |       |
 * |                                 | SS      | 00, 01, ..., 99                   |       |
 * |                                 | SSS     | 000, 001, ..., 999                |       |
 * |                                 | SSSS    | ...                               | 3     |
 * | Timezone (ISO-8601 w/ Z)        | X       | -08, +0530, Z                     |       |
 * |                                 | XX      | -0800, +0530, Z                   |       |
 * |                                 | XXX     | -08:00, +05:30, Z                 |       |
 * |                                 | XXXX    | -0800, +0530, Z, +123456          | 2     |
 * |                                 | XXXXX   | -08:00, +05:30, Z, +12:34:56      |       |
 * | Timezone (ISO-8601 w/o Z)       | x       | -08, +0530, +00                   |       |
 * |                                 | xx      | -0800, +0530, +0000               |       |
 * |                                 | xxx     | -08:00, +05:30, +00:00            | 2     |
 * |                                 | xxxx    | -0800, +0530, +0000, +123456      |       |
 * |                                 | xxxxx   | -08:00, +05:30, +00:00, +12:34:56 |       |
 * | Timezone (GMT)                  | O...OOO | GMT-8, GMT+5:30, GMT+0            |       |
 * |                                 | OOOO    | GMT-08:00, GMT+05:30, GMT+00:00   | 2     |
 * | Timezone (specific non-locat.)  | z...zzz | GMT-8, GMT+5:30, GMT+0            | 6     |
 * |                                 | zzzz    | GMT-08:00, GMT+05:30, GMT+00:00   | 2,6   |
 * | Seconds timestamp               | t       | 512969520                         | 7     |
 * |                                 | tt      | ...                               | 3,7   |
 * | Milliseconds timestamp          | T       | 512969520900                      | 7     |
 * |                                 | TT      | ...                               | 3,7   |
 * | Long localized date             | P       | 04/29/1453                        | 7     |
 * |                                 | PP      | Apr 29, 1453                      | 7     |
 * |                                 | PPP     | April 29th, 1453                  | 7     |
 * |                                 | PPPP    | Friday, April 29th, 1453          | 2,7   |
 * | Long localized time             | p       | 12:00 AM                          | 7     |
 * |                                 | pp      | 12:00:00 AM                       | 7     |
 * |                                 | ppp     | 12:00:00 AM GMT+2                 | 7     |
 * |                                 | pppp    | 12:00:00 AM GMT+02:00             | 2,7   |
 * | Combination of date and time    | Pp      | 04/29/1453, 12:00 AM              | 7     |
 * |                                 | PPpp    | Apr 29, 1453, 12:00:00 AM         | 7     |
 * |                                 | PPPppp  | April 29th, 1453 at ...           | 7     |
 * |                                 | PPPPpppp| Friday, April 29th, 1453 at ...   | 2,7   |
 * Notes:
 * 1. "Formatting" units (e.g. formatting quarter) in the default en-US locale
 *    are the same as "stand-alone" units, but are different in some languages.
 *    "Formatting" units are declined according to the rules of the language
 *    in the context of a date. "Stand-alone" units are always nominative singular:
 *
 *    `format(new Date(2017, 10, 6), 'do LLLL', {locale: cs}) //=> '6. listopad'`
 *
 *    `format(new Date(2017, 10, 6), 'do MMMM', {locale: cs}) //=> '6. listopadu'`
 *
 * 2. Any sequence of the identical letters is a pattern, unless it is escaped by
 *    the single quote characters (see below).
 *    If the sequence is longer than listed in table (e.g. `EEEEEEEEEEE`)
 *    the output will be the same as default pattern for this unit, usually
 *    the longest one (in case of ISO weekdays, `EEEE`). Default patterns for units
 *    are marked with "2" in the last column of the table.
 *
 *    `format(new Date(2017, 10, 6), 'MMM') //=> 'Nov'`
 *
 *    `format(new Date(2017, 10, 6), 'MMMM') //=> 'November'`
 *
 *    `format(new Date(2017, 10, 6), 'MMMMM') //=> 'N'`
 *
 *    `format(new Date(2017, 10, 6), 'MMMMMM') //=> 'November'`
 *
 *    `format(new Date(2017, 10, 6), 'MMMMMMM') //=> 'November'`
 *
 * 3. Some patterns could be unlimited length (such as `yyyyyyyy`).
 *    The output will be padded with zeros to match the length of the pattern.
 *
 *    `format(new Date(2017, 10, 6), 'yyyyyyyy') //=> '00002017'`
 *
 * 4. `QQQQQ` and `qqqqq` could be not strictly numerical in some locales.
 *    These tokens represent the shortest form of the quarter.
 *
 * 5. The main difference between `y` and `u` patterns are B.C. years:
 *
 *    | Year | `y` | `u` |
 *    |------|-----|-----|
 *    | AC 1 |   1 |   1 |
 *    | BC 1 |   1 |   0 |
 *    | BC 2 |   2 |  -1 |
 *
 *    Also `yy` always returns the last two digits of a year,
 *    while `uu` pads single digit years to 2 characters and returns other years unchanged:
 *
 *    | Year | `yy` | `uu` |
 *    |------|------|------|
 *    | 1    |   01 |   01 |
 *    | 14   |   14 |   14 |
 *    | 376  |   76 |  376 |
 *    | 1453 |   53 | 1453 |
 *
 *    The same difference is true for local and ISO week-numbering years (`Y` and `R`),
 *    except local week-numbering years are dependent on `options.weekStartsOn`
 *    and `options.firstWeekContainsDate` (compare [getISOWeekYear](https://date-fns.org/docs/getISOWeekYear)
 *    and [getWeekYear](https://date-fns.org/docs/getWeekYear)).
 *
 * 6. Specific non-location timezones are currently unavailable in `date-fns`,
 *    so right now these tokens fall back to GMT timezones.
 *
 * 7. These patterns are not in the Unicode Technical Standard #35:
 *    - `i`: ISO day of week
 *    - `I`: ISO week of year
 *    - `R`: ISO week-numbering year
 *    - `t`: seconds timestamp
 *    - `T`: milliseconds timestamp
 *    - `o`: ordinal number modifier
 *    - `P`: long localized date
 *    - `p`: long localized time
 *
 * 8. `YY` and `YYYY` tokens represent week-numbering years but they are often confused with years.
 *    You should enable `options.useAdditionalWeekYearTokens` to use them. See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 *
 * 9. `D` and `DD` tokens represent days of the year but they are often confused with days of the month.
 *    You should enable `options.useAdditionalDayOfYearTokens` to use them. See: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 *
 * @param date - The original date
 * @param format - The string of tokens
 * @param options - An object with options
 *
 * @returns The formatted date string
 *
 * @throws `date` must not be Invalid Date
 * @throws `options.locale` must contain `localize` property
 * @throws `options.locale` must contain `formatLong` property
 * @throws use `yyyy` instead of `YYYY` for formatting years using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 * @throws use `yy` instead of `YY` for formatting years using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 * @throws use `d` instead of `D` for formatting days of the month using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 * @throws use `dd` instead of `DD` for formatting days of the month using [format provided] to the input [input provided]; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md
 * @throws format string contains an unescaped latin alphabet character
 *
 * @example
 * // Represent 11 February 2014 in middle-endian format:
 * const result = format(new Date(2014, 1, 11), 'MM/dd/yyyy')
 * //=> '02/11/2014'
 *
 * @example
 * // Represent 2 July 2014 in Esperanto:
 * import { eoLocale } from 'date-fns/locale/eo'
 * const result = format(new Date(2014, 6, 2), "do 'de' MMMM yyyy", {
 *   locale: eoLocale
 * })
 * //=> '2-a de julio 2014'
 *
 * @example
 * // Escape string by single quote characters:
 * const result = format(new Date(2014, 6, 2, 15), "h 'o''clock'")
 * //=> "3 o'clock"
 */
function format$1(date, formatStr, options) {
  const defaultOptions = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions.locale ?? enUS;

  const firstWeekContainsDate =
    options?.firstWeekContainsDate ??
    options?.locale?.options?.firstWeekContainsDate ??
    defaultOptions.firstWeekContainsDate ??
    defaultOptions.locale?.options?.firstWeekContainsDate ??
    1;

  const weekStartsOn =
    options?.weekStartsOn ??
    options?.locale?.options?.weekStartsOn ??
    defaultOptions.weekStartsOn ??
    defaultOptions.locale?.options?.weekStartsOn ??
    0;

  const originalDate = toDate(date, options?.in);

  if (!isValid(originalDate)) {
    throw new RangeError("Invalid time value");
  }

  let parts = formatStr
    .match(longFormattingTokensRegExp)
    .map((substring) => {
      const firstCharacter = substring[0];
      if (firstCharacter === "p" || firstCharacter === "P") {
        const longFormatter = longFormatters[firstCharacter];
        return longFormatter(substring, locale.formatLong);
      }
      return substring;
    })
    .join("")
    .match(formattingTokensRegExp)
    .map((substring) => {
      // Replace two single quote characters with one single quote character
      if (substring === "''") {
        return { isToken: false, value: "'" };
      }

      const firstCharacter = substring[0];
      if (firstCharacter === "'") {
        return { isToken: false, value: cleanEscapedString(substring) };
      }

      if (formatters[firstCharacter]) {
        return { isToken: true, value: substring };
      }

      if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
        throw new RangeError(
          "Format string contains an unescaped latin alphabet character `" +
            firstCharacter +
            "`",
        );
      }

      return { isToken: false, value: substring };
    });

  // invoke localize preprocessor (only for french locales at the moment)
  if (locale.localize.preprocessor) {
    parts = locale.localize.preprocessor(originalDate, parts);
  }

  const formatterOptions = {
    firstWeekContainsDate,
    weekStartsOn,
    locale,
  };

  return parts
    .map((part) => {
      if (!part.isToken) return part.value;

      const token = part.value;

      if (
        (!options?.useAdditionalWeekYearTokens &&
          isProtectedWeekYearToken(token)) ||
        (!options?.useAdditionalDayOfYearTokens &&
          isProtectedDayOfYearToken(token))
      ) {
        warnOrThrowProtectedError(token, formatStr, String(date));
      }

      const formatter = formatters[token[0]];
      return formatter(originalDate, token, locale.localize, formatterOptions);
    })
    .join("");
}

function cleanEscapedString(input) {
  const matched = input.match(escapedStringRegExp);

  if (!matched) {
    return input;
  }

  return matched[1].replace(doubleQuoteRegExp, "'");
}

/**
 * The {@link formatDistanceStrict} function options.
 */

/**
 * The unit used to format the distance in {@link formatDistanceStrict}.
 */

/**
 * @name formatDistanceStrict
 * @category Common Helpers
 * @summary Return the distance between the given dates in words.
 *
 * @description
 * Return the distance between the given dates in words, using strict units.
 * This is like `formatDistance`, but does not use helpers like 'almost', 'over',
 * 'less than' and the like.
 *
 * | Distance between dates | Result              |
 * |------------------------|---------------------|
 * | 0 ... 59 secs          | [0..59] seconds     |
 * | 1 ... 59 mins          | [1..59] minutes     |
 * | 1 ... 23 hrs           | [1..23] hours       |
 * | 1 ... 29 days          | [1..29] days        |
 * | 1 ... 11 months        | [1..11] months      |
 * | 1 ... N years          | [1..N]  years       |
 *
 * @param laterDate - The date
 * @param earlierDate - The date to compare with
 * @param options - An object with options
 *
 * @returns The distance in words
 *
 * @throws `date` must not be Invalid Date
 * @throws `baseDate` must not be Invalid Date
 * @throws `options.unit` must be 'second', 'minute', 'hour', 'day', 'month' or 'year'
 * @throws `options.locale` must contain `formatDistance` property
 *
 * @example
 * // What is the distance between 2 July 2014 and 1 January 2015?
 * const result = formatDistanceStrict(new Date(2014, 6, 2), new Date(2015, 0, 2))
 * //=> '6 months'
 *
 * @example
 * // What is the distance between 1 January 2015 00:00:15
 * // and 1 January 2015 00:00:00?
 * const result = formatDistanceStrict(
 *   new Date(2015, 0, 1, 0, 0, 15),
 *   new Date(2015, 0, 1, 0, 0, 0)
 * )
 * //=> '15 seconds'
 *
 * @example
 * // What is the distance from 1 January 2016
 * // to 1 January 2015, with a suffix?
 * const result = formatDistanceStrict(new Date(2015, 0, 1), new Date(2016, 0, 1), {
 *   addSuffix: true
 * })
 * //=> '1 year ago'
 *
 * @example
 * // What is the distance from 1 January 2016
 * // to 1 January 2015, in minutes?
 * const result = formatDistanceStrict(new Date(2016, 0, 1), new Date(2015, 0, 1), {
 *   unit: 'minute'
 * })
 * //=> '525600 minutes'
 *
 * @example
 * // What is the distance from 1 January 2015
 * // to 28 January 2015, in months, rounded up?
 * const result = formatDistanceStrict(new Date(2015, 0, 28), new Date(2015, 0, 1), {
 *   unit: 'month',
 *   roundingMethod: 'ceil'
 * })
 * //=> '1 month'
 *
 * @example
 * // What is the distance between 1 August 2016 and 1 January 2015 in Esperanto?
 * import { eoLocale } from 'date-fns/locale/eo'
 * const result = formatDistanceStrict(new Date(2016, 7, 1), new Date(2015, 0, 1), {
 *   locale: eoLocale
 * })
 * //=> '1 jaro'
 */

function formatDistanceStrict(laterDate, earlierDate, options) {
  const defaultOptions = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions.locale ?? enUS;

  const comparison = compareAsc(laterDate, earlierDate);

  if (isNaN(comparison)) {
    throw new RangeError("Invalid time value");
  }

  const localizeOptions = Object.assign({}, options, {
    addSuffix: options?.addSuffix,
    comparison: comparison,
  });

  const [laterDate_, earlierDate_] = normalizeDates(
    options?.in,
    ...(comparison > 0 ? [earlierDate, laterDate] : [laterDate, earlierDate]),
  );

  const roundingMethod = getRoundingMethod(options?.roundingMethod ?? "round");

  const milliseconds = earlierDate_.getTime() - laterDate_.getTime();
  const minutes = milliseconds / millisecondsInMinute;

  const timezoneOffset =
    getTimezoneOffsetInMilliseconds(earlierDate_) -
    getTimezoneOffsetInMilliseconds(laterDate_);

  // Use DST-normalized difference in minutes for years, months and days;
  // use regular difference in minutes for hours, minutes and seconds.
  const dstNormalizedMinutes =
    (milliseconds - timezoneOffset) / millisecondsInMinute;

  const defaultUnit = options?.unit;
  let unit;
  if (!defaultUnit) {
    if (minutes < 1) {
      unit = "second";
    } else if (minutes < 60) {
      unit = "minute";
    } else if (minutes < minutesInDay) {
      unit = "hour";
    } else if (dstNormalizedMinutes < minutesInMonth) {
      unit = "day";
    } else if (dstNormalizedMinutes < minutesInYear) {
      unit = "month";
    } else {
      unit = "year";
    }
  } else {
    unit = defaultUnit;
  }

  // 0 up to 60 seconds
  if (unit === "second") {
    const seconds = roundingMethod(milliseconds / 1000);
    return locale.formatDistance("xSeconds", seconds, localizeOptions);

    // 1 up to 60 mins
  } else if (unit === "minute") {
    const roundedMinutes = roundingMethod(minutes);
    return locale.formatDistance("xMinutes", roundedMinutes, localizeOptions);

    // 1 up to 24 hours
  } else if (unit === "hour") {
    const hours = roundingMethod(minutes / 60);
    return locale.formatDistance("xHours", hours, localizeOptions);

    // 1 up to 30 days
  } else if (unit === "day") {
    const days = roundingMethod(dstNormalizedMinutes / minutesInDay);
    return locale.formatDistance("xDays", days, localizeOptions);

    // 1 up to 12 months
  } else if (unit === "month") {
    const months = roundingMethod(dstNormalizedMinutes / minutesInMonth);
    return months === 12 && defaultUnit !== "month"
      ? locale.formatDistance("xYears", 1, localizeOptions)
      : locale.formatDistance("xMonths", months, localizeOptions);

    // 1 year up to max Date
  } else {
    const years = roundingMethod(dstNormalizedMinutes / minutesInYear);
    return locale.formatDistance("xYears", years, localizeOptions);
  }
}

/**
 * The {@link formatDistanceToNowStrict} function options.
 */

/**
 * @name formatDistanceToNowStrict
 * @category Common Helpers
 * @summary Return the distance between the given date and now in words.
 * @pure false
 *
 * @description
 * Return the distance between the given dates in words, using strict units.
 * This is like `formatDistance`, but does not use helpers like 'almost', 'over',
 * 'less than' and the like.
 *
 * | Distance between dates | Result              |
 * |------------------------|---------------------|
 * | 0 ... 59 secs          | [0..59] seconds     |
 * | 1 ... 59 mins          | [1..59] minutes     |
 * | 1 ... 23 hrs           | [1..23] hours       |
 * | 1 ... 29 days          | [1..29] days        |
 * | 1 ... 11 months        | [1..11] months      |
 * | 1 ... N years          | [1..N]  years       |
 *
 * @param date - The given date
 * @param options - An object with options.
 *
 * @returns The distance in words
 *
 * @throws `date` must not be Invalid Date
 * @throws `options.locale` must contain `formatDistance` property
 *
 * @example
 * // If today is 1 January 2015, what is the distance to 2 July 2014?
 * const result = formatDistanceToNowStrict(
 *   new Date(2014, 6, 2)
 * )
 * //=> '6 months'
 *
 * @example
 * // If now is 1 January 2015 00:00:00,
 * // what is the distance to 1 January 2015 00:00:15, including seconds?
 * const result = formatDistanceToNowStrict(
 *   new Date(2015, 0, 1, 0, 0, 15)
 * )
 * //=> '15 seconds'
 *
 * @example
 * // If today is 1 January 2015,
 * // what is the distance to 1 January 2016, with a suffix?
 * const result = formatDistanceToNowStrict(
 *   new Date(2016, 0, 1),
 *   {addSuffix: true}
 * )
 * //=> 'in 1 year'
 *
 * @example
 * // If today is 28 January 2015,
 * // what is the distance to 1 January 2015, in months, rounded up??
 * const result = formatDistanceToNowStrict(new Date(2015, 0, 1), {
 *   unit: 'month',
 *   roundingMethod: 'ceil'
 * })
 * //=> '1 month'
 *
 * @example
 * // If today is 1 January 2015,
 * // what is the distance to 1 January 2016 in Esperanto?
 * const eoLocale = require('date-fns/locale/eo')
 * const result = formatDistanceToNowStrict(
 *   new Date(2016, 0, 1),
 *   {locale: eoLocale}
 * )
 * //=> '1 jaro'
 */
function formatDistanceToNowStrict(date, options) {
  return formatDistanceStrict(date, constructNow(date), options);
}

/**
 * The {@link formatRelative} function options.
 */

/**
 * @name formatRelative
 * @category Common Helpers
 * @summary Represent the date in words relative to the given base date.
 *
 * @description
 * Represent the date in words relative to the given base date.
 *
 * | Distance to the base date | Result                    |
 * |---------------------------|---------------------------|
 * | Previous 6 days           | last Sunday at 04:30 AM   |
 * | Last day                  | yesterday at 04:30 AM     |
 * | Same day                  | today at 04:30 AM         |
 * | Next day                  | tomorrow at 04:30 AM      |
 * | Next 6 days               | Sunday at 04:30 AM        |
 * | Other                     | 12/31/2017                |
 *
 * @param date - The date to format
 * @param baseDate - The date to compare with
 * @param options - An object with options
 *
 * @returns The date in words
 *
 * @throws `date` must not be Invalid Date
 * @throws `baseDate` must not be Invalid Date
 * @throws `options.locale` must contain `localize` property
 * @throws `options.locale` must contain `formatLong` property
 * @throws `options.locale` must contain `formatRelative` property
 *
 * @example
 * // Represent the date of 6 days ago in words relative to the given base date. In this example, today is Wednesday
 * const result = formatRelative(subDays(new Date(), 6), new Date())
 * //=> "last Thursday at 12:45 AM"
 */
function formatRelative(date, baseDate, options) {
  const [date_, baseDate_] = normalizeDates(options?.in, date, baseDate);

  const defaultOptions = getDefaultOptions();
  const locale = options?.locale ?? defaultOptions.locale ?? enUS;
  const weekStartsOn =
    options?.weekStartsOn ??
    options?.locale?.options?.weekStartsOn ??
    defaultOptions.weekStartsOn ??
    defaultOptions.locale?.options?.weekStartsOn ??
    0;

  const diff = differenceInCalendarDays(date_, baseDate_);

  if (isNaN(diff)) {
    throw new RangeError("Invalid time value");
  }

  let token;
  if (diff < -6) {
    token = "other";
  } else if (diff < -1) {
    token = "lastWeek";
  } else if (diff < 0) {
    token = "yesterday";
  } else if (diff < 1) {
    token = "today";
  } else if (diff < 2) {
    token = "tomorrow";
  } else if (diff < 7) {
    token = "nextWeek";
  } else {
    token = "other";
  }

  const formatStr = locale.formatRelative(token, date_, baseDate_, {
    locale,
    weekStartsOn,
  });
  return format$1(date_, formatStr, { locale, weekStartsOn });
}

const Preferences = registerPlugin('Preferences', {
    web: () => import('./web-BI8h3PAP.js').then(m => new m.PreferencesWeb()),
});

var asyncStorage = {
    get: get$2,
    set: set$3,
    remove(key) {
        return Preferences.remove({ key });
    },
    // migration from capacitor 2.0 to 3.0
    // TODO remove after
    async migrate() {
        const result = await Preferences.migrate();
        console.log(result);
    },
};
function get$2(key) {
    return Preferences.get({ key }).then(({ value }) => {
        if (value !== null) {
            return JSON.parse(value);
        }
        else
            return value;
    });
}
function set$3(key, value) {
    return Preferences.set({ key, value: JSON.stringify(value) })
        .then(() => value);
}

/**
 * Performs equality by iterating through keys on an object and returning false
 * when any key has values which are not strictly equal between the arguments.
 * Returns true when the values of all keys are strictly equal.
 */
const hasOwnProperty = Object.prototype.hasOwnProperty;
function shallowEqual(objA, objB) {
    if (Object.is(objA, objB)) {
        return true;
    }
    if (typeof objA !== 'object' || objA === null ||
        typeof objB !== 'object' || objB === null) {
        return false;
    }
    const keysA = Object.keys(objA);
    const keysB = Object.keys(objB);
    if (keysA.length !== keysB.length) {
        return false;
    }
    for (let i = 0; i < keysA.length; i++) {
        if (!hasOwnProperty.call(objB, keysA[i]) ||
            !Object.is(objA[keysA[i]], objB[keysA[i]])) {
            return false;
        }
    }
    return true;
}
function getAtPath(obj, path) {
    return path.split('.').reduce((acc, x) => acc && acc[x], obj);
}
function setAtPath(obj, path, value) {
    if (typeof path === 'string') {
        path = path.split('.');
    }
    if (path.length > 1) {
        const p = path.shift();
        if (obj[p] === null || typeof obj[p] !== 'object') {
            obj[p] = {};
        }
        setAtPath(obj[p], path, value);
    }
    else {
        obj[path[0]] = value;
    }
}
function pick(obj, props) {
    return {
        ...props.reduce((acc, key) => ({ ...acc, [key]: obj[key] }), {})
    };
}

function tupleOf(x) {
    return [x.toString(), x.toString()];
}

function increments(min, max, step = 1) {
    const array = [];
    for (let i = min; i <= max; i += step) {
        array.push(i.toString());
    }
    return array;
}
function incrementTuples(min, max, step = 1) {
    return increments(min, max, step).map(tupleOf);
}

const STORAGE_KEY$1 = 'settings';
const offlineAvailableVariants = [
    ['Standard', 'standard'],
    ['Crazyhouse', 'crazyhouse'],
    ['Chess960', 'chess960'],
    ['King of the Hill', 'kingOfTheHill'],
    ['Three-check', 'threeCheck'],
    ['Antichess', 'antichess'],
    ['Atomic', 'atomic'],
    ['Horde', 'horde'],
    ['Racing Kings', 'racingKings']
];
const availableClocks = [
    ['Sudden Death', 'simple'],
    ['Increment', 'increment'],
    ['Increment with Handicap', 'handicapInc'],
    ['Simple Delay', 'delay'],
    ['Bronstein Delay', 'bronstein'],
    ['Hourglass', 'hourglass'],
    ['Stage', 'stage'],
];
const ratingRanges = [...Array(11).keys()].map(x => x * 50);
const settingsStore = {};
async function init$2() {
    await asyncStorage.migrate();
    const data = await asyncStorage.get(STORAGE_KEY$1);
    Object.assign(settingsStore, data);
}
var settings = {
    general: {
        locale: prop$1('lang', null),
        sound: prop$1('sound', true),
        theme: {
            availableBackgroundThemes: [
                { key: 'dark', name: 'dark', ext: '' },
                { key: 'light', name: 'light', ext: '' },
                { key: 'system', name: 'bgThemeSyncWithSystem', ext: '' },
                { key: 'bgshapes', name: 'Shapes', ext: 'jpg' },
                { key: 'anthracite', name: 'Anthracite', ext: 'jpg' },
                { key: 'blue-maze', name: 'Blue Maze', ext: 'jpg' },
                { key: 'red-maze', name: 'Red Maze', ext: 'jpg' },
                { key: 'checkerboard', name: 'Checkerboard', ext: 'png' },
                { key: 'wood', name: 'Wood', ext: 'jpg' },
                { key: 'space', name: 'Space', ext: 'jpg' },
            ],
            availableBoardThemes: [
                { key: 'blue', name: 'Blue', ext: 'svg' },
                { key: 'blue2', name: 'Blue 2', ext: 'jpg' },
                { key: 'blue3', name: 'Blue 3', ext: 'jpg' },
                { key: 'blue-marble', name: 'Blue Marble', ext: 'jpg' },
                { key: 'canvas', name: 'Canvas', ext: 'jpg' },
                { key: 'wood', name: 'Wood', ext: 'jpg' },
                { key: 'wood2', name: 'Wood 2', ext: 'jpg' },
                { key: 'wood3', name: 'Wood 3', ext: 'jpg' },
                { key: 'wood4', name: 'Wood 4', ext: 'jpg' },
                { key: 'maple', name: 'Maple', ext: 'jpg' },
                { key: 'maple2', name: 'Maple 2', ext: 'jpg' },
                { key: 'brown', name: 'Brown', ext: 'svg' },
                { key: 'leather', name: 'Leather', ext: 'jpg' },
                { key: 'green', name: 'Green', ext: 'svg' },
                { key: 'marble', name: 'Marble', ext: 'jpg' },
                { key: 'green-plastic', name: 'Green Plastic', ext: 'png' },
                { key: 'grey', name: 'Grey', ext: 'jpg' },
                { key: 'metal', name: 'Metal', ext: 'jpg' },
                { key: 'olive', name: 'Olive', ext: 'jpg' },
                { key: 'newspaper', name: 'Newspaper', ext: 'png' },
                { key: 'purple', name: 'Purple', ext: 'svg' },
                { key: 'purple-diag', name: 'Purple 2', ext: 'png' },
                { key: 'pink', name: 'Pink', ext: 'png' },
                { key: 'ic', name: 'IC', ext: 'svg' },
                { key: 'horsey', name: 'horsey', ext: 'jpg' },
            ],
            bundledBoardThemes: ['brown', 'blue', 'green', 'purple', 'ic'],
            availablePieceThemes: [
                ['cburnett', 'Colin M.L. Burnett'],
                ['merida'],
                ['pirouetti'],
                ['chessnut'],
                ['chess7'],
                ['alpha'],
                ['reilly'],
                ['companion'],
                ['riohacha'],
                ['kosal'],
                ['leipzig'],
                ['fantasy'],
                ['spatial'],
                ['california'],
                ['pixel'],
                ['maestro'],
                ['fresca'],
                ['cardinal'],
                ['gioco'],
                ['tatiana'],
                ['staunty'],
                ['governor'],
                ['symmetric'],
                ['dubrovny'],
                ['icpieces'],
                ['libra'],
                ['shapes'],
                ['letter'],
                ['horsey'],
                ['anarcandy'],
            ],
            background: prop$1('bgTheme', 'dark'),
            board: prop$1('theme.board', 'brown'),
            piece: prop$1('theme.piece', 'cburnett')
        },
        vibrateOnGameEvents: prop$1('vibrateOnGameEvents', false),
        notifications: {
            enable: prop$1('notifications', true),
            vibrate: prop$1('notifications.vibrate', true),
            sound: prop$1('notifications.sound', true)
        }
    },
    game: {
        supportedVariants: ['standard', 'chess960', 'antichess', 'fromPosition',
            'kingOfTheHill', 'threeCheck', 'atomic', 'horde', 'racingKings', 'crazyhouse'
        ],
        animations: prop$1('gameAnimations', true),
        highlights: prop$1('boardHighlights', true),
        pieceDestinations: prop$1('pieceDestinations', true),
        coords: prop$1('coords', true),
        magnified: prop$1('pieceMagnified', true),
        pieceNotation: prop$1('pieceNotation', true),
        zenMode: prop$1('zenMode', false),
        blindfoldChess: prop$1('blindfoldChess', false),
        clockPosition: prop$1('game.inversedClockPos', 'right'),
        pieceMove: prop$1('game.pieceMove', 'both'),
        rookCastle: prop$1('game.rookCastle', 1),
        moveList: prop$1('game.moveList', true),
        landscapeBoardSide: prop$1('game.landscapeBoardSide', 'left'),
    },
    analyse: {
        supportedVariants: ['standard', 'chess960', 'antichess', 'fromPosition',
            'kingOfTheHill', 'threeCheck', 'atomic', 'horde', 'racingKings', 'crazyhouse'
        ],
        availableVariants: offlineAvailableVariants,
        syntheticVariant: prop$1('analyse.syntheticVariant', 'standard'),
        enableCeval: prop$1('analyse.enableCeval', false),
        cevalMultiPvs: prop$1('ceval.multipv', 1),
        cevalCores: prop$1('ceval.cores', 1),
        cevalHashSize: prop$1('ceval.hashSize', 16),
        cevalInfinite: prop$1('ceval.infinite', false),
        cevalMaxDepth: prop$1('ceval.maxDepth', 18),
        showBestMove: prop$1('analyse.showBestMove', true),
        showComments: prop$1('analyse.showComments', true),
        smallBoard: prop$1('analyse.smallBoard', true),
        explorer: {
            db: prop$1('analyse.explorer.db', 'lichess'),
            availableRatings: [1600, 1800, 2000, 2200, 2500],
            rating: prop$1('analyse.explorer.rating', [1600, 1800, 2000, 2200, 2500]),
            availableSpeeds: ['bullet', 'blitz', 'rapid', 'classical'],
            speed: prop$1('analyse.explorer.speed', ['bullet', 'blitz', 'rapid', 'classical'])
        }
    },
    ai: {
        availableOpponents: [
            ['Stockfish', '1'],
            ['Stockfish', '2'],
            ['Stockfish', '3'],
            ['Stockfish', '4'],
            ['Stockfish', '5'],
            ['Stockfish', '6'],
            ['Stockfish', '7'],
            ['Stockfish', '8']
        ],
        color: prop$1('ai.color', 'white'),
        opponent: prop$1('ai.opponent', '1'),
        variant: prop$1('ai.variant', 'standard'),
        availableVariants: offlineAvailableVariants
    },
    otb: {
        flipPieces: prop$1('otb.flipPieces', false),
        useSymmetric: prop$1('otb.useSymmetric', false),
        variant: prop$1('otb.variant', 'standard'),
        availableVariants: offlineAvailableVariants,
        whitePlayer: prop$1('otb.whitePlayer', 'White'),
        blackPlayer: prop$1('otb.blackPlayer', 'Black'),
        clockType: prop$1('otb.clockType', 'none'),
        availableClocks: [
            ['None', 'none']
        ].concat(availableClocks)
    },
    clock: {
        availableClocks,
        clockType: prop$1('clock.clockType', 'simple'),
        simple: {
            time: prop$1('clock.simple.time', '5')
        },
        increment: {
            time: prop$1('clock.increment.time', '3'),
            increment: prop$1('clock.increment.increment', '2')
        },
        handicapInc: {
            topTime: prop$1('clock.handicapInc.topTime', '3'),
            topIncrement: prop$1('clock.handicapInc.topIncrement', '2'),
            bottomTime: prop$1('clock.handicapInc.bottomTime', '3'),
            bottomIncrement: prop$1('clock.handicapInc.bottomIncrement', '2')
        },
        delay: {
            time: prop$1('clock.delay.time', '3'),
            increment: prop$1('clock.delay.increment', '2')
        },
        bronstein: {
            time: prop$1('clock.bronstein.time', '3'),
            increment: prop$1('clock.bronstein.increment', '2')
        },
        hourglass: {
            time: prop$1('clock.hourglass.time', '5')
        },
        stage: {
            stages: prop$1('clock.stage.stages', [{ time: '120', moves: '40' }, { time: '60', moves: null }]),
            increment: prop$1('clock.stage.increment', '30')
        },
        availableTimes: [['0', '0'], ['½', '0.5'], ['¾', '0.75'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6'], ['7', '7'], ['8', '8'], ['9', '9'], ['10', '10'], ['15', '15'], ['20', '20'], ['25', '25'], ['30', '30'], ['45', '45'], ['60', '60'], ['90', '90'], ['120', '120'], ['150', '150'], ['180', '180']
        ],
        availableIncrements: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '10', '15', '20', '25', '30', '45', '60', '90', '120', '150', '180'
        ],
        availableMoves: ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60'
        ]
    },
    gameSetup: {
        availableTimes: [['0', '0'], ['¼', '0.25'], ['½', '0.5'], ['¾', '0.75'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6'], ['7', '7'], ['8', '8'], ['9', '9'], ['10', '10'], ['15', '15'], ['20', '20'], ['25', '25'], ['30', '30'], ['45', '45'], ['60', '60'], ['90', '90'], ['120', '120'], ['150', '150'], ['180', '180']
        ],
        availableIncrements: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            '10', '15', '20', '25', '30', '45', '60', '90', '120', '150', '180'
        ],
        availableDays: ['1', '2', '3', '5', '7', '10', '14'],
        isTimeValid: function (gameSettings) {
            return gameSettings.timeMode() !== '1' ||
                gameSettings.time() !== '0' ||
                gameSettings.increment() !== '0';
        },
        ai: {
            color: prop$1('game.ai.color', 'random'),
            availableVariants: [
                ['Standard', '1'],
                ['Crazyhouse', '10'],
                ['Chess960', '2'],
                ['King of the Hill', '4'],
                ['Three-check', '5'],
                ['Antichess', '6'],
                ['Atomic', '7'],
                ['Horde', '8'],
                ['Racing Kings', '9'],
                ['From Position', '3']
            ],
            variant: prop$1('game.ai.variant', '1'),
            availableTimeModes: [
                ['unlimited', '0'],
                ['realTime', '1']
            ],
            timeMode: prop$1('game.ai.clock', '1'),
            time: prop$1('game.ai.time', '10'),
            increment: prop$1('game.ai.increment', '0'),
            days: prop$1('game.ai.days', '2'),
            level: prop$1('game.ai.aiLevel', '3')
        },
        human: {
            availableVariants: [
                ['Standard', '1'],
                ['Crazyhouse', '10'],
                ['Chess960', '2'],
                ['King of the Hill', '4'],
                ['Three-check', '5'],
                ['Antichess', '6'],
                ['Atomic', '7'],
                ['Horde', '8'],
                ['Racing Kings', '9']
            ],
            availableRatingRanges: {
                min: [...ratingRanges].reverse().map(n => ['-' + n, '-' + n]),
                max: ratingRanges.map(n => ['+' + n, '+' + n]),
            },
            ratingRangeMin: prop$1('game.human.rating.range_min', '-500'),
            ratingRangeMax: prop$1('game.human.rating.range_max', '+500'),
            color: prop$1('game.human.color', 'random'),
            variant: prop$1('game.human.variant', '1'),
            availableTimeModes: [
                ['realTime', '1'],
                ['correspondence', '2'],
                ['unlimited', '0']
            ],
            timeMode: prop$1('game.human.clock', '1'),
            time: prop$1('game.human.time', '5'),
            increment: prop$1('game.human.increment', '0'),
            days: prop$1('game.human.days', '2'),
            mode: prop$1('game.human.mode', '0'),
            preset: prop$1('game.human.preset', 'quick'),
            pool: prop$1('game.human.pool', ''),
        },
        challenge: {
            availableVariants: [
                ['Standard', '1'],
                ['Crazyhouse', '10'],
                ['Chess960', '2'],
                ['King of the Hill', '4'],
                ['Three-check', '5'],
                ['Antichess', '6'],
                ['Atomic', '7'],
                ['Horde', '8'],
                ['Racing Kings', '9'],
                ['From Position', '3']
            ],
            color: prop$1('game.invite.color', 'random'),
            variant: prop$1('game.invite.variant', '1'),
            availableTimeModes: [
                ['realTime', '1'],
                ['correspondence', '2'],
                ['unlimited', '0']
            ],
            timeMode: prop$1('game.invite.clock', '1'),
            time: prop$1('game.invite.time', '5'),
            increment: prop$1('game.invite.increment', '0'),
            days: prop$1('game.invite.days', '2'),
            mode: prop$1('game.invite.mode', '0')
        }
    },
    tournament: {
        availableVariants: [
            ['Standard', '1'],
            ['Crazyhouse', '10'],
            ['Chess960', '2'],
            ['King of the Hill', '4'],
            ['Three-check', '5'],
            ['Antichess', '6'],
            ['Atomic', '7'],
            ['Horde', '8'],
            ['Racing Kings', '9']
        ],
        availableModes: [
            ['Casual', '0'],
            ['Rated', '1']
        ],
        availableTimes: [
            ['0', '0'], ['½', '0.5'], ['¾', '0.75'], ['1', '1'], ['1.5', '1.5'],
        ].concat(incrementTuples(2, 7, 1))
            .concat(incrementTuples(10, 25, 5))
            .concat(incrementTuples(30, 60, 10)),
        availableIncrements: increments(0, 7, 1)
            .concat(increments(10, 25, 5))
            .concat(increments(30, 60, 10)),
        availableDurations: increments(20, 55, 5)
            .concat(increments(60, 110, 10))
            .concat(increments(120, 360, 30))
            .concat(increments(420, 540, 60))
            .concat(['600', '720']),
        availableTimesToStart: ['1', '2', '3', '5', '10', '15', '20', '30', '45', '60'],
        variant: prop$1('tournament.variant', '1'),
        mode: prop$1('tournament.mode', '0'),
        time: prop$1('tournament.time', '5'),
        increment: prop$1('tournament.increment', '0'),
        duration: prop$1('tournament.duration', '45'),
        timeToStart: prop$1('tournament.timeToStart', '15'),
        position: prop$1('tournament.timeToStart', '15'),
        private: prop$1('tournament.private', false),
        join: {
            lastTeam: prop$1('tournament.join.lastTeam', '')
        },
    },
    tv: {
        channel: prop$1('tv.channel', 'best')
    },
    importer: {
        analyse: prop$1('importer.analyse', false)
    },
    training: {
        puzzleBufferLen: 50},
    coordinates: {
        colorChoice: prop$1('coordinates.colorChoice', 'random')
    },
    study: {
        tour: prop$1('study.tour', null)
    },
};
function prop$1(key, initialValue) {
    return function (value) {
        if (value !== undefined) {
            setAtPath(settingsStore, key, value);
            asyncStorage.set(STORAGE_KEY$1, settingsStore)
                .then(() => {
                console.debug(`${key}:${value} settings successfully persisted`);
            });
            return value;
        }
        const ret = getAtPath(settingsStore, key);
        return ret !== undefined ? ret : initialValue;
    };
}

const defaultLocale = 'en-GB';
const englishMessages = {};
const dateFormatOpts = { day: '2-digit', month: 'long', year: 'numeric' };
const dateTimeFormatOpts = { ...dateFormatOpts, hour: '2-digit', minute: '2-digit' };
let currentLocale = defaultLocale;
let dateLocale;
let messages = {};
let numberFormat = new Intl.NumberFormat();
let dateFormat = new Intl.DateTimeFormat(undefined, dateFormatOpts);
let dateTimeFormat = new Intl.DateTimeFormat(undefined, dateTimeFormatOpts);
function i18n(key, ...args) {
    const str = messages[key] || untranslated[key];
    return str ? format(str, ...args) : key;
}
function i18nVdom(key, ...args) {
    const str = messages[key] || untranslated[key];
    return str ? formatVdom(str, ...args) : key;
}
function plural(key, count, replaceWith) {
    const pluralKey = key + ':' + quantity(currentLocale, count);
    const str = messages[pluralKey] || messages[key + ':other'] || messages[key];
    return str ? format(str, replaceWith !== undefined ? replaceWith : count) : key;
}
function format(message, ...args) {
    let str = message;
    if (args.length) {
        if (str.includes('$s')) {
            for (let i = 1; i < 4; i++) {
                str = str.replace('%' + i + '$s', String(args[i - 1]));
            }
        }
        for (const arg of args) {
            str = str.replace('%s', String(arg));
        }
    }
    return str;
}
function formatVdom(str, ...args) {
    const segments = str.split(/(%(?:\d\$)?s)/g);
    for (let i = 1; i <= args.length; i++) {
        const pos = segments.indexOf('%' + i + '$s');
        if (pos !== -1)
            segments[pos] = args[i - 1];
    }
    for (let i = 0; i < args.length; i++) {
        const pos = segments.indexOf('%s');
        if (pos === -1)
            break;
        segments[pos] = args[i];
    }
    return segments;
}
function formatNumber(n) {
    return numberFormat.format(n);
}
function formatDate(d) {
    return dateFormat.format(d);
}
function formatDateTime(d) {
    return dateTimeFormat.format(d);
}
function formatDuration(duration) {
    const epoch = new Date(0);
    return formatDistanceStrict(epoch, addSeconds(epoch, duration), { locale: dateLocale });
}
function fromNow(date) {
    return formatRelative(date, new Date(), {
        locale: dateLocale
    });
}
function distanceToNowStrict(date, addSuffix = false) {
    return formatDistanceToNowStrict(date, {
        locale: dateLocale,
        addSuffix: addSuffix,
    });
}
function getLanguage(locale) {
    return locale.split('-')[0];
}
function getDefaultLocaleForLang(lang) {
    return defaultRegions[lang] || allKeys$1.find(k => getLanguage(k) === lang);
}
function getCurrentLocale() {
    return currentLocale;
}
/*
 * Call this once during app init.
 * Load english messages, they must always be there.
 * Load either lang stored as a setting or default app language.
 * It is called during app initialization, when we don't know yet server lang
 * preference.
 */
async function init$1() {
    // must use concat with defaultLocale const to force runtime module resolution
    const englishPromise = import('./i18n/' + defaultLocale + '.js')
        .then(({ default: data }) => {
        Object.assign(englishMessages, data);
    });
    const fromSettings = settings.general.locale();
    if (fromSettings && allLocales[fromSettings] !== undefined) {
        return englishPromise.then(() => loadLanguage(fromSettings));
    }
    else {
        return englishPromise
            .then(() => Device.getLanguageCode())
            .then(({ value }) => loadLanguage(getDefaultLocaleForLang(value) || defaultLocale));
    }
}
function loadLanguage(locale) {
    return loadFile(locale)
        .then(settings.general.locale)
        .then(() => loadDateLocale(locale));
}
function loadFile(locale) {
    const availLocale = allLocales[locale] ? locale : defaultLocale;
    console.info('Load language', availLocale);
    return import('./i18n/' + availLocale + '.js')
        .then(({ default: data }) => {
        currentLocale = availLocale;
        // some translation files don't have all the keys, merge with english
        // messages to keep a fallback to english
        messages = {
            ...englishMessages,
            ...data,
        };
        numberFormat = new Intl.NumberFormat(availLocale);
        dateFormat = new Intl.DateTimeFormat(availLocale, dateFormatOpts);
        dateTimeFormat = new Intl.DateTimeFormat(availLocale, dateTimeFormatOpts);
        return availLocale;
    });
}
// supported date-fns locales with region
const supportedDateLocales = ['ar-DZ', 'ar-MA', 'ar-SA', 'en-AU', 'en-CA', 'en-GB', 'en-IN', 'en-US', 'fa-IR', 'fr-CA', 'fr-CH', 'nl-BE', 'pt-BR', 'zh-CN', 'zh-TW'];
function loadDateLocale(locale) {
    if (locale === defaultLocale)
        return Promise.resolve(locale);
    const lCode = supportedDateLocales.includes(locale) ? locale : getLanguage(locale);
    return import(`./i18n/date/${lCode}.js`)
        .then(module => {
        dateLocale = module.default || undefined;
        return locale;
    })
        .catch(() => {
        dateLocale = undefined;
        return locale;
    });
}
function quantity(locale, c) {
    const rem100 = c % 100;
    const rem10 = c % 10;
    const code = getLanguage(locale);
    switch (code) {
        // french
        case 'fr':
        case 'ff':
        case 'kab':
            return c < 2 ? 'one' : 'other';
        // czech
        case 'cs':
        case 'sk':
            if (c === 1)
                return 'one';
            else if (c >= 2 && c <= 4)
                return 'few';
            else
                return 'other';
        // balkan
        case 'hr':
        case 'ru':
        case 'sr':
        case 'uk':
        case 'be':
        case 'bs':
        case 'sh':
            if (rem10 === 1 && rem100 !== 11)
                return 'one';
            else if (rem10 >= 2 && rem10 <= 4 && !(rem100 >= 12 && rem100 <= 14))
                return 'few';
            else if (rem10 === 0 || (rem10 >= 5 && rem10 <= 9) || (rem100 >= 11 && rem100 <= 14))
                return 'many';
            else
                return 'other';
        // latvian
        case 'lv':
            if (c === 0)
                return 'zero';
            else if (c % 10 === 1 && c % 100 !== 11)
                return 'one';
            else
                return 'other';
        // lithuanian
        case 'lt':
            if (rem10 === 1 && !(rem100 >= 11 && rem100 <= 19))
                return 'one';
            else if (rem10 >= 2 && rem10 <= 9 && !(rem100 >= 11 && rem100 <= 19))
                return 'few';
            else
                return 'other';
        // polish
        case 'pl':
            if (c === 1)
                return 'one';
            else if (rem10 >= 2 && rem10 <= 4 && !(rem100 >= 12 && rem100 <= 14))
                return 'few';
            else
                return 'other';
        // romanian
        case 'ro':
        case 'mo':
            if (c === 1)
                return 'one';
            else if ((c === 0 || (rem100 >= 1 && rem100 <= 19)))
                return 'few';
            else
                return 'other';
        // slovenian
        case 'sl':
            if (rem100 === 1)
                return 'one';
            else if (rem100 === 2)
                return 'two';
            else if (rem100 >= 3 && rem100 <= 4)
                return 'few';
            else
                return 'other';
        // arabic
        case 'ar':
            if (c === 0)
                return 'zero';
            else if (c === 1)
                return 'one';
            else if (c === 2)
                return 'two';
            else if (rem100 >= 3 && rem100 <= 10)
                return 'few';
            else if (rem100 >= 11 && rem100 <= 99)
                return 'many';
            else
                return 'other';
        // macedonian
        case 'mk':
            return (c % 10 === 1 && c !== 11) ? 'one' : 'other';
        // welsh
        case 'cy':
        case 'br':
            if (c === 0)
                return 'zero';
            else if (c === 1)
                return 'one';
            else if (c === 2)
                return 'two';
            else if (c === 3)
                return 'few';
            else if (c === 6)
                return 'many';
            else
                return 'other';
        // maltese
        case 'mt':
            if (c === 1)
                return 'one';
            else if (c === 0 || (rem100 >= 2 && rem100 <= 10))
                return 'few';
            else if (rem100 >= 11 && rem100 <= 19)
                return 'many';
            else
                return 'other';
        // two
        case 'ga':
        case 'se':
        case 'sma':
        case 'smi':
        case 'smj':
        case 'smn':
        case 'sms':
            if (c === 1)
                return 'one';
            else if (c === 2)
                return 'two';
            else
                return 'other';
        // zero
        case 'ak':
        case 'am':
        case 'bh':
        case 'fil':
        case 'tl':
        case 'guw':
        case 'hi':
        case 'ln':
        case 'mg':
        case 'nso':
        case 'ti':
        case 'wa':
            return (c === 0 || c === 1) ? 'one' : 'other';
        // none
        case 'az':
        case 'bm':
        case 'fa':
        case 'ig':
        case 'hu':
        case 'ja':
        case 'kde':
        case 'kea':
        case 'ko':
        case 'my':
        case 'ses':
        case 'sg':
        case 'to':
        case 'tr':
        case 'vi':
        case 'wo':
        case 'yo':
        case 'zh':
        case 'bo':
        case 'dz':
        case 'id':
        case 'jv':
        case 'ka':
        case 'km':
        case 'kn':
        case 'ms':
        case 'th':
        case 'tp':
        case 'io':
        case 'ia':
            return 'other';
        default:
            return c === 1 ? 'one' : 'other';
    }
}
const allLocales = {
    'af-ZA': 'Afrikaans',
    'an-ES': 'aragonés',
    'ar-SA': 'العربية',
    'as-IN': 'অসমীয়া',
    'az-AZ': 'Azərbaycanca',
    'be-BY': 'Беларуская',
    'bg-BG': 'български език',
    'bn-BD': 'বাংলা',
    'br-FR': 'brezhoneg',
    'bs-BA': 'bosanski',
    'ca-ES': 'Català, valencià',
    'cs-CZ': 'čeština',
    'cv-CU': 'чӑваш чӗлхи',
    'cy-GB': 'Cymraeg',
    'da-DK': 'Dansk',
    'de-CH': 'Schwiizerdüütsch',
    'de-DE': 'Deutsch',
    'el-GR': 'Ελληνικά',
    'en-GB': 'English',
    'en-US': 'English (US)',
    'eo-UY': 'Esperanto',
    'es-ES': 'español',
    'et-EE': 'eesti keel',
    'eu-ES': 'Euskara',
    'fa-IR': 'فارسی',
    'fi-FI': 'suomen kieli',
    'fo-FO': 'føroyskt',
    'fr-FR': 'français',
    'frp-IT': 'arpitan',
    'fy-NL': 'Frysk',
    'ga-IE': 'Gaeilge',
    'gd-GB': 'Gàidhlig',
    'gl-ES': 'Galego',
    'gu-IN': 'ગુજરાતી',
    'he-IL': 'עִבְרִית',
    'hi-IN': 'हिन्दी, हिंदी',
    'hr-HR': 'hrvatski',
    'hu-HU': 'Magyar',
    'hy-AM': 'Հայերեն',
    'ia-IA': 'Interlingua',
    'id-ID': 'Bahasa Indonesia',
    'io-EN': 'Ido',
    'is-IS': 'Íslenska',
    'it-IT': 'Italiano',
    'ja-JP': '日本語',
    'jbo-EN': 'lojban',
    'jv-ID': 'basa Jawa',
    'ka-GE': 'ქართული',
    'kab-DZ': 'Taqvaylit',
    'kk-KZ': 'қазақша',
    'kmr-TR': 'Kurdî (Kurmancî)',
    'kn-IN': 'ಕನ್ನಡ',
    'ko-KR': '한국어',
    'ky-KG': 'кыргызча',
    'la-LA': 'lingua Latina',
    'lb-LU': 'Lëtzebuergesch',
    'lt-LT': 'lietuvių kalba',
    'lv-LV': 'latviešu valoda',
    'mg-MG': 'fiteny malagasy',
    'mk-MK': 'македонски јази',
    'ml-IN': 'മലയാളം',
    'mn-MN': 'монгол',
    'mr-IN': 'मराठी',
    'nb-NO': 'Norsk bokmål',
    'ne-NP': 'नेपाली',
    'nl-NL': 'Nederlands',
    'nn-NO': 'Norsk nynorsk',
    'pi-IN': 'पालि',
    'pl-PL': 'polski',
    'ps-AF': 'پښتو',
    'pt-PT': 'Português',
    'pt-BR': 'Português (BR)',
    'ro-RO': 'Română',
    'ru-RU': 'русский язык',
    'sa-IN': 'संस्कृत',
    'sk-SK': 'slovenčina',
    'sl-SI': 'slovenščina',
    'sq-AL': 'Shqip',
    'sr-SP': 'Српски језик',
    'sv-SE': 'svenska',
    'sw-KE': 'Kiswahili',
    'ta-IN': 'தமிழ்',
    'tg-TJ': 'тоҷикӣ',
    'th-TH': 'ไทย',
    'tk-TM': 'Türkmençe',
    'tl-PH': 'Tagalog',
    'tp-TP': 'toki pona',
    'tr-TR': 'Türkçe',
    'uk-UA': 'українська',
    'ur-PK': 'اُردُو',
    'uz-UZ': 'oʻzbekcha',
    'vi-VN': 'Tiếng Việt',
    'yo-NG': 'Yorùbá',
    'zh-CN': '中文',
    'zh-TW': '繁體中文',
    'zu-ZA': 'isiZulu'
};
const allKeys$1 = Object.keys(allLocales);
const defaultRegions = {
    'de': 'de-DE',
    'en': 'en-US',
    'pt': 'pt-PT',
    'zh': 'zh-CN',
};
const untranslated = {
    apiUnsupported: 'Your version of lichess app is too old! Please upgrade for free to the latest version.',
    apiDeprecated: 'Upgrade for free to the latest lichess app! Support for this version will be dropped on %s.',
    playerisInvitingYou: '%s is inviting you',
    unsupportedVariant: 'Variant %s is not supported in this version',
    notesSynchronizationHasFailed: 'Notes synchronization with lichess has failed, please try later.',
    localEvalCaution: 'Caution: intensive usage will drain battery.',
    incorrectThreefoldClaim: 'Incorrect threefold repetition claim.',
    vibrateOnGameEvents: 'Vibrate on game events',
    offline: 'Offline'
};

const defaults = {
    apiVersion: 5,
    fetchTimeoutMs: 15000
};
const config = Object.assign({}, defaults, window.lichess);

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

var signals$2 = {exports: {}};

/*jslint onevar:true, undef:true, newcap:true, regexp:true, bitwise:true, maxerr:50, indent:4, white:false, nomen:false, plusplus:false */
var signals$1 = signals$2.exports;

var hasRequiredSignals;

function requireSignals () {
	if (hasRequiredSignals) return signals$2.exports;
	hasRequiredSignals = 1;
	(function (module) {
		/*global define:false, require:false, exports:false, module:false, signals:false */

		/** @license
		 * JS Signals <http://millermedeiros.github.com/js-signals/>
		 * Released under the MIT license
		 * Author: Miller Medeiros
		 * Version: 1.0.0 - Build: 268 (2012/11/29 05:48 PM)
		 */

		(function(global){

		    // SignalBinding -------------------------------------------------
		    //================================================================

		    /**
		     * Object that represents a binding between a Signal and a listener function.
		     * <br />- <strong>This is an internal constructor and shouldn't be called by regular users.</strong>
		     * <br />- inspired by Joa Ebert AS3 SignalBinding and Robert Penner's Slot classes.
		     * @author Miller Medeiros
		     * @constructor
		     * @internal
		     * @name SignalBinding
		     * @param {Signal} signal Reference to Signal object that listener is currently bound to.
		     * @param {Function} listener Handler function bound to the signal.
		     * @param {boolean} isOnce If binding should be executed just once.
		     * @param {Object} [listenerContext] Context on which listener will be executed (object that should represent the `this` variable inside listener function).
		     * @param {Number} [priority] The priority level of the event listener. (default = 0).
		     */
		    function SignalBinding(signal, listener, isOnce, listenerContext, priority) {

		        /**
		         * Handler function bound to the signal.
		         * @type Function
		         * @private
		         */
		        this._listener = listener;

		        /**
		         * If binding should be executed just once.
		         * @type boolean
		         * @private
		         */
		        this._isOnce = isOnce;

		        /**
		         * Context on which listener will be executed (object that should represent the `this` variable inside listener function).
		         * @memberOf SignalBinding.prototype
		         * @name context
		         * @type Object|undefined|null
		         */
		        this.context = listenerContext;

		        /**
		         * Reference to Signal object that listener is currently bound to.
		         * @type Signal
		         * @private
		         */
		        this._signal = signal;

		        /**
		         * Listener priority
		         * @type Number
		         * @private
		         */
		        this._priority = priority || 0;
		    }

		    SignalBinding.prototype = {

		        /**
		         * If binding is active and should be executed.
		         * @type boolean
		         */
		        active : true,

		        /**
		         * Default parameters passed to listener during `Signal.dispatch` and `SignalBinding.execute`. (curried parameters)
		         * @type Array|null
		         */
		        params : null,

		        /**
		         * Call listener passing arbitrary parameters.
		         * <p>If binding was added using `Signal.addOnce()` it will be automatically removed from signal dispatch queue, this method is used internally for the signal dispatch.</p>
		         * @param {Array} [paramsArr] Array of parameters that should be passed to the listener
		         * @return {*} Value returned by the listener.
		         */
		        execute : function (paramsArr) {
		            var handlerReturn, params;
		            if (this.active && !!this._listener) {
		                params = this.params? this.params.concat(paramsArr) : paramsArr;
		                handlerReturn = this._listener.apply(this.context, params);
		                if (this._isOnce) {
		                    this.detach();
		                }
		            }
		            return handlerReturn;
		        },

		        /**
		         * Detach binding from signal.
		         * - alias to: mySignal.remove(myBinding.getListener());
		         * @return {Function|null} Handler function bound to the signal or `null` if binding was previously detached.
		         */
		        detach : function () {
		            return this.isBound()? this._signal.remove(this._listener, this.context) : null;
		        },

		        /**
		         * @return {Boolean} `true` if binding is still bound to the signal and have a listener.
		         */
		        isBound : function () {
		            return (!!this._signal && !!this._listener);
		        },

		        /**
		         * @return {boolean} If SignalBinding will only be executed once.
		         */
		        isOnce : function () {
		            return this._isOnce;
		        },

		        /**
		         * @return {Function} Handler function bound to the signal.
		         */
		        getListener : function () {
		            return this._listener;
		        },

		        /**
		         * @return {Signal} Signal that listener is currently bound to.
		         */
		        getSignal : function () {
		            return this._signal;
		        },

		        /**
		         * Delete instance properties
		         * @private
		         */
		        _destroy : function () {
		            delete this._signal;
		            delete this._listener;
		            delete this.context;
		        },

		        /**
		         * @return {string} String representation of the object.
		         */
		        toString : function () {
		            return '[SignalBinding isOnce:' + this._isOnce +', isBound:'+ this.isBound() +', active:' + this.active + ']';
		        }

		    };


		/*global SignalBinding:false*/

		    // Signal --------------------------------------------------------
		    //================================================================

		    function validateListener(listener, fnName) {
		        if (typeof listener !== 'function') {
		            throw new Error( 'listener is a required param of {fn}() and should be a Function.'.replace('{fn}', fnName) );
		        }
		    }

		    /**
		     * Custom event broadcaster
		     * <br />- inspired by Robert Penner's AS3 Signals.
		     * @name Signal
		     * @author Miller Medeiros
		     * @constructor
		     */
		    function Signal() {
		        /**
		         * @type Array.<SignalBinding>
		         * @private
		         */
		        this._bindings = [];
		        this._prevParams = null;

		        // enforce dispatch to aways work on same context (#47)
		        var self = this;
		        this.dispatch = function(){
		            Signal.prototype.dispatch.apply(self, arguments);
		        };
		    }

		    Signal.prototype = {

		        /**
		         * Signals Version Number
		         * @type String
		         * @const
		         */
		        VERSION : '1.0.0',

		        /**
		         * If Signal should keep record of previously dispatched parameters and
		         * automatically execute listener during `add()`/`addOnce()` if Signal was
		         * already dispatched before.
		         * @type boolean
		         */
		        memorize : false,

		        /**
		         * @type boolean
		         * @private
		         */
		        _shouldPropagate : true,

		        /**
		         * If Signal is active and should broadcast events.
		         * <p><strong>IMPORTANT:</strong> Setting this property during a dispatch will only affect the next dispatch, if you want to stop the propagation of a signal use `halt()` instead.</p>
		         * @type boolean
		         */
		        active : true,

		        /**
		         * @param {Function} listener
		         * @param {boolean} isOnce
		         * @param {Object} [listenerContext]
		         * @param {Number} [priority]
		         * @return {SignalBinding}
		         * @private
		         */
		        _registerListener : function (listener, isOnce, listenerContext, priority) {

		            var prevIndex = this._indexOfListener(listener, listenerContext),
		                binding;

		            if (prevIndex !== -1) {
		                binding = this._bindings[prevIndex];
		                if (binding.isOnce() !== isOnce) {
		                    throw new Error('You cannot add'+ (isOnce? '' : 'Once') +'() then add'+ (!isOnce? '' : 'Once') +'() the same listener without removing the relationship first.');
		                }
		            } else {
		                binding = new SignalBinding(this, listener, isOnce, listenerContext, priority);
		                this._addBinding(binding);
		            }

		            if(this.memorize && this._prevParams){
		                binding.execute(this._prevParams);
		            }

		            return binding;
		        },

		        /**
		         * @param {SignalBinding} binding
		         * @private
		         */
		        _addBinding : function (binding) {
		            //simplified insertion sort
		            var n = this._bindings.length;
		            do { --n; } while (this._bindings[n] && binding._priority <= this._bindings[n]._priority);
		            this._bindings.splice(n + 1, 0, binding);
		        },

		        /**
		         * @param {Function} listener
		         * @return {number}
		         * @private
		         */
		        _indexOfListener : function (listener, context) {
		            var n = this._bindings.length,
		                cur;
		            while (n--) {
		                cur = this._bindings[n];
		                if (cur._listener === listener && cur.context === context) {
		                    return n;
		                }
		            }
		            return -1;
		        },

		        /**
		         * Check if listener was attached to Signal.
		         * @param {Function} listener
		         * @param {Object} [context]
		         * @return {boolean} if Signal has the specified listener.
		         */
		        has : function (listener, context) {
		            return this._indexOfListener(listener, context) !== -1;
		        },

		        /**
		         * Add a listener to the signal.
		         * @param {Function} listener Signal handler function.
		         * @param {Object} [listenerContext] Context on which listener will be executed (object that should represent the `this` variable inside listener function).
		         * @param {Number} [priority] The priority level of the event listener. Listeners with higher priority will be executed before listeners with lower priority. Listeners with same priority level will be executed at the same order as they were added. (default = 0)
		         * @return {SignalBinding} An Object representing the binding between the Signal and listener.
		         */
		        add : function (listener, listenerContext, priority) {
		            validateListener(listener, 'add');
		            return this._registerListener(listener, false, listenerContext, priority);
		        },

		        /**
		         * Add listener to the signal that should be removed after first execution (will be executed only once).
		         * @param {Function} listener Signal handler function.
		         * @param {Object} [listenerContext] Context on which listener will be executed (object that should represent the `this` variable inside listener function).
		         * @param {Number} [priority] The priority level of the event listener. Listeners with higher priority will be executed before listeners with lower priority. Listeners with same priority level will be executed at the same order as they were added. (default = 0)
		         * @return {SignalBinding} An Object representing the binding between the Signal and listener.
		         */
		        addOnce : function (listener, listenerContext, priority) {
		            validateListener(listener, 'addOnce');
		            return this._registerListener(listener, true, listenerContext, priority);
		        },

		        /**
		         * Remove a single listener from the dispatch queue.
		         * @param {Function} listener Handler function that should be removed.
		         * @param {Object} [context] Execution context (since you can add the same handler multiple times if executing in a different context).
		         * @return {Function} Listener handler function.
		         */
		        remove : function (listener, context) {
		            validateListener(listener, 'remove');

		            var i = this._indexOfListener(listener, context);
		            if (i !== -1) {
		                this._bindings[i]._destroy(); //no reason to a SignalBinding exist if it isn't attached to a signal
		                this._bindings.splice(i, 1);
		            }
		            return listener;
		        },

		        /**
		         * Remove all listeners from the Signal.
		         */
		        removeAll : function () {
		            var n = this._bindings.length;
		            while (n--) {
		                this._bindings[n]._destroy();
		            }
		            this._bindings.length = 0;
		        },

		        /**
		         * @return {number} Number of listeners attached to the Signal.
		         */
		        getNumListeners : function () {
		            return this._bindings.length;
		        },

		        /**
		         * Stop propagation of the event, blocking the dispatch to next listeners on the queue.
		         * <p><strong>IMPORTANT:</strong> should be called only during signal dispatch, calling it before/after dispatch won't affect signal broadcast.</p>
		         * @see Signal.prototype.disable
		         */
		        halt : function () {
		            this._shouldPropagate = false;
		        },

		        /**
		         * Dispatch/Broadcast Signal to all listeners added to the queue.
		         * @param {...*} [params] Parameters that should be passed to each handler.
		         */
		        dispatch : function (params) {
		            if (! this.active) {
		                return;
		            }

		            var paramsArr = Array.prototype.slice.call(arguments),
		                n = this._bindings.length,
		                bindings;

		            if (this.memorize) {
		                this._prevParams = paramsArr;
		            }

		            if (! n) {
		                //should come after memorize
		                return;
		            }

		            bindings = this._bindings.slice(); //clone array in case add/remove items during dispatch
		            this._shouldPropagate = true; //in case `halt` was called before dispatch or during the previous dispatch.

		            //execute all callbacks until end of the list or until a callback returns `false` or stops propagation
		            //reverse loop since listeners with higher priority will be added at the end of the list
		            do { n--; } while (bindings[n] && this._shouldPropagate && bindings[n].execute(paramsArr) !== false);
		        },

		        /**
		         * Forget memorized arguments.
		         * @see Signal.memorize
		         */
		        forget : function(){
		            this._prevParams = null;
		        },

		        /**
		         * Remove all bindings from signal and destroy any reference to external objects (destroy Signal object).
		         * <p><strong>IMPORTANT:</strong> calling any method on the signal instance after calling dispose will throw errors.</p>
		         */
		        dispose : function () {
		            this.removeAll();
		            delete this._bindings;
		            delete this._prevParams;
		        },

		        /**
		         * @return {string} String representation of the object.
		         */
		        toString : function () {
		            return '[Signal active:'+ this.active +' numListeners:'+ this.getNumListeners() +']';
		        }

		    };


		    // Namespace -----------------------------------------------------
		    //================================================================

		    /**
		     * Signals namespace
		     * @namespace
		     * @name signals
		     */
		    var signals = Signal;

		    /**
		     * Custom event broadcaster
		     * @see Signal
		     */
		    // alias for backwards compatibility (see #gh-44)
		    signals.Signal = Signal;



		    //exports to multiple environments
		    if (module.exports){ //node
		        module.exports = signals;
		    } else { //browser
		        //use string because of Google closure compiler ADVANCED_MODE
		        /*jslint sub:true */
		        global['signals'] = signals;
		    }

		}(signals$1)); 
	} (signals$2));
	return signals$2.exports;
}

var signalsExports = requireSignals();

var signals = {
    // global screen redraw mechanism; it works the same way as m.redraw() works
    // except it is always async and debounced within an animation frame
    redraw: new signalsExports.Signal(),
    // signal sent after successful login
    afterLogin: new signalsExports.Signal(),
    // signal sent after logout, or loosing session
    afterLogout: new signalsExports.Signal(),
    // signal sent after successful restored session from offline database
    sessionRestored: new signalsExports.Signal(),
    // signal fired on websocket pong in homepage
    homePong: new signalsExports.Signal(),
    // signal fired when a backbutton requesting a back history was called in a
    // game screen
    gameBackButton: new signalsExports.Signal(),
};

let callbacks = new Set();
let batching = false;
function batchRequestAnimationFrame(callback) {
    callbacks.add(callback);
    if (!batching) {
        batching = true;
        requestAnimationFrame((ts) => {
            const batch = callbacks;
            batching = false;
            callbacks = new Set();
            batch.forEach(f => f(ts));
            // console.debug('batchRAF', batch.size, 'execution time (ms)', performance.now() - ts)
        });
    }
}
function removeFromBatchAnimationFrame(callback) {
    callbacks.delete(callback);
}

const redrawSync = signals.redraw.dispatch;
function redraw() {
    // console.trace()
    batchRequestAnimationFrame(redrawSync);
}

let sri;
function currentSri() {
    return sri || newSri();
}
// Unique id for the current websocket connection. Should be different after
// each websocket reconnection. Should be unpredictable and secret while
// in use.
function newSri() {
    const data = window.crypto.getRandomValues(new Uint8Array(9));
    sri = btoa(String.fromCharCode(...data)).replace(/[/+]/g, '_');
    return sri;
}
function loadLocalJsonFile(url) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.overrideMimeType('application/json');
        xhr.open('GET', url, true);
        xhr.onreadystatechange = () => {
            if (xhr.readyState === 4) {
                if (xhr.status === 0 || xhr.status === 200)
                    resolve(JSON.parse(xhr.responseText));
                else
                    reject(xhr);
            }
        };
        xhr.send(null);
    });
}
function isScriptLoaded(url) {
    const scripts = document.head.getElementsByTagName('script');
    for (let i = 0, len = scripts.length; i < len; i++) {
        if (scripts[i].getAttribute('src') === url) {
            return true;
        }
    }
    return false;
}
function isCssLoaded(url) {
    const links = document.head.getElementsByTagName('link');
    for (let i = 0, len = links.length; i < len; i++) {
        if (links[i].getAttribute('href') === url) {
            return true;
        }
    }
    return false;
}
function loadScript(url) {
    return new Promise((resolve, reject) => {
        if (!isScriptLoaded(url)) {
            const script = document.createElement('script');
            script.src = url;
            script.onload = () => resolve();
            script.onerror = () => reject();
            document.head.appendChild(script);
        }
        else {
            setTimeout(resolve, 0);
        }
    });
}
function loadCss(url) {
    return new Promise((resolve, reject) => {
        if (!isCssLoaded(url)) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = url;
            link.onload = () => resolve();
            link.onerror = () => reject();
            document.head.appendChild(link);
        }
        else {
            setTimeout(resolve, 0);
        }
    });
}
function autoredraw(action) {
    const res = action();
    redraw();
    return res;
}
let networkStatus = { connected: false};
Network.addListener('networkStatusChange', st => {
    networkStatus = st;
});
Network.getStatus().then(st => {
    networkStatus = st;
});
function hasNetwork() {
    return networkStatus.connected;
}
function handleXhrError(error) {
    const status = error.status;
    const data = error.body;
    let message;
    if (!status || status === 0)
        message = 'Chess-Online Arena is unreachable.';
    else if (status === 401)
        message = 'You are not authorized to do that.';
    else if (status === 404)
        message = 'Resource not found.';
    else if (status === 503)
        message = 'Chess-Online Arena is temporarily down for maintenance.';
    else if (status >= 500)
        message = 'Server error.';
    else
        message = 'Something went wrong.';
    if (data) {
        if (typeof data === 'string') {
            message += ` ${data}`;
        }
        else if (typeof data.error === 'string') {
            message += ` ${data.error}`;
        }
        else if (data.global && data.global.constructor === Array) {
            message += ` ${i18n(data.global[0])}`;
        }
    }
    Toast.show({ text: message, duration: 'short' });
}
function serializeQueryParameters(obj) {
    let str = '';
    const keys = Object.keys(obj);
    keys.forEach(key => {
        const val = obj[key];
        if (val !== null && val !== undefined) {
            if (str !== '') {
                str += '&';
            }
            str += encodeURIComponent(key) + '=' + encodeURIComponent(val);
        }
    });
    return str;
}
function noop$1() { }
const perfIconsMap = {
    bullet: 'T',
    blitz: ')',
    rapid: '#',
    classical: '+',
    correspondence: ';',
    chess960: '\'',
    kingOfTheHill: '(',
    threeCheck: '.',
    antichess: '@',
    atomic: '>',
    puzzle: '-',
    horde: '_',
    fromPosition: '*',
    racingKings: '',
    crazyhouse: '',
    ultraBullet: '{',
    computer: 'n',
    bot: 'n',
};
function gameIcon(perf) {
    return perf ? perfIconsMap[perf] || '8' : '8';
}
function secondsToMinutes(sec) {
    return sec === 0 ? sec : sec / 60;
}
function oppositeColor(color) {
    return color === 'white' ? 'black' : 'white';
}
function capitalize(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
}
function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}
function boardOrientation(data, flip) {
    if (data.game.variant.key === 'racingKings') {
        return flip ? 'black' : 'white';
    }
    else {
        return flip ? data.opponent.color : data.player.color;
    }
}
function pad(num, size) {
    let s = num + '';
    while (s.length < size)
        s = '0' + s;
    return s;
}
function formatTimeInSecs(seconds, format = 'hour_min_secs') {
    let timeStr = '';
    const hours = Math.floor(seconds / 60 / 60);
    const mins = Math.floor(seconds / 60) - (hours * 60);
    const secs = seconds % 60;
    if (format === 'hour_min_secs') {
        if (hours > 0) {
            timeStr = hours + ':' + pad(mins, 2) + ':' + pad(secs, 2);
        }
        else {
            timeStr = mins + ':' + pad(secs, 2);
        }
    }
    else {
        timeStr = pad(secs, 2);
    }
    return timeStr;
}
function formatTournamentDuration(timeInMin) {
    const hours = Math.floor(timeInMin / 60);
    const minutes = Math.floor(timeInMin - hours * 60);
    return (hours ? hours + 'H ' : '') + (minutes ? minutes + 'M' : '');
}
function formatTournamentTimeControl(clock) {
    if (clock) {
        const min = secondsToMinutes(clock.limit);
        const t = min === 0.25 ? '¼' : min === 0.5 ? '½' : min === 0.75 ? '¾' : min.toString();
        return t + '+' + clock.increment;
    }
    else {
        return '∞';
    }
}
function noNull(v) {
    return v !== undefined && v !== null;
}
function lichessAssetSrc(path) {
    return `${config.apiEndPoint}/assets/${path}`;
}
function displayTime(time) {
    if (time === '0.75')
        return '¾';
    if (time === '0.5')
        return '½';
    if (time === '0.25')
        return '¼';
    return time;
}
function truncate(text, len) {
    return text.length > len ? text.slice(0, len) + '…' : text;
}
function safeStringToNum(s) {
    const n = Number(s);
    return isNaN(n) ? undefined : n;
}
function charToInt(char) {
    const i = char.charCodeAt(0);
    if (i > 96) {
        return i - 71;
    }
    else if (i > 64) {
        return i - 65;
    }
    return i + 4;
}
function base62ToNumber(id) {
    // Server idSize is 5 at the time of writing, but we'll be lenient
    if (id === undefined || id.length > 7 || id.length === 0 || (/[^a-zA-Z0-9]/.exec(id))) {
        return undefined;
    }
    return id.split('').reduce((output, char, i) => {
        return output + charToInt(char) * Math.pow(62, i);
    }, 0);
}
const requestIdleCallback = window.requestIdleCallback || window.setTimeout;
function prop(initialValue) {
    let value = initialValue;
    return (v) => {
        if (v !== undefined)
            value = v;
        return value;
    };
}
function animationDuration(pref) {
    return pref ? 250 : 0;
    // const base = 250
    // switch (pref) {
    //   case 0:
    //     return 0
    //   case 1:
    //     return base * 0.5
    //   case 2:
    //     return base
    //   case 3:
    //     return base * 2
    //   default:
    //     return base
    // }
}
function randomColor() {
    return Math.random() > 0.5 ? 'white' : 'black';
}
/**
 * Gets the legal color options from a given mode (casual/rated) and variant.
 *
 * @param modeNum the mode represented by '0' (casual) or '1' (rated)
 * @param variantNum the variant represented by a number string
 * @returns a list of (i18n key, color key) tuples
 */
function getColorOptionsFromModeAndVariant(modeNum, variantNum) {
    // if mode is rated only allow random color for three-check, atomic, antichess, horde variants
    if (modeNum === '1' && ['5', '6', '7', '8', '9'].indexOf(variantNum) !== -1) {
        return [
            ['randomColor', 'random']
        ];
    }
    else {
        return [
            ['randomColor', 'random'],
            ['white', 'white'],
            ['black', 'black']
        ];
    }
}

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a throttled function that only invokes `func` at most once per
 * every `wait` milliseconds. The throttled function comes with a `cancel`
 * method to cancel delayed `func` invocations and a `flush` method to
 * immediately invoke them. Provide `options` to indicate whether `func`
 * should be invoked on the leading and/or trailing edge of the `wait`
 * timeout. The `func` is invoked with the last arguments provided to the
 * throttled function. Subsequent calls to the throttled function return the
 * result of the last `func` invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the throttled function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.throttle` and `_.debounce`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to throttle.
 * @param {number} [wait=0] The number of milliseconds to throttle invocations to.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=true]
 *  Specify invoking on the leading edge of the timeout.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new throttled function.
 * @example
 *
 * // Avoid excessively updating the position while scrolling.
 * jQuery(window).on('scroll', _.throttle(updatePosition, 100));
 *
 * // Invoke `renewToken` when the click event is fired, but not more than once every 5 minutes.
 * var throttled = _.throttle(renewToken, 300000, { 'trailing': false });
 * jQuery(element).on('click', throttled);
 *
 * // Cancel the trailing throttled invocation.
 * jQuery(window).on('popstate', throttled.cancel);
 */
function throttle(func, wait, options) {
  var leading = true,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  if (isObject$1(options)) {
    leading = 'leading' in options ? !!options.leading : leading;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }
  return debounce(func, wait, {
    'leading': leading,
    'maxWait': wait,
    'trailing': trailing
  });
}

function withStorage(f) {
    // can throw an exception when storage is full
    try {
        return window.localStorage ? f(window.localStorage) : null;
    }
    catch (e) { /* noop */ }
}
var storage = {
    get: get$1,
    set: set$2,
    remove,
};
function get$1(k) {
    return withStorage((s) => {
        const item = s.getItem(k);
        return item ? JSON.parse(item) : null;
    });
}
function remove(k) {
    withStorage((s) => {
        s.removeItem(k);
    });
}
function set$2(k, v) {
    withStorage((s) => {
        try {
            s.setItem(k, JSON.stringify(v));
        }
        catch (_) {
            // http://stackoverflow.com/questions/2603682/is-anyone-else-receiving-a-quota-exceeded-err-on-their-ipad-when-accessing-local
            s.removeItem(k);
            s.setItem(k, JSON.stringify(v));
        }
    });
}

var vnode;
var hasRequiredVnode;

function requireVnode () {
	if (hasRequiredVnode) return vnode;
	hasRequiredVnode = 1;

	function Vnode(tag, key, attrs, children, text, dom) {
		return {tag: tag, key: key, attrs: attrs, children: children, text: text, dom: dom, domSize: undefined, state: undefined, events: undefined, instance: undefined}
	}
	Vnode.normalize = function(node) {
		if (Array.isArray(node)) return Vnode("[", undefined, undefined, Vnode.normalizeChildren(node), undefined, undefined)
		if (node == null || typeof node === "boolean") return null
		if (typeof node === "object") return node
		return Vnode("#", undefined, undefined, String(node), undefined, undefined)
	};
	Vnode.normalizeChildren = function(input) {
		var children = [];
		if (window.lichess && window.lichess.mode === 'dev' && input.length) {
			var isKeyed = input[0] != null && input[0].key != null;
			// Note: this is a *very* perf-sensitive check.
			// Fun fact: merging the loop like this is somehow faster than splitting
			// it, noticeably so.
			for (var i = 1; i < input.length; i++) {
				if ((input[i] != null && input[i].key != null) !== isKeyed) {
					throw new TypeError(
						isKeyed && (input[i] != null || typeof input[i] === "boolean")
							? "In fragments, vnodes must either all have keys or none have keys. You may wish to consider using an explicit keyed empty fragment, m.fragment({key: ...}), instead of a hole."
							: "In fragments, vnodes must either all have keys or none have keys."
					)
				}
			}
		}
	  for (var i = 0; i < input.length; i++) {
	    children[i] = Vnode.normalize(input[i]);
	  }
		return children
	};

	vnode = Vnode;
	return vnode;
}

var hyperscriptVnode;
var hasRequiredHyperscriptVnode;

function requireHyperscriptVnode () {
	if (hasRequiredHyperscriptVnode) return hyperscriptVnode;
	hasRequiredHyperscriptVnode = 1;

	var Vnode = requireVnode();

	// Call via `hyperscriptVnode.apply(startOffset, arguments)`
	//
	// The reason I do it this way, forwarding the arguments and passing the start
	// offset in `this`, is so I don't have to create a temporary array in a
	// performance-critical path.
	//
	// In native ES6, I'd instead add a final `...args` parameter to the
	// `hyperscript` and `fragment` factories and define this as
	// `hyperscriptVnode(...args)`, since modern engines do optimize that away. But
	// ES5 (what Mithril requires thanks to IE support) doesn't give me that luxury,
	// and engines aren't nearly intelligent enough to do either of these:
	//
	// 1. Elide the allocation for `[].slice.call(arguments, 1)` when it's passed to
	//    another function only to be indexed.
	// 2. Elide an `arguments` allocation when it's passed to any function other
	//    than `Function.prototype.apply` or `Reflect.apply`.
	//
	// In ES6, it'd probably look closer to this (I'd need to profile it, though):
	// module.exports = function(attrs, ...children) {
	//     if (attrs == null || typeof attrs === "object" && attrs.tag == null && !Array.isArray(attrs)) {
	//         if (children.length === 1 && Array.isArray(children[0])) children = children[0]
	//     } else {
	//         children = children.length === 0 && Array.isArray(attrs) ? attrs : [attrs, ...children]
	//         attrs = undefined
	//     }
	//
	//     if (attrs == null) attrs = {}
	//     return Vnode("", attrs.key, attrs, children)
	// }
	hyperscriptVnode = function() {
		var attrs = arguments[this], start = this + 1, children;

		if (attrs == null) {
			attrs = {};
		} else if (typeof attrs !== "object" || attrs.tag != null || Array.isArray(attrs)) {
			attrs = {};
			start = this;
		}

		if (arguments.length === start + 1) {
			children = arguments[start];
			if (!Array.isArray(children)) children = [children];
		} else {
			children = [];
			while (start < arguments.length) children.push(arguments[start++]);
		}

		return Vnode("", attrs.key, attrs, children)
	};
	return hyperscriptVnode;
}

var hasOwn;
var hasRequiredHasOwn;

function requireHasOwn () {
	if (hasRequiredHasOwn) return hasOwn;
	hasRequiredHasOwn = 1;

	hasOwn = {}.hasOwnProperty;
	return hasOwn;
}

var hyperscript_1$1;
var hasRequiredHyperscript$1;

function requireHyperscript$1 () {
	if (hasRequiredHyperscript$1) return hyperscript_1$1;
	hasRequiredHyperscript$1 = 1;

	var Vnode = requireVnode();
	var hyperscriptVnode = requireHyperscriptVnode();
	var hasOwn = requireHasOwn();

	var selectorParser = /(?:(^|#|\.)([^#\.\[\]]+))|(\[(.+?)(?:\s*=\s*("|'|)((?:\\["'\]]|.)*?)\5)?\])/g;
	var selectorCache = {};

	function isEmpty(object) {
		for (var key in object) if (hasOwn.call(object, key)) return false
		return true
	}

	function compileSelector(selector) {
		var match, tag = "div", classes = [], attrs = {};
		while (match = selectorParser.exec(selector)) {
			var type = match[1], value = match[2];
			if (type === "" && value !== "") tag = value;
			else if (type === "#") attrs.id = value;
			else if (type === ".") classes.push(value);
			else if (match[3][0] === "[") {
				var attrValue = match[6];
				if (attrValue) attrValue = attrValue.replace(/\\(["'])/g, "$1").replace(/\\\\/g, "\\");
				if (match[4] === "class") classes.push(attrValue);
				else attrs[match[4]] = attrValue === "" ? attrValue : attrValue || true;
			}
		}
		if (classes.length > 0) attrs.className = classes.join(" ");
		return selectorCache[selector] = {tag: tag, attrs: attrs}
	}

	function execSelector(state, vnode) {
		var attrs = vnode.attrs;
		var children = Vnode.normalizeChildren(vnode.children);
		var hasClass = hasOwn.call(attrs, "class");
		var className = hasClass ? attrs.class : attrs.className;

		vnode.tag = state.tag;
		vnode.attrs = null;
		vnode.children = undefined;

		if (!isEmpty(state.attrs) && !isEmpty(attrs)) {
			var newAttrs = {};

			for (var key in attrs) {
				if (hasOwn.call(attrs, key)) newAttrs[key] = attrs[key];
			}

			attrs = newAttrs;
		}

		for (var key in state.attrs) {
			if (hasOwn.call(state.attrs, key) && key !== "className" && !hasOwn.call(attrs, key)){
				attrs[key] = state.attrs[key];
			}
		}
		if (className != null || state.attrs.className != null) attrs.className =
			className != null
				? state.attrs.className != null
					? String(state.attrs.className) + " " + String(className)
					: className
				: state.attrs.className != null
					? state.attrs.className
					: null;

		if (hasClass) attrs.class = null;

		for (var key in attrs) {
			if (hasOwn.call(attrs, key) && key !== "key") {
				vnode.attrs = attrs;
				break
			}
		}

		if (Array.isArray(children) && children.length === 1 && children[0] != null && children[0].tag === "#") {
			vnode.text = children[0].children;
		} else {
			vnode.children = children;
		}

		return vnode
	}

	function hyperscript(selector) {
		if (selector == null || typeof selector !== "string" && typeof selector !== "function" && typeof selector.view !== "function") {
			throw Error("The selector must be either a string or a component.");
		}

		var vnode = hyperscriptVnode.apply(1, arguments);

		if (typeof selector === "string") {
			vnode.children = Vnode.normalizeChildren(vnode.children);
			if (selector !== "[") return execSelector(selectorCache[selector] || compileSelector(selector), vnode)
		}

		vnode.tag = selector;
		return vnode
	}

	hyperscript_1$1 = hyperscript;
	return hyperscript_1$1;
}

var trust;
var hasRequiredTrust;

function requireTrust () {
	if (hasRequiredTrust) return trust;
	hasRequiredTrust = 1;

	var Vnode = requireVnode();

	trust = function(html) {
		if (html == null) html = "";
		return Vnode("<", undefined, undefined, html, undefined, undefined)
	};
	return trust;
}

var fragment;
var hasRequiredFragment;

function requireFragment () {
	if (hasRequiredFragment) return fragment;
	hasRequiredFragment = 1;

	var Vnode = requireVnode();
	var hyperscriptVnode = requireHyperscriptVnode();

	fragment = function() {
		var vnode = hyperscriptVnode.apply(0, arguments);

		vnode.tag = "[";
		vnode.children = Vnode.normalizeChildren(vnode.children);
		return vnode
	};
	return fragment;
}

var hyperscript_1;
var hasRequiredHyperscript;

function requireHyperscript () {
	if (hasRequiredHyperscript) return hyperscript_1;
	hasRequiredHyperscript = 1;

	var hyperscript = requireHyperscript$1();

	hyperscript.trust = requireTrust();
	hyperscript.fragment = requireFragment();

	hyperscript_1 = hyperscript;
	return hyperscript_1;
}

var hyperscriptExports = requireHyperscript();
var h = /*@__PURE__*/getDefaultExportFromCjs(hyperscriptExports);

let timeoutId;
var spinner = {
    spin() {
        if (timeoutId !== undefined || document.getElementById('globalSpinner')) {
            return;
        }
        const spinner = document.createElement('div');
        spinner.id = 'globalSpinner';
        spinner.className = 'spinner globalSpinner';
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 40 40');
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', '20');
        circle.setAttribute('cy', '20');
        circle.setAttribute('r', '18');
        circle.setAttribute('fill', 'none');
        svg.appendChild(circle);
        spinner.appendChild(svg);
        timeoutId = setTimeout(() => {
            document.body.appendChild(spinner);
        }, 200);
    },
    stop() {
        clearTimeout(timeoutId);
        timeoutId = undefined;
        const spinners = document.getElementsByClassName('globalSpinner');
        if (spinners.length) {
            setTimeout(function () {
                while (spinners[0])
                    document.body.removeChild(spinners[0]);
            }, 500);
        }
    },
    getVdom(classes) {
        return h('div.spinner', { className: classes || '' }, [
            h('svg', {
                viewBox: '0 0 40 40'
            }, [
                h('circle', { cx: '20', cy: '20', r: '18', fill: 'none' })
            ])
        ]);
    },
    getHtml() {
        return '<div class="spinner monochrome"><svg viewBox="0 0 40 40"><circle cx=20 cy=20 r=18 fill="none"></circle></svg></div>';
    }
};

// from https://github.com/Gozala/querystring
function stringifyPrimitive(v) {
    switch (typeof v) {
        case 'string':
            return v;
        case 'boolean':
            return v ? 'true' : 'false';
        case 'number':
            return isFinite(v) ? v.toString() : '';
        default:
            return '';
    }
}
function buildQueryString(obj, sep, eq, name) {
    sep = sep || '&';
    eq = eq || '=';
    if (obj === null) {
        obj = undefined;
    }
    if (typeof obj === 'object') {
        return Object.keys(obj).map((k) => {
            const ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
            if (Array.isArray(obj[k])) {
                return obj[k].map((v) => {
                    return ks + encodeURIComponent(stringifyPrimitive(v));
                }).join(sep);
            }
            else {
                return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
            }
        }).join(sep);
    }
    return '';
}

const SESSION_ID_KEY = 'sessionId';
const baseUrl$1 = config.apiEndPoint;
function addQuerystring(url, querystring) {
    const prefix = url.indexOf('?') < 0 ? '?' : '&';
    const res = url + prefix + querystring;
    return res;
}
// lichess can return either json or text
// for convenience, this wrapper returns a promise with the response body already
// extracted
function request(url, type, opts, feedback = false) {
    let timeoutId;
    function onComplete() {
        clearTimeout(timeoutId);
        if (feedback)
            spinner.stop();
    }
    const headers = new Headers({
        'X-Requested-With': 'XMLHttpRequest',
        'Accept': 'application/vnd.lichess.v' + config.apiVersion + '+json'
    });
    const sid = storage.get(SESSION_ID_KEY);
    if (sid !== null && sid !== undefined) {
        headers.append(SESSION_ID_KEY, sid);
    }
    const cfg = {
        method: 'GET',
        credentials: 'include',
    };
    let fetchTimeoutMs;
    // merge opts if they are defined
    if (opts !== undefined) {
        const { headers: optsHeaders, query, timeout, ...optsRest } = opts;
        fetchTimeoutMs = timeout;
        if (query) {
            const qs = buildQueryString(query);
            if (qs !== '') {
                url = addQuerystring(url, qs);
            }
        }
        Object.assign(cfg, optsRest);
        // allow to remove header if caller specifically mark it as __delete
        // (important for cors)
        if (optsHeaders) {
            Object.keys(optsHeaders)
                .forEach(k => {
                const v = optsHeaders[k];
                if (v !== '__delete') {
                    headers.set(k, v);
                }
                else {
                    headers.delete(k);
                }
            });
        }
    }
    // by default POST and PUT send json except if defined otherwise in caller
    if ((cfg.method === 'POST' || cfg.method === 'PUT') && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json; charset=UTF-8');
        // always send a json body
        if (!cfg.body) {
            cfg.body = '{}';
        }
    }
    const fullUrl = url.indexOf('http') > -1 ? url : baseUrl$1 + url;
    const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Request timeout.')), fetchTimeoutMs || config.fetchTimeoutMs);
    });
    const respOrTimeout = Promise.race([
        fetch(fullUrl, { ...cfg, headers }),
        timeoutPromise
    ]);
    if (feedback) {
        spinner.spin();
    }
    return new Promise((resolve, reject) => {
        respOrTimeout
            .then((r) => {
            onComplete();
            if (r.ok) {
                resolve(r[type]());
            }
            else {
                // assume error is returned as json
                // if parsing fails, return text
                r.text()
                    .then((bodyText) => {
                    try {
                        reject({
                            status: r.status,
                            body: JSON.parse(bodyText)
                        });
                    }
                    catch (_) {
                        reject({
                            status: r.status,
                            body: r.statusText
                        });
                    }
                });
            }
        })
            .catch(err => {
            onComplete();
            // network or timeout error
            reject({
                status: 0,
                body: err.message
            });
        });
    });
}
function fetchJSON(url, opts, feedback = false) {
    return request(url, 'json', opts, feedback);
}
function fetchText(url, opts, feedback = false) {
    return request(url, 'text', opts, feedback);
}

const onlineFriends = new Map();
var friendsApi = {
    list() {
        return [...onlineFriends.values()].sort((f, f2) => lexicallyCompareFriends(f, f2));
    },
    count() {
        return onlineFriends.size;
    },
    reset(friends, playings, patrons) {
        onlineFriends.clear();
        friends.forEach(friend => {
            const [id, name, title] = parseFriend(friend);
            const playing = playings.includes(id);
            const patron = patrons.includes(id);
            onlineFriends.set(friend, { id, name, title, playing, patron });
        });
    },
    set(rawName, playing, patron) {
        const [id, name, title] = parseFriend(rawName);
        onlineFriends.set(rawName, { id, name, title, playing, patron });
    },
    playing(rawName) {
        const friend = onlineFriends.get(rawName);
        if (friend) {
            onlineFriends.set(rawName, { ...friend, playing: true });
        }
    },
    stoppedPlaying(rawName) {
        const friend = onlineFriends.get(rawName);
        if (friend) {
            onlineFriends.set(rawName, { ...friend, playing: false });
        }
    },
    remove(leaving) {
        onlineFriends.delete(leaving);
    },
    clear() {
        onlineFriends.clear();
    },
};
function parseFriend(friend) {
    const [id, ...rest] = friend.split('/');
    const [name, title] = rest.length > 0 ? rest[0].split(' ') : [friend.split(' ').pop(), undefined];
    return [id, name ?? id, title];
}
function lexicallyCompareFriends(friend1, friend2) {
    if (friend1.name.toLowerCase() < friend2.name.toLowerCase())
        return -1;
    else if (friend1.name.toLowerCase() > friend2.name.toLowerCase())
        return 1;
    else
        return 0;
}

let foreground = true;
function isForeground() {
    return foreground;
}
function setForeground() {
    foreground = true;
}
function setBackground() {
    foreground = false;
}

let ctx = typeof (window.AudioContext) !== 'undefined' ? new AudioContext() : null;
var sound = {
    load() {
        return Promise.all([
            loadSound('move'),
            loadSound('capture'),
            loadSound('explosion'),
            loadSound('lowtime'),
            loadSound('dong'),
            loadSound('berserk'),
            loadSound('clock'),
            loadSound('confirmation'),
        ]).then(() => console.log('all sounds loaded.'));
    },
    resume() {
        if (ctx != null) {
            void ctx.close(); // should be able to reuse these. However, webkit.
            ctx = new AudioContext();
        }
    },
    move() {
        play('move');
    },
    throttledMove: throttle(() => {
        play('move');
    }, 50),
    capture() {
        play('capture');
    },
    throttledCapture: throttle(() => {
        play('capture');
    }, 50),
    explosion() {
        play('explosion');
    },
    throttledExplosion: throttle(() => {
        play('explosion');
    }, 50),
    lowtime() {
        play('lowtime');
    },
    dong() {
        play('dong');
    },
    berserk() {
        play('berserk');
    },
    clock() {
        play('clock');
    },
    confirmation() {
        play('confirmation');
    },
};
const audioMap = {};
function loadSound(id) {
    const path = `sounds/${id}.mp3`;
    const audio = new Audio();
    audio.setAttribute('src', path);
    audio.load();
    audioMap[id] = audio;
}
function play(id) {
    if (settings.general.sound() && isForeground()) {
        const audio = audioMap[id];
        if (audio)
            audio.play();
    }
}

const Dialog = registerPlugin('Dialog', {
    web: () => import('./web-DSfaEuh_.js').then(m => new m.DialogWeb()),
});

function humanSetupFromSettings(settingsObj) {
    return {
        mode: Number(settingsObj.mode()),
        variant: Number(settingsObj.variant()),
        timeMode: Number(settingsObj.timeMode()),
        time: Number(settingsObj.time()),
        increment: Number(settingsObj.increment()),
        days: Number(settingsObj.days()),
        color: settingsObj.color(),
        ratingRangeMin: Number(settingsObj.ratingRangeMin()),
        ratingRangeMax: Number(settingsObj.ratingRangeMax())
    };
}
function makeRatingRange(user, setup) {
    const { ratingRangeMin, ratingRangeMax } = setup;
    let perfKey = 'correspondence';
    switch (setup.variant) {
        case 1:
        case 3: {
            if (setup.timeMode === 1) {
                const time = setup.time * 60 + setup.increment * 40;
                if (time < 30)
                    perfKey = 'ultraBullet';
                else if (time < 180)
                    perfKey = 'bullet';
                else if (time < 480)
                    perfKey = 'blitz';
                else if (time < 1500)
                    perfKey = 'rapid';
                else
                    perfKey = 'classical';
            }
            break;
        }
        case 2:
            perfKey = 'chess960';
            break;
        case 4:
            perfKey = 'kingOfTheHill';
            break;
        case 5:
            perfKey = 'threeCheck';
            break;
        case 6:
            perfKey = 'antichess';
            break;
        case 7:
            perfKey = 'atomic';
            break;
        case 8:
            perfKey = 'horde';
            break;
        case 9:
            perfKey = 'racingKings';
            break;
        case 10:
            perfKey = 'crazyhouse';
            break;
    }
    const perf = user.perfs[perfKey];
    if (perf && ratingRangeMin !== undefined && ratingRangeMax !== undefined) {
        return `${perf.rating + ratingRangeMin}-${perf.rating + ratingRangeMax}`;
    }
    else {
        return null;
    }
}

function newAiGame(fen) {
    const config = settings.gameSetup.ai;
    const body = {
        variant: config.variant(),
        timeMode: config.timeMode(),
        days: config.days(),
        time: config.time(),
        increment: config.increment(),
        level: config.level(),
        color: config.color()
    };
    if (fen)
        body.fen = fen;
    return fetchJSON('/setup/ai', {
        method: 'POST',
        body: JSON.stringify(body)
    }, true);
}
function seekGame(setup) {
    const { ratingRangeMin, ratingRangeMax, ...rest } = setup;
    const user = session$1.get();
    const ratingRange = user ? makeRatingRange(user, setup) : null;
    const body = ratingRange ? {
        ...rest,
        ratingRange,
    } : { ...rest };
    return fetchJSON('/setup/hook/' + currentSri(), {
        method: 'POST',
        body: JSON.stringify(body),
    }, true);
}
function newOpponentHook(gameId, setup) {
    const user = session$1.get();
    const rr = user ? makeRatingRange(user, setup) : null;
    return fetchJSON(`/setup/hook/${currentSri()}/like/${gameId}?rr=${rr || ''}`, {
        method: 'POST',
    }, true);
}
function challenge(userId, fen) {
    const config = settings.gameSetup.challenge;
    const url = userId ? `/setup/friend?user=${userId}` : '/setup/friend';
    const body = {
        variant: config.variant(),
        timeMode: config.timeMode(),
        days: config.days(),
        time: config.time(),
        increment: config.increment(),
        color: config.color(),
        mode: session$1.isConnected() ? config.mode() : '0'
    };
    if (fen)
        body.fen = fen;
    return fetchJSON(url, {
        method: 'POST',
        body: JSON.stringify(body)
    }, true);
}
function getChallenges() {
    return fetchJSON('/challenge');
}
function getChallenge(id) {
    return fetchJSON(`/challenge/${id}`, {}, true);
}
function cancelChallenge$1(id) {
    return fetchText(`/challenge/${id}/cancel`, {
        method: 'POST'
    }, true);
}
function declineChallenge$1(id) {
    return fetchText(`/challenge/${id}/decline`, {
        method: 'POST'
    }, true);
}
function acceptChallenge$1(id) {
    return fetchJSON(`/challenge/${id}/accept`, { method: 'POST' }, true);
}
let cachedPools = [];
function lobby$1(feedback) {
    return fetchJSON('/', undefined, feedback)
        .then((d) => {
        if (d.lobby.pools !== undefined)
            cachedPools = d.lobby.pools;
        return d;
    });
}
function seeks(feedback) {
    return fetchJSON('/lobby/seeks', {
        query: {
            _: Date.now()
        }
    }, feedback);
}
function game(id, color) {
    let url = '/' + id;
    if (color)
        url += ('/' + color);
    return fetchJSON(url);
}
function toggleGameBookmark(id) {
    return fetchText('/bookmark/' + id, {
        method: 'POST'
    });
}
function featured(channel, flip) {
    return fetchJSON('/tv/' + channel, flip ? { query: { flip: 1 } } : {});
}
function importMasterGame(gameId, orientation) {
    return fetchJSON(`/import/master/${gameId}/${orientation}`);
}
function setServerLang(lang) {
    if (session$1.isConnected()) {
        return fetchJSON('/translation/select', {
            method: 'POST',
            body: JSON.stringify({
                lang
            })
        })
            .then(() => { });
    }
    else {
        return Promise.resolve();
    }
}
function miniUser(userId) {
    return fetchJSON(`/@/${userId}/mini`);
}
function timeline() {
    return fetchJSON('/timeline', { query: { nb: 10 } }, false);
}
function status() {
    const v = 'yandex-game';
    return fetchJSON('/api/status', {
        query: {
            v
        }
    })
        .then((data) => {
        // warn if buggy app
        if (data.mustUpgrade) {
            console.log('A new version is available. Please upgrade as soon as possible.');
        }
        else if (data.api.current > config.apiVersion) {
            const versionInfo = data.api.olds.find(o => o.version === config.apiVersion);
            if (versionInfo) {
                const now = new Date(), unsupportedDate = new Date(versionInfo.unsupportedAt), deprecatedDate = new Date(versionInfo.deprecatedAt);
                const key = 'warn_old_' + versionInfo.version;
                const deprWarnCount = Number(storage.get(key)) || 0;
                if (now > unsupportedDate) {
                    Dialog.alert({
                        title: 'Alert',
                        message: i18n('apiUnsupported'),
                    });
                }
                else if (now > deprecatedDate) {
                    if (deprWarnCount === 0) {
                        Dialog.alert({
                            title: 'Alert',
                            message: i18n('apiDeprecated', formatDate(unsupportedDate)),
                        }).then(() => {
                            storage.set(key, 1);
                        });
                    }
                    else if (deprWarnCount === 15) {
                        storage.remove(key);
                    }
                    else {
                        storage.set(key, deprWarnCount + 1);
                    }
                }
            }
        }
    });
}

function isTimeControlClock(t) {
    return t.type === 'clock';
}
function isTimeControlCorrespondence(t) {
    return t.type === 'correspondence';
}

let incoming = [];
let sending = [];
function supportedAndCreated(c) {
    return settings.game.supportedVariants.indexOf(c.variant.key) !== -1 &&
        c.status === 'created';
}
function set$1(data) {
    if (data.in.length > incoming.length) {
        sound.dong();
    }
    incoming = data.in;
    sending = data.out;
}
var challengesApi = {
    all() {
        return incoming.filter(supportedAndCreated).concat(sending.filter(supportedAndCreated));
    },
    incoming() {
        return incoming.filter(supportedAndCreated);
    },
    sending() {
        return sending.filter(supportedAndCreated);
    },
    set: set$1,
    refresh() {
        return throttle(getChallenges, 1000)().then(set$1);
    },
    remove(id) {
        incoming = incoming.filter((c) => c.id !== id);
        sending = sending.filter((c) => c.id !== id);
    },
    isPersistent(c) {
        return c.timeControl.type === 'correspondence' ||
            c.timeControl.type === 'unlimited';
    },
    challengeTime(c) {
        if (isTimeControlClock(c.timeControl)) {
            return c.timeControl.show;
        }
        else if (isTimeControlCorrespondence(c.timeControl)) {
            return plural('nbDays', c.timeControl.daysPerTurn);
        }
        else {
            return '∞';
        }
    }
};

const STORAGE_KEY = 'announce';
let announce;
function keyOf(a) {
    return a.date; // includes milliseconds, effectively unique
}
function isExpired(dateStr) {
    return new Date(dateStr) < new Date();
}
function get() {
    if (announce && isExpired(announce.date)) {
        announce = undefined;
    }
    return announce;
}
async function set(a) {
    if (a) {
        const newKey = keyOf(a);
        const existing = await asyncStorage.get(STORAGE_KEY);
        if (existing?.includes(newKey)) {
            // previously dismissed, no-op
            return;
        }
    }
    announce = a;
    redraw();
}
async function dismiss() {
    if (announce === undefined) {
        return;
    }
    const dismissKey = keyOf(announce);
    // clear the announcement
    announce = undefined;
    redraw();
    // clean up existing dismissed cache and add this new entry
    const existingDismissed = await asyncStorage.get(STORAGE_KEY);
    const newDismissed = (existingDismissed || []).filter(dateStr => !isExpired(dateStr));
    newDismissed.push(dismissKey);
    await asyncStorage.set(STORAGE_KEY, newDismissed);
}
var announce$1 = {
    get,
    set,
    dismiss,
};

let session;
function isConnected() {
    return session !== undefined;
}
function getSession() {
    return session;
}
// store session data for offline usage
function storeSession(d) {
    asyncStorage.set('session', d);
}
// clear session data stored in async storage and sessionId
function onLogout() {
    asyncStorage.remove('session');
    storage.remove(SESSION_ID_KEY);
    signals.afterLogout.dispatch();
}
function restoreStoredSession() {
    asyncStorage.get('session')
        .then(d => {
        session = d || undefined;
        if (d !== null) {
            signals.sessionRestored.dispatch();
            redraw();
        }
    });
}
function getUserId() {
    return session && session.id;
}
function nowPlaying() {
    const np = session && session.nowPlaying || [];
    return np.filter(e => settings.game.supportedVariants.indexOf(e.variant.key) !== -1);
}
function isKidMode() {
    return !!(session && session.kid);
}
function isShadowban() {
    return !!(session && session.troll);
}
function myTurnGames() {
    return nowPlaying().filter(e => e.isMyTurn);
}
function showSavedPrefToast(data) {
    Toast.show({ text: '✓ chess-online.com: ' + i18n('yourPreferencesHaveBeenSaved'), position: 'center', duration: 'short' });
    return data;
}
function setKidMode(v, data) {
    return fetchText(`/account/kid?v=${v}`, {
        method: 'POST',
        body: new URLSearchParams(data),
        headers: {
            'Content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/*'
        },
    }, true)
        .then(refresh);
}
function numValue(v) {
    if (v === true)
        return '1';
    else if (v === false)
        return '0';
    else
        return String(v);
}
function makeReducer(prefix) {
    return function (acc, [k, v]) {
        return {
            ...acc,
            [prefix + k]: numValue(v)
        };
    };
}
const savePreferences = throttle(() => {
    const prefs = session && session.prefs || {};
    const display = Object.entries(pick(prefs, [
        'animation',
        'captured',
        'highlight',
        'destination',
        'coords',
        'replay',
        'blindfold'
    ])).reduce(makeReducer('display.'), {});
    const behavior = Object.entries(pick(prefs, [
        'premove',
        'takeback',
        'autoQueen',
        'autoThreefold',
        'submitMove',
        'confirmResign',
        'moretime',
    ])).reduce(makeReducer('behavior.'), {});
    const rest = Object.entries(pick(prefs, [
        'clockTenths',
        'clockBar',
        'clockSound',
        'follow',
        'challenge',
        'message',
        'insightShare'
    ])).reduce(makeReducer(''), {});
    return fetchText('/account/preferences', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/*'
        },
        body: serializeQueryParameters({ ...rest, ...display, ...behavior })
    }, true)
        .then(showSavedPrefToast);
}, 1000);
function lichessBackedProp(path, defaultVal) {
    return function (...args) {
        if (args.length) {
            let oldPref;
            if (session) {
                oldPref = getAtPath(session, path);
                setAtPath(session, path, args[0]);
            }
            savePreferences()
                .catch((err) => {
                if (session)
                    setAtPath(session, path, oldPref);
                if (hasNetwork())
                    handleXhrError(err);
            });
        }
        return session ? getAtPath(session, path) : defaultVal;
    };
}
function isSession(data) {
    return data.id !== undefined;
}
function login(username, password, token) {
    return fetchJSON('/login', {
        method: 'POST',
        body: JSON.stringify({
            username,
            password,
            token,
        })
    }, true)
        .then(data => {
        if (isSession(data)) {
            session = data;
            if (session.sessionId) {
                storage.set(SESSION_ID_KEY, session.sessionId);
            }
            storeSession(data);
            return session;
        }
        else {
            throw { ipban: true };
        }
    });
}
function logout() {
    return fetchJSON('/logout', { method: 'POST' }, true)
        .then(() => {
        session = undefined;
        onLogout();
        friendsApi.clear();
        redraw();
    })
        .catch(handleXhrError);
}
function confirmEmail(token) {
    return fetchJSON(`/signup/confirm/${token}`, undefined, true)
        .then(data => {
        session = data;
        storeSession(data);
        return session;
    });
}
function signup(username, email, password) {
    return fetchJSON('/signup', {
        method: 'POST',
        body: JSON.stringify({
            username,
            email,
            password,
            'can-confirm': true
        })
    }, true)
        .then(d => {
        if (isSession(d)) {
            session = d;
            if (session.sessionId) {
                storage.set(SESSION_ID_KEY, session.sessionId);
            }
        }
        return d;
    });
}
function rememberLogin() {
    return fetchJSON('/account/info')
        .then(data => {
        session = data;
        storeSession(data);
        return data;
    });
}
async function refresh() {
    try {
        const data = await fetchJSON('/account/info', { cache: 'reload' });
        session = data;
        storeSession(data);
        announce$1.set(data.announce);
        // if server tells me, reload challenges
        if (session.nbChallenges !== challengesApi.incoming().length) {
            challengesApi.refresh().then(redraw);
        }
        redraw();
    }
    catch (err) {
        if (session !== undefined && err.status === 401) {
            session = undefined;
            onLogout();
            redraw();
            Toast.show({ text: 'You have been signed out', position: 'center', duration: 'short' });
        }
    }
}
async function backgroundRefresh() {
    if (hasNetwork() && isConnected()) {
        const data = await fetchJSON('/account/info');
        session = data;
        storeSession(data);
        announce$1.set(data.announce);
        // if server tells me, reload challenges
        if (session.nbChallenges !== challengesApi.incoming().length) {
            challengesApi.refresh().then(redraw);
        }
    }
}
var session$1 = {
    isConnected,
    isKidMode,
    isShadowban,
    logout,
    signup,
    login: throttle(login, 1000),
    rememberLogin: throttle(rememberLogin, 1000),
    restoreStoredSession,
    refresh: throttle(refresh, 1000),
    backgroundRefresh: throttle(backgroundRefresh, 1000),
    get: getSession,
    getUserId,
    appUser(fallback) {
        if (session)
            return session && session.username;
        else
            return fallback;
    },
    nowPlaying,
    myTurnGames,
    lichessBackedProp,
    setKidMode,
    confirmEmail,
    hasCurrentBan() {
        return session?.playban !== undefined;
    },
};

// Zanimo.js - Promise based CSS3 transitions
// (c) 2011-2014 Paul Panserrieu
// modified here for lichobile
const transition = 'transition', transitionend = 'transitionend';
/**
* Zanimo(el | promise[el])
* > Returns a Promise of el.
*
* Zanimo(el | promise[el], attr, value)
* > Sets el.style[attr]=value and returns the promise of el.
*
* Zanimo(el | promise[el], attr, value, duration, [easing])
* > Performs a transition.
*/
function Zanimo(el, attr, value, duration, easing) {
    var args = arguments, arity = arguments.length;
    if (arity === 0 || arity === 2 || arity > 5) {
        return Promise.reject(new Error('Zanimo invalid arguments'));
    }
    if (el instanceof Promise) {
        return el.then(function (val) {
            return Zanimo.apply(this, [val].concat(Array.prototype.slice.call(args, 1)));
        });
    }
    if (!isDOM(el)) {
        return Promise.reject(new Error('Zanimo require an HTMLElement, or a promise of an HTMLElement'));
    }
    if (arity === 1) {
        return Promise(el);
    }
    if (arity === 3) {
        return css(el, attr, value);
    }
    if (window.isNaN(parseInt(duration, 10))) {
        return Promise.reject(new Error('Zanimo transition: duration must be an integer!'));
    }
    return animate$1(el, attr, value, duration, easing);
}
function shorthand(v, d, t) {
    return v + ' ' + d + 'ms ' + (t || 'linear');
}
function isDOM(el) {
    try {
        return el && el.nodeType;
    }
    catch (err) {
        return false;
    }
}
function addTransition(elt, attr, value, duration, easing) {
    var currentValue = elt.style[transition];
    if (currentValue) {
        elt.style[transition] = currentValue + ', ' + shorthand(attr, duration, easing);
    }
    else {
        elt.style[transition] = shorthand(attr, duration, easing);
    }
    elt.style[attr] = value;
}
function removeTransition(el, attr) {
    el.style[transition] = el.style[transition]
        .split(',').filter(function (t) {
        return !t.match(attr);
    }).join(',');
}
function applycss(el, attr, value) {
    requestAnimationFrame(function () {
        el.style[attr] = value;
    });
    return Promise(el);
}
function css(el, attr, value) {
    if (el._zanimo && Object.prototype.hasOwnProperty.call(el._zanimo, attr)) {
        console.warn('Zanimo transition with transform=' +
            el._zanimo[attr].value +
            ' stopped by transform=' + value);
    }
    return applycss(el, attr, value);
}
function animate$1(el, attr, value, duration, easing) {
    var prefixed = attr, timeout;
    var promise = new Promise(function (resolve, reject) {
        function cbTransitionend(evt) {
            if (evt.propertyName === prefixed) {
                cb();
                resolve(el);
            }
        }
        function cb(clear) {
            if (timeout) {
                clearTimeout(timeout);
                timeout = null;
            }
            removeTransition(el, attr);
            el.removeEventListener(transitionend, cbTransitionend);
            {
                delete el._zanimo[attr];
            }
        }
        el.addEventListener(transitionend, cbTransitionend);
        requestAnimationFrame(function () {
            addTransition(el, attr, value, duration, easing);
            timeout = setTimeout(function () {
                // var rawVal = el.style.getPropertyValue(prefixed),
                // domVal = rawVal,
                // givenVal = value;
                cb();
                resolve(el);
                // if (domVal !== givenVal) {
                //     console.warn('Zanimo transition: with '
                //         + attr + ' = ' + givenVal + ', DOM value=' + domVal
                //     );
                // }
            }, duration + 20);
            el._zanimo = el._zanimo || {};
            if (el._zanimo[attr]) {
                console.warn('Zanimo transition with ' +
                    attr + '=' + el._zanimo[attr].value +
                    ' stopped by transition with ' + attr + '=' + value);
            }
            el._zanimo[attr] = { value: value };
        });
    });
    return promise;
}

var rlite$1 = {exports: {}};

var rlite = rlite$1.exports;

var hasRequiredRlite;

function requireRlite () {
	if (hasRequiredRlite) return rlite$1.exports;
	hasRequiredRlite = 1;
	(function (module) {
		// This library started as an experiment to see how small I could make
		// a functional router. It has since been optimized (and thus grown).
		// The redundancy and inelegance here is for the sake of either size
		// or speed.
		(function (root, factory) {
		  var define = root.define;

		  if (define && define.amd) {
		    define('rlite', [], factory);
		  } else if (module.exports) {
		    module.exports = factory();
		  } else {
		    root.Rlite = factory();
		  }
		}(rlite, function () { return function() {
		    var routes = {},
		        decode = decodeURIComponent;

		    function noop(s) { return s; }

		    function sanitize(url) {
		      ~url.indexOf('/?') && (url = url.replace('/?', '?'));
		      url[0] == '/' && (url = url.slice(1));
		      url[url.length - 1] == '/' && (url = url.slice(0, -1));

		      return url;
		    }

		    function processUrl(url, esc) {
		      var pieces = url.split('/'),
		          rules = routes,
		          params = {};

		      for (var i = 0; i < pieces.length && rules; ++i) {
		        var piece = esc(pieces[i]);
		        rules = rules[piece.toLowerCase()] || rules[':'];
		        rules && rules['~'] && (params[rules['~']] = piece);
		      }

		      return rules && {
		        cb: rules['@'],
		        params: params
		      };
		    }

		    function processQuery(url, ctx, esc) {
		      if (url && ctx.cb) {
		        var hash = url.indexOf('#'),
		            query = (hash < 0 ? url : url.slice(0, hash)).split('&');

		        for (var i = 0; i < query.length; ++i) {
		          var nameValue = query[i].split('=');

		          ctx.params[nameValue[0]] = esc(nameValue[1]);
		        }
		      }

		      return ctx;
		    }

		    function lookup(url) {
		      var querySplit = sanitize(url).split('?'),
		          esc = ~url.indexOf('%') ? decode : noop;

		      return processQuery(querySplit[1], processUrl(querySplit[0], esc) || {}, esc);
		    }

		    return {
		      add: function(route, handler) {

		        var pieces = route.split('/'),
		            rules = routes;

		        for (var i = 0; i < pieces.length; ++i) {
		          var piece = pieces[i],
		              name = piece[0] == ':' ? ':' : piece.toLowerCase();

		          rules = rules[name] || (rules[name] = {});

		          name == ':' && (rules['~'] = piece.slice(1));
		        }

		        rules['@'] = handler;
		      },

		      exists: function (url) {
		        return !!lookup(url).cb;
		      },

		      lookup: lookup,

		      run: function(url) {
		        var result = lookup(url);

		        result.cb && result.cb({
		          url: url,
		          params: result.params
		        });

		        return !!result.cb;
		      }
		    };
		  };
		})); 
	} (rlite$1));
	return rlite$1.exports;
}

var rliteExports = requireRlite();
var Rlite = /*@__PURE__*/getDefaultExportFromCjs(rliteExports);

var render$2;
var hasRequiredRender$1;

function requireRender$1 () {
	if (hasRequiredRender$1) return render$2;
	hasRequiredRender$1 = 1;

	var Vnode = requireVnode();

	render$2 = function($window) {
		var $doc = $window && $window.document;
		var currentRedraw;

		var nameSpace = {
			svg: "http://www.w3.org/2000/svg",
			math: "http://www.w3.org/1998/Math/MathML"
		};

		function getNameSpace(vnode) {
			return vnode.attrs && vnode.attrs.xmlns || nameSpace[vnode.tag]
		}

		//sanity check to discourage people from doing `vnode.state = ...`
		function checkState(vnode, original) {
			if (vnode.state !== original) throw new Error("'vnode.state' must not be modified.")
		}

		//Note: the hook is passed as the `this` argument to allow proxying the
		//arguments without requiring a full array allocation to do so. It also
		//takes advantage of the fact the current `vnode` is the first argument in
		//all lifecycle methods.
		function callHook(vnode) {
			var original = vnode.state;
			try {
				return this.apply(original, arguments)
			} finally {
				checkState(vnode, original);
			}
		}

		// IE11 (at least) throws an UnspecifiedError when accessing document.activeElement when
		// inside an iframe. Catch and swallow this error, and heavy-handidly return null.
		function activeElement() {
			try {
				return $doc.activeElement
			} catch (e) {
				return null
			}
		}
		//create
		function createNodes(parent, vnodes, start, end, hooks, nextSibling, ns) {
			for (var i = start; i < end; i++) {
				var vnode = vnodes[i];
				if (vnode != null) {
					createNode(parent, vnode, hooks, ns, nextSibling);
				}
			}
		}
		function createNode(parent, vnode, hooks, ns, nextSibling) {
			var tag = vnode.tag;
			if (typeof tag === "string") {
				vnode.state = {};
				if (vnode.attrs != null) initLifecycle(vnode.attrs, vnode, hooks);
				switch (tag) {
					case "#": createText(parent, vnode, nextSibling); break
					case "<": createHTML(parent, vnode, ns, nextSibling); break
					case "[": createFragment(parent, vnode, hooks, ns, nextSibling); break
					default: createElement(parent, vnode, hooks, ns, nextSibling);
				}
			}
			else createComponent(parent, vnode, hooks, ns, nextSibling);
		}
		function createText(parent, vnode, nextSibling) {
			vnode.dom = $doc.createTextNode(vnode.children);
			insertNode(parent, vnode.dom, nextSibling);
		}
		var possibleParents = {caption: "table", thead: "table", tbody: "table", tfoot: "table", tr: "tbody", th: "tr", td: "tr", colgroup: "table", col: "colgroup"};
		function createHTML(parent, vnode, ns, nextSibling) {
			var match = vnode.children.match(/^\s*?<(\w+)/im) || [];
			// not using the proper parent makes the child element(s) vanish.
			//     var div = document.createElement("div")
			//     div.innerHTML = "<td>i</td><td>j</td>"
			//     console.log(div.innerHTML)
			// --> "ij", no <td> in sight.
			var temp = $doc.createElement(possibleParents[match[1]] || "div");
			if (ns === "http://www.w3.org/2000/svg") {
				temp.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\">" + vnode.children + "</svg>";
				temp = temp.firstChild;
			} else {
				temp.innerHTML = vnode.children;
			}
			vnode.dom = temp.firstChild;
			vnode.domSize = temp.childNodes.length;
			// Capture nodes to remove, so we don't confuse them.
			vnode.instance = [];
			var fragment = $doc.createDocumentFragment();
			var child;
			while (child = temp.firstChild) {
				vnode.instance.push(child);
				fragment.appendChild(child);
			}
			insertNode(parent, fragment, nextSibling);
		}
		function createFragment(parent, vnode, hooks, ns, nextSibling) {
			var fragment = $doc.createDocumentFragment();
			if (vnode.children != null) {
				var children = vnode.children;
				createNodes(fragment, children, 0, children.length, hooks, null, ns);
			}
			vnode.dom = fragment.firstChild;
			vnode.domSize = fragment.childNodes.length;
			insertNode(parent, fragment, nextSibling);
		}
		function createElement(parent, vnode, hooks, ns, nextSibling) {
			var tag = vnode.tag;
			var attrs = vnode.attrs;
			var is = attrs && attrs.is;

			ns = getNameSpace(vnode) || ns;

			var element = ns ?
				is ? $doc.createElementNS(ns, tag, {is: is}) : $doc.createElementNS(ns, tag) :
				is ? $doc.createElement(tag, {is: is}) : $doc.createElement(tag);
			vnode.dom = element;

			if (attrs != null) {
				setAttrs(vnode, attrs, ns);
			}

			insertNode(parent, element, nextSibling);

			if (!maybeSetContentEditable(vnode)) {
				if (vnode.text != null) {
					if (vnode.text !== "") element.textContent = vnode.text;
					else vnode.children = [Vnode("#", undefined, undefined, vnode.text, undefined, undefined)];
				}
				if (vnode.children != null) {
					var children = vnode.children;
					createNodes(element, children, 0, children.length, hooks, null, ns);
					if (vnode.tag === "select" && attrs != null) setLateSelectAttrs(vnode, attrs);
				}
			}
		}
		function initComponent(vnode, hooks) {
			var sentinel;
			if (typeof vnode.tag.view === "function") {
				vnode.state = Object.create(vnode.tag);
				sentinel = vnode.state.view;
				if (sentinel.$$reentrantLock$$ != null) return
				sentinel.$$reentrantLock$$ = true;
			} else {
				vnode.state = void 0;
				sentinel = vnode.tag;
				if (sentinel.$$reentrantLock$$ != null) return
				sentinel.$$reentrantLock$$ = true;
				vnode.state = (vnode.tag.prototype != null && typeof vnode.tag.prototype.view === "function") ? new vnode.tag(vnode) : vnode.tag(vnode);
			}
			initLifecycle(vnode.state, vnode, hooks);
			if (vnode.attrs != null) initLifecycle(vnode.attrs, vnode, hooks);
			vnode.instance = Vnode.normalize(callHook.call(vnode.state.view, vnode));
			if (vnode.instance === vnode) throw Error("A view cannot return the vnode it received as argument")
			sentinel.$$reentrantLock$$ = null;
		}
		function createComponent(parent, vnode, hooks, ns, nextSibling) {
			initComponent(vnode, hooks);
			if (vnode.instance != null) {
				createNode(parent, vnode.instance, hooks, ns, nextSibling);
				vnode.dom = vnode.instance.dom;
				vnode.domSize = vnode.dom != null ? vnode.instance.domSize : 0;
			}
			else {
				vnode.domSize = 0;
			}
		}

		//update
		/**
		 * @param {Element|Fragment} parent - the parent element
		 * @param {Vnode[] | null} old - the list of vnodes of the last `render()` call for
		 *                               this part of the tree
		 * @param {Vnode[] | null} vnodes - as above, but for the current `render()` call.
		 * @param {Function[]} hooks - an accumulator of post-render hooks (oncreate/onupdate)
		 * @param {Element | null} nextSibling - the next DOM node if we're dealing with a
		 *                                       fragment that is not the last item in its
		 *                                       parent
		 * @param {'svg' | 'math' | String | null} ns) - the current XML namespace, if any
		 * @returns void
		 */
		// This function diffs and patches lists of vnodes, both keyed and unkeyed.
		//
		// We will:
		//
		// 1. describe its general structure
		// 2. focus on the diff algorithm optimizations
		// 3. discuss DOM node operations.

		// ## Overview:
		//
		// The updateNodes() function:
		// - deals with trivial cases
		// - determines whether the lists are keyed or unkeyed based on the first non-null node
		//   of each list.
		// - diffs them and patches the DOM if needed (that's the brunt of the code)
		// - manages the leftovers: after diffing, are there:
		//   - old nodes left to remove?
		// 	 - new nodes to insert?
		// 	 deal with them!
		//
		// The lists are only iterated over once, with an exception for the nodes in `old` that
		// are visited in the fourth part of the diff and in the `removeNodes` loop.

		// ## Diffing
		//
		// Reading https://github.com/localvoid/ivi/blob/ddc09d06abaef45248e6133f7040d00d3c6be853/packages/ivi/src/vdom/implementation.ts#L617-L837
		// may be good for context on longest increasing subsequence-based logic for moving nodes.
		//
		// In order to diff keyed lists, one has to
		//
		// 1) match nodes in both lists, per key, and update them accordingly
		// 2) create the nodes present in the new list, but absent in the old one
		// 3) remove the nodes present in the old list, but absent in the new one
		// 4) figure out what nodes in 1) to move in order to minimize the DOM operations.
		//
		// To achieve 1) one can create a dictionary of keys => index (for the old list), then iterate
		// over the new list and for each new vnode, find the corresponding vnode in the old list using
		// the map.
		// 2) is achieved in the same step: if a new node has no corresponding entry in the map, it is new
		// and must be created.
		// For the removals, we actually remove the nodes that have been updated from the old list.
		// The nodes that remain in that list after 1) and 2) have been performed can be safely removed.
		// The fourth step is a bit more complex and relies on the longest increasing subsequence (LIS)
		// algorithm.
		//
		// the longest increasing subsequence is the list of nodes that can remain in place. Imagine going
		// from `1,2,3,4,5` to `4,5,1,2,3` where the numbers are not necessarily the keys, but the indices
		// corresponding to the keyed nodes in the old list (keyed nodes `e,d,c,b,a` => `b,a,e,d,c` would
		//  match the above lists, for example).
		//
		// In there are two increasing subsequences: `4,5` and `1,2,3`, the latter being the longest. We
		// can update those nodes without moving them, and only call `insertNode` on `4` and `5`.
		//
		// @localvoid adapted the algo to also support node deletions and insertions (the `lis` is actually
		// the longest increasing subsequence *of old nodes still present in the new list*).
		//
		// It is a general algorithm that is fireproof in all circumstances, but it requires the allocation
		// and the construction of a `key => oldIndex` map, and three arrays (one with `newIndex => oldIndex`,
		// the `LIS` and a temporary one to create the LIS).
		//
		// So we cheat where we can: if the tails of the lists are identical, they are guaranteed to be part of
		// the LIS and can be updated without moving them.
		//
		// If two nodes are swapped, they are guaranteed not to be part of the LIS, and must be moved (with
		// the exception of the last node if the list is fully reversed).
		//
		// ## Finding the next sibling.
		//
		// `updateNode()` and `createNode()` expect a nextSibling parameter to perform DOM operations.
		// When the list is being traversed top-down, at any index, the DOM nodes up to the previous
		// vnode reflect the content of the new list, whereas the rest of the DOM nodes reflect the old
		// list. The next sibling must be looked for in the old list using `getNextSibling(... oldStart + 1 ...)`.
		//
		// In the other scenarios (swaps, upwards traversal, map-based diff),
		// the new vnodes list is traversed upwards. The DOM nodes at the bottom of the list reflect the
		// bottom part of the new vnodes list, and we can use the `v.dom`  value of the previous node
		// as the next sibling (cached in the `nextSibling` variable).


		// ## DOM node moves
		//
		// In most scenarios `updateNode()` and `createNode()` perform the DOM operations. However,
		// this is not the case if the node moved (second and fourth part of the diff algo). We move
		// the old DOM nodes before updateNode runs because it enables us to use the cached `nextSibling`
		// variable rather than fetching it using `getNextSibling()`.
		//
		// The fourth part of the diff currently inserts nodes unconditionally, leading to issues
		// like #1791 and #1999. We need to be smarter about those situations where adjascent old
		// nodes remain together in the new list in a way that isn't covered by parts one and
		// three of the diff algo.

		function updateNodes(parent, old, vnodes, hooks, nextSibling, ns) {
			if (old === vnodes || old == null && vnodes == null) return
			else if (old == null || old.length === 0) createNodes(parent, vnodes, 0, vnodes.length, hooks, nextSibling, ns);
			else if (vnodes == null || vnodes.length === 0) removeNodes(parent, old, 0, old.length);
			else {
				var isOldKeyed = old[0] != null && old[0].key != null;
				var isKeyed = vnodes[0] != null && vnodes[0].key != null;
				var start = 0, oldStart = 0;
				if (!isOldKeyed) while (oldStart < old.length && old[oldStart] == null) oldStart++;
				if (!isKeyed) while (start < vnodes.length && vnodes[start] == null) start++;
				if (isKeyed === null && isOldKeyed == null) return // both lists are full of nulls
				if (isOldKeyed !== isKeyed) {
					removeNodes(parent, old, oldStart, old.length);
					createNodes(parent, vnodes, start, vnodes.length, hooks, nextSibling, ns);
				} else if (!isKeyed) {
					// Don't index past the end of either list (causes deopts).
					var commonLength = old.length < vnodes.length ? old.length : vnodes.length;
					// Rewind if necessary to the first non-null index on either side.
					// We could alternatively either explicitly create or remove nodes when `start !== oldStart`
					// but that would be optimizing for sparse lists which are more rare than dense ones.
					start = start < oldStart ? start : oldStart;
					for (; start < commonLength; start++) {
						o = old[start];
						v = vnodes[start];
						if (o === v || o == null && v == null) continue
						else if (o == null) createNode(parent, v, hooks, ns, getNextSibling(old, start + 1, nextSibling));
						else if (v == null) removeNode(parent, o);
						else updateNode(parent, o, v, hooks, getNextSibling(old, start + 1, nextSibling), ns);
					}
					if (old.length > commonLength) removeNodes(parent, old, start, old.length);
					if (vnodes.length > commonLength) createNodes(parent, vnodes, start, vnodes.length, hooks, nextSibling, ns);
				} else {
					// keyed diff
					var oldEnd = old.length - 1, end = vnodes.length - 1, map, o, v, oe, ve, topSibling;

					// bottom-up
					while (oldEnd >= oldStart && end >= start) {
						oe = old[oldEnd];
						ve = vnodes[end];
						if (oe.key !== ve.key) break
						if (oe !== ve) updateNode(parent, oe, ve, hooks, nextSibling, ns);
						if (ve.dom != null) nextSibling = ve.dom;
						oldEnd--, end--;
					}
					// top-down
					while (oldEnd >= oldStart && end >= start) {
						o = old[oldStart];
						v = vnodes[start];
						if (o.key !== v.key) break
						oldStart++, start++;
						if (o !== v) updateNode(parent, o, v, hooks, getNextSibling(old, oldStart, nextSibling), ns);
					}
					// swaps and list reversals
					while (oldEnd >= oldStart && end >= start) {
						if (start === end) break
						if (o.key !== ve.key || oe.key !== v.key) break
						topSibling = getNextSibling(old, oldStart, nextSibling);
						moveNodes(parent, oe, topSibling);
						if (oe !== v) updateNode(parent, oe, v, hooks, topSibling, ns);
						if (++start <= --end) moveNodes(parent, o, nextSibling);
						if (o !== ve) updateNode(parent, o, ve, hooks, nextSibling, ns);
						if (ve.dom != null) nextSibling = ve.dom;
						oldStart++; oldEnd--;
						oe = old[oldEnd];
						ve = vnodes[end];
						o = old[oldStart];
						v = vnodes[start];
					}
					// bottom up once again
					while (oldEnd >= oldStart && end >= start) {
						if (oe.key !== ve.key) break
						if (oe !== ve) updateNode(parent, oe, ve, hooks, nextSibling, ns);
						if (ve.dom != null) nextSibling = ve.dom;
						oldEnd--, end--;
						oe = old[oldEnd];
						ve = vnodes[end];
					}
					if (start > end) removeNodes(parent, old, oldStart, oldEnd + 1);
					else if (oldStart > oldEnd) createNodes(parent, vnodes, start, end + 1, hooks, nextSibling, ns);
					else {
						// inspired by ivi https://github.com/ivijs/ivi/ by Boris Kaul
						var originalNextSibling = nextSibling, vnodesLength = end - start + 1, oldIndices = new Array(vnodesLength), li=0, i=0, pos = 2147483647, matched = 0, map, lisIndices;
						for (i = 0; i < vnodesLength; i++) oldIndices[i] = -1;
						for (i = end; i >= start; i--) {
							if (map == null) map = getKeyMap(old, oldStart, oldEnd + 1);
							ve = vnodes[i];
							var oldIndex = map[ve.key];
							if (oldIndex != null) {
								pos = (oldIndex < pos) ? oldIndex : -1; // becomes -1 if nodes were re-ordered
								oldIndices[i-start] = oldIndex;
								oe = old[oldIndex];
								old[oldIndex] = null;
								if (oe !== ve) updateNode(parent, oe, ve, hooks, nextSibling, ns);
								if (ve.dom != null) nextSibling = ve.dom;
								matched++;
							}
						}
						nextSibling = originalNextSibling;
						if (matched !== oldEnd - oldStart + 1) removeNodes(parent, old, oldStart, oldEnd + 1);
						if (matched === 0) createNodes(parent, vnodes, start, end + 1, hooks, nextSibling, ns);
						else {
							if (pos === -1) {
								// the indices of the indices of the items that are part of the
								// longest increasing subsequence in the oldIndices list
								lisIndices = makeLisIndices(oldIndices);
								li = lisIndices.length - 1;
								for (i = end; i >= start; i--) {
									v = vnodes[i];
									if (oldIndices[i-start] === -1) createNode(parent, v, hooks, ns, nextSibling);
									else {
										if (lisIndices[li] === i - start) li--;
										else moveNodes(parent, v, nextSibling);
									}
									if (v.dom != null) nextSibling = vnodes[i].dom;
								}
							} else {
								for (i = end; i >= start; i--) {
									v = vnodes[i];
									if (oldIndices[i-start] === -1) createNode(parent, v, hooks, ns, nextSibling);
									if (v.dom != null) nextSibling = vnodes[i].dom;
								}
							}
						}
					}
				}
			}
		}
		function updateNode(parent, old, vnode, hooks, nextSibling, ns) {
			var oldTag = old.tag, tag = vnode.tag;
			if (oldTag === tag) {
				vnode.state = old.state;
				vnode.events = old.events;
				if (shouldNotUpdate(vnode, old)) return
				if (typeof oldTag === "string") {
					if (vnode.attrs != null) {
						updateLifecycle(vnode.attrs, vnode, hooks);
					}
					switch (oldTag) {
						case "#": updateText(old, vnode); break
						case "<": updateHTML(parent, old, vnode, ns, nextSibling); break
						case "[": updateFragment(parent, old, vnode, hooks, nextSibling, ns); break
						default: updateElement(old, vnode, hooks, ns);
					}
				}
				else updateComponent(parent, old, vnode, hooks, nextSibling, ns);
			}
			else {
				removeNode(parent, old);
				createNode(parent, vnode, hooks, ns, nextSibling);
			}
		}
		function updateText(old, vnode) {
			if (old.children.toString() !== vnode.children.toString()) {
				old.dom.nodeValue = vnode.children;
			}
			vnode.dom = old.dom;
		}
		function updateHTML(parent, old, vnode, ns, nextSibling) {
			if (old.children !== vnode.children) {
				removeHTML(parent, old);
				createHTML(parent, vnode, ns, nextSibling);
			}
			else {
				vnode.dom = old.dom;
				vnode.domSize = old.domSize;
				vnode.instance = old.instance;
			}
		}
		function updateFragment(parent, old, vnode, hooks, nextSibling, ns) {
			updateNodes(parent, old.children, vnode.children, hooks, nextSibling, ns);
			var domSize = 0, children = vnode.children;
			vnode.dom = null;
			if (children != null) {
				for (var i = 0; i < children.length; i++) {
					var child = children[i];
					if (child != null && child.dom != null) {
						if (vnode.dom == null) vnode.dom = child.dom;
						domSize += child.domSize || 1;
					}
				}
				if (domSize !== 1) vnode.domSize = domSize;
			}
		}
		function updateElement(old, vnode, hooks, ns) {
			var element = vnode.dom = old.dom;
			ns = getNameSpace(vnode) || ns;

			if (vnode.tag === "textarea") {
				if (vnode.attrs == null) vnode.attrs = {};
				if (vnode.text != null) {
					vnode.attrs.value = vnode.text; //FIXME handle multiple children
					vnode.text = undefined;
				}
			}
			updateAttrs(vnode, old.attrs, vnode.attrs, ns);
			if (!maybeSetContentEditable(vnode)) {
				if (old.text != null && vnode.text != null && vnode.text !== "") {
					if (old.text.toString() !== vnode.text.toString()) old.dom.firstChild.nodeValue = vnode.text;
				}
				else {
					if (old.text != null) old.children = [Vnode("#", undefined, undefined, old.text, undefined, old.dom.firstChild)];
					if (vnode.text != null) vnode.children = [Vnode("#", undefined, undefined, vnode.text, undefined, undefined)];
					updateNodes(element, old.children, vnode.children, hooks, null, ns);
				}
			}
		}
		function updateComponent(parent, old, vnode, hooks, nextSibling, ns) {
			vnode.instance = Vnode.normalize(callHook.call(vnode.state.view, vnode));
			if (vnode.instance === vnode) throw Error("A view cannot return the vnode it received as argument")
			updateLifecycle(vnode.state, vnode, hooks);
			if (vnode.attrs != null) updateLifecycle(vnode.attrs, vnode, hooks);
			if (vnode.instance != null) {
				if (old.instance == null) createNode(parent, vnode.instance, hooks, ns, nextSibling);
				else updateNode(parent, old.instance, vnode.instance, hooks, nextSibling, ns);
				vnode.dom = vnode.instance.dom;
				vnode.domSize = vnode.instance.domSize;
			}
			else if (old.instance != null) {
				removeNode(parent, old.instance);
				vnode.dom = undefined;
				vnode.domSize = 0;
			}
			else {
				vnode.dom = old.dom;
				vnode.domSize = old.domSize;
			}
		}
		function getKeyMap(vnodes, start, end) {
			var map = Object.create(null);
			for (; start < end; start++) {
				var vnode = vnodes[start];
				if (vnode != null) {
					var key = vnode.key;
					if (key != null) map[key] = start;
				}
			}
			return map
		}
		// Lifted from ivi https://github.com/ivijs/ivi/
		// takes a list of unique numbers (-1 is special and can
		// occur multiple times) and returns an array with the indices
		// of the items that are part of the longest increasing
		// subsequence
		var lisTemp = [];
		function makeLisIndices(a) {
			var result = [0];
			var u = 0, v = 0, i = 0;
			var il = lisTemp.length = a.length;
			for (var i = 0; i < il; i++) lisTemp[i] = a[i];
			for (var i = 0; i < il; ++i) {
				if (a[i] === -1) continue
				var j = result[result.length - 1];
				if (a[j] < a[i]) {
					lisTemp[i] = j;
					result.push(i);
					continue
				}
				u = 0;
				v = result.length - 1;
				while (u < v) {
					// Fast integer average without overflow.
					// eslint-disable-next-line no-bitwise
					var c = (u >>> 1) + (v >>> 1) + (u & v & 1);
					if (a[result[c]] < a[i]) {
						u = c + 1;
					}
					else {
						v = c;
					}
				}
				if (a[i] < a[result[u]]) {
					if (u > 0) lisTemp[i] = result[u - 1];
					result[u] = i;
				}
			}
			u = result.length;
			v = result[u - 1];
			while (u-- > 0) {
				result[u] = v;
				v = lisTemp[v];
			}
			lisTemp.length = 0;
			return result
		}

		function getNextSibling(vnodes, i, nextSibling) {
			for (; i < vnodes.length; i++) {
				if (vnodes[i] != null && vnodes[i].dom != null) return vnodes[i].dom
			}
			return nextSibling
		}

		// This covers a really specific edge case:
		// - Parent node is keyed and contains child
		// - Child is removed, returns unresolved promise in `onbeforeremove`
		// - Parent node is moved in keyed diff
		// - Remaining children still need moved appropriately
		//
		// Ideally, I'd track removed nodes as well, but that introduces a lot more
		// complexity and I'm not exactly interested in doing that.
		function moveNodes(parent, vnode, nextSibling) {
			var frag = $doc.createDocumentFragment();
			moveChildToFrag(parent, frag, vnode);
			insertNode(parent, frag, nextSibling);
		}
		function moveChildToFrag(parent, frag, vnode) {
			// Dodge the recursion overhead in a few of the most common cases.
			while (vnode.dom != null && vnode.dom.parentNode === parent) {
				if (typeof vnode.tag !== "string") {
					vnode = vnode.instance;
					if (vnode != null) continue
				} else if (vnode.tag === "<") {
					for (var i = 0; i < vnode.instance.length; i++) {
						frag.appendChild(vnode.instance[i]);
					}
				} else if (vnode.tag !== "[") {
					// Don't recurse for text nodes *or* elements, just fragments
					frag.appendChild(vnode.dom);
				} else if (vnode.children.length === 1) {
					vnode = vnode.children[0];
					if (vnode != null) continue
				} else {
					for (var i = 0; i < vnode.children.length; i++) {
						var child = vnode.children[i];
						if (child != null) moveChildToFrag(parent, frag, child);
					}
				}
				break
			}
		}

		function insertNode(parent, dom, nextSibling) {
			if (nextSibling != null) parent.insertBefore(dom, nextSibling);
			else parent.appendChild(dom);
		}

		function maybeSetContentEditable(vnode) {
			if (vnode.attrs == null || (
				vnode.attrs.contenteditable == null && // attribute
				vnode.attrs.contentEditable == null // property
			)) return false
			var children = vnode.children;
			if (children != null && children.length === 1 && children[0].tag === "<") {
				var content = children[0].children;
				if (vnode.dom.innerHTML !== content) vnode.dom.innerHTML = content;
			}
			else if (vnode.text != null || children != null && children.length !== 0) throw new Error("Child node of a contenteditable must be trusted.")
			return true
		}

		//remove
		function removeNodes(parent, vnodes, start, end) {
			for (var i = start; i < end; i++) {
				var vnode = vnodes[i];
				if (vnode != null) removeNode(parent, vnode);
			}
		}
		function removeNode(parent, vnode) {
			var mask = 0;
			var original = vnode.state;
			var stateResult, attrsResult;
			if (typeof vnode.tag !== "string" && typeof vnode.state.onbeforeremove === "function") {
				var result = callHook.call(vnode.state.onbeforeremove, vnode);
				if (result != null && typeof result.then === "function") {
					mask = 1;
					stateResult = result;
				}
			}
			if (vnode.attrs && typeof vnode.attrs.onbeforeremove === "function") {
				var result = callHook.call(vnode.attrs.onbeforeremove, vnode);
				if (result != null && typeof result.then === "function") {
					// eslint-disable-next-line no-bitwise
					mask |= 2;
					attrsResult = result;
				}
			}
			checkState(vnode, original);

			// If we can, try to fast-path it and avoid all the overhead of awaiting
			if (!mask) {
				onremove(vnode);
				removeChild(parent, vnode);
			} else {
				if (stateResult != null) {
					var next = function () {
						// eslint-disable-next-line no-bitwise
						if (mask & 1) { mask &= 2; if (!mask) reallyRemove(); }
					};
					stateResult.then(next, next);
				}
				if (attrsResult != null) {
					var next = function () {
						// eslint-disable-next-line no-bitwise
						if (mask & 2) { mask &= 1; if (!mask) reallyRemove(); }
					};
					attrsResult.then(next, next);
				}
			}

			function reallyRemove() {
				checkState(vnode, original);
				onremove(vnode);
				removeChild(parent, vnode);
			}
		}
		function removeHTML(parent, vnode) {
			for (var i = 0; i < vnode.instance.length; i++) {
				parent.removeChild(vnode.instance[i]);
			}
		}
		function removeChild(parent, vnode) {
			// Dodge the recursion overhead in a few of the most common cases.
			while (vnode.dom != null && vnode.dom.parentNode === parent) {
				if (typeof vnode.tag !== "string") {
					vnode = vnode.instance;
					if (vnode != null) continue
				} else if (vnode.tag === "<") {
					removeHTML(parent, vnode);
				} else {
					if (vnode.tag !== "[") {
						parent.removeChild(vnode.dom);
						if (!Array.isArray(vnode.children)) break
					}
					if (vnode.children.length === 1) {
						vnode = vnode.children[0];
						if (vnode != null) continue
					} else {
						for (var i = 0; i < vnode.children.length; i++) {
							var child = vnode.children[i];
							if (child != null) removeChild(parent, child);
						}
					}
				}
				break
			}
		}
		function onremove(vnode) {
			if (typeof vnode.tag !== "string" && typeof vnode.state.onremove === "function") callHook.call(vnode.state.onremove, vnode);
			if (vnode.attrs && typeof vnode.attrs.onremove === "function") callHook.call(vnode.attrs.onremove, vnode);
			if (typeof vnode.tag !== "string") {
				if (vnode.instance != null) onremove(vnode.instance);
			} else {
				var children = vnode.children;
				if (Array.isArray(children)) {
					for (var i = 0; i < children.length; i++) {
						var child = children[i];
						if (child != null) onremove(child);
					}
				}
			}
		}

		//attrs
		function setAttrs(vnode, attrs, ns) {
			for (var key in attrs) {
				setAttr(vnode, key, null, attrs[key], ns);
			}
		}
		function setAttr(vnode, key, old, value, ns) {
			if (key === "key" || key === "is" || value == null || isLifecycleMethod(key) || (old === value && !isFormAttribute(vnode, key)) && typeof value !== "object") return
			if (key[0] === "o" && key[1] === "n") return updateEvent(vnode, key, value)
			if (key.slice(0, 6) === "xlink:") vnode.dom.setAttributeNS("http://www.w3.org/1999/xlink", key.slice(6), value);
			else if (key === "style") updateStyle(vnode.dom, old, value);
			else if (hasPropertyKey(vnode, key, ns)) {
				if (key === "value") {
					// Only do the coercion if we're actually going to check the value.
					/* eslint-disable no-implicit-coercion */
					//setting input[value] to same value by typing on focused element moves cursor to end in Chrome
					if ((vnode.tag === "input" || vnode.tag === "textarea") && vnode.dom.value === "" + value && vnode.dom === activeElement()) return
					//setting select[value] to same value while having select open blinks select dropdown in Chrome
					if (vnode.tag === "select" && old !== null && vnode.dom.value === "" + value) return
					//setting option[value] to same value while having select open blinks select dropdown in Chrome
					if (vnode.tag === "option" && old !== null && vnode.dom.value === "" + value) return
					/* eslint-enable no-implicit-coercion */
				}
				// If you assign an input type that is not supported by IE 11 with an assignment expression, an error will occur.
				if (vnode.tag === "input" && key === "type") vnode.dom.setAttribute(key, value);
				else vnode.dom[key] = value;
			} else {
				if (typeof value === "boolean") {
					if (value) vnode.dom.setAttribute(key, "");
					else vnode.dom.removeAttribute(key);
				}
				else vnode.dom.setAttribute(key === "className" ? "class" : key, value);
			}
		}
		function removeAttr(vnode, key, old, ns) {
			if (key === "key" || key === "is" || old == null || isLifecycleMethod(key)) return
			if (key[0] === "o" && key[1] === "n" && !isLifecycleMethod(key)) updateEvent(vnode, key, undefined);
			else if (key === "style") updateStyle(vnode.dom, old, null);
			else if (
				hasPropertyKey(vnode, key, ns)
				&& key !== "className"
				&& !(key === "value" && (
					vnode.tag === "option"
					|| vnode.tag === "select" && vnode.dom.selectedIndex === -1 && vnode.dom === activeElement()
				))
				&& !(vnode.tag === "input" && key === "type")
			) {
				vnode.dom[key] = null;
			} else {
				var nsLastIndex = key.indexOf(":");
				if (nsLastIndex !== -1) key = key.slice(nsLastIndex + 1);
				if (old !== false) vnode.dom.removeAttribute(key === "className" ? "class" : key);
			}
		}
		function setLateSelectAttrs(vnode, attrs) {
			if ("value" in attrs) {
				if(attrs.value === null) {
					if (vnode.dom.selectedIndex !== -1) vnode.dom.value = null;
				} else {
					var normalized = "" + attrs.value; // eslint-disable-line no-implicit-coercion
					if (vnode.dom.value !== normalized || vnode.dom.selectedIndex === -1) {
						vnode.dom.value = normalized;
					}
				}
			}
			if ("selectedIndex" in attrs) setAttr(vnode, "selectedIndex", null, attrs.selectedIndex, undefined);
		}
		function updateAttrs(vnode, old, attrs, ns) {
			if (attrs != null) {
				for (var key in attrs) {
					setAttr(vnode, key, old && old[key], attrs[key], ns);
				}
			}
			var val;
			if (old != null) {
				for (var key in old) {
					if (((val = old[key]) != null) && (attrs == null || attrs[key] == null)) {
						removeAttr(vnode, key, val, ns);
					}
				}
			}
		}
		function isFormAttribute(vnode, attr) {
			return attr === "value" || attr === "checked" || attr === "selectedIndex" || attr === "selected" && vnode.dom === activeElement() || vnode.tag === "option" && vnode.dom.parentNode === $doc.activeElement
		}
		function isLifecycleMethod(attr) {
			return attr === "oninit" || attr === "oncreate" || attr === "onupdate" || attr === "onremove" || attr === "onbeforeremove" || attr === "onbeforeupdate"
		}
		function hasPropertyKey(vnode, key, ns) {
			// Filter out namespaced keys
			return ns === undefined && (
				// If it's a custom element, just keep it.
				vnode.tag.indexOf("-") > -1 || vnode.attrs != null && vnode.attrs.is ||
				// If it's a normal element, let's try to avoid a few browser bugs.
				key !== "href" && key !== "list" && key !== "form" && key !== "width" && key !== "height"// && key !== "type"
				// Defer the property check until *after* we check everything.
			) && key in vnode.dom
		}

		//style
		var uppercaseRegex = /[A-Z]/g;
		function toLowerCase(capital) { return "-" + capital.toLowerCase() }
		function normalizeKey(key) {
			return key[0] === "-" && key[1] === "-" ? key :
				key === "cssFloat" ? "float" :
					key.replace(uppercaseRegex, toLowerCase)
		}
		function updateStyle(element, old, style) {
			if (old === style) ; else if (style == null) {
				// New style is missing, just clear it.
				element.style.cssText = "";
			} else if (typeof style !== "object") {
				// New style is a string, let engine deal with patching.
				element.style.cssText = style;
			} else if (old == null || typeof old !== "object") {
				// `old` is missing or a string, `style` is an object.
				element.style.cssText = "";
				// Add new style properties
				for (var key in style) {
					var value = style[key];
					if (value != null) element.style.setProperty(normalizeKey(key), String(value));
				}
			} else {
				// Both old & new are (different) objects.
				// Update style properties that have changed
				for (var key in style) {
					var value = style[key];
					if (value != null && (value = String(value)) !== String(old[key])) {
						element.style.setProperty(normalizeKey(key), value);
					}
				}
				// Remove style properties that no longer exist
				for (var key in old) {
					if (old[key] != null && style[key] == null) {
						element.style.removeProperty(normalizeKey(key));
					}
				}
			}
		}

		// Here's an explanation of how this works:
		// 1. The event names are always (by design) prefixed by `on`.
		// 2. The EventListener interface accepts either a function or an object
		//    with a `handleEvent` method.
		// 3. The object does not inherit from `Object.prototype`, to avoid
		//    any potential interference with that (e.g. setters).
		// 4. The event name is remapped to the handler before calling it.
		// 5. In function-based event handlers, `ev.target === this`. We replicate
		//    that below.
		// 6. In function-based event handlers, `return false` prevents the default
		//    action and stops event propagation. We replicate that below.
		function EventDict() {
			// Save this, so the current redraw is correctly tracked.
			this._ = currentRedraw;
		}
		EventDict.prototype = Object.create(null);
		EventDict.prototype.handleEvent = function (ev) {
			var handler = this["on" + ev.type];
			var result;
			if (typeof handler === "function") result = handler.call(ev.currentTarget, ev);
			else if (typeof handler.handleEvent === "function") handler.handleEvent(ev);
			if (this._ && ev.redraw !== false) (0, this._)();
			if (result === false) {
				ev.preventDefault();
				ev.stopPropagation();
			}
		};

		//event
		function updateEvent(vnode, key, value) {
			if (vnode.events != null) {
				if (vnode.events[key] === value) return
				if (value != null && (typeof value === "function" || typeof value === "object")) {
					if (vnode.events[key] == null) vnode.dom.addEventListener(key.slice(2), vnode.events, false);
					vnode.events[key] = value;
				} else {
					if (vnode.events[key] != null) vnode.dom.removeEventListener(key.slice(2), vnode.events, false);
					vnode.events[key] = undefined;
				}
			} else if (value != null && (typeof value === "function" || typeof value === "object")) {
				vnode.events = new EventDict();
				vnode.dom.addEventListener(key.slice(2), vnode.events, false);
				vnode.events[key] = value;
			}
		}

		//lifecycle
		function initLifecycle(source, vnode, hooks) {
			if (typeof source.oninit === "function") callHook.call(source.oninit, vnode);
			if (typeof source.oncreate === "function") hooks.push(callHook.bind(source.oncreate, vnode));
		}
		function updateLifecycle(source, vnode, hooks) {
			if (typeof source.onupdate === "function") hooks.push(callHook.bind(source.onupdate, vnode));
		}
		function shouldNotUpdate(vnode, old) {
			do {
				if (vnode.attrs != null && typeof vnode.attrs.onbeforeupdate === "function") {
					var force = callHook.call(vnode.attrs.onbeforeupdate, vnode, old);
					if (force !== undefined && !force) break
				}
				if (typeof vnode.tag !== "string" && typeof vnode.state.onbeforeupdate === "function") {
					var force = callHook.call(vnode.state.onbeforeupdate, vnode, old);
					if (force !== undefined && !force) break
				}
				return false
			} while (false); // eslint-disable-line no-constant-condition
			vnode.dom = old.dom;
			vnode.domSize = old.domSize;
			vnode.instance = old.instance;
			// One would think having the actual latest attributes would be ideal,
			// but it doesn't let us properly diff based on our current internal
			// representation. We have to save not only the old DOM info, but also
			// the attributes used to create it, as we diff *that*, not against the
			// DOM directly (with a few exceptions in `setAttr`). And, of course, we
			// need to save the children and text as they are conceptually not
			// unlike special "attributes" internally.
			vnode.attrs = old.attrs;
			vnode.children = old.children;
			vnode.text = old.text;
			return true
		}

		var currentDOM;

		return function(dom, vnodes, redraw) {
			if (!dom) throw new TypeError("DOM element being rendered to does not exist.")
			if (currentDOM != null && dom.contains(currentDOM)) {
				throw new TypeError("Node is currently being rendered to and thus is locked.")
			}
			var prevRedraw = currentRedraw;
			var prevDOM = currentDOM;
			var hooks = [];
			var active = activeElement();
			var namespace = dom.namespaceURI;

			currentDOM = dom;
			currentRedraw = typeof redraw === "function" ? redraw : undefined;
			try {
				// First time rendering into a node clears it out
				if (dom.vnodes == null) dom.textContent = "";
				vnodes = Vnode.normalizeChildren(Array.isArray(vnodes) ? vnodes : [vnodes]);
				updateNodes(dom, dom.vnodes, vnodes, hooks, null, namespace === "http://www.w3.org/1999/xhtml" ? undefined : namespace);
				dom.vnodes = vnodes;
				// `document.activeElement` can return null: https://html.spec.whatwg.org/multipage/interaction.html#dom-document-activeelement
				if (active != null && activeElement() !== active && typeof active.focus === "function") active.focus();
				for (var i = 0; i < hooks.length; i++) hooks[i]();
			} finally {
				currentRedraw = prevRedraw;
				currentDOM = prevDOM;
			}
		}
	};
	return render$2;
}

var render$1;
var hasRequiredRender;

function requireRender () {
	if (hasRequiredRender) return render$1;
	hasRequiredRender = 1;

	render$1 = requireRender$1()(window);
	return render$1;
}

var renderExports = requireRender();
var render = /*@__PURE__*/getDefaultExportFromCjs(renderExports);

var vnodeExports = requireVnode();
var Vnode = /*@__PURE__*/getDefaultExportFromCjs(vnodeExports);

/** `Object#toString` result references. */
var asyncTag = '[object AsyncFunction]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    proxyTag = '[object Proxy]';

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  if (!isObject$1(value)) {
    return false;
  }
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 9 which returns 'object' for typed arrays and other constructors.
  var tag = baseGetTag(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}

const uid = (function () {
    let id = 0;
    return () => id++;
})();
const router = new Rlite();
// unique incremented state id to determine slide direction
let currentStateId = 0;
let viewSlideDirection = 'fwd';
let previousPath = '/';
const mountPoint = document.body;
function withRouter(f) {
    f(router);
}
function onRouteMatch(component, params) {
    const RouteComponent = { view() {
            return Vnode(component, undefined, params);
        } };
    function redraw() {
        render(mountPoint, Vnode(RouteComponent));
    }
    signals.redraw.removeAll();
    signals.redraw.add(redraw);
    // some error may be thrown during component initialization
    // in that case shutdown redraws to avoid multiple execution of oninit
    // hook of buggy component
    try {
        redraw();
    }
    catch (e) {
        signals.redraw.removeAll();
        throw e;
    }
}
function processWindowLocation(e) {
    if (e && e.state) {
        if (e.state.id < currentStateId) {
            viewSlideDirection = 'bwd';
        }
        else {
            viewSlideDirection = 'fwd';
        }
        currentStateId = e.state.id;
    }
    previousPath = getPath();
    const qs = window.location.search || '?=';
    const matched = router.run(qs.slice(2));
    if (!matched)
        router.run('/');
}
const History = {
    replaceState(state, path) {
        // try catch to avoid ios 9 100th pushState call DOM error
        // see https://forums.developer.apple.com/thread/36650
        // and https://bugs.webkit.org/show_bug.cgi?id=156115
        // (may be only 100 calls per 30s interval in ios 10... need to test)
        try {
            const newState = state ?
                Object.assign({}, window.history.state, state) :
                window.history.state;
            if (path !== undefined) {
                window.history.replaceState(newState, '', '?=' + path);
            }
            else {
                window.history.replaceState(newState, '');
            }
        }
        catch (e) {
            console.error(e);
        }
    },
    pushState(path) {
        const stateId = uid();
        currentStateId = stateId;
        viewSlideDirection = 'fwd';
        try {
            window.history.pushState({ id: stateId }, '', '?=' + path);
        }
        catch (e) {
            console.error(e);
        }
    },
};
function setQueryParams(params, newState = false) {
    const path = (window.location.search || '?=/').substring(2).replace(/\?.+$/, '');
    const newPath = path + `?${serializeQueryParameters(params)}`;
    if (newState) {
        setPath(newPath, true);
    }
    else {
        History.replaceState(undefined, newPath);
    }
}
function deleteQueryParam(name, newState = false) {
    const params = getQueryParams();
    if (params) {
        delete params[name];
        setQueryParams(params, newState);
    }
}
function getQueryParams() {
    const path = getPath();
    const match = /\?.+$/.exec(path);
    const params = {};
    if (match && match[0]) {
        for (const [k, v] of new URLSearchParams(match[0])) {
            params[k] = v;
        }
    }
    return params;
}
const backbutton = (() => {
    const x = () => {
        const b = x.stack.pop();
        if (isFunction(b)) {
            b('backbutton');
            redraw();
        }
        else if (!/^\/$/.test(getPath())) {
            // disable back history on game to prevent accidental quitting of a game
            // see src/ui/shared/round/OnlineRound.ts for the backbutton behavior during
            // a game
            if (/^\/game\/[a-zA-Z0-9]{12}/.test(getPath())) {
                signals.gameBackButton.dispatch(event);
            }
            else {
                backHistory();
            }
        }
        else {
            App.exitApp();
        }
    };
    x.stack = [];
    return x;
})();
// for debug purposes
window['backButton'] = backbutton;
function doSet(path, replace = false) {
    // reset backbutton stack when changing route
    backbutton.stack = [];
    previousPath = getPath();
    if (replace) {
        History.replaceState(undefined, path);
    }
    else {
        History.pushState(path);
    }
    const matched = router.run(path);
    if (!matched)
        router.run('/');
}
// sync call to router.set must be avoided in any `oninit` mithril component
// otherwise it makes mithril create another root component on top of the
// existing one
// making router.set async makes it safe everywhere
function setPath(path, replace = false) {
    setTimeout(() => doSet(path, replace), 0);
}
function getPath() {
    const path = window.location.search || '?=/';
    return decodeURIComponent(path.substring(2));
}
function backHistory() {
    window.history.go(-1);
}
var router$1 = {
    get: getPath,
    set: setPath,
    reload() {
        setPath(getPath(), true);
    },
    setQueryParams,
    getQueryParams,
    deleteQueryParam,
    History,
    backHistory,
    getViewSlideDirection() {
        return viewSlideDirection;
    },
    backbutton,
    getPreviousPath() {
        return previousPath;
    },
};

const HOLD_DURATION = 600;
const SCROLL_TOLERANCE_X = 4;
const SCROLL_TOLERANCE_Y = 4;
const ACTIVE_CLASS = 'active';
function ButtonHandler(el, tapHandler, holdHandler, repeatHandler, scrollX, scrollY, getElement, preventEndDefault = true) {
    let activeElement = el;
    let startX, startY, boundaries, active, holdTimeoutID, repeatTimeoutId, activeTimeoutId;
    if (typeof tapHandler !== 'function')
        throw new Error('ButtonHandler 2nd argument must be a function!');
    if (holdHandler && typeof holdHandler !== 'function')
        throw new Error('ButtonHandler 3rd argument must be a function!');
    if (repeatHandler && typeof repeatHandler !== 'function')
        throw new Error('ButtonHandler 4rd argument must be a function!');
    // http://ejohn.org/blog/how-javascript-timers-work/
    function onRepeat() {
        const res = repeatHandler();
        if (res)
            batchRequestAnimationFrame(onRepeat);
        redrawSync();
    }
    function onTouchStart(e) {
        const touch = e.changedTouches[0];
        activeElement = getElement ? getElement(e) : el;
        if (!activeElement)
            return;
        if (activeElement.disabled === true)
            return;
        const boundingRect = activeElement.getBoundingClientRect();
        startX = touch.clientX;
        startY = touch.clientY;
        boundaries = {
            minX: boundingRect.left,
            maxX: boundingRect.right,
            minY: boundingRect.top,
            maxY: boundingRect.bottom
        };
        active = true;
        clearTimeout(activeTimeoutId);
        // for ios: need to set it bc/ :active doesn't reset when moving away
        activeElement.classList.add(ACTIVE_CLASS);
        holdTimeoutID = setTimeout(() => onHold(e), HOLD_DURATION);
        if (repeatHandler)
            repeatTimeoutId = setTimeout(() => {
                batchRequestAnimationFrame(onRepeat);
            }, 500);
    }
    function onTouchMove(e) {
        // if going out of bounds, no way to reenable the button
        if (active && activeElement) {
            const touch = e.changedTouches[0];
            active = isActive(touch);
            if (!active) {
                clearTimeout(holdTimeoutID);
                clearTimeout(repeatTimeoutId);
                removeFromBatchAnimationFrame(onRepeat);
                activeElement.classList.remove(ACTIVE_CLASS);
            }
        }
    }
    function onTouchEnd(e) {
        if (e.cancelable && preventEndDefault)
            e.preventDefault();
        clearTimeout(repeatTimeoutId);
        removeFromBatchAnimationFrame(onRepeat);
        if (active && activeElement) {
            clearTimeout(holdTimeoutID);
            activeTimeoutId = setTimeout(() => activeElement && activeElement.classList.remove(ACTIVE_CLASS), 80);
            tapHandler(e);
            active = false;
        }
    }
    function onTouchCancel() {
        clearTimeout(holdTimeoutID);
        clearTimeout(repeatTimeoutId);
        removeFromBatchAnimationFrame(onRepeat);
        active = false;
        if (activeElement) {
            activeElement.classList.remove(ACTIVE_CLASS);
        }
    }
    // typescript doesn't like TouchEvent here
    function onContextMenu(e) {
        // just disable it since we handle manually holdHandler
        // because contextmenu does not work in iOS and chrome dev tools
        // (it fires a MouseEvent in the latter)
        e.preventDefault();
        e.stopPropagation();
    }
    function onHold(e) {
        if (holdHandler) {
            holdHandler(e);
            active = false;
            if (activeElement) {
                activeElement.classList.remove(ACTIVE_CLASS);
            }
        }
    }
    function isActive(touch) {
        const x = touch.clientX, y = touch.clientY, b = boundaries;
        let dX = 0, dY = 0;
        if (scrollX)
            dX = Math.abs(x - startX);
        if (scrollY)
            dY = Math.abs(y - startY);
        return (x < b.maxX &&
            x > b.minX &&
            y < b.maxY &&
            y > b.minY &&
            dX < SCROLL_TOLERANCE_X &&
            dY < SCROLL_TOLERANCE_Y);
    }
    const passiveConf = { passive: true };
    el.addEventListener('touchstart', onTouchStart, passiveConf);
    el.addEventListener('touchmove', onTouchMove, passiveConf);
    el.addEventListener('touchend', onTouchEnd, false);
    el.addEventListener('touchcancel', onTouchCancel, false);
    el.addEventListener('contextmenu', onContextMenu, false);
}

const animDuration = 250;
let cachedIsPortrait;
let cachedViewportDim = null;
const headerHeight = 56;
function onPageEnter(anim) {
    return ({ dom }) => anim(dom);
}
// el fade in transition, can be applied to any element
function elFadeIn(el, duration = animDuration, origOpacity = '0.5', endOpacity = '1') {
    let tId = undefined;
    el.style.opacity = origOpacity;
    el.style.transition = `opacity ${duration}ms ease-out`;
    setTimeout(() => {
        el.style.opacity = endOpacity;
    });
    function after() {
        clearTimeout(tId);
        if (el) {
            el.removeAttribute('style');
            el.removeEventListener('transitionend', after, false);
        }
    }
    el.addEventListener('transitionend', after, false);
    // in case transitionend does not fire
    tId = setTimeout(after, duration + 10);
}
// page slide transition
// apply only to page change transitions
// they listen to history to determine if animation is going forward or backward
function pageSlideIn(el) {
    let tId = undefined;
    function after() {
        clearTimeout(tId);
        if (el) {
            el.removeAttribute('style');
            el.removeEventListener('transitionend', after, false);
        }
    }
    const direction = router$1.getViewSlideDirection() === 'fwd' ? '100%' : '-100%';
    el.style.transform = `translate3d(${direction},0,0)`;
    setTimeout(() => {
        el.style.transition = `transform ${animDuration}ms ease-out`;
        el.style.transform = 'translate3d(0%,0,0)';
    }, 10);
    el.addEventListener('transitionend', after, false);
    // in case transitionend does not fire
    tId = setTimeout(after, animDuration + 20);
}
function elSlideIn(el, dir) {
    let tId = undefined;
    function after() {
        clearTimeout(tId);
        if (el) {
            el.removeAttribute('style');
            el.removeEventListener('transitionend', after, false);
        }
    }
    const trans = dir === 'left' ? '100%' : '-100%';
    el.style.transform = `translate3d(${trans},0,0)`;
    setTimeout(() => {
        el.style.transition = `transform ${animDuration}ms ease-out`;
        el.style.transform = 'translate3d(0%,0,0)';
    }, 10);
    el.addEventListener('transitionend', after, false);
    // in case transitionend does not fire
    tId = setTimeout(after, animDuration + 20);
}
function findParentBySelector(el, selector) {
    return el.closest(selector) || el;
}
function viewportDim() {
    if (cachedViewportDim)
        return cachedViewportDim;
    const e = document.documentElement;
    const vpd = cachedViewportDim = {
        vw: e.clientWidth,
        vh: e.clientHeight
    };
    return vpd;
}
const viewSlideIn = onPageEnter(pageSlideIn);
const viewFadeIn = onPageEnter(elFadeIn);
function clearCachedViewportDim() {
    cachedViewportDim = null;
    cachedIsPortrait = undefined;
}
function slidesInUp(vnode) {
    const el = vnode.dom;
    el.style.transform = 'translateY(100%)';
    // force reflow hack
    vnode.state.lol = el.offsetHeight;
    return Zanimo(el, 'transform', 'translateY(0)', 250, 'ease-out')
        .catch(console.log.bind(console));
}
function slidesOutDown(callback, elID) {
    return function (fromBB) {
        const el = document.getElementById(elID);
        if (el) {
            Zanimo(el, 'transform', 'translateY(100%)', 250, 'ease-out')
                .then(() => autoredraw(() => callback(fromBB)))
                .catch(console.log.bind(console));
        }
    };
}
function slidesOutRight(callback, elID) {
    return function (fromBB) {
        const el = document.getElementById(elID);
        if (el) {
            Zanimo(el, 'transform', 'translateX(100%)', 250, 'ease-out')
                .then(() => autoredraw(() => callback(fromBB)))
                .catch(console.log.bind(console));
        }
    };
}
function slidesInLeft(vnode) {
    const el = vnode.dom;
    el.style.transform = 'translateX(100%)';
    // force reflow hack
    vnode.state.lol = el.offsetHeight;
    return Zanimo(el, 'transform', 'translateX(0)', 250, 'ease-out')
        .catch(console.log.bind(console));
}
function fadesOut(e, callback, selector, time = 150) {
    e.stopPropagation();
    const el = findParentBySelector(e.target, selector) ;
    if (el) {
        Zanimo(el, 'opacity', 0, time)
            .then(() => autoredraw(callback))
            .catch(console.log.bind(console));
    }
    else {
        callback();
        redraw();
    }
}
function createTapHandler(tapHandler, holdHandler, repeatHandler, scrollX, scrollY, getElement, preventEndDefault) {
    return function (vnode) {
        ButtonHandler(vnode.dom, (e) => {
            tapHandler(e);
            redraw();
        }, holdHandler ? (e) => autoredraw(() => holdHandler(e)) : undefined, repeatHandler, scrollX, scrollY, getElement, preventEndDefault);
    };
}
function ontouch(handler) {
    return (vnode) => {
        const dom = vnode.dom;
        dom.addEventListener('touchstart', handler);
    };
}
function ontap(tapHandler, holdHandler, repeatHandler, getElement) {
    return createTapHandler(tapHandler, holdHandler, repeatHandler, false, false, getElement);
}
function ontapX(tapHandler, holdHandler, getElement) {
    return createTapHandler(tapHandler, holdHandler, undefined, true, false, getElement);
}
function ontapY(tapHandler, holdHandler, getElement, preventEndDefault = true) {
    return createTapHandler(tapHandler, holdHandler, undefined, false, true, getElement, preventEndDefault);
}
function ontapXY(tapHandler, holdHandler, getElement, preventEndDefault = true) {
    return createTapHandler(tapHandler, holdHandler, undefined, true, true, getElement, preventEndDefault);
}
function progress(p) {
    if (p === 0)
        return null;
    return h('span', {
        className: 'progress ' + (p > 0 ? 'positive' : 'negative'),
        'data-icon': p > 0 ? 'N' : 'M'
    }, String(Math.abs(p)));
}
function classSet(classes) {
    const arr = [];
    for (const i in classes) {
        if (classes[i])
            arr.push(i);
    }
    return arr.join(' ');
}
function isTablet() {
    const { vw, vh } = viewportDim();
    return vw >= 768 && vh >= 768;
}
function isPortrait() {
    if (cachedIsPortrait !== undefined)
        return cachedIsPortrait;
    else {
        cachedIsPortrait = window.matchMedia('(orientation: portrait)').matches;
        return cachedIsPortrait;
    }
}
let cachedSafeAreaInset = null;
function nbFromPropValue(p) {
    const f = /\d{1,3}/.exec(p);
    const r = f && f[0];
    const n = Number(r);
    return isNaN(n) ? 0 : n;
}
function getSafeArea() {
    if (!cachedSafeAreaInset) {
        const s = getComputedStyle(document.documentElement);
        cachedSafeAreaInset = {
            top: nbFromPropValue(s.getPropertyValue('--sat')),
            right: nbFromPropValue(s.getPropertyValue('--sar')),
            bottom: nbFromPropValue(s.getPropertyValue('--sab')),
            left: nbFromPropValue(s.getPropertyValue('--sal')),
        };
        return cachedSafeAreaInset;
    }
    return cachedSafeAreaInset;
}
function getBoardBounds(viewportDim, isPortrait) {
    const { vh, vw } = viewportDim;
    const safeArea = getSafeArea();
    const tablet = isTablet();
    if (isPortrait) {
        if (tablet) {
            const side = vw * 0.94;
            return {
                width: side,
                height: side
            };
        }
        else {
            return {
                width: vw,
                height: vw
            };
        }
    }
    else {
        if (tablet) {
            const wsSide = vh - headerHeight - (vh * 0.06) - safeArea.top;
            return {
                width: wsSide,
                height: wsSide
            };
        }
        else {
            const lSide = vh - headerHeight - safeArea.top;
            return {
                width: lSide,
                height: lSide
            };
        }
    }
}
function hasSpaceForInlineReplay(vd, isPortrait) {
    const bounds = getBoardBounds(vd, isPortrait);
    // vh - headerHeight - boardHeight - footerHeight - min size of player tables
    return vd.vh - bounds.height - 56 - 45 - 110 >= 25;
}
function autofocus(vnode) {
    vnode.dom.focus();
}
function renderRatingDiff(player) {
    if (player.ratingDiff === undefined)
        return null;
    if (player.ratingDiff === 0)
        return h('span.rp.null', ' +0');
    if (player.ratingDiff > 0)
        return h('span.rp.up', ' +' + player.ratingDiff);
    if (player.ratingDiff < 0)
        return h('span.rp.down', ' ' + player.ratingDiff);
    return null;
}
function getButton(e) {
    const target = e.target;
    return target.tagName === 'BUTTON' ? target : target.closest('button');
}
function getLI(e) {
    const target = e.target;
    return target.tagName === 'LI' ? target : target.closest('li');
}
function getTR(e) {
    const target = e.target;
    return target.tagName === 'TR' ? target : target.closest('tr');
}
function closest(e, selector) {
    return e.target?.closest(selector);
}
function closestHandler(selector) {
    return (e) => e.target?.closest(selector);
}

function tellWorker(worker, topic, payload) {
    if (payload !== undefined) {
        worker.postMessage({ topic, payload });
    }
    else {
        worker.postMessage({ topic });
    }
}
function askWorker(worker, msg) {
    return new Promise((resolve, reject) => {
        function listen(e) {
            if (e.data.topic === msg.topic && (msg.reqid === undefined || e.data.reqid === msg.reqid)) {
                worker.removeEventListener('message', listen);
                resolve(e.data.payload);
            }
            else if (e.data.topic === 'error' && e.data.payload.callerTopic === msg.topic && (msg.reqid === undefined || e.data.reqid === msg.reqid)) {
                worker.removeEventListener('message', listen);
                reject(e.data.payload.error);
            }
        }
        worker.addEventListener('message', listen);
        worker.postMessage(msg);
    });
}

const SEEKING_SOCKET_NAME = 'seekLobby';
const worker = new Worker('socketWorker.js');
// connectedWS means connection is established and server ping/pong
// is working normally
let connectedWS = false;
let currentMoveLatency = 0;
let currentPingInterval = 2000;
let currentSetup$1;
const defaultHandlers = {
    following_onlines: handleFollowingOnline,
    following_enters: (name, payload) => autoredraw(() => friendsApi.set(name, payload.playing || false, payload.patron || false)),
    following_leaves: (name) => autoredraw(() => friendsApi.remove(name)),
    following_playing: (name) => autoredraw(() => friendsApi.playing(name)),
    following_stopped_playing: (name) => autoredraw(() => friendsApi.stoppedPlaying(name)),
    challenges: (data) => {
        challengesApi.set(data);
        redraw();
    },
    mlat: (mlat) => {
        currentMoveLatency = mlat;
    },
    deployPost() {
        tellWorker(worker, 'deploy');
    },
    resync() {
        router$1.reload();
    },
    announce: (a) => {
        const announcement = a;
        if (announcement.date) {
            announce$1.set(announcement);
        }
        else {
            announce$1.set(undefined);
        }
    }
};
function handleFollowingOnline(data, payload) {
    const friendsPlaying = payload.playing;
    const friendsPatrons = payload.patrons;
    friendsApi.reset(data, friendsPlaying, friendsPatrons);
    redraw();
}
function setupConnection(setup, socketHandlers) {
    const sid = storage.get(SESSION_ID_KEY);
    if (sid !== null) {
        if (setup.opts.params) {
            setup.opts.params[SESSION_ID_KEY] = sid;
        }
        else {
            setup.opts.params = {
                [SESSION_ID_KEY]: sid
            };
        }
    }
    else if (setup.opts.params) {
        delete setup.opts.params.sessionId;
    }
    setup.opts.options.isAuth = !!sid;
    worker.onmessage = (msg) => {
        switch (msg.data.topic) {
            case 'onOpen':
                if (socketHandlers.onOpen)
                    socketHandlers.onOpen();
                break;
            case 'disconnected':
                onDisconnected();
                break;
            case 'connected':
                onConnected();
                break;
            case 'onError':
                if (socketHandlers.onError)
                    socketHandlers.onError();
                break;
            case 'resync':
                router$1.reload();
                break;
            case 'handle': {
                const h = socketHandlers.events[msg.data.payload.t];
                if (h)
                    h(msg.data.payload.d, msg.data.payload);
                break;
            }
            case 'pingInterval':
                currentPingInterval = msg.data.payload;
                break;
        }
    };
    currentSetup$1 = { setup, handlers: socketHandlers };
    tellWorker(worker, 'create', setup);
}
function send(url, t, data, opts) {
    tellWorker(worker, 'send', [url, t, data, opts]);
}
function ask(url, t, listenTo, data, opts) {
    return new Promise((resolve, reject) => {
        // eslint is wrong, this gets reassigned at the end of the function
        // eslint-disable-next-line prefer-const
        let tid;
        function listen(e) {
            if (e.data.topic === 'handle' && e.data.payload.t === listenTo) {
                clearTimeout(tid);
                worker.removeEventListener('message', listen);
                resolve(e.data.payload.d);
            }
        }
        worker.addEventListener('message', listen);
        tellWorker(worker, 'ask', { msg: [url, t, data, opts], listenTo });
        tid = setTimeout(() => {
            worker.removeEventListener('message', listen);
            reject();
        }, 3000);
    });
}
function socketIfaceFactory(url) {
    return {
        send: (t, data, opts) => send(url, t, data, opts),
        ask: (t, listenTo, data, opts) => ask(url, t, listenTo, data, opts)
    };
}
function createGame(url, version, handlers, gameUrl, userTv) {
    let errorDetected = false;
    const socketHandlers = {
        onError: function () {
            // we can't get socket error, so we send an xhr to test whether the
            // rejection is an authorization issue
            if (!errorDetected) {
                // just to be sure that we don't send an xhr every second when the
                // websocket is trying to reconnect
                errorDetected = true;
                game(gameUrl.substring(1))
                    .catch((err) => {
                    if (err.status === 401) {
                        Toast.show({ text: 'Access is unauthorised.', position: 'center', duration: 'short' });
                        router$1.set('/');
                    }
                });
            }
        },
        onOpen: session$1.backgroundRefresh,
        events: Object.assign({}, defaultHandlers, handlers)
    };
    const opts = {
        options: {
            name: 'game',
            debug: config.mode === 'dev',
            sendOnOpen: [{ t: 'following_onlines' }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    if (userTv)
        opts.params = { userTv };
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        version,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createTournament(tournamentId, version, handlers, featuredGameId) {
    const url = '/tournament/' + tournamentId + `/socket/v${config.apiVersion}`;
    const socketHandlers = {
        events: Object.assign({}, defaultHandlers, handlers),
        onOpen: session$1.backgroundRefresh
    };
    const opts = {
        options: {
            name: 'tournament',
            debug: config.mode === 'dev',
            pingDelay: 2000,
            sendOnOpen: [{ t: 'following_onlines' }, { t: 'startWatching', d: featuredGameId }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        version,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createChallenge(id, version, onOpen, handlers) {
    const socketHandlers = {
        onOpen: () => {
            session$1.backgroundRefresh();
            onOpen();
        },
        events: Object.assign({}, defaultHandlers, handlers)
    };
    const url = `/challenge/${id}/socket/v${config.apiVersion}`;
    const opts = {
        options: {
            name: 'challenge',
            debug: config.mode === 'dev',
            ignoreUnknownMessages: true,
            pingDelay: 2000,
            sendOnOpen: [{ t: 'following_onlines' }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        version,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createLobby(name, onOpen, handlers) {
    const socketHandlers = {
        onOpen: () => {
            session$1.refresh();
            onOpen();
        },
        events: Object.assign({}, defaultHandlers, handlers)
    };
    const opts = {
        options: {
            name,
            debug: config.mode === 'dev',
            pingDelay: 2000,
            sendOnOpen: [{ t: 'following_onlines' }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const url = `/lobby/socket/v${config.apiVersion}`;
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createAnalysis(handlers) {
    const socketHandlers = {
        events: { ...defaultHandlers, ...handlers },
        onOpen: session$1.backgroundRefresh
    };
    const opts = {
        options: {
            name: 'analysis',
            debug: config.mode === 'dev',
            pingDelay: 3000,
            sendOnOpen: [{ t: 'following_onlines' }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const url = `/analysis/socket/v${config.apiVersion}`;
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createChat(handlers, onOpen) {
    const socketHandlers = {
        events: { ...defaultHandlers, ...handlers },
        onOpen: () => {
            session$1.backgroundRefresh();
            onOpen && onOpen();
        },
    };
    const opts = {
        options: {
            name: 'chat',
            debug: config.mode === 'dev',
            pingDelay: 2500,
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const url = `/socket/v${config.apiVersion}`;
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createStudy(studyId, handlers) {
    const socketHandlers = {
        events: { ...defaultHandlers, ...handlers },
        onOpen: session$1.backgroundRefresh
    };
    const opts = {
        options: {
            name: 'study',
            debug: config.mode === 'dev',
            pingDelay: 3000,
            sendOnOpen: [{ t: 'following_onlines' }],
            registeredEvents: Object.keys(socketHandlers.events)
        }
    };
    const url = `/study/${studyId}/socket/v${config.apiVersion}`;
    const setup = {
        clientId: newSri(),
        socketEndPoint: config.socketEndPoint,
        url,
        opts
    };
    setupConnection(setup, socketHandlers);
    return socketIfaceFactory(url);
}
function createDefault() {
    if (hasNetwork()) {
        const socketHandlers = {
            events: defaultHandlers,
            onOpen: session$1.backgroundRefresh
        };
        const opts = {
            options: {
                name: 'default',
                debug: config.mode === 'dev',
                pingDelay: 3000,
                sendOnOpen: [{ t: 'following_onlines' }],
                registeredEvents: Object.keys(socketHandlers.events)
            }
        };
        const setup = {
            clientId: newSri(),
            socketEndPoint: config.socketEndPoint,
            url: `/socket/v${config.apiVersion}`,
            opts
        };
        setupConnection(setup, socketHandlers);
    }
}
function redirectToGame(obj) {
    let url;
    if (typeof obj === 'string')
        url = obj;
    else {
        url = obj.url;
        if (obj.cookie) {
            const domain = document.domain.replace(/^.+(\.[^.]+\.[^.]+)$/, '$1');
            const cookie = [
                encodeURIComponent(obj.cookie.name) + '=' + obj.cookie.value,
                '; max-age=' + obj.cookie.maxAge,
                '; path=/',
                '; domain=' + domain
            ].join('');
            document.cookie = cookie;
        }
    }
    router$1.set('/game' + url);
}
function onConnected() {
    if (!connectedWS) {
        connectedWS = true;
        redraw();
    }
}
function onDisconnected() {
    if (connectedWS) {
        connectedWS = false;
        redraw();
    }
}
// reconnect current socket giving a chance to refresh sessionId
function reconnectCurrent() {
    if (currentSetup$1) {
        setupConnection(currentSetup$1.setup, currentSetup$1.handlers);
    }
    else {
        tellWorker(worker, 'connect');
    }
}
signals.afterLogout.add(reconnectCurrent);
var socket = {
    createGame,
    createChallenge,
    createLobby,
    createTournament,
    createDefault,
    createAnalysis,
    createStudy,
    createChat,
    redirectToGame,
    // send a message to socket, not checking if sending to the proper url
    // use sparingly
    sendWithNoCheck(t, data, opts) {
        const whitelist = ['moveLat'];
        if (whitelist.includes(t)) {
            tellWorker(worker, 'send', ['noCheck', t, data, opts]);
        }
    },
    setVersion(version) {
        tellWorker(worker, 'setVersion', version);
    },
    connect() {
        tellWorker(worker, 'connect');
    },
    reconnectCurrent,
    disconnect() {
        tellWorker(worker, 'disconnect');
    },
    delayedDisconnect(delay) {
        tellWorker(worker, 'delayedDisconnect', delay);
    },
    cancelDelayedDisconnect() {
        tellWorker(worker, 'cancelDelayedDisconnect');
    },
    isConnected() {
        return connectedWS;
    },
    destroy() {
        tellWorker(worker, 'destroy');
    },
    getVersion() {
        return askWorker(worker, { topic: 'getVersion' });
    },
    getCurrentPing() {
        return askWorker(worker, { topic: 'averageLag' });
    },
    getCurrentMoveLatency() {
        return currentMoveLatency;
    },
    getCurrentPingInterval() {
        return currentPingInterval;
    },
    terminate() {
        if (worker)
            worker.terminate();
    }
};

function isPoolMember(conf) {
    return conf.id !== undefined;
}
function isSeekSetup(conf) {
    return conf.timeMode !== undefined;
}
function isGameData(data) {
    return data.steps !== undefined;
}

async function loadConvo(userId) {
    const d = await fetchJSON(`/inbox/${userId}`);
    return upgradeData(d);
}
async function getMore(userId, before) {
    const d = await fetchJSON(`/inbox/${userId}?before=${before.getTime()}`);
    return upgradeData(d);
}
async function loadContacts() {
    const d = await fetchJSON('/inbox');
    return upgradeData(d);
}
async function search(q) {
    const res = await fetchJSON(`/inbox/search?q=${q}`);
    return ({
        ...res,
        contacts: res.contacts.map(upgradeContact)
    });
}
function block(u) {
    return fetchJSON(`/rel/block/${u}`, { method: 'POST' });
}
function unblock(u) {
    return fetchJSON(`/rel/unblock/${u}`, { method: 'POST' });
}
async function del(u) {
    return fetchJSON(`/inbox/${u}/delete`, { method: 'POST' })
        .then(upgradeData);
}
function unreadCount() {
    return fetchJSON('/inbox/unread-count', {}, false);
}
class MessageSocket {
    constructor(ctrl) {
        const handlers = socketMessageHandlers(ctrl);
        this.socket = socket.createChat(handlers);
    }
    post(dest, text) {
        this.socket.send('msgSend', { dest, text });
    }
    setRead(dest) {
        this.socket.send('msgRead', dest);
    }
    typing(dest) {
        this.socket.send('msgType', dest);
    }
}
function socketMessageHandlers(ctrl) {
    return {
        msgNew: (msg) => {
            ctrl.receive({
                ...upgradeMsg(msg),
                read: false
            });
        },
        msgType: ctrl.receiveTyping,
        blockedBy: ctrl.changeBlockBy,
        unblockedBy: ctrl.changeBlockBy,
    };
}
// the upgrade functions convert incoming timestamps into JS dates
function upgradeData(d) {
    return {
        ...d,
        convo: d.convo && upgradeConvo(d.convo),
        contacts: d.contacts.map(upgradeContact)
    };
}
function upgradeMsg(m) {
    return {
        ...m,
        date: new Date(m.date)
    };
}
function upgradeUser(u) {
    return {
        ...u,
        id: u.name.toLowerCase()
    };
}
function upgradeContact(c) {
    return {
        ...c,
        user: upgradeUser(c.user),
        lastMsg: upgradeMsg(c.lastMsg)
    };
}
function upgradeConvo(c) {
    return {
        ...c,
        user: upgradeUser(c.user),
        msgs: c.msgs.map(upgradeMsg)
    };
}

const OPEN_AFTER_SLIDE_RATIO = 0.6;
const EDGE_SLIDE_THRESHOLD = 25;
const BACKDROP_OPACITY = 0.7;
function getMenuWidth() {
    const vw = viewportDim().vw;
    // see menu.styl
    const menuSizeRatio = vw >= 960 ? 0.35 : vw >= 500 ? 0.5 : 0.85;
    return vw * menuSizeRatio;
}
function translateMenu(el, xPos) {
    el.style.transform = `translate3d(${xPos}px, 0, 0)`;
}
function backdropOpacity(el, opacity) {
    el.style.opacity = `${opacity}`;
}

class SideMenuCtrl {
    constructor(side, menuID, backdropID, onOpen, onClose) {
        this.isOpen = false;
        this.open = () => {
            this.isOpen = true;
            router$1.backbutton.stack.push(this.close);
            const el = document.getElementById(this.menuID);
            const bd = document.getElementById(this.backdropID);
            if (this.onOpen)
                this.onOpen();
            return Promise.all([
                Zanimo(bd, 'visibility', 'visible', 0),
                Zanimo(bd, 'opacity', BACKDROP_OPACITY, 250, 'linear'),
                Zanimo(el, 'visibility', 'visible', 0),
                Zanimo(el, 'transform', 'translate3d(0,0,0)', 250, 'ease-out')
            ])
                .then(redraw)
                .catch(console.error.bind(console));
        };
        this.close = (fromBB) => {
            if (fromBB !== 'backbutton' && this.isOpen)
                router$1.backbutton.stack.pop();
            this.isOpen = false;
            const el = document.getElementById(this.menuID);
            const bd = document.getElementById(this.backdropID);
            if (this.onClose)
                this.onClose();
            return Promise.all([
                Zanimo(bd, 'opacity', 0, 250, 'linear'),
                Zanimo(el, 'transform', this.closeTranslate(), 250, 'ease-out')
            ])
                .then(() => Promise.all([
                Zanimo(el, 'visibility', 'hidden', 0),
                Zanimo(bd, 'visibility', 'hidden', 0)
            ]))
                .catch(console.error.bind(console));
        };
        this.toggle = (e) => {
            e.stopPropagation();
            if (this.isOpen)
                this.close();
            else
                this.open();
        };
        // ---
        this.closeTranslate = () => this.side === 'left' ? 'translate3d(-100%,0,0)' : 'translate3d(100%,0,0)';
        this.side = side;
        this.menuID = menuID;
        this.backdropID = backdropID;
        this.onOpen = onOpen;
        this.onClose = onClose;
    }
    getMenuEl() {
        return document.getElementById(this.menuID);
    }
    getBackdropEl() {
        return document.getElementById(this.backdropID);
    }
}

let pingsTimeoutID;
const inboxUnreadCount = prop(0);
const profileMenuOpen = prop(false);
const mlat = prop(0);
const ping = prop(0);
function onMenuOpen() {
    if (hasNetwork()) {
        socket.sendWithNoCheck('moveLat', true);
    }
    pingsTimeoutID = setTimeout(getServerLags, 2000);
}
function onMenuClose() {
    profileMenuOpen(false);
    clearTimeout(pingsTimeoutID);
    if (hasNetwork()) {
        socket.sendWithNoCheck('moveLat', false);
    }
}
const mainMenuCtrl = new SideMenuCtrl('left', 'side_menu', 'menu-close-overlay', onMenuOpen, onMenuClose);
function route(route) {
    return function () {
        return mainMenuCtrl.close().then(() => router$1.set(route));
    };
}
function action(f) {
    return function () {
        return mainMenuCtrl.close().then(() => {
            f();
            redraw();
        });
    };
}
function toggleHeader() {
    const open = !profileMenuOpen();
    if (open) {
        unreadCount()
            .then(nb => {
            inboxUnreadCount(nb);
            redraw();
        });
    }
    profileMenuOpen(open);
}
function getServerLags() {
    if (hasNetwork()) {
        socket.getCurrentPing()
            .then((p) => {
            ping(p);
            mlat(socket.getCurrentMoveLatency());
            if (mainMenuCtrl.isOpen) {
                redraw();
                setTimeout(getServerLags, 2000);
            }
        });
    }
}
const backdropCloseHandler = ontap((e) => {
    e.stopPropagation();
    mainMenuCtrl.close();
});

// Copyright (c) 2010-2016 Rasmus Andersson https://rsms.me/
// taken from https://github.com/rsms/js-lru
/**
 * A doubly linked list-based Least Recently Used (LRU) cache. Will keep most
 * recently used items while discarding least recently used items when its limit
 * is reached.
 *
 * Licensed under MIT. Copyright (c) 2010 Rasmus Andersson <http://hunch.se/>
 * See README.md for details.
 *
 * Illustration of the design:
 *
 *       entry             entry             entry             entry
 *       ______            ______            ______            ______
 *      | head |.newer => |      |.newer => |      |.newer => | tail |
 *      |  A   |          |  B   |          |  C   |          |  D   |
 *      |______| <= older.|______| <= older.|______| <= older.|______|
 *
 *  removed  <--  <--  <--  <--  <--  <--  <--  <--  <--  <--  <--  added
 */
const NEWER = Symbol('newer');
const OLDER = Symbol('older');
class LRUMap {
    constructor(limit, entries) {
        if (typeof limit !== 'number') {
            // called as (entries)
            entries = limit;
            limit = 0;
        }
        this.size = 0;
        this.limit = limit;
        this.oldest = this.newest = undefined;
        this._keymap = new Map();
        if (entries) {
            this.assign(entries);
            if (limit < 1) {
                this.limit = this.size;
            }
        }
    }
    _markEntryAsUsed(entry) {
        if (entry === this.newest) {
            // Already the most recenlty used entry, so no need to update the list
            return;
        }
        // HEAD--------------TAIL
        //   <.older   .newer>
        //  <--- add direction --
        //   A  B  C  <D>  E
        if (entry[NEWER]) {
            if (entry === this.oldest) {
                this.oldest = entry[NEWER];
            }
            entry[NEWER][OLDER] = entry[OLDER]; // C <-- E.
        }
        if (entry[OLDER]) {
            entry[OLDER][NEWER] = entry[NEWER]; // C. --> E
        }
        entry[NEWER] = undefined; // D --x
        entry[OLDER] = this.newest; // D. --> E
        if (this.newest) {
            this.newest[NEWER] = entry; // E. <-- D
        }
        this.newest = entry;
    }
    assign(entries) {
        let entry, limit = this.limit || Number.MAX_VALUE;
        this._keymap.clear();
        let it = entries[Symbol.iterator]();
        for (let itv = it.next(); !itv.done; itv = it.next()) {
            let e = new Entry(itv.value[0], itv.value[1]);
            this._keymap.set(e.key, e);
            if (!entry) {
                this.oldest = e;
            }
            else {
                entry[NEWER] = e;
                e[OLDER] = entry;
            }
            entry = e;
            if (limit-- === 0) {
                throw new Error('overflow');
            }
        }
        this.newest = entry;
        this.size = this._keymap.size;
    }
    get(key) {
        // First, find our cache entry
        var entry = this._keymap.get(key);
        if (!entry)
            return; // Not cached. Sorry.
        // As <key> was found in the cache, register it as being requested recently
        this._markEntryAsUsed(entry);
        return entry.value;
    }
    set(key, value) {
        var entry = this._keymap.get(key);
        if (entry) {
            // update existing
            entry.value = value;
            this._markEntryAsUsed(entry);
            return this;
        }
        // new entry
        this._keymap.set(key, (entry = new Entry(key, value)));
        if (this.newest) {
            // link previous tail to the new tail (entry)
            this.newest[NEWER] = entry;
            entry[OLDER] = this.newest;
        }
        else {
            // we're first in -- yay
            this.oldest = entry;
        }
        // add new entry to the end of the linked list -- it's now the freshest entry.
        this.newest = entry;
        ++this.size;
        if (this.size > this.limit) {
            // we hit the limit -- remove the head
            this.shift();
        }
        return this;
    }
    shift() {
        // todo: handle special case when limit == 1
        var entry = this.oldest;
        if (entry) {
            if (this.oldest[NEWER]) {
                // advance the list
                this.oldest = this.oldest[NEWER];
                this.oldest[OLDER] = undefined;
            }
            else {
                // the cache is exhausted
                this.oldest = undefined;
                this.newest = undefined;
            }
            // Remove last strong reference to <entry> and remove links from the purged
            // entry being returned:
            entry[NEWER] = entry[OLDER] = undefined;
            this._keymap.delete(entry.key);
            --this.size;
            return [entry.key, entry.value];
        }
    }
    /** Returns a JSON (array) representation */
    toJSON() {
        var s = new Array(this.size), i = 0, entry = this.oldest;
        while (entry) {
            s[i++] = [entry.key, entry.value];
            entry = entry[NEWER];
        }
        return s;
    }
}
function Entry(key, value) {
    this.key = key;
    this.value = value;
    this[NEWER] = undefined;
    this[OLDER] = undefined;
}

// remember game positions to improve game screen loading
// gameId -> Position
const positionsCache = new LRUMap(100);

function lightPlayerName(player, withRating) {
    if (player) {
        return (player.title ? player.title + ' ' + player.name : player.name) + ('');
    }
    else {
        return 'Anonymous';
    }
}
// this is too polymorphic to be typed... needs a refactoring
function playerName(player, withRating = false, tr = false, trLenght) {
    if (player.name || player.username || player.user) {
        let name = player.name || player.username || player.user.username;
        if (player.user && player.user.title)
            name = player.user.title + ' ' + name;
        if (tr)
            name = truncate(name, trLenght || 100);
        if (withRating && (player.user || player.rating)) {
            name += ' (' + (player.rating || player.user.rating);
            if (player.provisional)
                name += '?';
            name += ')';
        }
        return name;
    }
    if (player.ai) {
        return aiName(player);
    }
    return 'Anonymous';
}
function aiName(player) {
    return i18n('aiNameLevelAiLevel', 'Stockfish', player.ai);
}

const standardFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const variantMap = {
    standard: {
        name: 'Standard',
        tinyName: 'Std',
        id: 1,
        link: 'https://en.wikipedia.org/wiki/Rules_of_chess',
        title: 'Standard rules of chess (FIDE)'
    },
    chess960: {
        name: 'Chess960',
        tinyName: '960',
        id: 2,
        link: 'https://live.chess-online.com/variant/chess960',
        alert: 'This is a Chess960 game!\n\nThe starting position of the pieces on the players\' home ranks is randomized.',
        title: 'Starting position of the home rank pieces is randomized.',
    },
    fromPosition: {
        name: 'From position',
        shortName: 'Fen',
        tinyName: 'Fen',
        id: 3,
        title: 'Custom starting position',
    },
    kingOfTheHill: {
        name: 'King of the Hill',
        shortName: 'KotH',
        tinyName: 'KotH',
        id: 4,
        link: 'https://live.chess-online.com/variant/kingOfTheHill',
        alert: 'This is a King of the Hill game!\n\nThe game can be won by bringing the king to the center.',
        title: 'Bring your King to the center to win the game.',
    },
    threeCheck: {
        name: 'Three-check',
        shortName: '3-check',
        tinyName: '3+',
        id: 5,
        link: 'https://live.chess-online.com/variant/threeCheck',
        alert: 'This is a Three-check game!\n\nThe game can be won by checking the opponent 3 times.',
        title: 'Check your opponent 3 times to win the game.',
        initialFen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1 +0+0'
    },
    antichess: {
        name: 'Antichess',
        tinyName: 'Anti',
        id: 6,
        link: 'https://live.chess-online.com/variant/antichess',
        alert: 'This is an antichess chess game!\n\n If you can take a piece, you must. The game can be won by losing all your pieces.',
        title: 'Lose all your pieces (or reach a stalemate) to win the game.',
    },
    atomic: {
        name: 'Atomic',
        tinyName: 'Atom',
        id: 7,
        link: 'https://live.chess-online.com/variant/atomic',
        alert: 'This is an atomic chess game!\n\nCapturing a piece causes an explosion, taking out your piece and surrounding non-pawns. Win by mating or exploding your opponent\'s king.',
        title: 'Nuke your opponent\'s king to win.',
    },
    horde: {
        name: 'Horde',
        tinyName: 'Horde',
        id: 8,
        link: 'https://live.chess-online.com/variant/horde',
        alert: 'This is a horde chess game!\n\nBlack must take all white pawns to win. White must checkmate black king.',
        title: 'Destroy the horde to win!',
        initialFen: 'rnbqkbnr/pppppppp/8/1PP2PP1/PPPPPPPP/PPPPPPPP/PPPPPPPP/PPPPPPPP w kq - 0 1'
    },
    racingKings: {
        name: 'Racing Kings',
        shortName: 'Racing',
        tinyName: 'Racing',
        id: 9,
        link: 'https://live.chess-online.com/variant/racingKings',
        alert: 'Race to the eighth rank to win.',
        title: 'Race your King to the eighth rank to win.',
        initialFen: '8/8/8/8/8/8/krbnNBRK/qrbnNBRQ w - - 0 1'
    },
    crazyhouse: {
        name: 'Crazyhouse',
        tinyName: 'Crazy',
        id: 10,
        link: 'https://live.chess-online.com/variant/crazyhouse',
        alert: 'This is a crazyhouse game!\n\nEvery time a piece is captured the capturing player gets a piece of the same type and of their color in their pocket.',
        title: 'Captured pieces can be dropped back on the board instead of moving a piece.',
        initialFen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR/ w KQkq - 0 1'
    }
};
function getVariant(key) {
    return variantMap[key];
}
function getLichessVariant(key) {
    const dv = variantMap[key];
    return {
        key,
        name: dv.name,
        short: dv.shortName || dv.tinyName || dv.name,
        title: dv.title
    };
}
function getInitialFen(key) {
    const v = variantMap[key];
    return v.initialFen || standardFen;
}
function chessopRulesFromVariant(key) {
    switch (key) {
        case 'fromPosition':
        case 'standard':
        case 'chess960':
            return 'chess';
        case 'threeCheck':
            return '3check';
        default:
            return key.toLowerCase();
    }
}
const specialFenVariants = new Set(['crazyhouse', 'threeCheck']);
const openingSensibleVariants = new Set([
    'standard', 'crazyhouse', 'threeCheck', 'kingOfTheHill'
]);

// taken from https://github.com/pawelgrzybek/siema
// and adapted
class Siema {
    /**
     * Create a Siema.
     * @param {Object} options - Optional settings object.
     */
    constructor(options) {
        // Merge defaults with user's settings
        this.config = Siema.mergeSettings(options);
        // Resolve selector's type
        this.selector = typeof this.config.selector === 'string' ? document.querySelector(this.config.selector) : this.config.selector;
        // Early throw if selector doesn't exists
        if (this.selector === null) {
            throw new Error('Something wrong with your selector ??');
        }
        // update perPage number dependable of user value
        this.resolveSlidesNumber();
        // Create global references
        this.selectorWidth = this.selector.offsetWidth;
        this.innerElements = [].slice.call(this.selector.children);
        this.currentSlide =
            Math.max(0, Math.min(this.config.startIndex, this.innerElements.length - this.perPage));
        this.transformProperty = 'transform';
        // Bind all event handlers for referencability
        ['resizeHandler', 'touchstartHandler', 'touchendHandler', 'touchmoveHandler'].forEach(method => {
            this[method] = this[method].bind(this);
        });
        // Build markup and apply required styling to elements
        this.init();
    }
    /**
     * Overrides default settings with custom ones.
     * @param {Object} options - Optional settings object.
     * @returns {Object} - Custom Siema settings.
     */
    static mergeSettings(options) {
        const settings = {
            selector: '.siema',
            duration: 200,
            easing: 'ease-out',
            perPage: 1,
            startIndex: 0,
            draggable: true,
            // multipleDrag: true,
            threshold: 20,
            rtl: false,
            onInit: () => { },
            onChange: () => { },
        };
        const userSttings = options;
        for (const attrname in userSttings) {
            settings[attrname] = userSttings[attrname];
        }
        return settings;
    }
    /**
     * Attaches listeners to required events.
     */
    attachEvents() {
        // Resize element on window resize
        window.addEventListener('resize', this.resizeHandler);
        // If element is draggable / swipable, add event handlers
        if (this.config.draggable) {
            // Keep track pointer hold and dragging distance
            this.pointerDown = false;
            this.drag = {
                startX: 0,
                endX: 0,
                startY: 0,
                letItGo: null,
                preventClick: false,
            };
            const passiveConf = { passive: true };
            // Touch events
            this.selector.addEventListener('touchstart', this.touchstartHandler, passiveConf);
            this.selector.addEventListener('touchend', this.touchendHandler, passiveConf);
            this.selector.addEventListener('touchmove', this.touchmoveHandler, passiveConf);
        }
    }
    /**
     * Detaches listeners from required events.
     */
    detachEvents() {
        window.removeEventListener('resize', this.resizeHandler);
        this.selector.removeEventListener('touchstart', this.touchstartHandler);
        this.selector.removeEventListener('touchend', this.touchendHandler);
        this.selector.removeEventListener('touchmove', this.touchmoveHandler);
    }
    /**
     * Builds the markup and attaches listeners to required events.
     */
    init() {
        this.attachEvents();
        // hide everything out of selector's boundaries
        this.selector.style.overflow = 'hidden';
        // rtl or ltr
        this.selector.style.direction = this.config.rtl ? 'rtl' : 'ltr';
        // build a frame and slide to a currentSlide
        this.buildSliderFrame();
        this.config.onInit.call(this);
    }
    /**
     * Build a sliderFrame and slide to a current item.
     */
    buildSliderFrame() {
        const widthItem = this.selectorWidth / this.perPage;
        const itemsToBuild = this.innerElements.length;
        // Create frame and apply styling
        this.sliderFrame = document.createElement('div');
        this.sliderFrame.style.width = `${widthItem * itemsToBuild}px`;
        // Create a document fragment to put slides into it
        const docFragment = document.createDocumentFragment();
        for (let i = 0; i < this.innerElements.length; i++) {
            const element = this.buildSliderFrameItem(this.innerElements[i]);
            docFragment.appendChild(element);
        }
        // Add fragment to the frame
        this.sliderFrame.appendChild(docFragment);
        // Clear selector (just in case something is there) and insert a frame
        this.selector.innerHTML = '';
        this.selector.appendChild(this.sliderFrame);
        // Go to currently active slide after initial build
        this.slideToCurrent();
    }
    buildSliderFrameItem(elm) {
        const elementContainer = document.createElement('div');
        elementContainer.style.cssFloat = this.config.rtl ? 'right' : 'left';
        elementContainer.style.float = this.config.rtl ? 'right' : 'left';
        elementContainer.style.width = `${100 / (this.innerElements.length)}%`;
        elementContainer.appendChild(elm);
        return elementContainer;
    }
    /**
     * Determinates slides number accordingly to clients viewport.
     */
    resolveSlidesNumber() {
        if (typeof this.config.perPage === 'number') {
            this.perPage = this.config.perPage;
        }
        else if (typeof this.config.perPage === 'object') {
            this.perPage = 1;
            for (const viewport in this.config.perPage) {
                if (window.innerWidth >= viewport) {
                    this.perPage = this.config.perPage[viewport];
                }
            }
        }
    }
    /**
     * Go to previous slide.
     * @param {number} [howManySlides=1] - How many items to slide backward.
     * @param {function} callback - Optional callback function.
     */
    prev(howManySlides = 1) {
        // early return when there is nothing to slide
        if (this.innerElements.length <= this.perPage) {
            return;
        }
        const beforeChange = this.currentSlide;
        this.currentSlide = Math.max(this.currentSlide - howManySlides, 0);
        if (beforeChange !== this.currentSlide) {
            this.slideToCurrent();
            setTimeout(() => this.config.onChange(), 0);
        }
    }
    /**
     * Go to next slide.
     * @param {number} [howManySlides=1] - How many items to slide forward.
     * @param {function} callback - Optional callback function.
     */
    next(howManySlides = 1) {
        // early return when there is nothing to slide
        if (this.innerElements.length <= this.perPage) {
            return;
        }
        const beforeChange = this.currentSlide;
        this.currentSlide = Math.min(this.currentSlide + howManySlides, this.innerElements.length - this.perPage);
        if (beforeChange !== this.currentSlide) {
            this.slideToCurrent();
            setTimeout(() => this.config.onChange(), 0);
        }
    }
    /**
     * Go to slide with particular index
     * @param {number} index - Item index to slide to.
     */
    goTo(index) {
        if (this.innerElements.length <= this.perPage) {
            return;
        }
        const beforeChange = this.currentSlide;
        this.currentSlide =
            Math.min(Math.max(index, 0), this.innerElements.length - this.perPage);
        if (beforeChange !== this.currentSlide) {
            this.slideToCurrent();
            setTimeout(() => this.config.onChange(), 0);
        }
    }
    /**
     * Moves sliders frame to position of currently active slide
     */
    slideToCurrent() {
        const currentSlide = this.currentSlide;
        const offset = (this.config.rtl ? 1 : -1) * currentSlide * (this.selectorWidth / this.perPage);
        Zanimo(this.sliderFrame, 'transform', `translate3d(${offset}px, 0, 0)`, this.config.duration, this.config.easing);
    }
    /**
     * Recalculate drag /swipe event and reposition the frame of a slider
     */
    updateAfterDrag() {
        const movement = (this.config.rtl ? -1 : 1) * (this.drag.endX - this.drag.startX);
        const movementDistance = Math.abs(movement);
        // const howManySliderToSlide = this.config.multipleDrag ? Math.ceil(movementDistance / (this.selectorWidth / this.perPage)) : 1;
        const howManySliderToSlide = 1;
        if (movement > 0 && movementDistance > this.config.threshold && this.innerElements.length > this.perPage && this.currentSlide - howManySliderToSlide >= 0) {
            this.prev(howManySliderToSlide);
        }
        else if (movement < 0 && movementDistance > this.config.threshold && this.innerElements.length > this.perPage && this.currentSlide + howManySliderToSlide <= this.innerElements.length - this.perPage) {
            this.next(howManySliderToSlide);
        }
        else {
            this.slideToCurrent();
        }
    }
    /**
     * When window resizes, resize slider components as well
     */
    resizeHandler() {
        // update perPage number dependable of user value
        this.resolveSlidesNumber();
        // relcalculate currentSlide
        // prevent hiding items when browser width increases
        if (this.currentSlide + this.perPage > this.innerElements.length) {
            this.currentSlide = this.innerElements.length <= this.perPage ? 0 : this.innerElements.length - this.perPage;
        }
        this.selectorWidth = this.selector.offsetWidth;
        this.buildSliderFrame();
    }
    /**
     * Clear drag after touchend and mouseup event
     */
    clearDrag() {
        this.drag = {
            startX: 0,
            endX: 0,
            startY: 0,
            letItGo: null,
            preventClick: this.drag.preventClick
        };
    }
    /**
     * touchstart event handler
     */
    touchstartHandler(e) {
        // Prevent dragging / swiping on inputs, selects and textareas
        const ignoreSiema = ['TEXTAREA', 'OPTION', 'INPUT', 'SELECT'].indexOf(e.target.nodeName) !== -1;
        if (ignoreSiema) {
            return;
        }
        e.stopPropagation();
        this.pointerDown = true;
        this.drag.startX = e.touches[0].pageX;
        this.drag.startY = e.touches[0].pageY;
    }
    /**
     * touchend event handler
     */
    touchendHandler(e) {
        e.stopPropagation();
        this.pointerDown = false;
        if (this.drag.endX) {
            this.updateAfterDrag();
        }
        this.clearDrag();
    }
    /**
     * touchmove event handler
     */
    touchmoveHandler(e) {
        e.stopPropagation();
        if (this.drag.letItGo === null) {
            this.drag.letItGo = Math.abs(this.drag.startY - e.touches[0].pageY) < Math.abs(this.drag.startX - e.touches[0].pageX);
        }
        if (this.pointerDown && this.drag.letItGo) {
            this.drag.endX = e.touches[0].pageX;
            const currentSlide = this.currentSlide;
            const currentOffset = currentSlide * (this.selectorWidth / this.perPage);
            const dragOffset = (this.drag.endX - this.drag.startX);
            const offset = this.config.rtl ? currentOffset + dragOffset : currentOffset - dragOffset;
            this.sliderFrame.style[this.transformProperty] = `translate3d(${(this.config.rtl ? 1 : -1) * offset}px, 0, 0)`;
        }
    }
    /**
     * Remove item from carousel.
     * @param {number} index - Item index to remove.
     * @param {function} callback - Optional callback to call after remove.
     */
    remove(index, callback) {
        if (index < 0 || index >= this.innerElements.length) {
            throw new Error('Item to remove doesn\'t exist ??');
        }
        // Shift sliderFrame back by one item when:
        // 1. Item with lower index than currenSlide is removed.
        // 2. Last item is removed.
        const lowerIndex = index < this.currentSlide;
        const lastItem = this.currentSlide + this.perPage - 1 === index;
        if (lowerIndex || lastItem) {
            this.currentSlide--;
        }
        this.innerElements.splice(index, 1);
        // build a frame and slide to a currentSlide
        this.buildSliderFrame();
        if (callback) {
            callback.call(this);
        }
    }
    /**
     * Insert item to carousel at particular index.
     * @param {HTMLElement} item - Item to insert.
     * @param {number} index - Index of new new item insertion.
     * @param {function} callback - Optional callback to call after insert.
     */
    insert(item, index, callback) {
        if (index < 0 || index > this.innerElements.length + 1) {
            throw new Error('Unable to inset it at this index ??');
        }
        if (this.innerElements.indexOf(item) !== -1) {
            throw new Error('The same item in a carousel? Really? Nope ??');
        }
        // Avoid shifting content
        const shouldItShift = index <= this.currentSlide > 0 && this.innerElements.length;
        this.currentSlide = shouldItShift ? this.currentSlide + 1 : this.currentSlide;
        this.innerElements.splice(index, 0, item);
        // build a frame and slide to a currentSlide
        this.buildSliderFrame();
        if (callback) {
            callback.call(this);
        }
    }
    /**
     * Prepernd item to carousel.
     * @param {HTMLElement} item - Item to prepend.
     * @param {function} callback - Optional callback to call after prepend.
     */
    prepend(item, callback) {
        this.insert(item, 0);
        if (callback) {
            callback.call(this);
        }
    }
    /**
     * Append item to carousel.
     * @param {HTMLElement} item - Item to append.
     * @param {function} callback - Optional callback to call after append.
     */
    append(item, callback) {
        this.insert(item, this.innerElements.length + 1);
        if (callback) {
            callback.call(this);
        }
    }
    /**
     * Removes listeners and optionally restores to initial markup
     * @param {boolean} restoreMarkup - Determinants about restoring an initial markup.
     * @param {function} callback - Optional callback function.
     */
    destroy(restoreMarkup = false, callback) {
        this.detachEvents();
        this.selector.style.cursor = 'auto';
        if (restoreMarkup) {
            const slides = document.createDocumentFragment();
            for (let i = 0; i < this.innerElements.length; i++) {
                slides.appendChild(this.innerElements[i]);
            }
            this.selector.innerHTML = '';
            this.selector.appendChild(slides);
            this.selector.removeAttribute('style');
        }
        if (callback) {
            callback.call(this);
        }
    }
}

function callUserFunction(f, ...args) {
    if (f)
        setTimeout(() => f(...args), 1);
}
function noop() { }
const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const invFiles = files.slice().reverse();
const ranks = [1, 2, 3, 4, 5, 6, 7, 8];
const invRanks = [8, 7, 6, 5, 4, 3, 2, 1];
// https://gist.github.com/gre/1650294
function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
}
function roundBy(n, by) {
    return Math.round(n * by) / by;
}
function pos2key(pos) {
    return (files[pos[0] - 1] + pos[1]);
}
function key2pos(k) {
    return [k.charCodeAt(0) - 96, k.charCodeAt(1) - 48];
}
function posToTranslate(pos, asWhite, bounds) {
    return [
        (asWhite ? pos[0] - 1 : 8 - pos[0]) * bounds.width / 8,
        (asWhite ? 8 - pos[1] : pos[1] - 1) * bounds.height / 8
    ];
}
const allKeys = Array.prototype.concat(...files.map(c => ranks.map(r => c + r)));
allKeys.slice(0).reverse();
function opposite$1(color) {
    return color === 'white' ? 'black' : 'white';
}
function containsX(xs, x) {
    return xs !== undefined && xs.indexOf(x) !== -1;
}
function distance(pos1, pos2) {
    return Math.sqrt(Math.pow(pos1[0] - pos2[0], 2) + Math.pow(pos1[1] - pos2[1], 2));
}
function transform(state, pieceColor, translateProp) {
    if (state.otb) {
        const o = state.orientation;
        const m = state.otbMode;
        const t = state.turnColor;
        if ((m === 'facing' && o === 'white' && pieceColor === 'black') ||
            (m === 'facing' && o === 'black' && pieceColor === 'white') ||
            (m === 'flip' && o === 'white' && t === 'black') ||
            (m === 'flip' && o === 'black' && t === 'white')) {
            return translateProp + ' rotate(180deg)';
        }
        else {
            return translateProp;
        }
    }
    return translateProp;
}
function translate(coord) {
    return 'translate(' + coord[0] + 'px,' + coord[1] + 'px)';
}
function translate3d(coord) {
    return 'translate3d(' + coord[0] + 'px,' + coord[1] + 'px, 0)';
}
const translateAway = translate([-99999, -99999]);
const translate3dAway = translate3d([-99999, -99999]);
function eventPosition(e) {
    const touch = e.targetTouches[0];
    return [touch.clientX, touch.clientY];
}
function computeSquareBounds(orientation, bounds, key) {
    const pos = key2pos(key);
    if (orientation !== 'white') {
        pos[0] = 9 - pos[0];
        pos[1] = 9 - pos[1];
    }
    return {
        left: bounds.left + bounds.width * (pos[0] - 1) / 8,
        top: bounds.top + bounds.height * (8 - pos[1]) / 8,
        width: bounds.width / 8,
        height: bounds.height / 8
    };
}
function getPieceByKey(dom, key) {
    let el = dom.board.firstChild;
    while (el) {
        if (el.tagName === 'PIECE' && el.cgKey === key)
            return el;
        el = el.nextSibling;
    }
    return null;
}

function diff(a, b) {
    return Math.abs(a - b);
}
function pawn(color) {
    return (x1, y1, x2, y2) => diff(x1, x2) < 2 && (color === 'white' ? (
    // allow 2 squares from 1 and 8, for horde
    y2 === y1 + 1 || (y1 <= 2 && y2 === (y1 + 2) && x1 === x2)) : (y2 === y1 - 1 || (y1 >= 7 && y2 === (y1 - 2) && x1 === x2)));
}
const knight = (x1, y1, x2, y2) => {
    const xd = diff(x1, x2);
    const yd = diff(y1, y2);
    return (xd === 1 && yd === 2) || (xd === 2 && yd === 1);
};
const bishop = (x1, y1, x2, y2) => {
    return diff(x1, x2) === diff(y1, y2);
};
const rook = (x1, y1, x2, y2) => {
    return x1 === x2 || y1 === y2;
};
const queen = (x1, y1, x2, y2) => {
    return bishop(x1, y1, x2, y2) || rook(x1, y1, x2, y2);
};
function king(color, rookFiles, canCastle) {
    return (x1, y1, x2, y2) => (diff(x1, x2) < 2 && diff(y1, y2) < 2) || (canCastle && y1 === y2 && y1 === (color === 'white' ? 1 : 8) && ((x1 === 5 && (x2 === 3 || x2 === 7)) || containsX(rookFiles, x2)));
}
function rookFilesOf(pieces, color) {
    const files = [];
    for (const [k, piece] of pieces) {
        if (piece && piece.color === color && piece.role === 'rook') {
            files.push(key2pos(k)[0]);
        }
    }
    return files;
}
function premove(pieces, key, canCastle) {
    const piece = pieces.get(key);
    if (!piece) {
        return [];
    }
    const pos = key2pos(key);
    let mobility;
    switch (piece.role) {
        case 'pawn':
            mobility = pawn(piece.color);
            break;
        case 'knight':
            mobility = knight;
            break;
        case 'bishop':
            mobility = bishop;
            break;
        case 'rook':
            mobility = rook;
            break;
        case 'queen':
            mobility = queen;
            break;
        case 'king':
            mobility = king(piece.color, rookFilesOf(pieces, piece.color), canCastle);
            break;
    }
    return allKeys.map(key2pos)
        .filter(pos2 => (pos[0] !== pos2[0] || pos[1] !== pos2[1]) && mobility(pos[0], pos[1], pos2[0], pos2[1]))
        .map(pos2key);
}

function toggleOrientation(state) {
    state.orientation = opposite$1(state.orientation);
}
function setPieces(state, pieces) {
    for (const [key, piece] of pieces) {
        if (piece)
            state.pieces.set(key, piece);
        else
            state.pieces.delete(key);
    }
}
function setCheck(state, color) {
    state.check = null;
    if (color === true)
        color = state.turnColor;
    if (color) {
        for (const [k, v] of state.pieces) {
            if (v.role === 'king' && v.color === color) {
                state.check = k;
            }
        }
    }
}
function setPremove(state, orig, dest) {
    unsetPredrop(state);
    state.premovable.current = [orig, dest];
    callUserFunction(state.premovable.events.set, orig, dest);
}
function unsetPremove(state) {
    if (state.premovable.current) {
        state.premovable.current = null;
        callUserFunction(state.premovable.events.unset);
    }
}
function setPredrop(state, role, key) {
    unsetPremove(state);
    state.predroppable.current = {
        role: role,
        key
    };
    callUserFunction(state.predroppable.events.set, role, key);
}
function unsetPredrop(state) {
    if (state.predroppable.current) {
        state.predroppable.current = null;
        callUserFunction(state.predroppable.events.unset);
    }
}
function apiMove(state, orig, dest) {
    return baseMove(state, orig, dest);
}
function apiNewPiece(state, piece, key) {
    return baseNewPiece(state, piece, key);
}
function userMove(state, orig, dest) {
    if (canMove(state, orig, dest)) {
        const result = baseUserMove(state, orig, dest);
        if (result) {
            setSelected(state, null);
            callUserFunction(state.movable.events.after, orig, dest, { premove: false });
            return true;
        }
    }
    else if (canPremove(state, orig, dest)) {
        setPremove(state, orig, dest);
        setSelected(state, null);
    }
    else if (isMovable(state, dest) || isPremovable(state, dest)) {
        setSelected(state, dest);
    }
    else {
        unselect(state);
    }
    return false;
}
function dropNewPiece(state, orig, dest, force = false) {
    const piece = state.pieces.get(orig);
    if (piece && (canDrop(state, orig, dest) || force)) {
        state.pieces.delete(orig);
        baseNewPiece(state, piece, dest, force);
        callUserFunction(state.movable.events.afterNewPiece, piece.role, dest, {
            predrop: false
        });
    }
    else if (piece && canPredrop(state, orig, dest)) {
        setPredrop(state, piece.role, dest);
    }
    else {
        unsetPremove(state);
        unsetPredrop(state);
    }
    state.pieces.delete(orig);
    setSelected(state, null);
}
function selectSquare(state, key) {
    if (state.selected) {
        if (state.selected === key && !state.draggable.enabled) {
            unselect(state);
        }
        else if (state.selectable.enabled && state.selected !== key) {
            userMove(state, state.selected, key);
        }
    }
    else if (isMovable(state, key) || isPremovable(state, key)) {
        setSelected(state, key);
    }
    callUserFunction(state.events.select, key);
}
function setSelected(state, key) {
    state.selected = key;
    if (key && isPremovable(state, key))
        state.premovable.dests = premove(state.pieces, key, state.premovable.castle);
    else
        state.premovable.dests = null;
}
function unselect(state) {
    state.selected = null;
    state.premovable.dests = null;
}
function isMovable(state, orig) {
    const piece = state.pieces.get(orig);
    return !!piece && (state.movable.color === 'both' || (state.movable.color === piece.color &&
        state.turnColor === piece.color));
}
function canMove(state, orig, dest) {
    return orig !== dest && isMovable(state, orig) && (state.movable.free || (state.movable.dests !== null && containsX(state.movable.dests[orig], dest)));
}
function canDrop(state, orig, dest) {
    const piece = state.pieces.get(orig);
    return !!piece && dest && (orig === dest || !state.pieces.has(dest)) && (state.movable.color === 'both' || (state.movable.color === piece.color &&
        state.turnColor === piece.color));
}
function isPremovable(state, orig) {
    const piece = state.pieces.get(orig);
    return !!piece && state.premovable.enabled &&
        state.movable.color === piece.color &&
        state.turnColor !== piece.color;
}
function canPremove(state, orig, dest) {
    return orig !== dest &&
        isPremovable(state, orig) &&
        containsX(premove(state.pieces, orig, state.premovable.castle), dest);
}
function canPredrop(state, orig, dest) {
    const piece = state.pieces.get(orig);
    const destPiece = state.pieces.get(dest);
    return !!piece && dest &&
        (!destPiece || destPiece.color !== state.movable.color) &&
        state.predroppable.enabled &&
        (piece.role !== 'pawn' || (dest[1] !== '1' && dest[1] !== '8')) &&
        state.movable.color === piece.color &&
        state.turnColor !== piece.color;
}
function isDraggable(state, orig) {
    const piece = state.pieces.get(orig);
    return !!piece && state.draggable.enabled && (state.movable.color === 'both' || (state.movable.color === piece.color && (state.turnColor === piece.color || state.premovable.enabled)));
}
function playPremove(state) {
    const move = state.premovable.current;
    if (!move)
        return;
    const orig = move[0], dest = move[1];
    if (canMove(state, orig, dest)) {
        if (baseUserMove(state, orig, dest)) {
            callUserFunction(state.movable.events.after, orig, dest, {
                premove: true
            });
        }
    }
    unsetPremove(state);
}
function playPredrop(state, validate) {
    const drop = state.predroppable.current;
    if (!drop)
        return false;
    let success = false;
    if (validate(drop)) {
        const piece = {
            role: drop.role,
            color: state.movable.color
        };
        if (baseNewPiece(state, piece, drop.key)) {
            callUserFunction(state.movable.events.afterNewPiece, drop.role, drop.key, {
                predrop: true
            });
            success = true;
        }
    }
    unsetPredrop(state);
    return success;
}
function cancelMove(state) {
    unsetPremove(state);
    unsetPredrop(state);
    setSelected(state, null);
}
function stop(state) {
    state.movable.color = null;
    state.movable.dests = {};
    cancelMove(state);
}
function baseMove(state, orig, dest) {
    const origPiece = state.pieces.get(orig);
    if (orig === dest || !origPiece) {
        return false;
    }
    const destPiece = state.pieces.get(dest);
    const captured = (destPiece && destPiece.color !== origPiece.color) ? destPiece : undefined;
    callUserFunction(state.events.move, orig, dest, captured);
    if (!tryAutoCastle(state, orig, dest)) {
        state.pieces.set(dest, origPiece);
        state.pieces.delete(orig);
    }
    state.lastMove = [orig, dest];
    state.check = null;
    callUserFunction(state.events.change);
    return true;
}
function baseNewPiece(state, piece, key, force = false) {
    if (state.pieces.has(key)) {
        if (force)
            state.pieces.delete(key);
        else
            return false;
    }
    callUserFunction(state.events.dropNewPiece, piece, key);
    state.pieces.set(key, piece);
    state.lastMove = [key, key];
    state.check = null;
    callUserFunction(state.events.change);
    state.movable.dests = {};
    state.turnColor = opposite$1(state.turnColor);
    return true;
}
function baseUserMove(state, orig, dest) {
    const result = baseMove(state, orig, dest);
    if (result) {
        state.movable.dests = null;
        state.turnColor = opposite$1(state.turnColor);
        state.animation.current = null;
    }
    return result;
}
function tryAutoCastle(state, orig, dest) {
    if (!state.autoCastle)
        return false;
    const king = state.pieces.get(orig);
    if (!king || king.role !== 'king')
        return false;
    const origPos = key2pos(orig);
    const destPos = key2pos(dest);
    if ((origPos[1] !== 1 && origPos[1] !== 8) || origPos[1] !== destPos[1])
        return false;
    if (origPos[0] === 5 && !state.pieces.has(dest)) {
        if (destPos[0] === 7)
            dest = pos2key([8, destPos[1]]);
        else if (destPos[0] === 3)
            dest = pos2key([1, destPos[1]]);
    }
    const rook = state.pieces.get(dest);
    if (!rook || rook.color !== king.color || rook.role !== 'rook')
        return false;
    state.pieces.delete(orig);
    state.pieces.delete(dest);
    if (origPos[0] < destPos[0]) {
        state.pieces.set(pos2key([7, destPos[1]]), king);
        state.pieces.set(pos2key([6, destPos[1]]), rook);
    }
    else {
        state.pieces.set(pos2key([3, destPos[1]]), king);
        state.pieces.set(pos2key([4, destPos[1]]), rook);
    }
    return true;
}

function makeDefaults() {
    return {
        pieces: new Map(),
        orientation: 'white',
        turnColor: 'white',
        check: null,
        lastMove: null,
        selected: null,
        coordinates: true,
        symmetricCoordinates: false,
        otb: false,
        otbMode: 'facing',
        autoCastle: true,
        viewOnly: false,
        fixed: false,
        exploding: null,
        highlight: {
            lastMove: true,
            check: true
        },
        animation: {
            enabled: true,
            duration: 200,
            current: null
        },
        movable: {
            free: true,
            color: 'both',
            dests: null,
            dropped: null,
            showDests: true,
            rookCastle: true,
            events: {}
        },
        premovable: {
            enabled: true,
            showDests: true,
            castle: true,
            dests: null,
            current: null,
            events: {}
        },
        predroppable: {
            enabled: false,
            current: null,
            events: {}
        },
        draggable: {
            enabled: true,
            distance: 3,
            magnified: true,
            centerPiece: false,
            preventDefault: true,
            showGhost: true,
            deleteOnDropOff: false,
            current: null
        },
        selectable: {
            enabled: true
        },
        events: {},
        prev: {
            orientation: null,
            bounds: null,
            turnColor: null,
            otbMode: null
        }
    };
}

const initial = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';
const roles = {
    p: 'pawn',
    r: 'rook',
    n: 'knight',
    b: 'bishop',
    q: 'queen',
    k: 'king',
    P: 'pawn',
    R: 'rook',
    N: 'knight',
    B: 'bishop',
    Q: 'queen',
    K: 'king'
};
const letters = {
    pawn: 'p',
    rook: 'r',
    knight: 'n',
    bishop: 'b',
    queen: 'q',
    king: 'k'
};
function read(fen) {
    if (fen === 'start')
        fen = initial;
    const pieces = new Map();
    let row = 8;
    let col = 0;
    for (let i = 0; i < fen.length; i++) {
        const c = fen[i];
        switch (c) {
            case ' ': return pieces;
            case '/':
                --row;
                if (row === 0)
                    return pieces;
                col = 0;
                break;
            case '~': {
                const k = pos2key([col, row]);
                const p = pieces.get(k);
                if (p) {
                    p.promoted = true;
                    pieces.set(k, p);
                }
                break;
            }
            default: {
                const nb = ~~c;
                if (nb)
                    col += nb;
                else {
                    ++col;
                    const role = c.toLowerCase();
                    pieces.set(pos2key([col, row]), {
                        role: roles[role],
                        color: (c === role ? 'black' : 'white')
                    });
                }
            }
        }
    }
    return pieces;
}
function write(pieces) {
    return [8, 7, 6, 5, 4, 3, 2].reduce(function (str, nb) {
        return str.replace(new RegExp(Array(nb + 1).join('1'), 'g'), String(nb));
    }, invRanks.map((y) => {
        return ranks.map((x) => {
            const piece = pieces.get(pos2key([x, y]));
            if (piece) {
                const letter = letters[piece.role];
                return piece.color === 'white' ? letter.toUpperCase() : letter;
            }
            else
                return '1';
        }).join('');
    }).join('/'));
}
var cgFen = {
    initial,
    read,
    write
};

function initBoard(cfg) {
    const defaults = makeDefaults();
    configureBoard(defaults, cfg || {});
    return defaults;
}
function configureBoard(state, config) {
    if (!config)
        return;
    // don't merge destinations. Just override.
    if (config.movable && config.movable.dests)
        state.movable.dests = null;
    merge(state, config);
    // if a fen was provided, replace the pieces
    if (config.fen) {
        state.pieces = cgFen.read(config.fen);
    }
    if (Object.prototype.hasOwnProperty.call(config, 'check'))
        setCheck(state, config.check || false);
    if (Object.prototype.hasOwnProperty.call(config, 'lastMove') && !config.lastMove)
        state.lastMove = null;
    // fix move/premove dests
    if (state.selected)
        setSelected(state, state.selected);
    // no need for such short animations
    if (!state.animation.duration || state.animation.duration < 100) {
        state.animation.enabled = false;
    }
    setRookCastle(state);
}
function setNewBoardState(d, config) {
    if (!config)
        return;
    if (config.fen) {
        d.pieces = cgFen.read(config.fen);
    }
    if (config.orientation !== undefined)
        d.orientation = config.orientation;
    if (config.turnColor !== undefined)
        d.turnColor = config.turnColor;
    if (config.dests !== undefined) {
        d.movable.dests = config.dests;
    }
    if (config.movableColor !== undefined) {
        d.movable.color = config.movableColor;
    }
    // set check after setting turn color
    if (Object.prototype.hasOwnProperty.call(config, 'check'))
        setCheck(d, config.check || false);
    if (Object.prototype.hasOwnProperty.call(config, 'lastMove') && !config.lastMove)
        d.lastMove = null;
    else if (config.lastMove)
        d.lastMove = config.lastMove;
    // fix move/premove dests
    if (d.selected) {
        setSelected(d, d.selected);
    }
    setRookCastle(d);
}
function setRookCastle(state) {
    if (!state.movable.rookCastle && state.movable.dests) {
        const rank = state.movable.color === 'white' ? 1 : 8, kingStartPos = 'e' + rank, dests = state.movable.dests[kingStartPos], king = state.pieces.get(kingStartPos);
        if (!dests || !king || king.role !== 'king')
            return;
        state.movable.dests[kingStartPos] = dests.filter(d => !((d === 'a' + rank) && dests.indexOf('c' + rank) !== -1) &&
            !((d === 'h' + rank) && dests.indexOf('g' + rank) !== -1));
    }
}
function merge(base, extend) {
    for (const key in extend) {
        if (isObject(base[key]) && isObject(extend[key]))
            merge(base[key], extend[key]);
        else
            base[key] = extend[key];
    }
}
function isObject(o) {
    return o && typeof o === 'object';
}

/**
 * Board diffing and rendering logic. It runs in 3 main steps:
 *   1. Iterate over all DOM elements under board (pieces and squares).
 *     For each element, flag it either as 'same' if current state objet holds the
 *     same element at this DOM position (using board key as position ID) or as
 *     'moved' otherwise. Flagged elements are kept in sets for next steps.
 *     Apply animation and capture changes if necessary.
 *
 *   2. Iterate over all pieces and square objects from State. For each element,
 *   if it was flagged as 'same', do nothing. Otherwise 2 possibilities:
 *     - an equivalent piece or square is found in the corresponding 'moved' set:
 *     reuse it and apply translation change;
 *     - no dom element found in the 'moved' set: create it and append it to the
 *     board element
 *
 *   3. Delete from the DOM all remaining element in the 'moved' sets.
 *
 * These steps ensure that, for each re-rendering, the smallest number of DOM
 * operations are made.
 */
function renderBoard(d, dom) {
    const boardElement = dom.board;
    const asWhite = d.orientation === 'white';
    const posToTranslate = d.fixed ? posToTranslateRel : posToTranslateAbs(dom.bounds);
    const orientationChange = d.prev.orientation && d.prev.orientation !== d.orientation;
    d.prev.orientation = d.orientation;
    const boundsChange = d.prev.bounds && d.prev.bounds !== dom.bounds;
    d.prev.bounds = dom.bounds;
    const allChange = boundsChange || orientationChange;
    const pieces = d.pieces;
    const anims = d.animation.current && d.animation.current.plan.anims;
    const capturedPieces = d.animation.current && d.animation.current.plan.captured;
    const squares = computeSquareClasses(d);
    const samePieces = new Set();
    const sameSquares = new Set();
    const movedPieces = new Map();
    const movedSquares = new Map();
    let squareClassAtKey, pieceAtKey, anim, captured, translate, elPieceName;
    let mvdset, mvd;
    let otbTurnFlipChange, otbModeChange, otbChange = false;
    if (d.otb) {
        otbTurnFlipChange = d.prev.turnColor && d.prev.turnColor !== d.turnColor;
        otbModeChange = d.prev.otbMode && d.prev.otbMode !== d.otbMode;
        d.prev.otbMode = d.otbMode;
        d.prev.turnColor = d.turnColor;
        otbChange = !!(otbTurnFlipChange || otbModeChange);
    }
    // walk over all board dom elements, apply animations and flag moved pieces
    let el = dom.board.firstChild;
    while (el) {
        const k = el.cgKey;
        if (isPieceNode(el)) {
            pieceAtKey = pieces.get(k);
            squareClassAtKey = squares.get(k);
            anim = anims && anims.get(k);
            captured = capturedPieces && capturedPieces.get(k);
            elPieceName = el.cgPiece;
            // if piece not being dragged anymore, remove dragging style
            if (el.cgDragging && (!d.draggable.current || d.draggable.current.orig !== k)) {
                el.classList.remove('dragging');
                el.classList.remove('magnified');
                translate = posToTranslate(key2pos(k), asWhite);
                positionPiece(d, el, el.cgColor, translate);
                el.cgDragging = false;
            }
            // remove captured class if it still remains
            if (!captured && el.cgCaptured) {
                el.cgCaptured = false;
                el.classList.remove('captured');
            }
            // there is now a piece at this dom key
            if (pieceAtKey) {
                const pieceAtKeyName = pieceNameOf(pieceAtKey);
                // continue animation if already animating and same color
                // (otherwise it could animate a captured piece)
                if (anim && el.cgAnimating && elPieceName === pieceAtKeyName) {
                    translate = posToTranslate(key2pos(k), asWhite);
                    translate[0] += anim[1][0];
                    translate[1] += anim[1][1];
                    el.classList.add('anim');
                    positionPiece(d, el, el.cgColor, translate);
                }
                else if (el.cgAnimating) {
                    translate = posToTranslate(key2pos(k), asWhite);
                    positionPiece(d, el, el.cgColor, translate);
                    el.classList.remove('anim');
                    el.cgAnimating = false;
                }
                // same piece, no change: flag as same
                if (elPieceName === pieceAtKeyName && !allChange && !otbChange && (!captured || !el.cgCaptured)) {
                    samePieces.add(k);
                }
                // different piece: flag as moved unless it is a captured piece
                else {
                    if (captured && pieceNameOf(captured) === elPieceName) {
                        el.classList.add('captured');
                        el.cgCaptured = true;
                    }
                    else {
                        appendValue(movedPieces, elPieceName, el);
                    }
                }
            }
            // no piece: flag as moved
            else {
                appendValue(movedPieces, elPieceName, el);
            }
        }
        else if (isSquareNode(el)) {
            if (!allChange && squareClassAtKey === el.className) {
                sameSquares.add(k);
            }
            else {
                appendValue(movedSquares, el.className, el);
            }
        }
        el = el.nextSibling;
    }
    // walk over all squares in current state object, apply dom changes to moved
    // squares or append new squares
    for (const [k, squareClass] of squares) {
        if (!sameSquares.has(k)) {
            mvdset = movedSquares.get(squareClass);
            mvd = mvdset && mvdset.pop();
            if (mvd) {
                mvd.cgKey = k;
                translate = posToTranslate(key2pos(k), asWhite);
                positionSquare(d, mvd, translate);
            }
            else {
                const se = document.createElement('square');
                se.className = squareClass;
                se.cgKey = k;
                translate = posToTranslate(key2pos(k), asWhite);
                positionSquare(d, se, translate);
                boardElement.insertBefore(se, boardElement.firstChild);
            }
        }
    }
    // walk over all pieces in current state object, apply dom changes to moved
    // pieces or append new pieces
    for (const [k, p] of pieces) {
        const pieceClass = p.role + p.color;
        anim = anims && anims.get(k);
        if (!samePieces.has(k)) {
            mvdset = movedPieces.get(pieceClass);
            mvd = mvdset && mvdset.pop();
            // a equivalent piece was moved
            if (mvd) {
                // apply dom changes
                mvd.cgKey = k;
                translate = posToTranslate(key2pos(k), asWhite);
                if (anim) {
                    mvd.cgAnimating = true;
                    translate[0] += anim[1][0];
                    translate[1] += anim[1][1];
                }
                positionPiece(d, mvd, mvd.cgColor, translate);
            }
            // no piece in moved set: insert the new piece
            else {
                const pe = document.createElement('piece');
                const pName = pieceNameOf(p);
                pe.className = pName;
                pe.cgPiece = pName;
                pe.cgColor = p.color;
                pe.cgKey = k;
                translate = posToTranslate(key2pos(k), asWhite);
                if (anim) {
                    pe.cgAnimating = true;
                    translate[0] += anim[1][0];
                    translate[1] += anim[1][1];
                }
                positionPiece(d, pe, p.color, translate);
                boardElement.appendChild(pe);
            }
        }
    }
    // remove from the board any DOM element that remains in the moved sets
    for (const nodes of movedPieces.values())
        removeNodes(dom, nodes);
    for (const nodes of movedSquares.values())
        removeNodes(dom, nodes);
}
function makeCoords(el, withSymm) {
    const coords = document.createDocumentFragment();
    coords.appendChild(renderCoords(ranks, 'ranks'));
    coords.appendChild(renderCoords(files, 'files' + (withSymm ? ' withSymm' : '')));
    el.appendChild(coords);
}
function makeSymmCoords(el) {
    const coords = document.createDocumentFragment();
    coords.appendChild(renderCoords(invRanks, 'ranks symm'));
    coords.appendChild(renderCoords(invFiles, 'files symm'));
    el.appendChild(coords);
}
function posToTranslateBase(pos, asWhite, xFactor, yFactor) {
    return [
        (asWhite ? pos[0] - 1 : 8 - pos[0]) * xFactor,
        (asWhite ? 8 - pos[1] : pos[1] - 1) * yFactor
    ];
}
const posToTranslateAbs = (bounds) => {
    const xFactor = bounds.width / 8;
    const yFactor = bounds.height / 8;
    return (pos, asWhite) => posToTranslateBase(pos, asWhite, xFactor, yFactor);
};
const posToTranslateRel = (pos, asWhite) => posToTranslateBase(pos, asWhite, 12.5, 12.5);
function positionPiece(d, el, color, pos) {
    if (d.fixed) {
        el.style.left = pos[0] + '%';
        el.style.top = pos[1] + '%';
    }
    else {
        el.style.transform = transform(d, color, translate(pos));
    }
}
function positionSquare(d, el, pos) {
    if (d.fixed) {
        el.style.left = pos[0] + '%';
        el.style.top = pos[1] + '%';
    }
    else {
        el.style.transform = translate(pos);
    }
}
function isPieceNode(el) {
    return el.tagName === 'PIECE';
}
function isSquareNode(el) {
    return el.tagName === 'SQUARE';
}
function pieceNameOf(p) {
    return p.role + ' ' + p.color;
}
function removeNodes(dom, nodes) {
    for (const node of nodes)
        dom.board.removeChild(node);
}
function appendValue(map, key, value) {
    const arr = map.get(key);
    if (arr)
        arr.push(value);
    else
        map.set(key, [value]);
}
function addSquare(squares, key, klass) {
    squares.set(key, (squares.get(key) || '') + ' ' + klass);
}
function computeSquareClasses(d) {
    const squares = new Map();
    if (d.lastMove && d.highlight.lastMove) {
        addSquare(squares, d.lastMove[0], 'last-move');
        addSquare(squares, d.lastMove[1], 'last-move');
    }
    if (d.check && d.highlight.check)
        addSquare(squares, d.check, 'check');
    if (d.selected) {
        addSquare(squares, d.selected, 'selected');
        if (d.movable.showDests) {
            const dests = d.movable.dests && d.movable.dests[d.selected];
            if (dests) {
                for (let i = 0, len = dests.length; i < len; i++) {
                    const k = dests[i];
                    addSquare(squares, k, 'move-dest' + (d.pieces.has(k) ? ' occupied' : ''));
                }
            }
            const pDests = d.premovable.dests;
            if (pDests) {
                for (let j = 0, len = pDests.length; j < len; j++) {
                    const k = pDests[j];
                    addSquare(squares, k, 'premove-dest' + (d.pieces.has(k) ? ' occupied' : ''));
                }
            }
        }
    }
    const premove = d.premovable.current;
    if (premove) {
        addSquare(squares, premove[0], 'current-premove');
        addSquare(squares, premove[1], 'current-premove');
    }
    if (d.exploding) {
        for (const k of d.exploding.keys) {
            addSquare(squares, k, 'exploding' + d.exploding.stage);
        }
    }
    return squares;
}
function renderCoords(elems, klass) {
    const el = document.createElement('li-coords');
    el.className = klass;
    elems.forEach((content, i) => {
        const f = document.createElement('li-coord');
        f.className = i % 2 === 0 ? 'coord-odd' : 'coord-even';
        f.textContent = String(content);
        el.appendChild(f);
    });
    return el;
}

function anim(mutation, ctrl) {
    return ctrl.state.animation.enabled ? animate(mutation, ctrl) : skip(mutation, ctrl);
}
function skip(mutation, ctrl) {
    const result = mutation(ctrl.state);
    ctrl.redraw();
    return result;
}
function makePiece$1(key, piece) {
    return {
        key,
        pos: key2pos(key),
        piece
    };
}
function samePiece(p1, p2) {
    return p1.role === p2.role && p1.color === p2.color;
}
function closer(piece, pieces) {
    return pieces.sort((p1, p2) => {
        return distance(piece.pos, p1.pos) - distance(piece.pos, p2.pos);
    })[0];
}
function computePlan(prevPieces, state, dom) {
    const bounds = dom.bounds, width = bounds.width / 8, height = bounds.height / 8, anims = new Map(), animedOrigs = [], capturedPieces = new Map(), missings = [], news = [], prePieces = new Map(), white = state.orientation === 'white';
    for (const [k, p] of prevPieces) {
        prePieces.set(k, makePiece$1(k, p));
    }
    for (let i = 0, ilen = allKeys.length; i < ilen; i++) {
        const key = allKeys[i];
        const curP = state.pieces.get(key);
        const preP = prePieces.get(key);
        if (curP) {
            if (preP) {
                if (!samePiece(curP, preP.piece)) {
                    missings.push(preP);
                    news.push(makePiece$1(key, curP));
                }
            }
            else {
                news.push(makePiece$1(key, curP));
            }
        }
        else if (preP) {
            missings.push(preP);
        }
    }
    for (const newP of news) {
        const nPreP = closer(newP, missings.filter((p) => samePiece(newP.piece, p.piece)));
        if (nPreP) {
            const orig = white ? nPreP.pos : newP.pos;
            const dest = white ? newP.pos : nPreP.pos;
            const pos = [(orig[0] - dest[0]) * width, (dest[1] - orig[1]) * height];
            anims.set(newP.key, [pos, pos]);
            animedOrigs.push(nPreP.key);
        }
    }
    for (const p of missings) {
        if (!containsX(animedOrigs, p.key)) {
            capturedPieces.set(p.key, p.piece);
        }
    }
    return {
        anims,
        captured: capturedPieces
    };
}
function animate(mutation, ctrl) {
    const state = ctrl.state;
    // clone state before mutating it
    const prevPieces = new Map(state.pieces);
    const result = mutation(state);
    const plan = ctrl.dom !== undefined ?
        computePlan(prevPieces, state, ctrl.dom) : undefined;
    if (plan !== undefined && (plan.anims.size || plan.captured.size)) {
        const alreadyRunning = state.animation.current && state.animation.current.start !== null;
        state.animation.current = {
            start: null,
            duration: state.animation.duration,
            plan
        };
        if (!alreadyRunning) {
            batchRequestAnimationFrame(ctrl.applyAnim);
        }
    }
    else {
        ctrl.redraw();
    }
    return result;
}

function dragNewPiece(ctrl, piece, e, force) {
    const key = 'a0';
    const s = ctrl.state;
    const dom = ctrl.dom;
    s.pieces.set(key, piece);
    // we need the new piece to be in DOM immediately
    ctrl.redrawSync();
    const position = eventPosition(e);
    const asWhite = s.orientation === 'white';
    const bounds = dom.bounds;
    const squareBounds = computeSquareBounds(s.orientation, bounds, key);
    const rel = [
        (asWhite ? 0 : 7) * squareBounds.width + bounds.left,
        (asWhite ? 8 : -1) * squareBounds.height + bounds.top
    ];
    s.draggable.current = {
        orig: key,
        origPos: key2pos(key),
        piece,
        rel,
        epos: position,
        pos: [position[0] - rel[0], position[1] - rel[1]],
        dec: s.draggable.magnified ?
            [-squareBounds.width, -squareBounds.height * 2] :
            [-squareBounds.width / 2, -squareBounds.height / 2],
        over: null,
        prevOver: null,
        started: true,
        element: getPieceByKey(dom, key),
        originTarget: e.target,
        previouslySelected: null,
        newPiece: true,
        force: force || false,
        showGhost: false
    };
    processDrag(ctrl);
}
function start(ctrl, e) {
    // support one finger touch only
    if (!e.isTrusted || (e.touches && e.touches.length > 1))
        return;
    e.preventDefault();
    const state = ctrl.state;
    const dom = ctrl.dom;
    const bounds = dom.bounds;
    const position = eventPosition(e);
    const orig = getKeyAtDomPos(state, position, bounds);
    if (!orig)
        return;
    const previouslySelected = state.selected;
    const hadPremove = !!state.premovable.current;
    const hadPredrop = !!state.predroppable.current;
    if (state.selected && canMove(state, state.selected, orig)) {
        anim(s => selectSquare(s, orig), ctrl);
    }
    else {
        selectSquare(state, orig);
    }
    const stillSelected = state.selected === orig;
    const origPiece = state.pieces.get(orig);
    if (origPiece && stillSelected && isDraggable(state, orig)) {
        const squareBounds = computeSquareBounds(state.orientation, bounds, orig);
        const origPos = key2pos(orig);
        state.draggable.current = {
            previouslySelected,
            orig,
            piece: origPiece,
            rel: position,
            epos: position,
            pos: [0, 0],
            origPos,
            dec: state.draggable.magnified ? [
                position[0] - (squareBounds.left + squareBounds.width),
                position[1] - (squareBounds.top + squareBounds.height * 2)
            ] : [
                position[0] - (squareBounds.left + squareBounds.width / 2),
                position[1] - (squareBounds.top + squareBounds.height / 2)
            ],
            // auto start drag if we're in drag'n drop only mode
            started: state.selectable.enabled === false,
            over: orig,
            prevOver: null,
            element: getPieceByKey(dom, orig),
            originTarget: e.target,
            showGhost: state.draggable.showGhost,
            scheduledAnimationFrame: false
        };
        if (state.draggable.magnified && state.draggable.centerPiece) {
            state.draggable.current.dec[1] = position[1] - (squareBounds.top + squareBounds.height);
        }
        if (state.draggable.current.started) {
            processDrag(ctrl);
        }
    }
    else {
        if (hadPremove)
            unsetPremove(state);
        if (hadPredrop)
            unsetPredrop(state);
    }
    ctrl.redraw();
}
function move(ctrl, e) {
    if (e.touches && e.touches.length > 1)
        return;
    const state = ctrl.state;
    if (state.draggable.preventDefault)
        e.preventDefault();
    const cur = state.draggable.current;
    if (!cur)
        return;
    if (cur.orig) {
        cur.epos = eventPosition(e);
        if (!cur.started && distance(cur.epos, cur.rel) >= state.draggable.distance) {
            cur.started = true;
            processDrag(ctrl);
        }
    }
}
function end(ctrl, e) {
    const state = ctrl.state;
    const draggable = state.draggable;
    const cur = draggable.current;
    if (!cur)
        return;
    // we don't want that end event since the target is different from the drag
    // touchstart
    if (cur.originTarget !== e.target && !cur.newPiece) {
        return;
    }
    if (state.draggable.preventDefault) {
        e.preventDefault();
    }
    const dest = cur.over;
    unsetPremove(state);
    unsetPredrop(state);
    // regular drag'n drop move (or crazy drop)
    if (cur.started && dest) {
        if (cur.newPiece) {
            dropNewPiece(state, cur.orig, dest, cur.force);
        }
        else {
            userMove(state, cur.orig, dest);
        }
    }
    // board editor mode: delete any piece dropped off the board
    else if (cur.started && draggable.deleteOnDropOff) {
        state.pieces.delete(cur.orig);
        setTimeout(state.events.change || noop, 0);
    }
    // crazy invalid drop (no dest): delete the piece
    else if (cur.newPiece) {
        state.pieces.delete(cur.orig);
    }
    if (cur && cur.orig === cur.previouslySelected && (cur.orig === dest || !dest)) {
        unselect(state);
    }
    else if (!state.selectable.enabled) {
        unselect(state);
    }
    state.draggable.current = null;
    // must perform it in same raf callback or browser may skip it
    batchRequestAnimationFrame(() => removeDragElements(ctrl.dom));
    ctrl.redraw();
}
function cancel(ctrl) {
    const state = ctrl.state;
    if (ctrl.dom)
        removeDragElements(ctrl.dom);
    if (state.draggable.current) {
        state.draggable.current = null;
        unselect(state);
    }
}
function getKeyAtDomPos(state, pos, bounds) {
    if (typeof bounds !== 'object') {
        throw new Error('function getKeyAtDomPos require bounds object arg');
    }
    const asWhite = state.orientation === 'white';
    const x = Math.ceil(8 * ((pos[0] - bounds.left) / bounds.width));
    const ox = (asWhite ? x : 9 - x);
    const y = Math.ceil(8 - (8 * ((pos[1] - bounds.top) / bounds.height)));
    const oy = (asWhite ? y : 9 - y);
    if (ox > 0 && ox < 9 && oy > 0 && oy < 9) {
        return pos2key([ox, oy]);
    }
    return null;
}
function processDrag(ctrl) {
    const state = ctrl.state;
    const dom = ctrl.dom;
    const cur = state.draggable.current;
    if (!cur)
        return;
    if (cur.scheduledAnimationFrame)
        return;
    cur.scheduledAnimationFrame = true;
    requestAnimationFrame(() => {
        const bounds = dom.bounds;
        const asWhite = state.orientation === 'white';
        cur.scheduledAnimationFrame = false;
        if (cur.orig) {
            // if moving piece is gone, cancel
            if (state.pieces.get(cur.orig) !== cur.piece) {
                cancel(ctrl);
                return;
            }
            // cancel animations while dragging
            if (state.animation.current && state.animation.current.plan.anims.get(cur.orig)) {
                state.animation.current = null;
            }
            const pieceEl = cur.element;
            if (cur.started && pieceEl) {
                if (!pieceEl.cgDragging) {
                    pieceEl.cgDragging = true;
                    pieceEl.classList.add('dragging');
                    if (state.draggable.magnified) {
                        pieceEl.classList.add('magnified');
                    }
                    const ghost = dom.elements.ghost;
                    if (ghost && cur.showGhost) {
                        ghost.className = `ghost ${cur.piece.color} ${cur.piece.role}`;
                        const translation = posToTranslate(key2pos(cur.orig), state.orientation === 'white', bounds);
                        ghost.style.transform = transform(state, cur.piece.color, translate(translation));
                    }
                }
                cur.pos = [
                    cur.epos[0] - cur.rel[0],
                    cur.epos[1] - cur.rel[1]
                ];
                cur.over = getKeyAtDomPos(state, cur.epos, bounds);
                // move piece
                const translate$1 = posToTranslate(cur.origPos, asWhite, bounds);
                translate$1[0] += cur.pos[0] + cur.dec[0];
                translate$1[1] += cur.pos[1] + cur.dec[1];
                pieceEl.style.transform = transform(state, cur.piece.color, translate3d(translate$1));
                // move square target
                const shadow = dom.elements.shadow;
                if (shadow) {
                    if (cur.over && cur.over !== cur.prevOver) {
                        const sqSize = bounds.width / 8;
                        const pos = key2pos(cur.over);
                        const translate = posToTranslate(pos, asWhite, bounds);
                        shadow.style.transform = translate3d([
                            translate[0] - sqSize / 2,
                            translate[1] - sqSize / 2
                        ]);
                    }
                    else if (!cur.over) {
                        shadow.style.transform = translate3dAway;
                    }
                    cur.prevOver = cur.over;
                }
            }
            processDrag(ctrl);
        }
    });
}
function removeDragElements(dom) {
    if (dom.elements.shadow) {
        dom.elements.shadow.style.transform = translate3dAway;
    }
    if (dom.elements.ghost) {
        dom.elements.ghost.style.transform = translateAway;
    }
}

const pieceScores = {
    pawn: 1,
    knight: 3,
    bishop: 3,
    rook: 5,
    queen: 9,
    king: 0
};
class Chessground {
    constructor(cfg) {
        this.detach = () => {
            this.dom = undefined;
            window.removeEventListener('resize', this.onOrientationChange);
        };
        this.applyAnim = (now) => {
            const state = this.state;
            const cur = state.animation.current;
            // animation was cancelled
            if (cur === null) {
                this.redrawSync();
                return;
            }
            if (cur.start === null)
                cur.start = now;
            const rest = 1 - (now - cur.start) / cur.duration;
            if (rest <= 0) {
                state.animation.current = null;
                this.redrawSync();
            }
            else {
                const ease = easeInOutCubic(rest);
                for (const vector of cur.plan.anims.values()) {
                    vector[1] = [
                        roundBy(vector[0][0] * ease, 10),
                        roundBy(vector[0][1] * ease, 10)
                    ];
                }
                this.redrawSync();
                batchRequestAnimationFrame(this.applyAnim);
            }
        };
        this.setBounds = (bounds) => {
            if (this.dom)
                this.dom.bounds = bounds;
        };
        this.redrawSync = () => {
            if (this.dom)
                renderBoard(this.state, this.dom);
        };
        this.redraw = () => {
            batchRequestAnimationFrame(this.redrawSync);
        };
        this.getFen = () => {
            return cgFen.write(this.state.pieces);
        };
        this.toggleOrientation = () => {
            anim(toggleOrientation, this);
        };
        this.playPremove = () => {
            if (this.state.premovable.current) {
                // eslint-disable-next-line no-extra-boolean-cast
                if (Boolean(anim(playPremove, this)))
                    return true;
                // if the premove couldn't be played, redraw to clear it up
                this.redraw();
            }
            return false;
        };
        this.playPredrop = (validate) => {
            if (this.state.predroppable.current) {
                const result = playPredrop(this.state, validate);
                this.redraw();
                return result;
            }
            return false;
        };
        this.cancelPremove = () => {
            skip(unsetPremove, this);
        };
        this.cancelPredrop = () => {
            skip(unsetPredrop, this);
        };
        this.setCheck = (a) => {
            skip(state => setCheck(state, a), this);
        };
        this.cancelMove = () => {
            cancel(this);
            skip(state => cancelMove(state), this);
        };
        this.stop = () => {
            cancel(this);
            skip(state => stop(state), this);
        };
        this.explode = (keys) => {
            if (!this.dom)
                return;
            this.state.exploding = {
                stage: 1,
                keys: keys
            };
            this.redraw();
            setTimeout(() => {
                if (this.state.exploding) {
                    this.state.exploding.stage = 2;
                    this.redraw();
                }
                setTimeout(() => {
                    this.state.exploding = null;
                    this.redraw();
                }, 120);
            }, 120);
        };
        this.onOrientationChange = () => {
            const dom = this.dom;
            if (dom) {
                // yolo
                requestAnimationFrame(() => {
                    dom.bounds = dom.board.getBoundingClientRect();
                    this.redraw();
                });
            }
        };
        this.state = initBoard(cfg);
    }
    attach(wrapper, bounds) {
        const isViewOnly = this.state.fixed || this.state.viewOnly;
        const board = document.createElement('div');
        board.className = 'cg-board';
        if (isViewOnly)
            board.className += ' view-only';
        else
            board.className += ' manipulable';
        wrapper.appendChild(board);
        this.dom = {
            board,
            elements: {},
            bounds
        };
        this.redrawSync();
        if (!isViewOnly) {
            const shadow = document.createElement('div');
            shadow.className = 'cg-square-target';
            shadow.style.transform = translate3dAway;
            wrapper.appendChild(shadow);
            this.dom.elements.shadow = shadow;
        }
        if (!isViewOnly && this.state.draggable.showGhost) {
            const ghost = document.createElement('piece');
            ghost.className = 'ghost';
            ghost.style.transform = translateAway;
            wrapper.appendChild(ghost);
            this.dom.elements.ghost = ghost;
        }
        if (this.state.coordinates) {
            makeCoords((wrapper), !!this.state.symmetricCoordinates);
            if (this.state.symmetricCoordinates) {
                makeSymmCoords(wrapper);
            }
        }
        if (!isViewOnly) {
            board.addEventListener('touchstart', (e) => start(this, e));
            board.addEventListener('touchmove', (e) => move(this, e));
            board.addEventListener('touchend', (e) => end(this, e));
            board.addEventListener('touchcancel', () => cancel(this));
        }
        window.addEventListener('resize', this.onOrientationChange);
    }
    getMaterialDiff() {
        let score = 0;
        const counts = {
            king: 0,
            queen: 0,
            rook: 0,
            bishop: 0,
            knight: 0,
            pawn: 0
        };
        for (const p of this.state.pieces.values()) {
            counts[p.role] += (p.color === 'white') ? 1 : -1;
            score += pieceScores[p.role] * (p.color === 'white' ? 1 : -1);
        }
        const diff = {
            white: { pieces: {}, score: score },
            black: { pieces: {}, score: -score }
        };
        for (const role in counts) {
            const c = counts[role];
            if (c > 0)
                diff.white.pieces[role] = c;
            else if (c < 0)
                diff.black.pieces[role] = -c;
        }
        return diff;
    }
    set(config) {
        anim(state => setNewBoardState(state, config), this);
    }
    reconfigure(config) {
        anim(state => configureBoard(state, config), this);
    }
    setOtbMode(mode) {
        anim(state => {
            state.otbMode = mode;
        }, this);
    }
    setPieces(pieces) {
        anim(state => setPieces(state, pieces), this);
    }
    promote(key, role) {
        const diff = new Map();
        const piece = this.state.pieces.get(key);
        if (piece && piece.role === 'pawn') {
            diff.set(key, {
                color: piece.color,
                role: role
            });
            this.setPieces(diff);
        }
    }
    dragNewPiece(e, piece, force = false) {
        dragNewPiece(this, piece, e, force);
    }
    selectSquare(key) {
        if (key)
            anim(state => selectSquare(state, key), this);
        else if (this.state.selected) {
            unselect(this.state);
            this.redraw();
        }
    }
    apiMove(orig, dest, pieces, config) {
        anim(state => {
            apiMove(state, orig, dest);
            if (pieces) {
                setPieces(state, pieces);
            }
            if (config) {
                setNewBoardState(state, config);
            }
        }, this);
    }
    apiNewPiece(piece, key, config) {
        anim(state => {
            apiNewPiece(state, piece, key);
            if (config) {
                setNewBoardState(state, config);
            }
        }, this);
    }
}

const uciRoleMap = {
    P: 'pawn',
    B: 'bishop',
    N: 'knight',
    R: 'rook',
    Q: 'queen',
    p: 'pawn',
    b: 'bishop',
    n: 'knight',
    r: 'rook',
    q: 'queen',
};
const sanToRole = {
    P: 'pawn',
    N: 'knight',
    B: 'bishop',
    R: 'rook',
    Q: 'queen'
};
const altCastles = {
    e1a1: 'e1c1',
    e1h1: 'e1g1',
    e8a8: 'e8c8',
    e8h8: 'e8g8'
};
function uciToMove(uci) {
    return [uci.substr(0, 2), uci.substr(2, 2)];
}
function uciToMoveOrDrop(uci) {
    if (uci[1] === '@')
        return [uci.substr(2, 2), uci.substr(2, 2)];
    return [uci.substr(0, 2), uci.substr(2, 2)];
}
function uciToProm(uci) {
    const p = uci.substr(4, 1);
    return uciRoleMap[p];
}
function uciToDropPos(uci) {
    return uci.substr(2, 2);
}
function uciToDropRole(uci) {
    return uciRoleMap[uci.substr(0, 1)];
}
function uciTolastDrop(uci) {
    return [uci.substr(2, 2), uci.substr(2, 2)];
}
function fixCrazySan(san) {
    return san[0] === 'P' ? san.slice(1) : san;
}
function decomposeUci(uci) {
    return [uci.slice(0, 2), uci.slice(2, 4), uci.slice(4, 5)];
}
function isString(o) {
    return typeof o === 'string';
}
function isDestMap(o) {
    return isObject$1(o);
}
function readDests(lines) {
    if (lines === undefined)
        return null;
    if (isDestMap(lines))
        return lines;
    const dests = {};
    if (lines && isString(lines))
        lines.split(' ').forEach(line => {
            dests[piotr2key[line[0]]] = line.split('').slice(1).map(c => piotr2key[c]);
        });
    return dests;
}
const piotr2key = {
    'a': 'a1',
    'b': 'b1',
    'c': 'c1',
    'd': 'd1',
    'e': 'e1',
    'f': 'f1',
    'g': 'g1',
    'h': 'h1',
    'i': 'a2',
    'j': 'b2',
    'k': 'c2',
    'l': 'd2',
    'm': 'e2',
    'n': 'f2',
    'o': 'g2',
    'p': 'h2',
    'q': 'a3',
    'r': 'b3',
    's': 'c3',
    't': 'd3',
    'u': 'e3',
    'v': 'f3',
    'w': 'g3',
    'x': 'h3',
    'y': 'a4',
    'z': 'b4',
    'A': 'c4',
    'B': 'd4',
    'C': 'e4',
    'D': 'f4',
    'E': 'g4',
    'F': 'h4',
    'G': 'a5',
    'H': 'b5',
    'I': 'c5',
    'J': 'd5',
    'K': 'e5',
    'L': 'f5',
    'M': 'g5',
    'N': 'h5',
    'O': 'a6',
    'P': 'b6',
    'Q': 'c6',
    'R': 'd6',
    'S': 'e6',
    'T': 'f6',
    'U': 'g6',
    'V': 'h6',
    'W': 'a7',
    'X': 'b7',
    'Y': 'c7',
    'Z': 'd7',
    '0': 'e7',
    '1': 'f7',
    '2': 'g7',
    '3': 'h7',
    '4': 'a8',
    '5': 'b8',
    '6': 'c8',
    '7': 'd8',
    '8': 'e8',
    '9': 'f8',
    '!': 'g8',
    '?': 'h8'
};

const ViewOnlyBoard = {
    oninit({ attrs }) {
        this.pieceTheme = settings.general.theme.piece();
        this.boardTheme = settings.general.theme.board();
        this.ground = new Chessground(makeConfig(attrs));
    },
    oncreate({ attrs, dom }) {
        const bounds = attrs.fixed ? {
            // dummy bounds since fixed board doesn't use bounds
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            height: 0,
            width: 0
        } : dom.getBoundingClientRect();
        if (attrs.delay !== undefined) {
            setTimeout(() => {
                this.ground.attach(dom, bounds);
            }, attrs.delay);
        }
        else {
            this.ground.attach(dom, bounds);
        }
    },
    onbeforeupdate({ attrs }, { attrs: oldattrs }) {
        if (attrs.fen !== oldattrs.fen ||
            attrs.lastMove !== oldattrs.lastMove ||
            attrs.orientation !== oldattrs.orientation) {
            return true;
        }
        else
            return false;
    },
    onupdate({ attrs }) {
        this.ground.set({
            ...attrs,
            lastMove: attrs.lastMove ? uciToMove(attrs.lastMove) : undefined
        });
    },
    onremove() {
        this.ground.detach();
    },
    view({ attrs }) {
        const boardClass = [
            'display_board',
            attrs.customPieceTheme || this.pieceTheme,
            `board-${this.boardTheme}`,
            attrs.variant || 'standard'
        ].join(' ');
        return h('div', { className: boardClass });
    }
};
function makeConfig({ fen, lastMove, orientation, fixed = true }) {
    const conf = {
        batchRAF: batchRequestAnimationFrame,
        viewOnly: true,
        fixed,
        minimalDom: true,
        coordinates: false,
        fen,
        lastMove: lastMove ? uciToMove(lastMove) : null,
        orientation: orientation || 'white'
    };
    return conf;
}

let scroller = null;
let isOpen$5 = false;
let lastJoined;
var gamesMenu = {
    lastJoined() {
        return lastJoined;
    },
    resetLastJoined() {
        lastJoined = undefined;
    },
    open: open$5,
    close: close$5,
    view() {
        if (!isOpen$5)
            return null;
        return h('div#games_menu.overlay_popup_wrapper', {
            onbeforeremove: menuOnBeforeRemove
        }, h.fragment({ key: isPortrait() ? 'portrait' : 'landscape' }, [
            h('div.wrapper_overlay_close', { oncreate: menuOnOverlayTap }),
            renderDotsWrapper(),
            h('div#wrapper_games', renderAllGames()),
        ]));
    }
};
const menuOnOverlayTap = ontap(() => close$5());
function menuOnBeforeRemove({ dom }) {
    dom.classList.add('fading_out');
    return new Promise((resolve) => {
        setTimeout(resolve, 500);
    });
}
let cardChangeTimeoutId;
function wrapperOnCreate({ dom }) {
    if (isPortrait()) {
        scroller = new Siema({
            selector: dom,
            duration: 250,
            loop: false,
            perPage: isTablet() ? 2 : 1,
            startIndex: 0,
            threshold: 50, // TODO adapt depending on screen size
            draggable: true,
            onChange: () => {
                clearTimeout(cardChangeTimeoutId);
                cardChangeTimeoutId = setTimeout(() => {
                    batchRequestAnimationFrame(redrawDots);
                }, 300);
            },
        });
        batchRequestAnimationFrame(redrawDots);
        redraw();
    }
}
function wrapperOnRemove() {
    if (scroller) {
        scroller.destroy();
        scroller = null;
    }
}
function open$5(page) {
    router$1.backbutton.stack.push(close$5);
    session$1.refresh();
    isOpen$5 = true;
    setTimeout(() => {
        if (scroller && !isTablet()) {
            scroller.goTo(page !== undefined ? page : 0);
        }
    }, 500);
}
function close$5(fromBB) {
    if (fromBB !== 'backbutton' && isOpen$5)
        router$1.backbutton.stack.pop();
    isOpen$5 = false;
}
function joinGame(g) {
    lastJoined = g;
    positionsCache.set(g.fullId, { fen: g.fen, orientation: g.color });
    close$5();
    router$1.set('/game/' + g.fullId);
}
function acceptChallenge(id) {
    return acceptChallenge$1(id)
        .then(data => {
        router$1.set('/game' + data.url.round);
    })
        .then(() => challengesApi.remove(id))
        .then(() => close$5());
}
function cancelChallenge(id) {
    return cancelChallenge$1(id)
        .then(() => {
        challengesApi.remove(id);
    });
}
function declineChallenge(id) {
    return declineChallenge$1(id)
        .then(() => {
        challengesApi.remove(id);
    });
}
function renderViewOnlyBoard(fen, orientation, lastMove, variant) {
    return h('div.boardWrapper', h(ViewOnlyBoard, { fen, lastMove, orientation, variant }));
}
function timeLeft(g) {
    if (!g.isMyTurn)
        return i18n('waitingForOpponent');
    if (!g.secondsLeft)
        return i18n('yourTurn');
    return h('time', {}, fromNow(addSeconds(new Date(), g.secondsLeft)));
}
function renderGame(g) {
    const icon = g.opponent.ai ? 'n' : gameIcon(g.perf);
    const playerName$1 = playerName(g.opponent, false);
    const cardClass = [
        'card',
        'standard',
        g.color
    ].join(' ');
    const timeClass = [
        'timeIndication',
        g.isMyTurn ? 'myTurn' : 'opponentTurn'
    ].join(' ');
    return h('div', {
        className: cardClass,
        key: 'game.' + g.gameId,
        oncreate: ontapXY(() => joinGame(g)),
    }, [
        renderViewOnlyBoard(g.fen, g.color, g.lastMove, g.variant.key),
        h('div.infos', [
            h('div.icon-game', { 'data-icon': icon || '' }),
            h('div.description', [
                h('h2.title', playerName$1),
                h('p', [
                    h('span.variant', g.variant.name),
                    h('span', { className: timeClass }, timeLeft(g))
                ])
            ])
        ])
    ]);
}
function renderIncomingChallenge(c) {
    if (!c.challenger) {
        return null;
    }
    const mode = c.rated ? i18n('rated') : i18n('casual');
    const mark = c.challenger.provisional ? '?' : '';
    const playerName = `${c.challenger.id} (${c.challenger.rating}${mark})`;
    return h('div.card.standard.challenge', {
        key: 'incoming.' + c.id,
    }, [
        renderViewOnlyBoard(c.initialFen || standardFen, 'white', undefined, c.variant.key),
        h('div.infos', [
            h('div.icon-game', { 'data-icon': gameIcon(c.speed) }),
            h('div.description', [
                h('h2.title', i18n('playerisInvitingYou', playerName)),
                h('p.variant', [
                    h('span.time-indication[data-icon=p]', challengesApi.challengeTime(c)),
                    ' • ',
                    h('span.variantName', c.variant.name),
                    ' • ',
                    h('span', mode),
                ])
            ]),
            h('div.actions', [
                h('button', { oncreate: ontapX(() => acceptChallenge(c.id)) }, i18n('accept')),
                h('button', {
                    oncreate: ontapX((e) => declineChallenge(c.id).then(() => {
                        fadesOut(e, () => close$5(), '.card', 250);
                    }))
                }, i18n('decline'))
            ])
        ])
    ]);
}
function renderSendingChallenge(c) {
    const mode = c.rated ? i18n('rated') : i18n('casual');
    function playerName(destUser) {
        const mark = destUser.provisional ? '?' : '';
        return `${destUser.id} (${destUser.rating}${mark})`;
    }
    return h('div.card.standard.challenge.sending', {
        key: 'sending.' + c.id,
    }, [
        renderViewOnlyBoard(c.initialFen || standardFen, 'white', undefined, c.variant.key),
        h('div.infos', [
            h('div.icon-game', { 'data-icon': gameIcon(c.speed) }),
            h('div.description', [
                h('h2.title', c.destUser ? playerName(c.destUser) : 'Open challenge'),
                h('p.variant', [
                    h('span.time-indication[data-icon=p]', challengesApi.challengeTime(c)),
                    ' • ',
                    h('span.variantName', c.variant.name),
                    ' • ',
                    h('span', mode),
                ]),
            ]),
            h('div.actions', [
                c.destUser ? null : h('button', {
                    oncreate: ontapX(() => {
                        close$5();
                        router$1.set(`/game/${c.id}`);
                    })
                }, i18n('viewInFullSize')),
                h('button', {
                    oncreate: ontapX((e) => cancelChallenge(c.id).then(() => {
                        fadesOut(e, () => close$5(), '.card', 250);
                    }))
                }, i18n('cancel')),
            ])
        ])
    ]);
}
function renderDotsWrapper() {
    if (isPortrait()) {
        return h('div.#games_menu__dots');
    }
    return null;
}
function redrawDots() {
    if (isPortrait() && scroller) {
        const elsNb = isTablet() ?
            Math.ceil(scroller.innerElements.length / 2) :
            scroller.innerElements.length;
        const wrapper = document.getElementById('games_menu__dots');
        if (wrapper) {
            const dotsNb = wrapper.childElementCount;
            const diff = elsNb - dotsNb;
            if (diff !== 0) {
                for (let i = 0, len = Math.abs(diff); i < len; i++) {
                    if (diff > 0) {
                        const dot = document.createElement('i');
                        dot.className = 'dot';
                        wrapper.appendChild(dot);
                    }
                    else {
                        const child = wrapper.firstChild;
                        if (child) {
                            wrapper.removeChild(child);
                        }
                    }
                }
            }
            const nodeList = wrapper.childNodes;
            for (let i = 0; i < nodeList.length; i++) {
                const dot = nodeList[i];
                if (i === scroller.currentSlide) {
                    dot.className = 'dot current';
                }
                else {
                    dot.className = 'dot';
                }
            }
        }
    }
}
function renderAllGames() {
    const nowPlaying = session$1.nowPlaying();
    const challenges = challengesApi.incoming();
    const sendingChallenges = challengesApi.sending().filter(challengesApi.isPersistent);
    const challengesDom = challenges.map(c => renderIncomingChallenge(c)).filter(noNull);
    const sendingChallengesDom = sendingChallenges.map(c => renderSendingChallenge(c));
    const allCards = [
        ...challengesDom,
        ...(nowPlaying.map(g => renderGame(g))),
        ...sendingChallengesDom,
    ];
    return h('div.games_carousel', {
        oncreate: wrapperOnCreate,
        onremove: wrapperOnRemove,
    }, allCards);
}

var formWidgets = {
    booleanChoice: [
        { label: 'no', value: false },
        { label: 'yes', value: true }
    ],
    renderRadio(label, name, value, checked, onchange, disabled, labelClasses) {
        const id = name + '_' + value;
        return [
            h('input.radio[type=radio]', {
                name,
                id,
                className: value,
                value,
                checked,
                onchange,
                disabled
            }),
            h('label', {
                for: id,
                className: labelClasses
            }, typeof label === 'string' ? i18n(label) : label)
        ];
    },
    renderSelect(label, name, options, settingsProp, isDisabled, onChangeCallback) {
        const prop = settingsProp();
        return [
            h('label', {
                'for': 'select_' + name
            }, i18n(label)),
            h('select', {
                id: 'select_' + name,
                disabled: isDisabled,
                onchange(e) {
                    const val = e.target.value;
                    settingsProp(val);
                    if (onChangeCallback)
                        onChangeCallback(val);
                    setTimeout(redraw, 10);
                }
            }, options.map(e => renderOption(e[0], e[1], prop, e[2], e[3])))
        ];
    },
    renderCheckbox(label, name, prop, callback, disabled) {
        const isOn = prop();
        return h('div.check_container', {
            className: disabled ? 'disabled' : ''
        }, [
            h('label', {
                'for': name
            }, label),
            h('input[type=checkbox]', {
                id: name,
                name: name,
                disabled,
                checked: isOn,
                onchange: () => {
                    const newVal = !isOn;
                    prop(newVal);
                    if (callback)
                        callback(newVal);
                    redraw();
                }
            })
        ]);
    },
    renderMultipleChoiceButton(label, options, prop, wrap = false, callback) {
        const selected = prop();
        return h('div.form-multipleChoiceContainer', [
            h('label', label),
            h('div.form-multipleChoice', {
                className: wrap ? 'wrap' : ''
            }, options.map(o => {
                const l = o.labelArg !== undefined ? i18n(o.label, o.labelArg) : i18n(o.label);
                return h('div', {
                    className: o.value === selected ? 'selected' : '',
                    oncreate: ontap(() => {
                        prop(o.value);
                        if (callback)
                            callback(o.value);
                    })
                }, l);
            }))
        ]);
    },
    renderSlider(label, name, min, max, step, prop, onChange, disabled) {
        const value = prop();
        return h('div.forms-rangeSlider', {
            className: disabled ? 'disabled' : ''
        }, [
            h('label', { 'for': name }, label),
            h('input[type=range]', {
                id: name,
                value,
                disabled,
                min,
                max,
                step,
                oninput(e) {
                    const val = e.target.value;
                    const nval = ~~val;
                    prop(nval);
                    if (onChange)
                        onChange(nval);
                    setTimeout(redraw, 10);
                }
            }),
            h('div.forms-sliderValue', value + ' / ' + max)
        ]);
    }
};
function renderOption(label, value, prop, labelArg, labelArg2) {
    const l = labelArg && labelArg2 ? i18n(label, labelArg, labelArg2) :
        labelArg ? i18n(label, labelArg) : i18n(label);
    return h('option', {
        key: value,
        value,
        selected: prop === value
    }, l);
}

function popup(classes, headerF, contentF, isShowing, closef) {
    if (!isShowing) {
        return null;
    }
    const defaultClasses = {
        overlay_popup: true,
        native_scroller: true
    };
    let className;
    if (typeof classes === 'object')
        className = classSet({ ...defaultClasses, ...classes });
    else if (typeof classes === 'string')
        className = classSet(defaultClasses) + ' ' + classes;
    else
        throw new Error('First popup argument must be either a string or an object');
    const contentClass = classSet({
        'popup_content': true,
        'noheader': !headerF
    });
    return (h("div", { className: "overlay_popup_wrapper fade-in", onbeforeremove: (vnode) => {
            vnode.dom.classList.add('fading_out');
            return new Promise((resolve) => {
                setTimeout(resolve, 500);
            });
        } },
        h("div", { className: "popup_overlay_close", oncreate: closef ? ontap(closef) : noop$1 }),
        h("div", { className: className },
            headerF ? h("header", null, headerF()) : null,
            h("div", { className: contentClass }, contentF()))));
}

let isOpen$4 = false;
const humanSetup = settings.gameSetup.human;
// cached tab preset
let tabPreset = humanSetup.preset();
// to restore previous if changed programmatically
// null means don't restore previous on close
let previousTabPreset = null;
var newGameForm = {
    open: open$4,
    close: close$4,
    openRealTime(tab) {
        humanSetup.timeMode('1');
        if (tab) {
            tabPreset = tab;
        }
        open$4();
    },
    openCorrespondence() {
        previousTabPreset = tabPreset;
        tabPreset = 'custom';
        humanSetup.timeMode('2');
        open$4();
    },
    view() {
        return popup('game_form_popup', undefined, renderContent, isOpen$4, close$4);
    }
};
function open$4() {
    if (session$1.hasCurrentBan()) {
        return;
    }
    if (cachedPools.length === 0) {
        lobby$1(false).then(redraw);
    }
    router$1.backbutton.stack.push(close$4);
    isOpen$4 = true;
}
function close$4(fromBB) {
    if (fromBB !== 'backbutton' && isOpen$4)
        router$1.backbutton.stack.pop();
    isOpen$4 = false;
    if (previousTabPreset) {
        tabPreset = previousTabPreset;
        previousTabPreset = null;
    }
}
function goSeek(conf) {
    close$4();
    // pool
    if (isPoolMember(conf)) {
        lobby.startSeeking(conf);
    }
    // real time seek
    else if (isSeekSetup(conf) && conf.timeMode === 1) {
        lobby.startSeeking(conf);
    }
    // correspondence or unlimited seek
    else {
        seekGame(conf)
            .then(() => router$1.set('/?tab=1'))
            .catch(handleXhrError);
    }
}
function renderContent() {
    const conf = humanSetup;
    const handleTabTap = (e) => autoredraw(() => {
        const val = e.target.value;
        tabPreset = val;
        conf.preset(val);
    });
    return [
        h('div.newGame-preset_switch', [
            h('div.nice-radio', formWidgets.renderRadio(i18n('quickPairing'), 'preset', 'quick', tabPreset === 'quick', handleTabTap)),
            h('div.nice-radio', formWidgets.renderRadio(i18n('custom'), 'preset', 'custom', tabPreset === 'custom', handleTabTap))
        ]),
        tabPreset === 'quick' ?
            renderQuickSetup(() => {
                tabPreset = 'custom';
                humanSetup.preset('custom');
            }) :
            renderCustomSetup$1('human', conf, conf.availableVariants, conf.availableTimeModes.filter((e) => {
                // correspondence and unlimited time modes are only available when
                // connected
                return e[1] === '1' || session$1.isConnected();
            })),
    ];
}
function renderQuickSetup(onCustom) {
    return h('div.newGame-pools', {
        className: cachedPools.length ? '' : 'loading'
    }, cachedPools.length ?
        cachedPools
            .map(p => renderPool(p))
            .concat(h('div.newGame-pool', {
            key: 'pool-custom',
            oncreate: ontap(onCustom)
        }, h('div.newGame-custom', i18n('custom')))) : spinner.getVdom('monochrome'));
}
function renderPool(p) {
    return h('div.newGame-pool', {
        key: 'pool-' + p.id,
        oncreate: ontap(() => {
            // remember pool id for new opponent button
            humanSetup.pool(p.id);
            goSeek({ id: p.id });
            close$4();
        })
    }, [
        h('div.newGame-clock', p.id),
        h('div.newGame-perf', p.perf)
    ]);
}
function renderCustomSetup$1(formName, settingsObj, variants, timeModes) {
    const timeMode = settingsObj.timeMode();
    const hasClock = timeMode === '1';
    const hasDays = timeMode === '2' && session$1.isConnected();
    const variant = settingsObj.variant();
    if (timeMode === '2' && variant !== '1') {
        settingsObj.mode('0');
    }
    const mode = settingsObj.mode();
    // be sure to set real time clock if disconnected
    if (!session$1.isConnected()) {
        humanSetup.timeMode('1');
    }
    if (timeMode === '0') {
        humanSetup.mode('0');
    }
    const modes = (session$1.isConnected() &&
        timeMode !== '0' &&
        (timeMode !== '2' || variant === '1')) ? [
        ['casual', '0'],
        ['rated', '1']
    ] : [
        ['casual', '0']
    ];
    // if mode is rated only allow random color
    // if mode is rated only allow random color for three-check, atomic, antichess
    // horde variants
    const colors = getColorOptionsFromModeAndVariant(mode, settingsObj.variant());
    if (colors.length === 1) {
        settingsObj.color(colors[0][1]);
    }
    const generalFieldset = [
        h('div.select_input', formWidgets.renderSelect('side', formName + 'color', colors, settingsObj.color)),
        h('div.select_input', formWidgets.renderSelect('variant', formName + 'variant', variants, settingsObj.variant))
    ];
    generalFieldset.push(h('div.select_input', formWidgets.renderSelect('mode', formName + 'mode', modes, settingsObj.mode)));
    if (session$1.isConnected()) {
        generalFieldset.push(h('div.rating_range', [
            h('div.title', i18n('ratingRange')),
            h('div.select_input.inline', formWidgets.renderSelect('Min', formName + 'rating_min', humanSetup.availableRatingRanges.min, settingsObj.ratingRangeMin, false)),
            h('div.select_input.inline', formWidgets.renderSelect('Max', formName + 'rating_max', humanSetup.availableRatingRanges.max, settingsObj.ratingRangeMax, false))
        ]));
    }
    const timeFieldset = [
        h('div.select_input', formWidgets.renderSelect('clock', formName + 'timeMode', timeModes, settingsObj.timeMode))
    ];
    if (hasClock) {
        timeFieldset.push(h('div.select_input.inline', formWidgets.renderSelect('time', formName + 'time', settings.gameSetup.availableTimes, settingsObj.time, false)), h('div.select_input.inline', formWidgets.renderSelect('increment', formName + 'increment', settings.gameSetup.availableIncrements.map(tupleOf), settingsObj.increment, false)));
    }
    if (hasDays) {
        timeFieldset.push(h('div.select_input.large_label', formWidgets.renderSelect('daysPerTurn', formName + 'days', settings.gameSetup.availableDays.map(tupleOf), settingsObj.days, false)));
    }
    return h('form.game_form', {
        onsubmit(e) {
            e.preventDefault();
            if (!settings.gameSetup.isTimeValid(settingsObj))
                return;
            close$4();
            goSeek(humanSetupFromSettings(settingsObj));
        }
    }, [
        h('fieldset', generalFieldset),
        h('fieldset', timeFieldset),
        h('div.popupActionWrapper', [
            h('button[type=submit].defaultButton', i18n('createAGame'))
        ])
    ]);
}

class r{unwrap(r,t){const e=this._chain(t=>n.ok(r?r(t):t),r=>t?n.ok(t(r)):n.err(r));if(e.isErr)throw e.error;return e.value}map(r,t){return this._chain(t=>n.ok(r(t)),r=>n.err(t?t(r):r))}chain(r,t){return this._chain(r,t||(r=>n.err(r)))}}class t extends r{constructor(r){super(),this.value=void 0,this.isOk=true,this.isErr=false,this.value=r;}_chain(r,t){return r(this.value)}}class e extends r{constructor(r){super(),this.error=void 0,this.isOk=false,this.isErr=true,this.error=r;}_chain(r,t){return t(this.error)}}var n;!function(r){r.ok=function(r){return new t(r)},r.err=function(r){return new e(r||new Error)},r.all=function(t){if(Array.isArray(t)){const e=[];for(let r=0;r<t.length;r++){const n=t[r];if(n.isErr)return n;e.push(n.value);}return r.ok(e)}const e={},n=Object.keys(t);for(let r=0;r<n.length;r++){const s=t[n[r]];if(s.isErr)return s;e[n[r]]=s.value;}return r.ok(e)};}(n||(n={}));

const FILE_NAMES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANK_NAMES = ['1', '2', '3', '4', '5', '6', '7', '8'];
const COLORS = ['white', 'black'];
const ROLES = ['pawn', 'knight', 'bishop', 'rook', 'queen', 'king'];
const CASTLING_SIDES = ['a', 'h'];
function isDrop(v) {
    return 'role' in v;
}

function popcnt32(n) {
    n = n - ((n >>> 1) & 1431655765);
    n = (n & 858993459) + ((n >>> 2) & 858993459);
    return Math.imul((n + (n >>> 4)) & 252645135, 16843009) >> 24;
}
function bswap32(n) {
    n = ((n >>> 8) & 16711935) | ((n & 16711935) << 8);
    return ((n >>> 16) & 0xffff) | ((n & 0xffff) << 16);
}
function rbit32(n) {
    n = ((n >>> 1) & 1431655765) | ((n & 1431655765) << 1);
    n = ((n >>> 2) & 858993459) | ((n & 858993459) << 2);
    n = ((n >>> 4) & 252645135) | ((n & 252645135) << 4);
    return bswap32(n);
}
class SquareSet {
    constructor(lo, hi) {
        this.lo = lo;
        this.hi = hi;
        this.lo = lo | 0;
        this.hi = hi | 0;
    }
    static fromSquare(square) {
        return square >= 32 ? new SquareSet(0, 1 << (square - 32)) : new SquareSet(1 << square, 0);
    }
    static fromRank(rank) {
        return new SquareSet(0xff, 0).shl64(8 * rank);
    }
    static fromFile(file) {
        return new SquareSet(16843009 << file, 16843009 << file);
    }
    static empty() {
        return new SquareSet(0, 0);
    }
    static full() {
        return new SquareSet(4294967295, 4294967295);
    }
    static corners() {
        return new SquareSet(0x81, 2164260864);
    }
    static center() {
        return new SquareSet(402653184, 0x18);
    }
    static backranks() {
        return new SquareSet(0xff, 4278190080);
    }
    static backrank(color) {
        return color === 'white' ? new SquareSet(0xff, 0) : new SquareSet(0, 4278190080);
    }
    static lightSquares() {
        return new SquareSet(1437226410, 1437226410);
    }
    static darkSquares() {
        return new SquareSet(2857740885, 2857740885);
    }
    complement() {
        return new SquareSet(~this.lo, ~this.hi);
    }
    xor(other) {
        return new SquareSet(this.lo ^ other.lo, this.hi ^ other.hi);
    }
    union(other) {
        return new SquareSet(this.lo | other.lo, this.hi | other.hi);
    }
    intersect(other) {
        return new SquareSet(this.lo & other.lo, this.hi & other.hi);
    }
    diff(other) {
        return new SquareSet(this.lo & ~other.lo, this.hi & ~other.hi);
    }
    intersects(other) {
        return this.intersect(other).nonEmpty();
    }
    isDisjoint(other) {
        return this.intersect(other).isEmpty();
    }
    supersetOf(other) {
        return other.diff(this).isEmpty();
    }
    subsetOf(other) {
        return this.diff(other).isEmpty();
    }
    shr64(shift) {
        if (shift >= 64)
            return SquareSet.empty();
        if (shift >= 32)
            return new SquareSet(this.hi >>> (shift - 32), 0);
        if (shift > 0)
            return new SquareSet((this.lo >>> shift) ^ (this.hi << (32 - shift)), this.hi >>> shift);
        return this;
    }
    shl64(shift) {
        if (shift >= 64)
            return SquareSet.empty();
        if (shift >= 32)
            return new SquareSet(0, this.lo << (shift - 32));
        if (shift > 0)
            return new SquareSet(this.lo << shift, (this.hi << shift) ^ (this.lo >>> (32 - shift)));
        return this;
    }
    bswap64() {
        return new SquareSet(bswap32(this.hi), bswap32(this.lo));
    }
    rbit64() {
        return new SquareSet(rbit32(this.hi), rbit32(this.lo));
    }
    minus64(other) {
        const lo = this.lo - other.lo;
        const c = ((lo & other.lo & 1) + (other.lo >>> 1) + (lo >>> 1)) >>> 31;
        return new SquareSet(lo, this.hi - (other.hi + c));
    }
    equals(other) {
        return this.lo === other.lo && this.hi === other.hi;
    }
    size() {
        return popcnt32(this.lo) + popcnt32(this.hi);
    }
    isEmpty() {
        return this.lo === 0 && this.hi === 0;
    }
    nonEmpty() {
        return this.lo !== 0 || this.hi !== 0;
    }
    has(square) {
        return (square >= 32 ? this.hi & (1 << (square - 32)) : this.lo & (1 << square)) !== 0;
    }
    set(square, on) {
        return on ? this.with(square) : this.without(square);
    }
    with(square) {
        return square >= 32
            ? new SquareSet(this.lo, this.hi | (1 << (square - 32)))
            : new SquareSet(this.lo | (1 << square), this.hi);
    }
    without(square) {
        return square >= 32
            ? new SquareSet(this.lo, this.hi & ~(1 << (square - 32)))
            : new SquareSet(this.lo & ~(1 << square), this.hi);
    }
    toggle(square) {
        return square >= 32
            ? new SquareSet(this.lo, this.hi ^ (1 << (square - 32)))
            : new SquareSet(this.lo ^ (1 << square), this.hi);
    }
    last() {
        if (this.hi !== 0)
            return 63 - Math.clz32(this.hi);
        if (this.lo !== 0)
            return 31 - Math.clz32(this.lo);
        return;
    }
    first() {
        if (this.lo !== 0)
            return 31 - Math.clz32(this.lo & -this.lo);
        if (this.hi !== 0)
            return 63 - Math.clz32(this.hi & -this.hi);
        return;
    }
    withoutFirst() {
        if (this.lo !== 0)
            return new SquareSet(this.lo & (this.lo - 1), this.hi);
        return new SquareSet(0, this.hi & (this.hi - 1));
    }
    moreThanOne() {
        return (this.hi !== 0 && this.lo !== 0) || (this.lo & (this.lo - 1)) !== 0 || (this.hi & (this.hi - 1)) !== 0;
    }
    singleSquare() {
        return this.moreThanOne() ? undefined : this.last();
    }
    isSingleSquare() {
        return this.nonEmpty() && !this.moreThanOne();
    }
    *[Symbol.iterator]() {
        let lo = this.lo;
        let hi = this.hi;
        while (lo !== 0) {
            const idx = 31 - Math.clz32(lo & -lo);
            lo ^= 1 << idx;
            yield idx;
        }
        while (hi !== 0) {
            const idx = 31 - Math.clz32(hi & -hi);
            hi ^= 1 << idx;
            yield 32 + idx;
        }
    }
    *reversed() {
        let lo = this.lo;
        let hi = this.hi;
        while (hi !== 0) {
            const idx = 31 - Math.clz32(hi);
            hi ^= 1 << idx;
            yield 32 + idx;
        }
        while (lo !== 0) {
            const idx = 31 - Math.clz32(lo);
            lo ^= 1 << idx;
            yield idx;
        }
    }
}

/**
 * Piece positions on a board.
 *
 * Properties are sets of squares, like `board.occupied` for all occupied
 * squares, `board[color]` for all pieces of that color, and `board[role]`
 * for all pieces of that role. When modifying the properties directly, take
 * care to keep them consistent.
 */
class Board {
    constructor() { }
    static default() {
        const board = new Board();
        board.reset();
        return board;
    }
    static racingKings() {
        const board = new Board();
        board.occupied = new SquareSet(0xffff, 0);
        board.promoted = SquareSet.empty();
        board.white = new SquareSet(0xf0f0, 0);
        board.black = new SquareSet(0x0f0f, 0);
        board.pawn = SquareSet.empty();
        board.knight = new SquareSet(0x1818, 0);
        board.bishop = new SquareSet(0x2424, 0);
        board.rook = new SquareSet(0x4242, 0);
        board.queen = new SquareSet(0x0081, 0);
        board.king = new SquareSet(0x8100, 0);
        return board;
    }
    static horde() {
        const board = new Board();
        board.occupied = new SquareSet(4294967295, 4294901862);
        board.promoted = SquareSet.empty();
        board.white = new SquareSet(4294967295, 102);
        board.black = new SquareSet(0, 4294901760);
        board.pawn = new SquareSet(4294967295, 16711782);
        board.knight = new SquareSet(0, 1107296256);
        board.bishop = new SquareSet(0, 603979776);
        board.rook = new SquareSet(0, 2164260864);
        board.queen = new SquareSet(0, 134217728);
        board.king = new SquareSet(0, 268435456);
        return board;
    }
    /**
     * Resets all pieces to the default starting position for standard chess.
     */
    reset() {
        this.occupied = new SquareSet(0xffff, 4294901760);
        this.promoted = SquareSet.empty();
        this.white = new SquareSet(0xffff, 0);
        this.black = new SquareSet(0, 4294901760);
        this.pawn = new SquareSet(0xff00, 16711680);
        this.knight = new SquareSet(0x42, 1107296256);
        this.bishop = new SquareSet(0x24, 603979776);
        this.rook = new SquareSet(0x81, 2164260864);
        this.queen = new SquareSet(0x8, 134217728);
        this.king = new SquareSet(0x10, 268435456);
    }
    static empty() {
        const board = new Board();
        board.clear();
        return board;
    }
    clear() {
        this.occupied = SquareSet.empty();
        this.promoted = SquareSet.empty();
        for (const color of COLORS)
            this[color] = SquareSet.empty();
        for (const role of ROLES)
            this[role] = SquareSet.empty();
    }
    clone() {
        const board = new Board();
        board.occupied = this.occupied;
        board.promoted = this.promoted;
        for (const color of COLORS)
            board[color] = this[color];
        for (const role of ROLES)
            board[role] = this[role];
        return board;
    }
    equalsIgnorePromoted(other) {
        if (!this.white.equals(other.white))
            return false;
        return ROLES.every(role => this[role].equals(other[role]));
    }
    equals(other) {
        return this.equalsIgnorePromoted(other) && this.promoted.equals(other.promoted);
    }
    getColor(square) {
        if (this.white.has(square))
            return 'white';
        if (this.black.has(square))
            return 'black';
        return;
    }
    getRole(square) {
        for (const role of ROLES) {
            if (this[role].has(square))
                return role;
        }
        return;
    }
    get(square) {
        const color = this.getColor(square);
        if (!color)
            return;
        const role = this.getRole(square);
        const promoted = this.promoted.has(square);
        return { color, role, promoted };
    }
    /**
     * Removes and returns the piece from the given `square`, if any.
     */
    take(square) {
        const piece = this.get(square);
        if (piece) {
            this.occupied = this.occupied.without(square);
            this[piece.color] = this[piece.color].without(square);
            this[piece.role] = this[piece.role].without(square);
            if (piece.promoted)
                this.promoted = this.promoted.without(square);
        }
        return piece;
    }
    /**
     * Put `piece` onto `square`, potentially replacing an existing piece.
     * Returns the existing piece, if any.
     */
    set(square, piece) {
        const old = this.take(square);
        this.occupied = this.occupied.with(square);
        this[piece.color] = this[piece.color].with(square);
        this[piece.role] = this[piece.role].with(square);
        if (piece.promoted)
            this.promoted = this.promoted.with(square);
        return old;
    }
    has(square) {
        return this.occupied.has(square);
    }
    *[Symbol.iterator]() {
        for (const square of this.occupied) {
            yield [square, this.get(square)];
        }
    }
    pieces(color, role) {
        return this[color].intersect(this[role]);
    }
    rooksAndQueens() {
        return this.rook.union(this.queen);
    }
    bishopsAndQueens() {
        return this.bishop.union(this.queen);
    }
    /**
     * Finds the unique unpromoted king of the given `color`, if any.
     */
    kingOf(color) {
        return this.king.intersect(this[color]).diff(this.promoted).singleSquare();
    }
}

class MaterialSide {
    constructor() { }
    static empty() {
        const m = new MaterialSide();
        for (const role of ROLES)
            m[role] = 0;
        return m;
    }
    static fromBoard(board, color) {
        const m = new MaterialSide();
        for (const role of ROLES)
            m[role] = board.pieces(color, role).size();
        return m;
    }
    clone() {
        const m = new MaterialSide();
        for (const role of ROLES)
            m[role] = this[role];
        return m;
    }
    equals(other) {
        return ROLES.every(role => this[role] === other[role]);
    }
    add(other) {
        const m = new MaterialSide();
        for (const role of ROLES)
            m[role] = this[role] + other[role];
        return m;
    }
    nonEmpty() {
        return ROLES.some(role => this[role] > 0);
    }
    isEmpty() {
        return !this.nonEmpty();
    }
    hasPawns() {
        return this.pawn > 0;
    }
    hasNonPawns() {
        return this.knight > 0 || this.bishop > 0 || this.rook > 0 || this.queen > 0 || this.king > 0;
    }
    count() {
        return this.pawn + this.knight + this.bishop + this.rook + this.queen + this.king;
    }
}
class Material {
    constructor(white, black) {
        this.white = white;
        this.black = black;
    }
    static empty() {
        return new Material(MaterialSide.empty(), MaterialSide.empty());
    }
    static fromBoard(board) {
        return new Material(MaterialSide.fromBoard(board, 'white'), MaterialSide.fromBoard(board, 'black'));
    }
    clone() {
        return new Material(this.white.clone(), this.black.clone());
    }
    equals(other) {
        return this.white.equals(other.white) && this.black.equals(other.black);
    }
    add(other) {
        return new Material(this.white.add(other.white), this.black.add(other.black));
    }
    count() {
        return this.white.count() + this.black.count();
    }
    isEmpty() {
        return this.white.isEmpty() && this.black.isEmpty();
    }
    nonEmpty() {
        return !this.isEmpty();
    }
    hasPawns() {
        return this.white.hasPawns() || this.black.hasPawns();
    }
    hasNonPawns() {
        return this.white.hasNonPawns() || this.black.hasNonPawns();
    }
}
class RemainingChecks {
    constructor(white, black) {
        this.white = white;
        this.black = black;
    }
    static default() {
        return new RemainingChecks(3, 3);
    }
    clone() {
        return new RemainingChecks(this.white, this.black);
    }
    equals(other) {
        return this.white === other.white && this.black === other.black;
    }
}

function defined(v) {
    return v !== undefined;
}
function opposite(color) {
    return color === 'white' ? 'black' : 'white';
}
function squareRank(square) {
    return square >> 3;
}
function squareFile(square) {
    return square & 0x7;
}
function roleToChar(role) {
    switch (role) {
        case 'pawn':
            return 'p';
        case 'knight':
            return 'n';
        case 'bishop':
            return 'b';
        case 'rook':
            return 'r';
        case 'queen':
            return 'q';
        case 'king':
            return 'k';
    }
}
function charToRole(ch) {
    switch (ch) {
        case 'P':
        case 'p':
            return 'pawn';
        case 'N':
        case 'n':
            return 'knight';
        case 'B':
        case 'b':
            return 'bishop';
        case 'R':
        case 'r':
            return 'rook';
        case 'Q':
        case 'q':
            return 'queen';
        case 'K':
        case 'k':
            return 'king';
        default:
            return;
    }
}
function parseSquare(str) {
    if (str.length !== 2)
        return;
    const file = str.charCodeAt(0) - 'a'.charCodeAt(0);
    const rank = str.charCodeAt(1) - '1'.charCodeAt(0);
    if (file < 0 || file >= 8 || rank < 0 || rank >= 8)
        return;
    return file + 8 * rank;
}
function makeSquare(square) {
    return (FILE_NAMES[squareFile(square)] + RANK_NAMES[squareRank(square)]);
}
function parseUci(str) {
    if (str[1] === '@' && str.length === 4) {
        const role = charToRole(str[0]);
        const to = parseSquare(str.slice(2));
        if (role && defined(to))
            return { role, to };
    }
    else if (str.length === 4 || str.length === 5) {
        const from = parseSquare(str.slice(0, 2));
        const to = parseSquare(str.slice(2, 4));
        let promotion;
        if (str.length === 5) {
            promotion = charToRole(str[4]);
            if (!promotion)
                return;
        }
        if (defined(from) && defined(to))
            return { from, to, promotion };
    }
    return;
}
function kingCastlesTo(color, side) {
    return color === 'white' ? (side === 'a' ? 2 : 6) : side === 'a' ? 58 : 62;
}

const INITIAL_BOARD_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR';
const INITIAL_EPD = INITIAL_BOARD_FEN + ' w KQkq -';
const INITIAL_FEN = INITIAL_EPD + ' 0 1';
const EMPTY_BOARD_FEN = '8/8/8/8/8/8/8/8';
const EMPTY_EPD = EMPTY_BOARD_FEN + ' w - -';
const EMPTY_FEN = EMPTY_EPD + ' 0 1';
var InvalidFen;
(function (InvalidFen) {
    InvalidFen["Fen"] = "ERR_FEN";
    InvalidFen["Board"] = "ERR_BOARD";
    InvalidFen["Pockets"] = "ERR_POCKETS";
    InvalidFen["Turn"] = "ERR_TURN";
    InvalidFen["Castling"] = "ERR_CASTLING";
    InvalidFen["EpSquare"] = "ERR_EP_SQUARE";
    InvalidFen["RemainingChecks"] = "ERR_REMAINING_CHECKS";
    InvalidFen["Halfmoves"] = "ERR_HALFMOVES";
    InvalidFen["Fullmoves"] = "ERR_FULLMOVES";
})(InvalidFen || (InvalidFen = {}));
class FenError extends Error {
}
function nthIndexOf(haystack, needle, n) {
    let index = haystack.indexOf(needle);
    while (n-- > 0) {
        if (index === -1)
            break;
        index = haystack.indexOf(needle, index + needle.length);
    }
    return index;
}
function parseSmallUint(str) {
    return /^\d{1,4}$/.test(str) ? parseInt(str, 10) : undefined;
}
function charToPiece(ch) {
    const role = charToRole(ch);
    return role && { role, color: ch.toLowerCase() === ch ? 'black' : 'white' };
}
function parseBoardFen(boardPart) {
    const board = Board.empty();
    let rank = 7;
    let file = 0;
    for (let i = 0; i < boardPart.length; i++) {
        const c = boardPart[i];
        if (c === '/' && file === 8) {
            file = 0;
            rank--;
        }
        else {
            const step = parseInt(c, 10);
            if (step > 0)
                file += step;
            else {
                if (file >= 8 || rank < 0)
                    return n.err(new FenError(InvalidFen.Board));
                const square = file + rank * 8;
                const piece = charToPiece(c);
                if (!piece)
                    return n.err(new FenError(InvalidFen.Board));
                if (boardPart[i + 1] === '~') {
                    piece.promoted = true;
                    i++;
                }
                board.set(square, piece);
                file++;
            }
        }
    }
    if (rank !== 0 || file !== 8)
        return n.err(new FenError(InvalidFen.Board));
    return n.ok(board);
}
function parsePockets(pocketPart) {
    if (pocketPart.length > 64)
        return n.err(new FenError(InvalidFen.Pockets));
    const pockets = Material.empty();
    for (const c of pocketPart) {
        const piece = charToPiece(c);
        if (!piece)
            return n.err(new FenError(InvalidFen.Pockets));
        pockets[piece.color][piece.role]++;
    }
    return n.ok(pockets);
}
function parseCastlingFen(board, castlingPart) {
    let unmovedRooks = SquareSet.empty();
    if (castlingPart === '-')
        return n.ok(unmovedRooks);
    if (!/^[KQABCDEFGH]{0,2}[kqabcdefgh]{0,2}$/.test(castlingPart)) {
        return n.err(new FenError(InvalidFen.Castling));
    }
    for (const c of castlingPart) {
        const lower = c.toLowerCase();
        const color = c === lower ? 'black' : 'white';
        const backrank = SquareSet.backrank(color).intersect(board[color]);
        let candidates;
        if (lower === 'q')
            candidates = backrank;
        else if (lower === 'k')
            candidates = backrank.reversed();
        else
            candidates = SquareSet.fromSquare(lower.charCodeAt(0) - 'a'.charCodeAt(0)).intersect(backrank);
        for (const square of candidates) {
            if (board.king.has(square) && !board.promoted.has(square))
                break;
            if (board.rook.has(square)) {
                unmovedRooks = unmovedRooks.with(square);
                break;
            }
        }
    }
    return n.ok(unmovedRooks);
}
function parseRemainingChecks(part) {
    const parts = part.split('+');
    if (parts.length === 3 && parts[0] === '') {
        const white = parseSmallUint(parts[1]);
        const black = parseSmallUint(parts[2]);
        if (!defined(white) || white > 3 || !defined(black) || black > 3)
            return n.err(new FenError(InvalidFen.RemainingChecks));
        return n.ok(new RemainingChecks(3 - white, 3 - black));
    }
    else if (parts.length === 2) {
        const white = parseSmallUint(parts[0]);
        const black = parseSmallUint(parts[1]);
        if (!defined(white) || white > 3 || !defined(black) || black > 3)
            return n.err(new FenError(InvalidFen.RemainingChecks));
        return n.ok(new RemainingChecks(white, black));
    }
    else
        return n.err(new FenError(InvalidFen.RemainingChecks));
}
function parseFen(fen) {
    const parts = fen.split(' ');
    const boardPart = parts.shift();
    // Board and pockets
    let board, pockets = n.ok(undefined);
    if (boardPart.endsWith(']')) {
        const pocketStart = boardPart.indexOf('[');
        if (pocketStart === -1)
            return n.err(new FenError(InvalidFen.Fen));
        board = parseBoardFen(boardPart.substr(0, pocketStart));
        pockets = parsePockets(boardPart.substr(pocketStart + 1, boardPart.length - 1 - pocketStart - 1));
    }
    else {
        const pocketStart = nthIndexOf(boardPart, '/', 7);
        if (pocketStart === -1)
            board = parseBoardFen(boardPart);
        else {
            board = parseBoardFen(boardPart.substr(0, pocketStart));
            pockets = parsePockets(boardPart.substr(pocketStart + 1));
        }
    }
    // Turn
    let turn;
    const turnPart = parts.shift();
    if (!defined(turnPart) || turnPart === 'w')
        turn = 'white';
    else if (turnPart === 'b')
        turn = 'black';
    else
        return n.err(new FenError(InvalidFen.Turn));
    return board.chain(board => {
        // Castling
        const castlingPart = parts.shift();
        const unmovedRooks = defined(castlingPart) ? parseCastlingFen(board, castlingPart) : n.ok(SquareSet.empty());
        // En passant square
        const epPart = parts.shift();
        let epSquare;
        if (defined(epPart) && epPart !== '-') {
            epSquare = parseSquare(epPart);
            if (!defined(epSquare))
                return n.err(new FenError(InvalidFen.EpSquare));
        }
        // Halfmoves or remaining checks
        let halfmovePart = parts.shift();
        let earlyRemainingChecks;
        if (defined(halfmovePart) && halfmovePart.includes('+')) {
            earlyRemainingChecks = parseRemainingChecks(halfmovePart);
            halfmovePart = parts.shift();
        }
        const halfmoves = defined(halfmovePart) ? parseSmallUint(halfmovePart) : 0;
        if (!defined(halfmoves))
            return n.err(new FenError(InvalidFen.Halfmoves));
        const fullmovesPart = parts.shift();
        const fullmoves = defined(fullmovesPart) ? parseSmallUint(fullmovesPart) : 1;
        if (!defined(fullmoves))
            return n.err(new FenError(InvalidFen.Fullmoves));
        const remainingChecksPart = parts.shift();
        let remainingChecks = n.ok(undefined);
        if (defined(remainingChecksPart)) {
            if (defined(earlyRemainingChecks))
                return n.err(new FenError(InvalidFen.RemainingChecks));
            remainingChecks = parseRemainingChecks(remainingChecksPart);
        }
        else if (defined(earlyRemainingChecks)) {
            remainingChecks = earlyRemainingChecks;
        }
        if (parts.length > 0)
            return n.err(new FenError(InvalidFen.Fen));
        return pockets.chain(pockets => unmovedRooks.chain(unmovedRooks => remainingChecks.map(remainingChecks => {
            return {
                board,
                pockets,
                turn,
                unmovedRooks,
                remainingChecks,
                epSquare,
                halfmoves,
                fullmoves: Math.max(1, fullmoves),
            };
        })));
    });
}
function makePiece(piece, opts) {
    let r = roleToChar(piece.role);
    if (piece.color === 'white')
        r = r.toUpperCase();
    if ((opts === null || opts === void 0 ? void 0 : opts.promoted) && piece.promoted)
        r += '~';
    return r;
}
function makeBoardFen(board, opts) {
    let fen = '';
    let empty = 0;
    for (let rank = 7; rank >= 0; rank--) {
        for (let file = 0; file < 8; file++) {
            const square = file + rank * 8;
            const piece = board.get(square);
            if (!piece)
                empty++;
            else {
                if (empty > 0) {
                    fen += empty;
                    empty = 0;
                }
                fen += makePiece(piece, opts);
            }
            if (file === 7) {
                if (empty > 0) {
                    fen += empty;
                    empty = 0;
                }
                if (rank !== 0)
                    fen += '/';
            }
        }
    }
    return fen;
}
function makePocket(material) {
    return ROLES.map(role => roleToChar(role).repeat(material[role])).join('');
}
function makePockets(pocket) {
    return makePocket(pocket.white).toUpperCase() + makePocket(pocket.black);
}
function makeCastlingFen(board, unmovedRooks, opts) {
    const shredder = opts === null || opts === void 0 ? void 0 : opts.shredder;
    let fen = '';
    for (const color of COLORS) {
        const backrank = SquareSet.backrank(color);
        const king = board.kingOf(color);
        if (!defined(king) || !backrank.has(king))
            continue;
        const candidates = board.pieces(color, 'rook').intersect(backrank);
        for (const rook of unmovedRooks.intersect(candidates).reversed()) {
            if (!shredder && rook === candidates.first() && rook < king) {
                fen += color === 'white' ? 'Q' : 'q';
            }
            else if (!shredder && rook === candidates.last() && king < rook) {
                fen += color === 'white' ? 'K' : 'k';
            }
            else {
                const file = FILE_NAMES[squareFile(rook)];
                fen += color === 'white' ? file.toUpperCase() : file;
            }
        }
    }
    return fen || '-';
}
function makeRemainingChecks(checks) {
    return `${checks.white}+${checks.black}`;
}
function makeFen(setup, opts) {
    return [
        makeBoardFen(setup.board, opts) + (setup.pockets ? `[${makePockets(setup.pockets)}]` : ''),
        setup.turn[0],
        makeCastlingFen(setup.board, setup.unmovedRooks, opts),
        defined(setup.epSquare) ? makeSquare(setup.epSquare) : '-',
        ...(setup.remainingChecks ? [makeRemainingChecks(setup.remainingChecks)] : []),
        ...((opts === null || opts === void 0 ? void 0 : opts.epd) ? [] : [Math.max(0, Math.min(setup.halfmoves, 9999)), Math.max(1, Math.min(setup.fullmoves, 9999))]),
    ].join(' ');
}

let actionName = '';
let userId;
let setupFen;
const isOpen$3 = prop(false);
function open$3(uid) {
    if (uid) {
        userId = uid;
        actionName = i18n('challengeToPlay');
    }
    else {
        userId = undefined;
        actionName = i18n('playWithAFriend');
    }
    router$1.backbutton.stack.push(close$3);
    isOpen$3(true);
    setupFen = undefined;
}
function close$3(fromBB) {
    if (fromBB !== 'backbutton' && isOpen$3())
        router$1.backbutton.stack.pop();
    isOpen$3(false);
}
function doChallenge() {
    return challenge(userId, setupFen)
        .then(data => {
        if (data.challenge.destUser && challengesApi.isPersistent(data.challenge)) {
            gamesMenu.open(session$1.nowPlaying().length + challengesApi.all().length);
        }
        else {
            router$1.set(`/game/${data.challenge.id}`);
        }
    })
        .catch(handleXhrError);
}
function renderForm$1() {
    const formName = 'invite';
    const settingsObj = settings.gameSetup.challenge;
    const variants = settings.gameSetup.challenge.availableVariants;
    const timeModes = settings.gameSetup.challenge.availableTimeModes;
    const timeMode = settingsObj.timeMode();
    const hasClock = timeMode === '1';
    const hasDays = timeMode === '2';
    const colors = getColorOptionsFromModeAndVariant(settingsObj.mode(), settingsObj.variant());
    if (colors.length === 1) {
        settingsObj.color(colors[0][1]);
    }
    const modes = session$1.isConnected() ? [
        ['casual', '0'],
        ['rated', '1']
    ] : [
        ['casual', '0']
    ];
    const generalFieldset = [
        h('div.select_input', formWidgets.renderSelect('side', formName + 'color', colors, settingsObj.color)),
        h('div.select_input', formWidgets.renderSelect('variant', formName + 'variant', variants, settingsObj.variant)),
        settingsObj.variant() === '3' ?
            h('div.setupPosition', [
                h('div.setupPositionInput', [
                    h('input[type=text][name=fen]', {
                        placeholder: i18n('pasteTheFenStringHere'),
                        oninput: (e) => {
                            const rawfen = e.target.value;
                            if (rawfen === '') {
                                setupFen = undefined;
                            }
                            else {
                                setupFen = parseFen(rawfen).unwrap(s => makeFen(s), () => false);
                            }
                            redraw();
                        }
                    }),
                    h('button.withIcon', {
                        oncreate: ontap(() => {
                            close$3();
                            router$1.set('/editor');
                        })
                    }, h('span.fa.fa-pencil')),
                ]),
                setupFen === false ?
                    h('div.setupFenError', 'Invalid FEN') : null,
                setupFen !== undefined && setupFen !== false ? [
                    h('div', {
                        style: {
                            width: '100px',
                            height: '100px'
                        },
                        oncreate: ontap(() => {
                            close$3();
                            if (setupFen)
                                router$1.set(`/editor/${encodeURIComponent(setupFen)}`);
                        })
                    }, [
                        h(ViewOnlyBoard, { fen: setupFen, orientation: 'white' })
                    ])
                ] : null
            ]) : null,
        settingsObj.variant() !== '3' ?
            h('div.select_input', formWidgets.renderSelect('mode', formName + 'mode', modes, settingsObj.mode)) : null
    ];
    const timeFieldset = [
        h('div.select_input', formWidgets.renderSelect('clock', formName + 'timeMode', timeModes, settingsObj.timeMode))
    ];
    if (hasClock) {
        timeFieldset.push(h('div.select_input.inline', formWidgets.renderSelect('time', formName + 'time', settings.gameSetup.availableTimes, settingsObj.time, false)), h('div.select_input.inline', formWidgets.renderSelect('increment', formName + 'increment', settings.gameSetup.availableIncrements.map(tupleOf), settingsObj.increment, false)));
    }
    if (hasDays) {
        timeFieldset.push(h('div.select_input.large_label', formWidgets.renderSelect('daysPerTurn', formName + 'days', settings.gameSetup.availableDays.map(tupleOf), settingsObj.days, false)));
    }
    return h('form#invite_form.game_form', {
        onsubmit(e) {
            e.preventDefault();
            if (!settings.gameSetup.isTimeValid(settingsObj))
                return;
            close$3();
            doChallenge();
        }
    }, [
        h('fieldset', generalFieldset),
        h('fieldset#clock', timeFieldset),
        h('div.popupActionWrapper', [
            h('button[type=submit].defaultButton', actionName)
        ])
    ]);
}
var challengeForm = {
    view() {
        return popup('invite_form_popup game_form_popup', undefined, renderForm$1, isOpen$3(), close$3);
    },
    open: open$3,
    openFromPosition(f) {
        open$3();
        setupFen = f;
        settings.gameSetup.challenge.variant('3');
        settings.gameSetup.challenge.mode('0');
    }
};

let isOpen$2 = false;
var friendsPopup = {
    open: open$2,
    close: close$2,
    view() {
        function header() {
            return [
                h('span', plural('nbFriendsOnline', friendsApi.count()))
            ];
        }
        return popup({ onlineFriends: true, native_scroller: false }, header, renderFriends, isOpen$2, close$2);
    }
};
function open$2() {
    router$1.backbutton.stack.push(close$2);
    isOpen$2 = true;
}
function close$2(fromBB) {
    if (fromBB !== 'backbutton' && isOpen$2)
        router$1.backbutton.stack.pop();
    isOpen$2 = false;
}
function renderFriends() {
    const list = friendsApi.list();
    return list.length ?
        (h("ul", null, list.map(renderFriend))) : (h("div", { className: "native_scroller nofriend" }));
}
function renderFriend(friend) {
    const userId = friend.name.toLowerCase();
    const isBot = friend.title === 'BOT';
    function action() {
        close$2();
        router$1.set('/@/' + userId);
    }
    function onTapTv(e) {
        e.stopPropagation();
        close$2();
        router$1.set('/@/' + userId + '/tv');
    }
    return (h("li", { className: "list_item", key: userId, oncreate: ontapY(action) },
        h("div", { className: "friend_name" },
            friend.patron ?
                h("span", { className: "patron is-green", "data-icon": "\uE019" })
                :
                    null,
            h("span", null,
                friend.title ?
                    h("span", { className: 'userTitle' + (isBot ? ' bot' : '') },
                        friend.title,
                        " ") :
                    null,
                friend.name)),
        h("div", { className: "onlineFriends_actions" },
            friend.playing ?
                h("span", { className: "friend_tv", "data-icon": "1", oncreate: ontapY(onTapTv) }, " ")
                :
                    null,
            h("span", { "data-icon": "U", oncreate: ontapY((e) => {
                    e.stopPropagation();
                    close$2();
                    challengeForm.open(userId);
                }) }),
            h("span", { "data-icon": "c", oncreate: ontapY((e) => {
                    e.stopPropagation();
                    close$2();
                    router$1.set(`/inbox/new/${userId}`);
                }) }))));
}

const backArrow = h("div", { className: "svg_icon" },
    h("div", { className: "svg_icon_inner" },
        h("svg", { width: "24", height: "24", viewBox: "0 0 24 24" },
            h("path", { d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" }))));
const closeIcon = h("div", { className: "svg_icon" },
    h("div", { className: "svg_icon_inner" },
        h("svg", { width: "24", height: "24", viewBox: "0 0 24 24" },
            h("path", { d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" }))));
const expandLess = h("div", { className: "svg_icon" },
    h("div", { className: "svg_icon_inner" },
        h("svg", { width: "24", height: "24", viewBox: "0 0 24 24" },
            h("path", { d: "M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z" }))));
const expandMore = h("div", { className: "svg_icon" },
    h("div", { className: "svg_icon_inner" },
        h("svg", { width: "24", height: "24", viewBox: "0 0 24 24" },
            h("path", { d: "M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z" }))));

function menuButton() {
    return h('button.fa.fa-navicon.main_header_button.menu_button', {
        oncreate: ontap(mainMenuCtrl.toggle)
    });
}
function backButton(title) {
    return h('div.back_button', [
        h('button', { oncreate: ontap(router$1.backHistory) }, backArrow),
        title !== undefined ? typeof title === 'string' ? h('div.main_header_title', title) : title : null
    ]);
}
function bookmarkButton(action, flag) {
    return session$1.isConnected() ? h('button.main_header_button.bookmarkButton', {
        oncreate: ontap(action, () => Toast.show({ text: i18n('bookmarkThisGame'), duration: 'short', position: 'top' })),
    }, h('span', {
        'data-icon': flag ? 't' : 's'
    })) : null;
}
function friendsButton() {
    const nbFriends = friendsApi.count();
    return (h("button", { className: "main_header_button friends_button", "data-icon": "f", "data-button": "friends" }, nbFriends > 0 ?
        h("span", { className: "chip nb_friends" }, nbFriends) : null));
}
let boardTheme;
function onBoardThemeChange(theme) {
    boardTheme = theme;
}
function gamesButton() {
    boardTheme = boardTheme || settings.general.theme.board();
    const myTurns = session$1.myTurnGames().length;
    const nbIncomingChallenges = challengesApi.incoming().length;
    const className = [
        'main_header_button',
        'game_menu_button',
        boardTheme,
        nbIncomingChallenges ? 'new_challenge' : '',
    ].join(' ');
    return (h("button", { className: className, "data-button": "games" },
        !nbIncomingChallenges && myTurns ?
            h("span", { className: "chip nb_playing" }, myTurns) : null,
        nbIncomingChallenges ?
            h("span", { className: "chip nb_challenges" }, nbIncomingChallenges) : null));
}
function onHeaderBtnTap(e) {
    const el = closest(e, '.main_header_button');
    const button = el?.dataset.button;
    if (el && button) {
        if (button === 'games') {
            const nbChallenges = challengesApi.all().length;
            if (session$1.nowPlaying().length || nbChallenges) {
                gamesMenu.open();
            }
            else {
                newGameForm.open();
            }
        }
        else if (button === 'friends') {
            friendsPopup.open();
        }
    }
}
function headerBtns() {
    const handler = ontap(onHeaderBtnTap, undefined, undefined, closestHandler('.main_header_button'));
    if (session$1.isConnected() && friendsApi.count()) {
        return (h("div", { className: "buttons", oncreate: handler },
            friendsButton(),
            gamesButton()));
    }
    else {
        return (h("div", { className: "buttons", oncreate: handler }, gamesButton()));
    }
}
// TODO refactor this
function header(title, leftButton) {
    return h('nav', [
        leftButton ? leftButton : menuButton(),
        typeof title === 'string' ?
            h('div.main_header_title', title) : title,
        headerBtns()
    ]);
}
function dropShadowHeader(title, leftButton) {
    return [
        h('nav', [
            leftButton ? leftButton : menuButton(),
            title ? h("div", { className: "main_header_title" }, title) : null,
            headerBtns()
        ]),
    ];
}
const loader = (h("div", { className: "loader_circles" }, [1, 2, 3].map(i => h("div", { className: 'circle_' + i }))));
function connectingHeader(title) {
    return (h("nav", null,
        menuButton(),
        h("div", { className: 'main_header_title reconnecting' + ('') },
            null,
            loader),
        headerBtns()));
}
function connectingDropShadowHeader(title) {
    return [
        h('nav', [
            menuButton(),
            h('div.main_header_title.reconnecting', {
                className: '',
            }),
            null,
            headerBtns()
        ]),
    ];
}
function loadingBackbutton(title) {
    return h('nav', [
        backButton(h('div.main_header_title.reconnecting', {
            className: '',
        }, [
            null,
            loader,
        ])),
        headerBtns()
    ]);
}
function userStatus(user) {
    const status = user.online ? 'online' : 'offline';
    return (h("div", { className: "user" },
        user.patron ?
            h("span", { className: 'patron userStatus ' + status, "data-icon": "\uE019" }) :
            h("span", { className: 'fa fa-circle userStatus ' + status }),
        user.title ? h("span", { className: "userTitle" },
            user.title,
            "\u00A0") : null,
        user.username));
}

const SETUP_STORAGE_KEY = 'setup.custom.last';
let nbPlayers = 0;
let nbGames = 0;
// popup is visible and we are currently seeking a game
let isOpenAndSeeking = false;
// current setup: either a pool or a seek
let currentSetup = null;
// reference created hookId to avoid creating more than 1 hook
let hookId = null;
// we send poolIn message every 10s in case of server disconnection
// (bad network, server restart, etc.)
let poolInIntervalId;
let socketIface;
const socketHandlers = {
    redirect: (d) => {
        stopAndClose();
        if (currentSetup !== null) {
            if (isPoolMember(currentSetup)) {
                leavePool(currentSetup);
            }
            else {
                storage.set(SETUP_STORAGE_KEY, currentSetup);
            }
        }
        socket.redirectToGame(d);
    },
    n: (_, d) => {
        nbPlayers = d.d;
        nbGames = d.r;
        redraw();
    }
};
var lobby = {
    startSeeking(conf) {
        doStartSeeking(conf);
    },
    appCancelSeeking() {
        if (isOpenAndSeeking) {
            leavePoolOrCancelHook();
        }
    },
    onNewOpponent(data) {
        if (data.game.source === 'pool') {
            const clock = data.clock;
            const poolId = clock.initial / 60 + '+' + clock.increment;
            doStartSeeking({ id: poolId });
        }
        else {
            const setup = currentSetup && isSeekSetup(currentSetup) ? currentSetup :
                storage.get(SETUP_STORAGE_KEY) ||
                    humanSetupFromSettings(settings.gameSetup.human);
            doStartSeeking(setup, data.game.id);
        }
    },
    view() {
        function content() {
            const nbPlayersStr = plural('nbPlayers', nbPlayers, nbPlayers ? undefined : '?');
            const nbGamesStr = plural('nbGames', nbGames, nbGames ? undefined : '?');
            if (currentSetup === null) {
                return h('div.lobby-waitingPopup', 'Something went wrong. Please try again');
            }
            return h('div.lobby-waitingPopup', [
                h('div.lobby-waitingForOpponent', i18n('waitingForOpponent')),
                h('br'),
                isPoolMember(currentSetup) ?
                    renderPoolSetup(currentSetup) :
                    renderCustomSetup(currentSetup),
                h('br'),
                spinner.getVdom(),
                h('div.lobby-nbPlayers', socket.isConnected() ? [
                    h('div', h.trust(nbPlayersStr.replace(/(\d+)/, '<strong>$1</strong>'))),
                    h('div', h.trust(nbGamesStr.replace(/(\d+)/, '<strong>$1</strong>'))),
                ] : h('div', [i18n('reconnecting'), loader])),
                h('button[data-icon=L]', {
                    oncreate: ontap(() => userCancelSeeking())
                }, i18n('cancel'))
            ]);
        }
        return popup('', undefined, content, isOpenAndSeeking);
    }
};
function renderCustomSetup(setup) {
    const availableVariants = settings.gameSetup.human.availableVariants;
    const variantConf = availableVariants.find(v => v[1] === String(setup.variant));
    const variant = variantConf && variantConf[0] || 'Standard';
    const timeMode = setup.timeMode;
    const mode = setup.mode === 0 ? i18n('casual') : i18n('rated');
    const minutes = setup.time;
    let time;
    if (timeMode === 1) {
        time = displayTime(String(minutes)) + '+' + setup.increment;
    }
    else if (timeMode === 2) {
        time = plural('nbDays', setup.days);
    }
    else {
        time = '∞';
    }
    const variantMode = ` • ${variant} • ${mode}`;
    return h('div.gameInfos', [
        h('span[data-icon=p]', time), variantMode
    ]);
}
function renderPoolSetup(member) {
    // pool is always rated, this is a hack for anon. fake pool
    const mode = session$1.isConnected() ? i18n('rated') : i18n('casual');
    const variantMode = ` • Standard • ${mode}`;
    return h('div.gameInfos', [
        h('span[data-icon=p]', member.id), variantMode
    ]);
}
/*
 * Start seeking according to conf
 *
 * @conf either Pool or Seek
 * @gameId? if provided this argument will trigger a seek like xhr
 */
function doStartSeeking(conf, gameId) {
    router$1.backbutton.stack.push(userCancelSeeking);
    isOpenAndSeeking = true;
    if (isPoolMember(conf))
        enterPool(conf);
    else
        session$1.refresh().then(() => sendHook(conf, gameId));
}
function stopAndClose(fromBB) {
    if (fromBB !== 'backbutton' && isOpenAndSeeking)
        router$1.backbutton.stack.pop();
    isOpenAndSeeking = false;
}
function userCancelSeeking(fromBB) {
    stopAndClose(fromBB);
    leavePoolOrCancelHook();
    router$1.reload(); // reload the page to restore socket
}
function sendHook(setup, gameId) {
    currentSetup = setup;
    if (hookId) {
        // normally can't create hook if already have a hook
        cancelHook();
    }
    socketIface = socket.createLobby(SEEKING_SOCKET_NAME, () => {
        // socket on open handler
        // we do want to be sure we don't do anything in background here
        if (!isOpenAndSeeking)
            return;
        // hook already created!
        if (hookId)
            return;
        gameId ? newOpponentHook(gameId, setup) : seekGame(setup)
            .then(data => {
            hookId = data.hook.id;
        })
            .catch(handleXhrError);
    }, socketHandlers);
}
function enterPool(member) {
    currentSetup = member;
    socketIface = socket.createLobby(SEEKING_SOCKET_NAME, () => {
        // socket on open handler
        // we do want to be sure we don't do anything in background here
        if (!isOpenAndSeeking)
            return;
        session$1.refresh()
            .then(() => {
            // ensure session with a refresh
            if (session$1.isConnected()) {
                socketSend('poolIn', member);
                clearInterval(poolInIntervalId);
                poolInIntervalId = setInterval(() => {
                    socketSend('poolIn', member);
                }, 10 * 1000);
            }
            // if anon. use a seek similar to the pool
            else {
                const pool = cachedPools.find(p => p.id === member.id);
                if (pool) {
                    sendHook({
                        mode: 0,
                        variant: 1,
                        timeMode: 1,
                        time: pool.lim,
                        increment: pool.inc,
                        days: 1,
                        color: 'random'
                    });
                }
            }
        });
    }, socketHandlers);
}
function leavePoolOrCancelHook() {
    if (currentSetup === null)
        return;
    if (isPoolMember(currentSetup)) {
        leavePool(currentSetup);
    }
    else if (hookId) {
        cancelHook();
    }
}
function leavePool(member) {
    clearInterval(poolInIntervalId);
    socketSend('poolOut', member.id);
}
function cancelHook() {
    socketSend('cancel', hookId);
    hookId = null;
}
function socketSend(t, d) {
    if (socketIface)
        socketIface.send(t, d);
}

const Badge = registerPlugin('Badge');

let firstConnection = true;
function appInit(appInfo) {
    window.lichess.cpuArch = 'x86';
    window.deviceInfo = {
        appVersion: appInfo.version,
        cpuCores: 1,
        stockfishMaxMemory: 16,
    };
    requestIdleCallback(() => {
        // cache viewport dims
        viewportDim();
        sound.load();
    });
    App.addListener('appStateChange', (state) => {
        if (state.isActive) {
            sound.resume();
            setForeground();
            session$1.refresh().then(() => {
                if (Capacitor.getPlatform() === 'ios') {
                    Badge.setNumber({ badge: session$1.myTurnGames().length });
                }
            });
            socket.cancelDelayedDisconnect();
            socket.connect();
            redraw();
        }
        else {
            setBackground();
            socket.delayedDisconnect(3 * 60 * 1000);
            lobby.appCancelSeeking();
        }
    });
    Network.addListener('networkStatusChange', s => {
        if (s.connected) {
            onOnline();
        }
        else {
            onOffline();
        }
    });
    App.addListener('backButton', router$1.backbutton);
    window.addEventListener('resize', debounce(onResize), false);
    // pull session data once (to log in user automatically thanks to cookie)
    // and also listen to online event in case network was disconnected at app
    // startup
    Network.getStatus().then(st => {
        if (st.connected) {
            onOnline();
        }
        else {
            session$1.restoreStoredSession();
        }
    });
}
function onResize() {
    clearCachedViewportDim();
    redraw();
}
function onOnline() {
    if (isForeground()) {
        if (firstConnection) {
            status()
                .then(() => {
                firstConnection = false;
                getPools();
                session$1.rememberLogin()
                    .then(() => {
                    challengesApi.refresh();
                    redraw();
                })
                    .catch(() => {
                    console.log('connected as anonymous');
                });
            })
                .catch((e) => {
                console.error(e);
                session$1.restoreStoredSession();
            });
        }
        else {
            socket.connect();
            session$1.refresh();
        }
    }
}
function onOffline() {
    // TODO check this behavior with capacitor
    // offline event fires every time the network connection changes
    // it doesn't mean necessarily the network is off
    if (isForeground() && !hasNetwork()) {
        socket.disconnect();
        redraw();
    }
}
// pre fetch and cache available pools
// retry 5 times
let nbRetries = 1;
function getPools() {
    return lobby$1()
        .then(redraw)
        .catch(() => {
        if (nbRetries <= 5) {
            nbRetries++;
            setTimeout(getPools, nbRetries * 1000);
        }
    });
}

var Directory;
(function (Directory) {
    /**
     * The Documents directory.
     * On iOS it's the app's documents directory.
     * Use this directory to store user-generated content.
     * On Android it's the Public Documents folder, so it's accessible from other apps.
     * It's not accesible on Android 10 unless the app enables legacy External Storage
     * by adding `android:requestLegacyExternalStorage="true"` in the `application` tag
     * in the `AndroidManifest.xml`.
     * On Android 11 or newer the app can only access the files/folders the app created.
     *
     * @since 1.0.0
     */
    Directory["Documents"] = "DOCUMENTS";
    /**
     * The Data directory.
     * On iOS it will use the Documents directory.
     * On Android it's the directory holding application files.
     * Files will be deleted when the application is uninstalled.
     *
     * @since 1.0.0
     */
    Directory["Data"] = "DATA";
    /**
     * The Library directory.
     * On iOS it will use the Library directory.
     * On Android it's the directory holding application files.
     * Files will be deleted when the application is uninstalled.
     *
     * @since 1.1.0
     */
    Directory["Library"] = "LIBRARY";
    /**
     * The Cache directory.
     * Can be deleted in cases of low memory, so use this directory to write app-specific files.
     * that your app can re-create easily.
     *
     * @since 1.0.0
     */
    Directory["Cache"] = "CACHE";
    /**
     * The external directory.
     * On iOS it will use the Documents directory.
     * On Android it's the directory on the primary shared/external
     * storage device where the application can place persistent files it owns.
     * These files are internal to the applications, and not typically visible
     * to the user as media.
     * Files will be deleted when the application is uninstalled.
     *
     * @since 1.0.0
     */
    Directory["External"] = "EXTERNAL";
    /**
     * The external storage directory.
     * On iOS it will use the Documents directory.
     * On Android it's the primary shared/external storage directory.
     * It's not accesible on Android 10 unless the app enables legacy External Storage
     * by adding `android:requestLegacyExternalStorage="true"` in the `application` tag
     * in the `AndroidManifest.xml`.
     * It's not accesible on Android 11 or newer.
     *
     * @since 1.0.0
     */
    Directory["ExternalStorage"] = "EXTERNAL_STORAGE";
})(Directory || (Directory = {}));
var Encoding;
(function (Encoding) {
    /**
     * Eight-bit UCS Transformation Format
     *
     * @since 1.0.0
     */
    Encoding["UTF8"] = "utf8";
    /**
     * Seven-bit ASCII, a.k.a. ISO646-US, a.k.a. the Basic Latin block of the
     * Unicode character set
     * This encoding is only supported on Android.
     *
     * @since 1.0.0
     */
    Encoding["ASCII"] = "ascii";
    /**
     * Sixteen-bit UCS Transformation Format, byte order identified by an
     * optional byte-order mark
     * This encoding is only supported on Android.
     *
     * @since 1.0.0
     */
    Encoding["UTF16"] = "utf16";
})(Encoding || (Encoding = {}));

const Filesystem = registerPlugin('Filesystem', {
    web: () => import('./web-DaDMWqcT.js').then(m => new m.FilesystemWeb()),
});

const baseUrl = 'https://veloce.github.io/lichobile-themes';
let styleEl;
function isTransparent(key) {
    return key !== 'dark' && key !== 'light' && key !== 'system';
}
function init() {
    const bgTheme = settings.general.theme.background();
    const boardTheme = settings.general.theme.board();
    // load background theme
    if (isTransparent(bgTheme)) {
        const filename = getFilenameFromKey('bg', bgTheme);
        getLocalFile('bg', filename).then(r => {
            createStylesheetRule('bg', bgTheme, filename, r);
        })
            .catch(() => {
            settings.general.theme.background('dark');
        });
    }
    // load board theme
    if (!settings.general.theme.bundledBoardThemes.includes(boardTheme)) {
        const filename = getFilenameFromKey('board', boardTheme);
        getLocalFile('board', filename).then(r => {
            createStylesheetRule('board', boardTheme, filename, r);
        })
            .catch(() => {
            settings.general.theme.board('brown');
        });
    }
}
function getLocalFile(theme, fileName) {
    return Filesystem.readFile({
        path: theme + '-' + fileName,
        directory: Directory.Data
    });
}
function getLocalFiles(theme) {
    return Filesystem.readdir({
        path: '',
        directory: Directory.Data
    }).then(({ files }) => files.map(f => f.name).filter(f => f.startsWith(theme)));
}
function filename(entry) {
    return entry.key + '.' + entry.ext;
}
// either download it from server of get it from filesystem
function loadImage(theme, key, onProgress) {
    const filename = getFilenameFromKey(theme, key);
    return getLocalFile(theme, filename)
        .catch(() => {
        // if not found, download
        return download(theme, filename, onProgress)
            .then(() => getLocalFile(theme, filename));
    })
        .then(res => {
        createStylesheetRule(theme, key, filename, res);
    });
}
function handleError(err) {
    console.error(err);
    Toast.show({ text: 'Cannot load theme file', duration: 'short' });
}
function createStylesheetRule(theme, key, filename, { data }) {
    if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.type = 'text/css';
        document.head.appendChild(styleEl);
    }
    const cleanData = data.replace(/\n/g, ''); // FIXME should be fixed in capacitor
    const ext = filename.split('.').pop();
    const mime = ext === 'png' ?
        'data:image/png;base64,' : 'data:image/jpeg;base64,';
    const dataUrl = mime + cleanData;
    const css = theme === 'bg' ?
        `.view-container.transp.${key} > main { background-image: url(${dataUrl}); }` :
        `:root { --board-background: url(${dataUrl}); }\n` +
            `.board-${key} > .cg-board { background-image: var(--board-background); }\n` +
            `.game_menu_button.${key}::before { background-image: var(--board-background); background-size: 40px; }`;
    styleEl.appendChild(document.createTextNode(css));
}
function getFilenameFromKey(theme, key) {
    const avails = theme === 'bg' ?
        settings.general.theme.availableBackgroundThemes :
        settings.general.theme.availableBoardThemes;
    const t = avails.find(t => t.key === key);
    return filename(t);
}
function download(theme, fileName, onProgress) {
    return new Promise((resolve, reject) => {
        const client = new XMLHttpRequest();
        const themePath = theme === 'bg' ? '/background' : '/board';
        client.open('GET', `${baseUrl}${themePath}/${fileName}`, true);
        client.responseType = 'blob';
        if (onProgress) {
            client.onprogress = onProgress;
        }
        client.onload = () => {
            if (client.status === 200) {
                const blob = client.response;
                if (blob) {
                    const reader = new FileReader();
                    reader.readAsDataURL(blob);
                    reader.onloadend = () => {
                        const base64data = reader.result;
                        Filesystem.writeFile({
                            path: theme + '-' + fileName,
                            data: base64data,
                            directory: Directory.Data,
                        })
                            .then(() => resolve());
                    };
                }
                else {
                    reject('could not get file');
                }
            }
            else {
                reject(`Request returned ${client.status}`);
            }
        };
        client.send();
    });
}
let systemTheme;
function getSystemTheme() {
    if (systemTheme === undefined) {
        const mql = window.matchMedia('(prefers-color-scheme: light)');
        systemTheme = mql.matches ? 'light' : 'dark';
        mql.addEventListener('change', e => {
            systemTheme = e.matches ? 'light' : 'dark';
        });
    }
    return systemTheme;
}

var routes = {
    init() {
        withRouter(router => {
            router.add('', ({ params }) => {
                import('./home-D9_89Ruf.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('timeline', ({ params }) => {
                import('./timeline-BwuTr8-b.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('otb', ({ params }) => {
                import('./otb-AXclahNy.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('otb/variant/:variant/fen/:fen', ({ params }) => {
                import('./otb-AXclahNy.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('ai', ({ params }) => {
                import('./ai-np9G6JEV.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('ai/variant/:variant/fen/:fen/color/:color', ({ params }) => {
                import('./ai-np9G6JEV.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('game/:id', ({ params }) => {
                import('./game-DQG4_Lsl.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('tournament/:tournamentId/game/:id', ({ params }) => {
                import('./game-DQG4_Lsl.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse/:source/:id/:color', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse/:source/:id', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse/fen/:fen', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse/variant/:variant', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse/variant/:variant/fen/:fen', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('analyse', ({ params }) => {
                import('./analyse-BqsjjBlx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('importer', ({ params }) => {
                import('./importer-BmXRijVr.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('tv', ({ params }) => {
                import('./tv-BSR0Ui0k.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('tv/:channel', ({ params }) => {
                import('./tv-BSR0Ui0k.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id', ({ params }) => {
                import('./user-C-xJGna2.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id/related', ({ params }) => {
                import('./related-BwAzJbjx.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id/games', ({ params }) => {
                import('./games-Ct1GV-_D.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id/games/:filter', ({ params }) => {
                import('./games-Ct1GV-_D.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id/:perf/perf', ({ params }) => {
                import('./perfStats-DgsLozHp.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('@/:id/tv', ({ params }) => {
                import('./userTv-BJbQJeB2.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('about', ({ params }) => {
                import('./about-CqkXicxU.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences', ({ params }) => {
                import('./preferences-BVng74qS.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences/game-display', ({ params }) => {
                import('./gameDisplay-C5H2DJSp.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences/game-behavior', ({ params }) => {
                import('./gameBehavior-CU7UaCoj.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences/clock', ({ params }) => {
                import('./clock-BGAarcjz.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences/privacy', ({ params }) => {
                import('./privacy-C1SeInvk.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('account/preferences/kidMode', ({ params }) => {
                import('./kid-CyimFk10.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('clock', ({ params }) => {
                import('./clock-BDanqFnV.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('editor', ({ params }) => {
                import('./editor-D_5O4t7t.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('editor/:fen', ({ params }) => {
                import('./editor-D_5O4t7t.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('inbox', ({ params }) => {
                import('./msg-BryWQ465.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('inbox/:id', ({ params }) => {
                import('./msg-BryWQ465.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('inbox/new', ({ params }) => {
                import('./msg-BryWQ465.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('inbox/new/:id', ({ params }) => {
                import('./msg-BryWQ465.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('players', ({ params }) => {
                import('./players-Cq92CW3I.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('search', ({ params }) => {
                import('./search-BqbHtXW3.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings', ({ params }) => {
                import('./settings-B5Pww0OA.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/gameDisplay', ({ params }) => {
                import('./gameDisplay-DFXSh3f4.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/clock', ({ params }) => {
                import('./clock-B3cpym32.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/gameBehavior', ({ params }) => {
                import('./gameBehavior-BJh8CzLt.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/soundNotifications', ({ params }) => {
                import('./soundNotifications-CJd1cT8g.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/background', ({ params }) => {
                import('./background-6y3J5oj2.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/themes/board', ({ params }) => {
                import('./boardTheme-D3BiV0n7.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/themes/piece', ({ params }) => {
                import('./pieceThemes-92N7U1Pl.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('settings/lang', ({ params }) => {
                import('./lang-CO0ObPms.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('teams', ({ params }) => {
                import('./teamsList-CO84qUbw.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('teams/:id', ({ params }) => {
                import('./teamDetail-XoPuk9Vw.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('training', ({ params }) => {
                import('./training-Dm_Jp5vj.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('training/:id', ({ params }) => {
                import('./training-Dm_Jp5vj.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('tournament', ({ params }) => {
                import('./tournamentList-BnDIVu8z.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('tournament/:id', ({ params }) => {
                import('./tournamentDetail-CMUzI3XS.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('study', ({ params }) => {
                import('./studyIndex-BkX6Lvid.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('study/:id', ({ params }) => {
                import('./study-D2X6q8Hu.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('study/:id/:chapterId', ({ params }) => {
                import('./study-D2X6q8Hu.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
            router.add('coord', ({ params }) => {
                import('./coordinates-CtP_IACs.js').then(m => {
                    onRouteMatch(m.default, params);
                });
            });
        });
        window.addEventListener('popstate', processWindowLocation);
    }
};

/// <reference types="@capacitor/cli" />
var KeyboardStyle;
(function (KeyboardStyle) {
    /**
     * Dark keyboard.
     *
     * @since 1.0.0
     */
    KeyboardStyle["Dark"] = "DARK";
    /**
     * Light keyboard.
     *
     * @since 1.0.0
     */
    KeyboardStyle["Light"] = "LIGHT";
    /**
     * On iOS 13 and newer the keyboard style is based on the device appearance.
     * If the device is using Dark mode, the keyboard will be dark.
     * If the device is using Light mode, the keyboard will be light.
     * On iOS 12 the keyboard will be light.
     *
     * @since 1.0.0
     */
    KeyboardStyle["Default"] = "DEFAULT";
})(KeyboardStyle || (KeyboardStyle = {}));
var KeyboardResize;
(function (KeyboardResize) {
    /**
     * Only the `body` HTML element will be resized.
     * Relative units are not affected, because the viewport does not change.
     *
     * @since 1.0.0
     */
    KeyboardResize["Body"] = "body";
    /**
     * Only the `ion-app` HTML element will be resized.
     * Use it only for Ionic Framework apps.
     *
     * @since 1.0.0
     */
    KeyboardResize["Ionic"] = "ionic";
    /**
     * The whole native Web View will be resized when the keyboard shows/hides.
     * This affects the `vh` relative unit.
     *
     * @since 1.0.0
     */
    KeyboardResize["Native"] = "native";
    /**
     * Neither the app nor the Web View are resized.
     *
     * @since 1.0.0
     */
    KeyboardResize["None"] = "none";
})(KeyboardResize || (KeyboardResize = {}));

const Keyboard = registerPlugin('Keyboard');

let isOpen$1 = false;
let loading$1 = false;
let formError$1 = null;
var loginModal = {
    open: open$1,
    close: close$1,
    view() {
        if (!isOpen$1)
            return null;
        return h('div.modal#loginModal', { oncreate: slidesInUp }, [
            h('header', [
                h('button.modal_close', {
                    oncreate: ontap(slidesOutDown(close$1, 'loginModal'))
                }, closeIcon),
                h('h2', i18n('signIn'))
            ]),
            h('div.modal_content', [
                h('form.defaultForm.login', {
                    onsubmit: onLogin
                }, [
                    formError$1 && !isTotpError(formError$1) ? h('div.form-error', formError$1) : null,
                    formError$1 === 'InvalidTotpToken' ? h('div.form-error', i18n('invalidAuthenticationCode')) : null,
                    h('div.field', [
                        h('input#username', {
                            type: isTotpError(formError$1) ? 'hidden' : 'text',
                            className: formError$1 ? 'form-error' : '',
                            placeholder: i18n('username'),
                            autocomplete: 'off',
                            autocapitalize: 'off',
                            autocorrect: 'off',
                            spellcheck: false,
                            required: true
                        }),
                    ]),
                    h('div.field', [
                        h('input#password', {
                            type: isTotpError(formError$1) ? 'hidden' : 'password',
                            className: formError$1 ? 'form-error' : '',
                            placeholder: i18n('password'),
                            required: true
                        }),
                    ]),
                    isTotpError(formError$1) ? [
                        h('div.field', [
                            h('input#token[type=number]', {
                                className: formError$1 !== 'MissingTotpToken' ? 'form-error' : '',
                                placeholder: i18n('authenticationCode'),
                                pattern: '\\d{6}',
                                required: true
                            }),
                        ]),
                        h('p.twofactorhelp', [
                            h('i.fa.fa-mobile-phone'), h.trust('&nbsp'),
                            'Open the two-factor authentication app on your device to view your authentication code and verify your identity.'
                        ]),
                    ] : null,
                    h('div.submit', [
                        h('button.defaultButton', {
                            disabled: loading$1
                        }, i18n('signIn'))
                    ])
                ]),
                h('div.loginActions', [
                    h('a', {
                        oncreate: ontap(signupModal.open)
                    }, [i18n('signUp')]),
                    h('a', {
                        href: 'https://live.chess-online.com/password/reset'
                    }, [i18n('passwordReset')])
                ]),
            ])
        ]);
    }
};
function onLogin(e) {
    if (loading$1)
        return false;
    e.preventDefault();
    const form = e.target;
    const username = form['username'].value.trim();
    const password = form['password'].value;
    const token = form['token'] ? form['token'].value : null;
    if (!username || !password)
        return;
    redraw();
    Keyboard.hide();
    loading$1 = true;
    session$1.login(username, password, token)
        .then(() => {
        loading$1 = false;
        close$1();
        signals.afterLogin.dispatch();
        redraw();
        // reconnect socket to refresh friends...
        socket.reconnectCurrent();
        challengesApi.refresh();
        session$1.refresh();
    })
        .catch((err) => {
        loading$1 = false;
        if (err.body.ipban) {
            close$1();
        }
        else {
            if (err.status !== 400 && err.status !== 401)
                handleXhrError(err);
            else {
                if (err.body.global) {
                    formError$1 = err.body.global[0];
                    redraw();
                }
            }
        }
    });
}
function isTotpError(formError) {
    return formError === 'MissingTotpToken' || formError === 'InvalidTotpToken';
}
function open$1() {
    router$1.backbutton.stack.push(slidesOutDown(close$1, 'loginModal'));
    isOpen$1 = true;
    loading$1 = false;
    formError$1 = null;
}
function close$1(fromBB) {
    Keyboard.hide();
    if (fromBB !== 'backbutton' && isOpen$1)
        router$1.backbutton.stack.pop();
    isOpen$1 = false;
}

let isOpen = false;
let loading = false;
let checkEmail = false;
let formError = null;
var signupModal = {
    open,
    close,
    view() {
        if (!isOpen)
            return null;
        return h('div.modal#signupModal', { oncreate: slidesInUp }, [
            h('header', [
                h('button.modal_close', {
                    oncreate: ontap(slidesOutDown(close, 'signupModal'))
                }, closeIcon),
                h('h2', i18n('signUp'))
            ]),
            h('div#signupModalContent.modal_content', {}, checkEmail ? renderCheckEmail() : renderForm())
        ]);
    }
};
function renderCheckEmail() {
    return [
        h('h1.signup-emailCheck.withIcon[data-icon=E]', i18n('checkYourEmail')),
        h('p', i18n('weHaveSentYouAnEmailClickTheLink')),
        h('p', i18n('ifYouDoNotSeeTheEmailCheckOtherPlaces')),
        h('p', 'Not receiving it? Visit https://lichess.org/contact to request a manual confirmation.')
    ];
}
function renderForm() {
    return [
        h('p.signupWarning.withIcon[data-icon=!]', [
            i18n('computersAreNotAllowedToPlay')
        ]),
        h('p.tosWarning', [
            'By registering, you agree to be bound by our ',
            h('a', {
                oncreate: ontap(() => window.open('https://lichess.org/terms-of-service', '_blank'))
            }, 'Terms of Service'), '.'
        ]),
        h('form.defaultForm.login', {
            onsubmit: onSignup,
        }, [
            h('div.field', [
                formError && formError.username ?
                    h('div.form-error', formError.username[0]) : null,
                h('input#pseudo[type=text]', {
                    className: formError && formError.username ? 'form-error' : '',
                    placeholder: i18n('username'),
                    autocomplete: 'off',
                    autocapitalize: 'off',
                    autocorrect: 'off',
                    spellcheck: false,
                    required: true,
                    onfocus: scrollToTop,
                    oninput: debounce(oninput, 500),
                }),
            ]),
            h('div.field', [
                formError && formError.email ?
                    h('div.form-error', formError.email[0]) : null,
                h('input#email[type=email]', {
                    onfocus: scrollToTop,
                    className: formError && formError.email ? 'form-error' : '',
                    placeholder: i18n('email'),
                    autocapitalize: 'off',
                    autocorrect: 'off',
                    spellcheck: false,
                    required: true
                })
            ]),
            h('div.field', [
                formError && formError.password ?
                    h('div.form-error', formError.password[0]) : null,
                h('input#password[type=password]', {
                    onfocus: scrollToTop,
                    className: formError && formError.password ? 'form-error' : '',
                    placeholder: i18n('password'),
                    required: true
                })
            ]),
            h('div.submit', [
                h('button.defaultButton', {
                    disabled: loading
                }, i18n('signUp'))
            ])
        ])
    ];
}
function oninput(e) {
    const val = e.target.value.trim();
    if (val && val.match(/^[a-z0-9][\w-]{2,29}$/i)) {
        testUserName(val).then(exists => {
            setUserExistsFeedback(exists);
        });
    }
    else {
        setUserExistsFeedback(false);
    }
}
function setUserExistsFeedback(exists) {
    if (exists) {
        formError = {
            username: ['This username is already in use, please try another one.']
        };
    }
    else {
        formError = null;
    }
    redraw();
}
function scrollToTop(e) {
    setTimeout(() => {
        const el = e.target;
        el.scrollIntoView(true);
    }, 300);
}
function isConfirmMailData(d) {
    return d.email_confirm !== undefined;
}
function onSignup(e) {
    e.preventDefault();
    const form = e.target;
    const login = form[0].value.trim();
    const email = form[1].value.trim();
    const pass = form[2].value;
    if (loading || !login || !email || !pass)
        return;
    Keyboard.hide();
    loading = true;
    formError = null;
    redraw();
    session$1.signup(login, email, pass)
        .then(d => {
        loading = false;
        if (d && isConfirmMailData(d)) {
            // should comfirm email
            checkEmail = true;
            redraw();
        }
        else {
            socket.reconnectCurrent();
            redraw();
            loginModal.close();
            close();
        }
    })
        .catch((error) => {
        loading = false;
        if (isSubmitError(error)) {
            formError = error.body.error;
            redraw();
        }
        else {
            handleXhrError(error);
        }
    });
}
function isSubmitError(err) {
    return err.body.error !== undefined;
}
function open() {
    router$1.backbutton.stack.push(slidesOutDown(close, 'signupModal'));
    formError = null;
    isOpen = true;
    loading = false;
}
function close(fromBB) {
    if (checkEmail === true)
        loginModal.close();
    Keyboard.hide();
    if (fromBB !== 'backbutton' && isOpen)
        router$1.backbutton.stack.pop();
    isOpen = false;
}
function testUserName(term) {
    return fetchJSON('/api/player/autocomplete?exists=1', {
        query: { term },
    });
}

const fenParams = ':r1/:r2/:r3/:r4/:r5/:r6/:r7/:r8';
function fenFromParams(params) {
    return params.r1 + '/' + params.r2 + '/' + params.r3 + '/' + params.r4 + '/' +
        params.r5 + '/' + params.r6 + '/' + params.r7 + '/' +
        params.r8.split('_').join(' ');
}
var deepLinks = {
    init() {
        void App.addListener('appUrlOpen', ({ url }) => {
            setTimeout(() => {
                const urlObject = new URL(url);
                const path = urlObject.pathname;
                const matched = links.run(path);
                if (!matched) {
                    // it can be a game or challenge but we want to do an exact regex match
                    const found = gamePattern.exec(path);
                    if (found) {
                        const color = found[2];
                        const plyMatch = plyHashPattern.exec(urlObject.hash);
                        const queryParams = {};
                        if (color) {
                            queryParams['color'] = color.substring(1);
                        }
                        if (plyMatch) {
                            queryParams['ply'] = plyMatch[1];
                        }
                        const queryString = buildQueryString(queryParams);
                        router$1.set(`/game/${found[1]}?${queryString}`);
                    }
                    else {
                        console.warn('Could not handle deep link', path);
                    }
                }
            }, 100);
        });
    }
};
const links = new Rlite();
const gamePattern = /^\/(\w{8})(\/black|\/white)?$/;
const plyHashPattern = /^#(\d+)$/;
links.add('analysis', () => router$1.set('/analyse'));
links.add(`analysis/${fenParams}`, ({ params }) => {
    const fen = encodeURIComponent(fenFromParams(params));
    router$1.set(`/analyse/fen/${fen}`);
});
links.add('editor', () => router$1.set('/editor'));
links.add(`editor/${fenParams}`, ({ params }) => {
    const fen = encodeURIComponent(fenFromParams(params));
    router$1.set(`/editor/${fen}`);
});
links.add('inbox', () => router$1.set('/inbox'));
links.add('inbox/new', () => router$1.set('/inbox/new'));
links.add('challenge/:id', ({ params }) => router$1.set(`/game/${params.id}`));
links.add('study', () => router$1.set('/study'));
links.add('study/:id', ({ params }) => router$1.set(`/study/${params.id}`));
links.add('study/:id/:chapterId', ({ params }) => router$1.set(`/study/${params.id}/${params.chapterId}`));
links.add('player', () => router$1.set('/players'));
links.add('tournament', () => router$1.set('/tournament'));
links.add('tournament/:id', ({ params }) => router$1.set(`/tournament/${params.id}`));
links.add('training', () => router$1.set('/training'));
links.add('training/:id', ({ params }) => router$1.set(`/training/${params.id}`));
links.add('tv', () => router$1.set('/tv'));
links.add('tv/:channel', ({ params }) => router$1.set(`/tv/${params.channel}`));
links.add('@/:id', ({ params }) => router$1.set(`/@/${params.id}`));
links.add('@/:id/tv', ({ params }) => router$1.set(`/@/${params.id}/tv`));
links.add('@/:id/all', ({ params }) => router$1.set(`/@/${params.id}/games`));
links.add('@/:id/perf/:key', ({ params }) => router$1.set(`/@/${params.id}/${params.key}/perf`));
links.add('signup/confirm/:token', ({ params }) => {
    const token = params.token;
    if (token) {
        session$1.confirmEmail(token)
            .then((data) => {
            signupModal.close();
            router$1.set(`/@/${data.id}`);
        })
            .catch(handleXhrError);
    }
});

/// <reference path="dts/index.d.ts" />
init$2()
    .then(() => App.getInfo().catch(() => ({ version: config.packageVersion })))
    .then((ai) => appInit(ai))
    .then(() => {
    routes.init();
    deepLinks.init();
})
    .then(init)
    .then(init$1)
    .then(() => processWindowLocation())
    .then(() => {
    setTimeout(() => {
        SplashScreen.hide();
    }, 500);
})
    .then(() => YaGames.init())
    .then((ysdk) => {
    console.log('Yandex SDK initialized');
    ysdk.features.LoadingAPI?.ready();
}).catch((e) => console.log(e));

export { Toast as $, App as A, formatNumber as B, newGameForm as C, challengeForm as D, getLI as E, viewFadeIn as F, dropShadowHeader as G, safeStringToNum as H, backButton as I, prop as J, handleXhrError as K, i18nVdom as L, popup as M, Network as N, formWidgets as O, specialFenVariants as P, getVariant as Q, sound as R, oppositeColor as S, uciToMoveOrDrop as T, classSet as U, ViewOnlyBoard as V, WebPlugin as W, isPortrait as X, viewportDim as Y, Zanimo as Z, hasSpaceForInlineReplay as _, signals as a, parseFen as a$, header as a0, uciToProm as a1, uciToDropPos as a2, uciToDropRole as a3, aiName as a4, getRandomArbitrary as a5, Chessground as a6, animationDuration as a7, boardOrientation as a8, standardFen as a9, viewSlideIn as aA, formatDate as aB, lichessAssetSrc as aC, formatDuration as aD, progress as aE, uciToMove as aF, uciTolastDrop as aG, miniUser as aH, userStatus as aI, playerName as aJ, lobby as aK, findParentBySelector as aL, menuButton as aM, headerBtns as aN, loader as aO, renderRatingDiff as aP, key2pos as aQ, pos2key as aR, isGameData as aS, ontouch as aT, formatTimeInSecs as aU, tupleOf as aV, move as aW, end as aX, INITIAL_FEN as aY, EMPTY_FEN as aZ, loadLocalJsonFile as a_, ontapX as aa, fixCrazySan as ab, acceptChallenge$1 as ac, challengesApi as ad, declineChallenge$1 as ae, cancelChallenge$1 as af, getChallenge as ag, registerPlugin as ah, loginModal as ai, positionsCache as aj, loadingBackbutton as ak, connectingHeader as al, pageSlideIn as am, elFadeIn as an, game as ao, storage as ap, Dialog as aq, gamesMenu as ar, getLichessVariant as as, getInitialFen as at, bookmarkButton as au, asyncStorage as av, serializeQueryParameters as aw, config as ax, batchRequestAnimationFrame as ay, toggleGameBookmark as az, session$1 as b, makeSquare as b$, Board as b0, parseCastlingFen as b1, makeFen as b2, Material as b3, RemainingChecks as b4, isTablet as b5, loadConvo as b6, getMore as b7, loadContacts as b8, search as b9, newAiGame as bA, EDGE_SLIDE_THRESHOLD as bB, closeIcon as bC, announce$1 as bD, backdropCloseHandler as bE, signupModal as bF, getSystemTheme as bG, getButton as bH, elSlideIn as bI, formatTournamentTimeControl as bJ, formatTournamentDuration as bK, capitalize as bL, pad as bM, secondsToMinutes as bN, slidesOutDown as bO, Keyboard as bP, requestIdleCallback as bQ, slidesInUp as bR, LRUMap as bS, fetchText as bT, SESSION_ID_KEY as bU, toNumber as bV, askWorker as bW, loadCss as bX, loadScript as bY, isDrop as bZ, roleToChar as b_, del as ba, block as bb, unblock as bc, MessageSocket as bd, closest as be, backArrow as bf, ontapXY as bg, autofocus as bh, closestHandler as bi, cgFen as bj, lightPlayerName as bk, getMenuWidth as bl, translateMenu as bm, backdropOpacity as bn, BACKDROP_OPACITY as bo, OPEN_AFTER_SLIDE_RATIO as bp, mainMenuCtrl as bq, profileMenuOpen as br, toggleHeader as bs, inboxUnreadCount as bt, friendsApi as bu, ping as bv, mlat as bw, route as bx, action as by, friendsPopup as bz, fromNow as c, squareFile as c0, SquareSet as c1, squareRank as c2, FILE_NAMES as c3, RANK_NAMES as c4, parseUci as c5, importMasterGame as c6, shallowEqual as c7, opposite$1 as c8, Capacitor as c9, loadLanguage as cA, base62ToNumber as cB, slidesInLeft as cC, slidesOutRight as cD, getTR as cE, connectingDropShadowHeader as cF, noNull as cG, expandLess as cH, expandMore as cI, randomColor as cJ, status as cK, buildRequestInit as cL, Encoding as cM, altCastles as ca, currentSri as cb, SideMenuCtrl as cc, decomposeUci as cd, sanToRole as ce, openingSensibleVariants as cf, chessopRulesFromVariant as cg, formatDateTime as ch, readDests as ci, kingCastlesTo as cj, COLORS as ck, defined as cl, CASTLING_SIDES as cm, n as cn, opposite as co, isTransparent as cp, loadImage as cq, handleError as cr, getLocalFiles as cs, filename as ct, onBoardThemeChange as cu, allLocales as cv, getDefaultLocaleForLang as cw, allKeys$1 as cx, getCurrentLocale as cy, setServerLang as cz, debounce as d, seeks as e, fetchJSON as f, settings as g, throttle as h, isForeground as i, featured as j, hasNetwork as k, lobby$1 as l, h as m, noop$1 as n, i18n as o, ontapY as p, router$1 as q, redraw as r, socket as s, timeline as t, distanceToNowStrict as u, renderQuickSetup as v, spinner as w, ontap as x, plural as y, gameIcon as z };
//# sourceMappingURL=main.js.map
