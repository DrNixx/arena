import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, k as hasNetwork, b as session, O as formWidgets, g as settings } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { render, prefsCtrl } from './gameBehavior-CU7UaCoj.js';
import './prefs-CFmBYsqy.js';

var gameBehavior = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('gameBehavior')));
        return layout.free(header, h('ul.native_scroller.page.settings_list.multiChoices', renderAppPrefs().concat(hasNetwork() && session.isConnected() ?
            render(prefsCtrl) : [])));
    }
};
function renderAppPrefs() {
    return [
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('howDoYouMovePieces'), [
            { label: i18n('clickTwoSquares'), value: 'tap' },
            { label: i18n('dragPiece'), value: 'drag' },
            { label: i18n('bothClicksAndDrag'), value: 'both' },
        ], settings.game.pieceMove)),
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('castleByMovingTheKingTwoSquaresOrOntoTheRook'), [
            { label: i18n('castleByMovingTwoSquares'), value: 0 },
            { label: i18n('castleByMovingOntoTheRook'), value: 1 },
        ], settings.game.rookCastle)),
    ];
}

export { gameBehavior as default };
//# sourceMappingURL=gameBehavior-BJh8CzLt.js.map
