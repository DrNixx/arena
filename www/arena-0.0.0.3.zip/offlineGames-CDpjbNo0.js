import { av as asyncStorage } from './main.js';

const OTB_STORAGE_KEY = 'otb.current';
const AI_STORAGE_KEY = 'ai.current';
function getCurrentOTBGame() {
    return asyncStorage.get(OTB_STORAGE_KEY);
}
function setCurrentOTBGame(game) {
    return asyncStorage.set(OTB_STORAGE_KEY, game);
}
function getCurrentAIGame() {
    return asyncStorage.get(AI_STORAGE_KEY);
}
function setCurrentAIGame(game) {
    return asyncStorage.set(AI_STORAGE_KEY, game);
}
function getAnalyseData(data, orientation) {
    if (!data)
        return null;
    const aData = data.data;
    aData.orientation = orientation;
    aData.treeParts = data.situations.map((o) => {
        const node = {
            // bc layer TODO remove in version 5.4
            id: o.id || o.nodeId,
            fen: o.fen,
            ply: o.ply,
            check: o.check,
            checkCount: o.checkCount,
            // uciMoves contains at least situation last move
            // bc layer TODO remove in version 5.4
            uci: o.uci || o.uciMoves[o.uciMoves.length - 1],
            san: o.san || o.pgnMoves.length ? o.pgnMoves[o.pgnMoves.length - 1] : undefined,
            dests: o.dests,
            drops: o.drops,
            crazyhouse: o.crazyhouse,
            pgnMoves: o.pgnMoves,
            end: o.end,
            player: o.player,
            children: []
        };
        return node;
    });
    return aData;
}

export { setCurrentAIGame as a, getCurrentAIGame as b, getAnalyseData as c, getCurrentOTBGame as g, setCurrentOTBGame as s };
//# sourceMappingURL=offlineGames-CDpjbNo0.js.map
