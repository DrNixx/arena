import { r as redraw, q as router, h as throttle, K as handleXhrError, b as session, a0 as header$1, m as h, o as i18n, x as ontap, g as settings, bf as backArrow, bh as autofocus, p as ontapY, w as spinner, E as getLI, F as viewFadeIn, s as socket, H as safeStringToNum } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { s as search, g as getPopularTeams, a as getUserTeams } from './teamsXhr-Bkb9l9T6.js';
import { T as TabNavigation, a as TabView } from './TabView-CG79fzxt.js';

class TeamsListCtrl {
    constructor(defaultTab) {
        this.isSearchOpen = false;
        this.onTabChange = (tabIndex) => {
            const loc = window.location.search.replace(/\?tab=\w+$/, '');
            try {
                window.history.replaceState(window.history.state, '', loc + '?tab=' + tabIndex);
            }
            catch (e) {
                console.error(e);
            }
            this.currentTab = tabIndex;
            redraw();
        };
        this.closeSearch = (fromBB) => {
            if (fromBB !== 'backbutton' && this.isSearchOpen)
                router.backbutton.stack.pop();
            this.isSearchOpen = false;
        };
        this.onInput = throttle((e) => {
            const term = e.target.value.trim();
            if (term.length >= 3)
                search(term).then(data => {
                    this.searchResults = data;
                    redraw();
                });
        }, 1000);
        this.goSearch = () => {
            router.backbutton.stack.push(this.closeSearch);
            this.isSearchOpen = true;
        };
        this.goToTeam = (team) => {
            router.set('/teams/' + team.id);
        };
        this.currentTab = defaultTab || 0;
        getPopularTeams()
            .then(data => {
            this.allTeams = data;
            redraw();
        })
            .catch(handleXhrError);
        const user = session.getUserId();
        if (user) {
            getUserTeams(user)
                .then(data => {
                this.myTeams = data;
                redraw();
            })
                .catch(handleXhrError);
        }
    }
}

function header(ctrl) {
    return header$1(h('div.teams_main_header', [
        h('div.main_header_title', i18n('teams')),
        h('button.main_header_button[data-icon=y]', {
            oncreate: ontap(ctrl.goSearch)
        })
    ]));
}
function body(ctrl) {
    const tabsContent = [
        { id: 'allTeams', f: () => renderAllTeams(ctrl) },
        { id: 'myTeams', f: () => renderMyTeams(ctrl) },
    ];
    return [
        h('div.tabs-nav-header.subHeader', h(TabNavigation, {
            buttons: [
                { label: i18n('allTeams') },
                { label: i18n('myTeams') },
            ],
            selectedIndex: ctrl.currentTab,
            onTabChange: ctrl.onTabChange
        })),
        h(TabView, {
            selectedIndex: ctrl.currentTab,
            tabs: tabsContent,
            onTabChange: ctrl.onTabChange,
        })
    ];
}
function searchModal(ctrl) {
    if (!ctrl.isSearchOpen)
        return null;
    const className = [
        'modal',
        'show',
        settings.general.theme.background()
    ].join(' ');
    return h('div.' + className, { 'id': 'searchTeamsModal' }, [
        h('header.main_header', [
            h('button.main_header_button', { 'oncreate': ontap(() => ctrl.closeSearch()) }, [backArrow]),
            h('div.search_input.allow_select', [
                h('input', { 'id': 'searchTeams', 'type': 'search', 'placeholder': i18n('search'), 'oninput': ctrl.onInput,
                    'autocapitalize': 'off', 'autocomplete': 'off', 'oncreate': autofocus })
            ])
        ]),
        h('ul.modal_content.native_scroller', { 'oncreate': ontapY(onTeamTap, undefined, getLI) }, [
            ctrl.searchResults ? ctrl.searchResults.currentPageResults.map(renderTeam) : null
        ])
    ]);
}
function renderAllTeams(ctrl) {
    if (!ctrl.allTeams) {
        return h('div.loader_container', [
            spinner.getVdom('monochrome')
        ]);
    }
    return h('ul.teamsSuggestion.native_scroller.page', { 'oncreate': ontapY(onTeamTap, undefined, getLI) }, [ctrl.allTeams.currentPageResults.map(renderTeam)]);
}
function renderMyTeams(ctrl) {
    if (!ctrl.myTeams) {
        return h('div.loader_container', [
            spinner.getVdom('monochrome')
        ]);
    }
    return h('ul.teamsSuggestion.native_scroller.page', { 'oncreate': ontapY(onTeamTap, undefined, getLI) }, [ctrl.myTeams.map(renderTeam)]);
}
function onTeamTap(e) {
    const el = getLI(e);
    const ds = el?.dataset;
    if (ds.id) {
        router.set('/teams/' + ds.id);
    }
}
function renderTeam(team, i) {
    const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
    return h('li.list_item.teamSuggestion.nav.' + evenOrOdd, { 'data-id': team.id }, [
        team.name,
        h('span.nbMembers', [
            team.nbMembers
        ])
    ]);
}

var teamsList = {
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = new TeamsListCtrl(safeStringToNum(attrs.tab));
    },
    oncreate: viewFadeIn,
    view() {
        const ctrl = this.ctrl;
        const headerCtrl = header(ctrl);
        const bodyCtrl = body(ctrl);
        const searchModalCtrl = searchModal(ctrl);
        return layout.free(headerCtrl, bodyCtrl, undefined, searchModalCtrl);
    }
};

export { teamsList as default };
//# sourceMappingURL=teamsList-CO84qUbw.js.map
