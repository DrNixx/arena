import { ac as acceptChallenge, q as router, ad as challengesApi, ae as declineChallenge, af as cancelChallenge, ag as getChallenge, s as socket, W as WebPlugin, ah as registerPlugin, a0 as header, a9 as standardFen, b as session, m as h, o as i18n, x as ontap, M as popup, w as spinner, ai as loginModal, $ as Toast, aj as positionsCache, ak as loadingBackbutton, al as connectingHeader, am as pageSlideIn, an as elFadeIn, ao as game$1, r as redraw, K as handleXhrError, R as sound, Q as getVariant, ap as storage, aq as Dialog, ar as gamesMenu } from './main.js';
import { v as vibrate } from './vibrate-CyNrNHlt.js';
import { e as emptyFen } from './fen-97CPMMDI.js';
import { a as isSupportedVariant, i as isPlayerPlaying, n as nbMoves } from './game-CgD9Ef6g.js';
import { v as viewOnlyBoardContent, e as view } from './crazyValid-BQyVE87l.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { O as OnlineRound } from './OnlineRound-Buu5hzF8.js';
import { S as Share } from './index-r4T5Y9G7.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './GameTitle-CU8rmgNb.js';
import './CountdownTimer-sy6et_C9.js';
import './Board-UV3Z06Mn.js';
import './promotion-yOaF5Jgj.js';
import './tournamentXhr-kOGDWEN6.js';
import './toInteger-bGq5KERl.js';
import './chat-Dbn1ft42.js';

function isOnlineGameData(d) {
    return d.url !== undefined;
}

class ChallengeCtrl {
    constructor(data) {
        this.data = data;
        this.joinChallenge = () => {
            const c = this.challenge;
            if (c) {
                return acceptChallenge(c.id)
                    .then(d => {
                    clearTimeout(this.pingTimeoutId);
                    router.set('/game' + d.url.round, true);
                })
                    .then(() => challengesApi.remove(c.id));
            }
            return Promise.reject('no challenge');
        };
        this.declineChallenge = () => {
            const c = this.challenge;
            if (c) {
                return declineChallenge(c.id)
                    .then(() => {
                    clearTimeout(this.pingTimeoutId);
                    challengesApi.remove(c.id);
                })
                    .then(router.backHistory);
            }
            return Promise.reject('no challenge');
        };
        this.cancelChallenge = () => {
            const c = this.challenge;
            if (c) {
                return cancelChallenge(c.id)
                    .then(() => {
                    clearTimeout(this.pingTimeoutId);
                    challengesApi.remove(c.id);
                })
                    .then(router.backHistory);
            }
            return Promise.reject('no challenge');
        };
        this.unload = () => {
            clearTimeout(this.pingTimeoutId);
        };
        this.reloadChallenge = () => {
            const c = this.challenge;
            if (c) {
                getChallenge(c.id)
                    .then(d => {
                    this.challenge = d.challenge;
                    switch (d.challenge.status) {
                        case 'accepted':
                            router.set(`/game/${d.challenge.id}`, true);
                            break;
                        case 'declined':
                            router.backHistory();
                            break;
                    }
                });
            }
        };
        this.pingNow = () => {
            clearTimeout(this.pingTimeoutId);
            this.pingTimeoutId = setTimeout(this.pingNow, 2000);
            if (this.socket)
                this.socket.send('ping');
        };
        this.onSocketOpen = () => {
            // reload on open in case the reload msg has not been received
            this.reloadChallenge();
            this.pingNow();
        };
        this.challenge = data.challenge;
        this.socket = socket.createChallenge(data.challenge.id, data.socketVersion, this.onSocketOpen, {
            reload: this.reloadChallenge
        });
    }
}

class ClipboardWeb extends WebPlugin {
    async write(options) {
        if (typeof navigator === 'undefined' || !navigator.clipboard) {
            throw this.unavailable('Clipboard API not available in this browser');
        }
        if (options.string !== undefined) {
            await this.writeText(options.string);
        }
        else if (options.url) {
            await this.writeText(options.url);
        }
        else if (options.image) {
            if (typeof ClipboardItem !== 'undefined') {
                try {
                    const blob = await (await fetch(options.image)).blob();
                    const clipboardItemInput = new ClipboardItem({ [blob.type]: blob });
                    await navigator.clipboard.write([clipboardItemInput]);
                }
                catch (err) {
                    throw new Error('Failed to write image');
                }
            }
            else {
                throw this.unavailable('Writing images to the clipboard is not supported in this browser');
            }
        }
        else {
            throw new Error('Nothing to write');
        }
    }
    async read() {
        if (typeof navigator === 'undefined' || !navigator.clipboard) {
            throw this.unavailable('Clipboard API not available in this browser');
        }
        if (typeof ClipboardItem !== 'undefined') {
            try {
                const clipboardItems = await navigator.clipboard.read();
                const type = clipboardItems[0].types[0];
                const clipboardBlob = await clipboardItems[0].getType(type);
                const data = await this._getBlobData(clipboardBlob, type);
                return { value: data, type };
            }
            catch (err) {
                return this.readText();
            }
        }
        else {
            return this.readText();
        }
    }
    async readText() {
        if (typeof navigator === 'undefined' ||
            !navigator.clipboard ||
            !navigator.clipboard.readText) {
            throw this.unavailable('Reading from clipboard not supported in this browser');
        }
        const text = await navigator.clipboard.readText();
        return { value: text, type: 'text/plain' };
    }
    async writeText(text) {
        if (typeof navigator === 'undefined' ||
            !navigator.clipboard ||
            !navigator.clipboard.writeText) {
            throw this.unavailable('Writting to clipboard not supported in this browser');
        }
        await navigator.clipboard.writeText(text);
    }
    _getBlobData(clipboardBlob, type) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            if (type.includes('image')) {
                reader.readAsDataURL(clipboardBlob);
            }
            else {
                reader.readAsText(clipboardBlob);
            }
            reader.onloadend = () => {
                const r = reader.result;
                resolve(r);
            };
            reader.onerror = e => {
                reject(e);
            };
        });
    }
}

const Clipboard = registerPlugin('Clipboard', {
    web: () => new ClipboardWeb(),
});

function challengeView(ctrl) {
    let overlay = undefined;
    let board = viewOnlyBoardContent(standardFen, 'white');
    const challenge = ctrl.challenge;
    const header$1 = header('Chess-Online Arena');
    if (challenge) {
        board = viewOnlyBoardContent(challenge.initialFen || standardFen, 'white');
        if (challenge.direction === 'in') {
            overlay = joinPopup(ctrl, challenge);
        }
        else if (challenge.direction === 'out') {
            if (challenge.destUser) {
                overlay = awaitChallengePopup(ctrl, challenge);
            }
            else {
                overlay = awaitInvitePopup(ctrl, challenge);
            }
        }
    }
    return layout.board(header$1, board, 'challenge', overlay);
}
function publicUrl(challenge) {
    return 'https://lichess.org/' + challenge.id;
}
function gameInfos(challenge) {
    const mode = challenge.rated ? i18n('rated') : i18n('casual');
    const time = challengesApi.challengeTime(challenge);
    return (h("div", { className: "gameInfos" },
        h("span", { "data-icon": "p" }, time),
        " \u2022 ",
        h("span", null, challenge.variant.name),
        " \u2022 ",
        h("span", null, mode)));
}
function joinPopup(ctrl, challenge) {
    let joinDom;
    if (challenge.rated && !session.isConnected()) {
        joinDom = h('div.error', [
            i18n('thisGameIsRated'), h('br'), h('br'), i18n('youNeedAnAccountToDoThat'),
            h('div.go_or_cancel', [
                h('button.binary_choice[data-icon=E].withIcon', {
                    oncreate: ontap(loginModal.open)
                }, i18n('signIn')),
                h('button.binary_choice[data-icon=L].withIcon', {
                    oncreate: ontap(router.backHistory)
                }, i18n('cancel'))
            ])
        ]);
    }
    else if (session.isConnected()) {
        joinDom = h('div.go_or_cancel', [
            h('button.binary_choice[data-icon=E].withIcon', {
                oncreate: ontap(ctrl.joinChallenge)
            }, i18n('join')),
            h('button.binary_choice[data-icon=L].withIcon', {
                oncreate: ontap(ctrl.declineChallenge)
            }, i18n('decline'))
        ]);
    }
    else {
        joinDom = h('div', [
            h('button[data-icon=E].withIcon', {
                oncreate: ontap(ctrl.joinChallenge)
            }, i18n('join'))
        ]);
    }
    const challenger = challenge.challenger ?
        i18n('playerisInvitingYou', challengeUserFormat(challenge.challenger)) :
        i18n('playerisInvitingYou', 'Anonymous');
    return popup('join_url_challenge', undefined, function () {
        return h('div.infos', [
            h('div.challenger', challenger),
            h('br'),
            gameInfos(challenge),
            h('br'),
            joinDom
        ]);
    }, true);
}
function awaitInvitePopup(ctrl, challenge) {
    const isPersistent = challengesApi.isPersistent(challenge);
    return popup('await_url_challenge', undefined, function () {
        return h('div.infos', [
            gameInfos(challenge),
            h('br'),
            h('p.explanation', i18n('toInviteSomeoneToPlayGiveThisUrl')),
            h('div.copy_container', [
                h('div.icon_container', [
                    h('span.fa.fa-clipboard')
                ]),
                h('input.lichess_game_url', {
                    oncreate: ontap(function () {
                        Clipboard.write({ url: publicUrl(challenge) });
                        Toast.show({ text: 'Copied to clipboard', position: 'center', duration: 'short' });
                    }),
                    value: publicUrl(challenge),
                    readonly: true
                })
            ]),
            h('p.explanation.small', i18n('theFirstPersonToComeOnThisUrlWillPlayWithYou')),
            h('div.go_or_cancel.clearfix', [
                h('button.binary_choice[data-icon=E].withIcon', {
                    oncreate: ontap(function () {
                        Share.share({ url: publicUrl(challenge) });
                    })
                }, i18n('shareGameUrl')),
                h('button.binary_choice[data-icon=L].withIcon', {
                    oncreate: ontap(ctrl.cancelChallenge)
                }, i18n('cancel'))
            ]),
            isPersistent ? h('div', [
                h('br'),
                h('button', {
                    oncreate: ontap(() => router.set('/'))
                }, [h('span.fa.fa-home'), i18n('Return to home')])
            ]) : null
        ]);
    }, true);
}
function challengeUserFormat(user) {
    const ratingString = user.rating + (user.provisional ? '?' : '');
    return `${user.name} (${ratingString})`;
}
function awaitChallengePopup(ctrl, challenge) {
    // destUser is there in await challenge
    // todo: discriminate in types
    function popupContent() {
        return h('div.infos', [
            h('div', i18n('waitingForOpponent')),
            h('br'),
            h('div.user', challengeUserFormat(challenge.destUser)),
            gameInfos(challenge),
            h('br'),
            spinner.getVdom(),
            h('br'),
            h('br'),
            h('button.withIcon[data-icon=L]', {
                oncreate: ontap(ctrl.cancelChallenge)
            }, i18n('cancel')),
            challengesApi.isPersistent(challenge) ? h('div', [
                h('br'),
                h('button', {
                    oncreate: ontap(() => router.set('/'))
                }, [h('span.fa.fa-home'), i18n('Return to home')])
            ]) : null
        ]);
    }
    return popup('await_url_challenge', undefined, popupContent, true);
}

var game = {
    oninit(vnode) {
        const now = performance.now();
        game$1(vnode.attrs.id, vnode.attrs.color)
            .then(data => {
            if (isChallengeData(data)) {
                vnode.state.challenge = new ChallengeCtrl(data);
                redraw();
            }
            else if (isOnlineGameData(data)) {
                loadRound(vnode, now, data);
            }
        })
            .catch(error => {
            handleXhrError(error);
            router.set('/');
        });
    },
    oncreate(vnode) {
        if (vnode.attrs.goingBack) {
            pageSlideIn(vnode.dom);
        }
        else {
            elFadeIn(vnode.dom);
        }
    },
    onremove() {
        socket.destroy();
        if (this.round) {
            this.round.unload();
        }
        if (this.challenge) {
            this.challenge.unload();
        }
    },
    view({ attrs }) {
        if (this.round)
            return view(this.round);
        if (this.challenge)
            return challengeView(this.challenge);
        const pov = gamesMenu.lastJoined();
        let board;
        if (pov) {
            board = viewOnlyBoardContent(pov.fen, pov.color, pov.lastMove, pov.variant.key);
        }
        else {
            const g = positionsCache.get(attrs.id);
            if (g)
                board = viewOnlyBoardContent(g.fen, g.orientation);
            else
                board = viewOnlyBoardContent(emptyFen, 'white');
        }
        return layout.board(attrs.goingBack ? loadingBackbutton() : connectingHeader(), board);
    }
};
function loadRound(vnode, time, data) {
    if (!data.player.spectator && !isSupportedVariant(data)) {
        Toast.show({ text: i18n('unsupportedVariant', data.game.variant.name), position: 'center', duration: 'short' });
        router.set('/');
    }
    else {
        if (isPlayerPlaying(data) &&
            nbMoves(data, data.player.color) === 0) {
            sound.dong();
            vibrate.quick();
            const variant = getVariant(data.game.variant.key);
            const storageKey = variantStorageKey(data.game.variant.key);
            if (variant.alert && [1, 3].indexOf(variant.id) === -1 &&
                !storage.get(storageKey)) {
                Dialog.alert({
                    title: 'Alert',
                    message: variant.alert
                }).then(() => {
                    storage.set(storageKey, true);
                });
            }
        }
        const elapsed = performance.now() - time;
        setTimeout(() => {
            const plyCast = Number(vnode.attrs.ply);
            const ply = isNaN(plyCast) ? undefined : plyCast;
            vnode.state.round = new OnlineRound(!!vnode.attrs.goingBack, vnode.attrs.id, data, false, undefined, undefined, ply);
        }, Math.max(400 - elapsed, 0));
        gamesMenu.resetLastJoined();
        if (data.player.user === undefined) {
            storage.set('lastPlayedGameURLAsAnon', data.url.round);
        }
    }
}
function isChallengeData(d) {
    return d.challenge !== undefined;
}
function variantStorageKey(variant) {
    return 'game.variant.prompt.' + variant;
}

export { game as default };
//# sourceMappingURL=game-DQG4_Lsl.js.map
