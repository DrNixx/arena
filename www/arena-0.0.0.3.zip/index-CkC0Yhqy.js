class StockfishWeb {
    async getMaxMemory() {
        return Promise.resolve({ value: 1024 });
    }
    async start() {
        return new Promise((resolve) => {
            if (this.worker) {
                setTimeout(resolve, 1);
            }
            else {
                this.worker = new Worker('../stockfish.js');
                this.worker.onmessage = msg => {
                    const ev = new Event('stockfish');
                    ev['output'] = msg.data;
                    window.dispatchEvent(ev);
                };
                setTimeout(resolve, 1);
            }
        }).then(() => { });
    }
    async cmd({ cmd }) {
        return new Promise((resolve) => {
            if (this.worker)
                this.worker.postMessage(cmd);
            setTimeout(resolve, 1);
        }).then(() => { });
    }
    async exit() {
        return new Promise((resolve) => {
            if (this.worker) {
                this.worker.terminate();
                this.worker = undefined;
            }
            setTimeout(resolve, 1);
        }).then(() => { });
    }
}

class StockfishPlugin {
    constructor(variant) {
        this.variant = variant;
        this.plugin = new StockfishWeb();
    }
    async start() {
        return new Promise((resolve) => {
            let engineName = 'Stockfish';
            const listener = (e) => {
                const line = e.output;
                console.debug('[stockfish >>] ' + line);
                if (line.startsWith('id name ')) {
                    engineName = line.substring('id name '.length);
                }
                if (line.startsWith('uciok')) {
                    window.removeEventListener('stockfish', listener, false);
                    resolve({ engineName });
                }
            };
            window.addEventListener('stockfish', listener, { passive: true });
            void this.plugin.start().then(() => this.send('uci'));
        });
    }
    isReady() {
        return new Promise((resolve) => {
            const listener = (e) => {
                const line = e.output;
                if (line.startsWith('readyok')) {
                    window.removeEventListener('stockfish', listener, false);
                    resolve();
                }
            };
            window.addEventListener('stockfish', listener, { passive: true });
            void this.send('isready');
        });
    }
    send(text) {
        console.debug('[stockfish <<] ' + text);
        return this.plugin.cmd({ cmd: text });
    }
    setOption(name, value) {
        return this.send(`setoption name ${name} value ${value}`);
    }
    setVariant() {
        if (this.isVariant()) {
            return this.setOption('UCI_Variant', 'giveaway');
        }
        else {
            return this.setOption('UCI_Chess960', 'chess960' === this.variant);
        }
    }
    exit() {
        return this.plugin.exit();
    }
    isVariant() {
        return !(this.variant === 'standard' ||
            this.variant === 'fromPosition' ||
            this.variant === 'chess960');
    }
}
function getNbCores() {
    const cores = window.deviceInfo.cpuCores;
    return cores > 2 ? cores - 1 : 1;
}

export { StockfishPlugin as S, getNbCores as g };
//# sourceMappingURL=index-CkC0Yhqy.js.map
