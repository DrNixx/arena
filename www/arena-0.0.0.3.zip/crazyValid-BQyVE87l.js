import { M as popup, m as h, w as spinner, b as session, aI as userStatus, x as ontap, aC as lichessAssetSrc, o as i18n, z as gameIcon, L as i18nVdom, aJ as playerName, q as router, U as classSet, r as redraw, y as plural, k as hasNetwork, aK as lobby, K as handleXhrError, ay as batchRequestAnimationFrame, aL as findParentBySelector, g as settings, aa as ontapX, p as ontapY, ab as fixCrazySan, X as isPortrait, Y as viewportDim, V as ViewOnlyBoard, _ as hasSpaceForInlineReplay, I as backButton, au as bookmarkButton, aM as menuButton, aN as headerBtns, s as socket, al as connectingHeader, aO as loader, aP as renderRatingDiff, a4 as aiName, n as noop, $ as Toast, aQ as key2pos, aR as pos2key } from './main.js';
import { h as berserkableBy, m as moretimeable, g as gameStatus, u as userAnalysable, j as replayable, k as forceResignable, l as resignable, o as publicUrl, p as playable, q as isPlayerTurn, t as title, v as forecastable, r as result, f as getPlayer, w as abortable, x as takebackable } from './game-CgD9Ef6g.js';
import { p as perfTypes } from './perfs-BLfNpglP.js';
import { e as emptyFen } from './fen-97CPMMDI.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { c as countries } from './countries-D-Tn65Re.js';
import { G as GameTitle } from './GameTitle-CU8rmgNb.js';
import { C as CountdownTimer } from './CountdownTimer-sy6et_C9.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import { p as promotion$1 } from './promotion-yOaF5Jgj.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { w as withdraw } from './tournamentXhr-kOGDWEN6.js';
import { a as getPGN, t as toInteger, n as notesView, C as CrazyPocket } from './toInteger-bGq5KERl.js';
import { c as chatView } from './chat-Dbn1ft42.js';

var PlayerPopup = {
    view({ attrs }) {
        const { player, mini, isOpen, close, opponent, score } = attrs;
        const user = player.user;
        return user ? popup('miniUserInfos', undefined, () => content(mini, player, opponent, score), isOpen, close) : null;
    }
};
function content(mini, player, opponent, score) {
    const user = player.user;
    if (!mini || !user) {
        return (h("div", { className: "miniUser" }, spinner.getVdom()));
    }
    const isMe = session.getUserId() === user.id;
    const oppUser = opponent.user;
    const status = userStatus(user);
    const curSess = session.get();
    const sessionUserId = curSess && curSess.id;
    const showYourScore = sessionUserId && mini.crosstable && mini.crosstable.nbGames > 0;
    return (h("div", { className: "miniUser" },
        h("div", { className: "title" },
            h("div", { className: "username", oncreate: ontap(() => router.set(`/@/${user.username}`)) }, status),
            user.profile && user.profile.country ?
                h("p", { className: "country" },
                    h("img", { className: "flag", src: lichessAssetSrc('images/flags/' + user.profile.country + '.png') }),
                    countries[user.profile.country]) : null),
        user.tosViolation ?
            h("div", { className: "warning" }, user.tosViolation ? i18n('thisAccountViolatedTos') : '') : null,
        mini.perfs ?
            h("div", { className: "mini_perfs" }, Object.keys(mini.perfs).map((p) => {
                const perf = mini.perfs[p];
                return (h("div", { className: "perf" },
                    h("span", { "data-icon": gameIcon(p) }),
                    perf.games > 0 ? perf.rating + (perf.prov ? '?' : '') : '-'));
            })) : null,
        sessionUserId !== undefined && showYourScore ?
            h("div", { className: "score_wrapper" }, i18nVdom('yourScore', h("span", { className: "score" }, `${mini.crosstable.users[sessionUserId]} - ${mini.crosstable.users[user.id]}`))) : null,
        !showYourScore && oppUser && score && score.nbGames > 0 ?
            h("div", { className: "score_wrapper" },
                "Lifetime score ",
                h("em", null, "vs"),
                " ",
                playerName(opponent),
                ":",
                h("br", null),
                h("span", { className: "score" }, score.users[user.id]),
                " - ",
                h("span", { className: "score" }, score.users[oppUser.id])) : null,
        !isMe ?
            h("div", { className: "mini_user_actions_wrapper" },
                h("button", { "data-icon": "1", oncreate: ontap(() => {
                        router.set(`/@/${user.id}/tv`);
                    }) }, i18n('watchGames'))) : null));
}

var Clock = {
    oninit({ attrs }) {
        const { ctrl, color } = attrs;
        this.clockOnCreate = ({ dom }) => {
            ctrl.elements[color] = dom;
            ctrl.updateElement(color, ctrl.millisOf(color));
        };
        this.clockOnUpdate = ({ dom }) => {
            ctrl.elements[color] = dom;
            ctrl.updateElement(color, ctrl.millisOf(color));
        };
    },
    view({ attrs }) {
        const { ctrl, color, isBerserk } = attrs;
        const time = ctrl.millisOf(color);
        const isRunning = color === ctrl.times.activeColor;
        const className = classSet({
            clock: true,
            outoftime: !time,
            running: isRunning,
            berserk: isBerserk
        });
        return h('div', {
            className,
            oncreate: this.clockOnCreate,
            onupdate: this.clockOnUpdate,
        }, formatClockTime$1(time, false));
    }
};
const sepHigh = ':';
const sepLow = ' ';
function formatClockTime$1(time, showTenths, isRunning = false) {
    const date = new Date(time);
    const millis = date.getUTCMilliseconds();
    const minutes = pad2(date.getUTCMinutes());
    const seconds = pad2(date.getUTCSeconds());
    if (time >= 3600000) {
        const hours = pad2(date.getUTCHours());
        const pulse = (isRunning && millis < 500) ? sepLow : sepHigh;
        return hours + pulse + minutes;
    }
    else if (showTenths) {
        let tenthsStr = Math.floor(millis / 100).toString();
        if (!isRunning && time < 1000) {
            tenthsStr += '<huns>' + (Math.floor(millis / 10) % 10) + '</huns>';
        }
        return minutes + sepHigh + seconds + '<tenths>.' + tenthsStr + '</tenths>';
    }
    return minutes + sepHigh + seconds;
}
function pad2(num) {
    return (num < 10 ? '0' : '') + num;
}

function start(ctrl, orig, dest, isPremove) {
    const piece = ctrl.chessground.state.pieces.get(dest);
    if (piece && piece.role === 'pawn' && ((dest[1] === '8' && ctrl.player() === 'white') ||
        (dest[1] === '1' && ctrl.player() === 'black'))) {
        if (ctrl.data.pref.autoQueen === 3 || (ctrl.data.pref.autoQueen === 2 && isPremove))
            return false;
        ctrl.promoting = {
            orig, dest,
            callback: (orig, dest, role) => ctrl.sendMove(orig, dest, role)
        };
        redraw();
        return true;
    }
    return false;
}
function cancel(ctrl) {
    if (ctrl.promoting)
        ctrl.reloadGameData();
    ctrl.promoting = null;
}
var promotion = {
    start: start,
    view: (ctrl) => promotion$1.view(ctrl, cancel)
};

var gameButton = {
    standard(ctrl, condition, icon, hint, socketMsg, onTap) {
        return condition(ctrl.data) && hasNetwork() ? h('button', {
            className: socketMsg,
            'data-icon': icon,
            oncreate: ontap(onTap ? onTap : () => { ctrl.socket.iface.send(socketMsg); })
        }, i18n(hint)) : null;
    },
    bookmark(ctrl) {
        return session.isConnected() ? h('button', {
            oncreate: ontap(ctrl.toggleBookmark),
            'data-icon': ctrl.data.bookmarked ? 't' : 's'
        }, [i18n('bookmarkThisGame')]) : null;
    },
    toggleZen(ctrl) {
        return ctrl.zenAvailable() ? h('button', {
            className: ctrl.isZen() ? 'on' : '',
            oncreate: ontap(ctrl.toggleZenMode)
        }, [h('span.fa.fa-volume-off'), i18n('zenMode')]) : null;
    },
    shareLink(ctrl) {
        return h('button', {
            oncreate: ontap(() => {
                const orientation = ctrl.chessground.state.orientation;
                Share.share({ url: `${publicUrl(ctrl.data)}/${orientation}#${ctrl.vm.ply}` });
            })
        }, [i18n('shareGameUrl')]);
    },
    sharePGN(ctrl) {
        function handler() {
            getPGN(ctrl.data.game.id)
                .catch(err => {
                handleXhrError(err);
                throw err;
            })
                .then((PGN) => Share.share({ text: PGN }));
        }
        return (h("button", { oncreate: ontap(handler) }, i18n('sharePgn')));
    },
    submitMove(ctrl) {
        return h('div.negotiationButtonsWrapper', [
            h('p', i18n('moveConfirmation')),
            h('div.negotiationButtons', {
                className: ctrl.vm.submitFeedback ? 'loading' : ''
            }, [
                h('button.accept', {
                    'data-icon': ctrl.vm.submitFeedback ? null : 'E',
                    oncreate: ontap(() => ctrl.submitMove(true)),
                }, ctrl.vm.submitFeedback ? spinner.getVdom('monochrome white') : null),
                h('button.decline', {
                    'data-icon': 'L',
                    oncreate: ontap(() => ctrl.submitMove(false)),
                }),
            ])
        ]);
    },
    resign(ctrl) {
        return resignable(ctrl.data) && !ctrl.vm.confirmResign ? h('button', {
            className: 'resign',
            'data-icon': 'b',
            oncreate: ontap(() => { ctrl.vm.confirmResign = true; })
        }, i18n('resign')) : null;
    },
    resignConfirmation(ctrl) {
        return resignable(ctrl.data) && ctrl.vm.confirmResign ? (h("div", { className: "negotiation" },
            h("div", { className: "binary_choice_wrapper" },
                h("button", { className: "binary_choice", "data-icon": "E", oncreate: ontap(() => { ctrl.socket.iface.send('resign'); }) }, i18n('resign')),
                h("button", { className: "binary_choice", "data-icon": "L", oncreate: ontap(() => { ctrl.vm.confirmResign = false; }) }, i18n('cancel'))))) : null;
    },
    forceResign(ctrl) {
        return forceResignable(ctrl.data) ?
            h('div.force_resign_zone', [
                h('div.notice', i18n('opponentLeftChoices')),
                h('div.binary_choice_wrapper', [
                    h('button.binary_choice.left', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('resign-force'); })
                    }, i18n('forceResignation')),
                    h('button.binary_choice.right', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('draw-force'); })
                    }, i18n('forceDraw'))
                ])
            ]) : null;
    },
    threefoldClaimDraw(ctrl) {
        return (ctrl.data.game.threefold) ? h('div.claim_draw_zone', [
            h('div.notice', i18n('threefoldRepetition')),
            h.trust('&nbsp;'),
            h('button[data-icon=E]', {
                oncreate: ontap(() => { ctrl.socket.iface.send('draw-claim'); })
            }, i18n('claimADraw'))
        ]) : null;
    },
    offerDraw(ctrl) {
        return !ctrl.vm.confirmDraw ? h('button', {
            className: 'draw-yes',
            oncreate: ontap(() => { ctrl.vm.confirmDraw = true; }),
            disabled: !ctrl.canOfferDraw()
        }, h('span', '½'), i18n('offerDraw')) : null;
    },
    drawConfirmation(ctrl) {
        return ctrl.canOfferDraw() && ctrl.vm.confirmDraw ? (h("div", { className: "negotiation" },
            h("div", { className: "binary_choice_wrapper" },
                h("button", { className: "binary_choice", "data-icon": "E", oncreate: ontap(() => {
                        ctrl.vm.confirmDraw = false;
                        ctrl.offerDraw();
                    }) }, i18n('offerDraw')),
                h("button", { className: "binary_choice", "data-icon": "L", oncreate: ontap(() => { ctrl.vm.confirmDraw = false; }) }, i18n('cancel'))))) : null;
    },
    cancelDrawOffer(ctrl) {
        if (ctrl.data.player.offeringDraw)
            return h('div.negotiation', [
                h('div.notice', i18n('drawOfferSent')),
            ]);
        return null;
    },
    answerOpponentDrawOffer(ctrl) {
        if (ctrl.data.opponent.offeringDraw)
            return h('div.negotiation', [
                h('div.notice', i18n('yourOpponentOffersADraw')),
                h('div.binary_choice_wrapper', [
                    h('button.binary_choice[data-icon=E]', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('draw-yes'); })
                    }, i18n('accept')),
                    h('button.binary_choice[data-icon=L]', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('draw-no'); })
                    }, i18n('decline'))
                ])
            ]);
        return null;
    },
    cancelTakebackProposition(ctrl) {
        if (ctrl.data.player.proposingTakeback)
            return h('div.negotiation', [
                h('div.notice', i18n('takebackPropositionSent')),
                h('button[data-icon=L]', {
                    oncreate: ontap(() => { ctrl.socket.iface.send('takeback-no'); })
                }, i18n('cancel'))
            ]);
        return null;
    },
    answerOpponentTakebackProposition(ctrl) {
        if (ctrl.data.opponent.proposingTakeback)
            return h('div.negotiation', [
                h('div.notice', i18n('yourOpponentProposesATakeback')),
                h('div.binary_choice_wrapper', [
                    h('button.binary_choice[data-icon=E]', {
                        oncreate: ontap(() => { ctrl.acceptTakeback(); })
                    }, i18n('accept')),
                    h('button.binary_choice[data-icon=L]', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('takeback-no'); })
                    }, i18n('decline'))
                ])
            ]);
        return null;
    },
    analysisBoard(ctrl) {
        const d = ctrl.data;
        if (userAnalysable(d) || replayable(d)) {
            return h('button', {
                oncreate: ontap(ctrl.goToAnalysis)
            }, [h('span[data-icon=A].withIcon'), i18n('analysis')]);
        }
        return null;
    },
    notes(ctrl) {
        return ctrl.notes ? h('button', {
            oncreate: ontap(() => ctrl.notes && ctrl.notes.open())
        }, [h('span.fa.fa-pencil.withIcon'), i18n('notes')]) : null;
    },
    analysisBoardIconOnly(ctrl) {
        const d = ctrl.data;
        if (userAnalysable(d) || replayable(d)) {
            return h('button.action_bar_button[data-icon=A]', {
                oncreate: ontap(ctrl.goToAnalysis)
            });
        }
        return null;
    },
    newOpponent(ctrl) {
        const d = ctrl.data;
        const newable = (gameStatus.finished(d) || gameStatus.aborted(d)) && (d.game.source === 'lobby' || d.game.source === 'pool');
        if (!ctrl.data.opponent.ai && newable) {
            return h('button[data-icon=r]', {
                oncreate: ontap(() => {
                    ctrl.hideActions();
                    lobby.onNewOpponent(ctrl.data);
                })
            }, i18n('newOpponent'));
        }
        return null;
    },
    rematch(ctrl) {
        const d = ctrl.data;
        const rematchable = !d.game.rematch && (gameStatus.finished(d) || gameStatus.aborted(d)) && !d.game.tournamentId && !d.game.boosted && (d.opponent.onGame || (!d.clock && d.player.user && d.opponent.user));
        if (ctrl.data.opponent.offeringRematch) {
            return h('div.negotiation', [
                h('div.notice', i18n('yourOpponentWantsToPlayANewGameWithYou')),
                h('div.binary_choice_wrapper', [
                    h('button.binary_choice[data-icon=E]', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('rematch-yes'); })
                    }, i18n('joinTheGame')),
                    h('button.binary_choice[data-icon=L]', {
                        oncreate: ontap(() => { ctrl.socket.iface.send('rematch-no'); })
                    }, i18n('decline'))
                ])
            ]);
        }
        else if (ctrl.data.player.offeringRematch) {
            return h('div.negotiation', [
                h('div.notice', i18n('rematchOfferSent')),
                h('div.notice', i18n('waitingForOpponent')),
                h('button[data-icon=L]', {
                    oncreate: ontap(() => { ctrl.socket.iface.send('rematch-no'); })
                }, i18n('cancelRematchOffer'))
            ]);
        }
        else {
            return h('button', {
                oncreate: ontap(() => { ctrl.socket.iface.send('rematch-yes'); }),
                disabled: !rematchable,
            }, [h('span.fa.fa-refresh'), i18n('rematch')]);
        }
    },
    moretime(ctrl) {
        if (moretimeable(ctrl.data))
            return h('button[data-icon=O]', {
                oncreate: ontap(ctrl.socket.moreTime)
            }, plural('giveNbSeconds', 15));
        return null;
    },
    flipBoard(ctrl) {
        const className = classSet({
            'action_bar_button': true,
            highlight: ctrl.vm.flip
        });
        return (h("button", { className: className, "data-icon": "B", oncreate: ontap(ctrl.flip) }));
    },
    first(ctrl) {
        const prevPly = ctrl.vm.ply - 1;
        const enabled = ctrl.vm.ply !== prevPly && prevPly >= ctrl.firstPly();
        const className = classSet({
            'action_bar_button': true,
            'fa': true,
            'fa-fast-backward': true,
            disabled: !enabled
        });
        return (h("button", { className: className, oncreate: ontap(ctrl.jumpFirst) }));
    },
    backward(ctrl) {
        const prevPly = ctrl.vm.ply - 1;
        const enabled = ctrl.vm.ply !== prevPly && prevPly >= ctrl.firstPly();
        const className = classSet({
            'action_bar_button': true,
            'fa': true,
            'fa-backward': true,
            disabled: !enabled
        });
        return (h("button", { className: className, oncreate: ontap(ctrl.jumpPrev, undefined, ctrl.jumpPrev) }));
    },
    forward(ctrl) {
        const nextPly = ctrl.vm.ply + 1;
        const enabled = ctrl.vm.ply !== nextPly && nextPly <= ctrl.lastPly();
        const className = classSet({
            'action_bar_button': true,
            'fa': true,
            'fa-forward': true,
            disabled: !enabled
        });
        return (h("button", { className: className, oncreate: ontap(ctrl.jumpNext, undefined, ctrl.jumpNext) }));
    },
    last(ctrl) {
        const nextPly = ctrl.vm.ply + 1;
        const enabled = ctrl.vm.ply !== nextPly && nextPly <= ctrl.lastPly();
        const className = classSet({
            'action_bar_button': true,
            'fa': true,
            'fa-fast-forward': true,
            disabled: !enabled
        });
        return (h("button", { className: className, oncreate: ontap(ctrl.jumpLast) }));
    },
    returnToTournament(ctrl) {
        function handler() {
            ctrl.hideActions();
            const url = `/tournament/${ctrl.data.game.tournamentId}`;
            if (ctrl.data.tv) {
                router.set(url);
            }
            else {
                router.set(url, true);
            }
        }
        return (h("button", { oncreate: ontap(handler) },
            h("span", { className: "fa fa-trophy" }),
            i18n('backToTournament')));
    },
    withdrawFromTournament(ctrl, tournamentId) {
        function handler() {
            ctrl.hideActions();
            withdraw(tournamentId);
            router.set(`/tournament/${tournamentId}`, true);
        }
        return (h("button", { oncreate: ontap(handler) },
            h("span", { className: "fa fa-flag" }),
            "Pause"));
    },
    goBerserk(ctrl) {
        if (!berserkableBy(ctrl.data))
            return null;
        if (ctrl.vm.goneBerserk[ctrl.data.player.color])
            return null;
        function handler() {
            ctrl.hideActions();
            ctrl.goBerserk();
        }
        return (h("button", { className: "berserk", oncreate: ontap(handler) },
            h("span", { "data-icon": "`" }),
            " GO BERSERK!",
            h("br", null),
            h("small", null, "Half the time, bonus point")));
    }
};

function prefixInteger(num, length) {
    return (num / Math.pow(10, length)).toFixed(length).substr(2);
}
function formatClockTime(time) {
    const date = new Date(time);
    const minutes = prefixInteger(date.getUTCMinutes(), 2);
    const seconds = prefixInteger(date.getSeconds(), 2);
    let hours, str = '';
    if (time >= 86400 * 1000) {
        // days : hours
        const days = date.getUTCDate() - 1;
        hours = date.getUTCHours();
        str += plural('nbDays', days);
        if (hours !== 0)
            str += ' ' + plural('nbHours', hours);
    }
    else if (time >= 3600 * 1000) {
        // hours : minutes
        hours = date.getUTCHours();
        str += prefixInteger(hours, 2) + ':' + minutes;
    }
    else {
        // minutes : seconds
        str += minutes + ':' + seconds;
    }
    return str + (hasNetwork() ? '' : '?');
}
function view$1(ctrl, color, runningColor) {
    const time = ctrl.data[color];
    const className = 'correspondence clock ' + classSet({
        'outoftime': !time,
        'running': runningColor === color,
        'emerg': time < ctrl.data.emerg,
        'offline': !hasNetwork()
    });
    return h('div', {
        className,
    }, formatClockTime(time * 1000));
}

function autoScroll(movelist) {
    if (!movelist)
        return;
    batchRequestAnimationFrame(() => {
        const plyEl = movelist.querySelector('.current');
        if (plyEl)
            movelist.scrollTop = plyEl.offsetTop - movelist.offsetHeight / 2 + plyEl.offsetHeight / 2;
    });
}
function autoScrollInline(movelist) {
    if (!movelist)
        return;
    batchRequestAnimationFrame(() => {
        const plyEl = movelist.querySelector('.current');
        if (plyEl)
            movelist.scrollLeft = plyEl.offsetLeft - movelist.offsetWidth / 2 + plyEl.offsetWidth / 2;
    });
}
function getMoveEl(e) {
    const target = e.target;
    return target.tagName === 'MOVE' ? target :
        findParentBySelector(target, 'move');
}
function onReplayTap(ctrl, e) {
    const el = getMoveEl(e);
    if (el && el.dataset.ply) {
        ctrl.jump(Number(el.dataset.ply));
    }
}
const NO_CHECKS = {
    white: 0,
    black: 0,
};
function countChecks(steps, ply) {
    const checks = { ...NO_CHECKS };
    for (const step of steps) {
        if (ply < step.ply)
            break;
        if (step.check) {
            if (step.ply % 2 === 1)
                checks.white++;
            else
                checks.black++;
        }
    }
    return checks;
}

function renderReplay(ctrl) {
    const pieceNotation = settings.game.pieceNotation();
    if (!ctrl.vm.moveList || ctrl.isZen()) {
        return null;
    }
    return h('div.replay.box', {
        className: classSet({
            displayPieces: !!pieceNotation,
        }),
        oncreate: (vnode) => {
            setTimeout(() => autoScroll(vnode.dom), 100);
            ontapY((e) => onReplayTap(ctrl, e), undefined, getMoveEl)(vnode);
        },
        onupdate: (vnode) => autoScroll(vnode.dom),
    }, renderMoves(ctrl));
}
function renderInlineReplay(ctrl) {
    const pieceNotation = settings.game.pieceNotation();
    if (!ctrl.vm.moveList) {
        return null;
    }
    return h('div.replay_inline', {
        className: classSet({
            displayPieces: !!pieceNotation,
            hidden: ctrl.isZen(),
        }),
        oncreate: (vnode) => {
            setTimeout(() => autoScrollInline(vnode.dom), 100);
            ontapX((e) => onReplayTap(ctrl, e), undefined, getMoveEl)(vnode);
        },
        onupdate: (vnode) => autoScrollInline(vnode.dom),
    }, renderMoves(ctrl));
}
function renderMoves(ctrl) {
    return ctrl.data.steps.filter(s => s.san !== null).map(s => h('move.replayMove', {
        className: s.ply === ctrl.vm.ply ? 'current' : '',
        'data-ply': s.ply,
    }, [
        s.ply & 1 ? renderIndex(s.ply) : null,
        fixCrazySan(s.san)
    ]));
}
function renderIndexText(ply, withDots) {
    return plyToTurn(ply) + ((ply % 2 === 1 ? '.' : '...') );
}
function renderIndex(ply, withDots) {
    return h('index', renderIndexText(ply));
}
function plyToTurn(ply) {
    return Math.floor((ply - 1) / 2) + 1;
}

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */
function baseTimes(n, iteratee) {
  var index = -1,
      result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }
  return result;
}

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */
function identity(value) {
  return value;
}

/**
 * Casts `value` to `identity` if it's not a function.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Function} Returns cast function.
 */
function castFunction(value) {
  return typeof value == 'function' ? value : identity;
}

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/** Used as references for the maximum length and index of an array. */
var MAX_ARRAY_LENGTH = 4294967295;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMin = Math.min;

/**
 * Invokes the iteratee `n` times, returning an array of the results of
 * each invocation. The iteratee is invoked with one argument; (index).
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} [iteratee=_.identity] The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 * @example
 *
 * _.times(3, String);
 * // => ['0', '1', '2']
 *
 *  _.times(4, _.constant(0));
 * // => [0, 0, 0, 0]
 */
function times(n, iteratee) {
  n = toInteger(n);
  if (n < 1 || n > MAX_SAFE_INTEGER) {
    return [];
  }
  var index = MAX_ARRAY_LENGTH,
      length = nativeMin(n, MAX_ARRAY_LENGTH);

  iteratee = castFunction(iteratee);
  n -= MAX_ARRAY_LENGTH;

  var result = baseTimes(length, iteratee);
  while (++index < n) {
    iteratee(index);
  }
  return result;
}

function view(ctrl) {
    const isPortrait$1 = isPortrait();
    return layout.board(renderHeader(ctrl), renderContent(ctrl, isPortrait$1), 'round', overlay(ctrl), undefined, undefined, 'roundView');
}
function renderMaterial(material) {
    return h.fragment({}, [
        h('div.materials', Object.keys(material.pieces).map((role) => h('div.material', times(material.pieces[role], _ => h('piece', { className: role }))))),
        material.score > 0 ? h('span', `+${material.score}`) : null,
    ]);
}
function viewOnlyBoardContent(fen, orientation, lastMove, variant, wrapperClass, customPieceTheme) {
    const isPortrait$1 = isPortrait();
    const vd = viewportDim();
    const className = 'board_wrapper' + ('');
    const board = (h("section", { className: className }, h(ViewOnlyBoard, { fen, lastMove, orientation, variant, customPieceTheme })));
    const showMoveList = hasSpaceForInlineReplay(vd, isPortrait$1) &&
        settings.game.moveList() &&
        !settings.game.zenMode();
    if (isPortrait$1) {
        return h.fragment({}, [
            showMoveList ? h('div.replay_inline') : null,
            h('section.playTable.opponent'),
            board,
            h('section.playTable.player'),
            h('section.actions_bar'),
        ]);
    }
    else {
        return h.fragment({}, [
            board,
            h('section.table'),
        ]);
    }
}
const LoadingBoard = {
    view() {
        return layout.board(connectingHeader(), viewOnlyBoardContent(emptyFen, 'white'), 'roundView');
    }
};
function overlay(ctrl) {
    let chatHeader = (!ctrl.data.opponent.user || ctrl.data.player.spectator) ? i18n('chat') : ctrl.data.opponent.user.username;
    const watchers = ctrl.data.watchers;
    if (ctrl.data.player.spectator && watchers && watchers.nb >= 2) {
        chatHeader = i18n('spectators') + ' ' + watchers.nb;
    }
    else if (ctrl.data.player.spectator) {
        chatHeader = i18n('spectatorRoom');
    }
    return [
        ctrl.chat ? chatView(ctrl.chat, chatHeader) : null,
        ctrl.notes ? notesView(ctrl.notes) : null,
        promotion.view(ctrl),
        renderGamePopup(ctrl),
        renderSubmitMovePopup(ctrl),
        h(PlayerPopup, {
            player: ctrl.data.player,
            opponent: ctrl.data.opponent,
            mini: ctrl.vm.miniUser.player.data,
            score: ctrl.score,
            isOpen: ctrl.vm.miniUser.player.showing,
            close: () => ctrl.closeUserPopup('player'),
        }),
        h(PlayerPopup, {
            player: ctrl.data.opponent,
            opponent: ctrl.data.player,
            mini: ctrl.vm.miniUser.opponent.data,
            score: ctrl.score,
            isOpen: ctrl.vm.miniUser.opponent.showing,
            close: () => ctrl.closeUserPopup('opponent'),
        })
    ];
}
function renderTitle(ctrl) {
    const data = ctrl.data;
    const tournament = ctrl.data.tournament;
    if (ctrl.vm.offlineWatcher || socket.isConnected()) {
        const isCorres = !data.player.spectator && data.game.speed === 'correspondence';
        if (ctrl.data.tv) {
            return h('div.main_header_title.withSub', [
                h('h1.header-gameTitle', [
                    tvChannelSelector(ctrl)
                ]),
                h('h2.header-subTitle', title(ctrl.data)),
            ]);
        }
        else if (ctrl.data.userTV) {
            return h('div.main_header_title.withSub', [
                h('h1.header-gameTitle', [
                    h('span.withIcon[data-icon=1]'), ctrl.data.userTV,
                ]),
                h('h2.header-subTitle', [
                    h(`span.withIcon[data-icon=${gameIcon(ctrl.data.game.perf)}]`),
                    title(ctrl.data),
                ].concat(tournament ? [
                    ' • ',
                    h('span.fa.fa-trophy'),
                    h(CountdownTimer, { seconds: tournament.secondsToFinish || 0 }),
                ] : [])),
            ]);
        }
        else {
            return h(GameTitle, {
                data: ctrl.data,
                kidMode: session.isKidMode(),
                subTitle: tournament ? 'tournament' : isCorres ? 'corres' : 'date'
            });
        }
    }
    else {
        return (h("div", { className: "main_header_title reconnecting" }, loader));
    }
}
function renderHeader(ctrl) {
    let children;
    if (ctrl.goingBack || (!ctrl.data.tv && !ctrl.data.userTV && ctrl.data.player.spectator)) {
        children = [
            backButton([
                renderTitle(ctrl),
                bookmarkButton(ctrl.toggleBookmark, ctrl.data.bookmarked),
            ])
        ];
    }
    else {
        children = [
            menuButton(),
            renderTitle(ctrl),
        ];
    }
    children.push(headerBtns());
    return h('nav', {
        key: 'roundHeader', // workaround to avoid mithril error
        className: socket.isConnected() ? '' : 'reconnecting'
    }, children);
}
function renderContent(ctrl, isPortrait) {
    const vd = viewportDim();
    const material = ctrl.chessground.getMaterialDiff();
    const checksCount = ctrl.data.player.checks || ctrl.data.opponent.checks ?
        countChecks(ctrl.data.steps, ctrl.vm.ply) : NO_CHECKS;
    const flip = !ctrl.data.tv && ctrl.vm.flip;
    const player = renderPlayTable(ctrl, ctrl.data.player, material[ctrl.data.player.color], checksCount[ctrl.data.player.color], 'player', flip);
    const opponent = renderPlayTable(ctrl, ctrl.data.opponent, material[ctrl.data.opponent.color], checksCount[ctrl.data.opponent.color], 'opponent', flip);
    const playable$1 = playable(ctrl.data);
    const myTurn = isPlayerTurn(ctrl.data);
    const board = h(Board, {
        variant: ctrl.data.game.variant.key,
        chessground: ctrl.chessground,
    }, playable$1 ? [
        !myTurn ? renderExpiration(ctrl, 'opponent', myTurn) : null,
        myTurn ? renderExpiration(ctrl, 'player', myTurn) : null,
    ] : []);
    if (isPortrait) {
        return [
            hasSpaceForInlineReplay(vd, isPortrait) ? renderInlineReplay(ctrl) : null,
            flip ? player : opponent,
            board,
            flip ? opponent : player,
            renderGameActionsBar(ctrl)
        ];
    }
    else {
        return [
            board,
            h('section.table', [
                flip ? player : opponent,
                renderReplay(ctrl),
                renderGameActionsBar(ctrl),
                flip ? opponent : player,
            ]),
        ];
    }
}
function renderExpiration(ctrl, position, myTurn) {
    const d = ctrl.data.expiration;
    if (!d)
        return null;
    const timeLeft = Math.max(0, d.movedAt - Date.now() + d.millisToMove);
    return h('div.round-expiration', {
        className: position,
    }, h(CountdownTimer, {
        seconds: Math.round(timeLeft / 1000),
        emergTime: myTurn ? 8 : undefined,
        textWrap: (sec, t) => plural('nbSecondsToPlayTheFirstMove', sec, `<strong>${t}</<strong>`),
        showOnlySecs: true
    }));
}
function renderSubmitMovePopup(ctrl) {
    if (ctrl.vm.moveToSubmit || ctrl.vm.dropToSubmit || ctrl.vm.submitFeedback) {
        return (h("div", { className: "overlay_popup_wrapper submitMovePopup" },
            h("div", { className: "overlay_popup" }, gameButton.submitMove(ctrl))));
    }
    return null;
}
function userInfos(user, player, playerName) {
    let title;
    if (user) {
        const onlineStatus = user.online ? 'connected to lichess' : 'offline';
        const onGameStatus = player.onGame ? 'currently on this game' : 'currently not on this game';
        title = `${playerName}: ${onlineStatus}; ${onGameStatus}`;
    }
    else {
        title = playerName;
    }
    Toast.show({ text: title, position: 'center', duration: 'short' });
}
function renderPlayerName(player) {
    if (player.name || player.username || player.user) {
        const name = player.name || player.username || player.user?.username;
        return h('span', [
            player.user?.title ? [
                h('span.userTitle' + (player.user?.title === 'BOT' ? '.bot' : ''), player.user.title),
                ' '
            ] : [],
            name
        ]);
    }
    if (player.ai)
        return aiName({ ai: player.ai });
    return 'Anonymous';
}
function renderPlayer(ctrl, player, material, checkCount, flipped, position, isCrazy) {
    const user = player.user;
    const playerName$1 = renderPlayerName(player);
    const togglePopup = user ? () => ctrl.openUserPopup(position, user.id) : noop;
    const vConf = user ?
        ontap(togglePopup, () => userInfos(user, player, playerName(player))) :
        ontap(noop, () => Toast.show({ text: (player.name || player.username || player.user?.username), position: 'center', duration: 'short' }));
    const tournamentRank = ctrl.data.tournament && ctrl.data.tournament.ranks ?
        '#' + ctrl.data.tournament.ranks[player.color] + ' ' : null;
    const isBerserk = ctrl.vm.goneBerserk[player.color];
    const checksNb = ctrl.data.game.variant.key === 'threeCheck' ? checkCount : undefined;
    return (h("div", { className: 'antagonistInfos' + (isCrazy ? ' crazy' : '') + (ctrl.isZen() ? ' zen' : ''), oncreate: vConf },
        h("h2", { className: "antagonistUser" },
            user && user.patron ?
                h("span", { className: 'patron status ' + (player.onGame ? 'ongame' : 'offgame'), "data-icon": "\uE019" })
                :
                    h("span", { className: 'fa fa-circle status ' + (player.onGame ? 'ongame' : 'offgame') }),
            tournamentRank,
            playerName$1,
            isBerserk ? h("span", { className: "berserk", "data-icon": "`" }) : null,
            isCrazy && position === 'opponent' && user && user.tosViolation ?
                h("span", { className: "warning", "data-icon": "j" }) : null),
        !isCrazy ?
            h("div", { className: "ratingAndMaterial" },
                position === 'opponent' && user && user.tosViolation ?
                    h("span", { className: "warning", "data-icon": "j" }) : null,
                user ?
                    h("h3", { className: "rating" },
                        player.rating,
                        player.provisional ? '?' : '',
                        renderRatingDiff(player)) : null,
                checksNb !== undefined ?
                    [...Array(checksNb).keys()].map(_ => h('div.material', h('piece', { className: 'king' }))) : null,
                !ctrl.vm.showCaptured || ctrl.data.game.variant.key === 'horde' ? null : renderMaterial(material)) : null,
        isCrazy && ctrl.clock ?
            // must reset clock with a single-child keyed fragment when flipped
            [h(Clock, {
                    key: flipped.toString(),
                    ctrl: ctrl.clock,
                    color: player.color,
                    isBerserk,
                })] :
            isCrazy && ctrl.correspondenceClock ?
                view$1(ctrl.correspondenceClock, player.color, ctrl.data.game.player) : null));
}
function renderPlayTable(ctrl, player, material, checkCount, position, flipped) {
    const step = ctrl.plyStep(ctrl.vm.ply);
    const isCrazy = !!step.crazy;
    const classN = classSet({
        playTable: true,
        crazy: isCrazy,
        clockOnLeft: ctrl.vm.clockPosition === 'left',
    });
    return (h("section", { className: classN + ' ' + position },
        renderPlayer(ctrl, player, material, checkCount, flipped, position, isCrazy),
        step.crazy ?
            h(CrazyPocket, {
                ctrl,
                crazyData: step.crazy,
                color: player.color,
                position
            }) : null,
        !isCrazy && ctrl.clock ?
            // must reset clock with a single-child keyed fragment when flipped
            [h(Clock, {
                    key: flipped.toString(),
                    ctrl: ctrl.clock,
                    color: player.color,
                    isBerserk: ctrl.vm.goneBerserk[player.color],
                })] :
            !isCrazy && ctrl.correspondenceClock ?
                view$1(ctrl.correspondenceClock, player.color, ctrl.data.game.player) : null));
}
function tvChannelSelector(ctrl) {
    const channels = perfTypes.filter(e => e[0] !== 'correspondence').map(e => [e[1], e[0]]);
    channels.unshift(['Top rated', 'best']);
    channels.push(['Bot', 'bot']);
    channels.push(['Computer', 'computer']);
    const channel = settings.tv.channel();
    const icon = gameIcon(channel);
    return (h('div.select_input.main_header-selector.round-tvChannelSelector', [
        h('label', {
            'for': 'channel_selector'
        }, [
            h(`i[data-icon=${icon}]`),
            h('span', h.trust('&nbsp;')),
            h('span', 'Lichess TV')
        ]),
        h('select#channel_selector', {
            value: channel,
            onchange(e) {
                const val = e.target.value;
                settings.tv.channel(val);
                ctrl.onFeatured && ctrl.onFeatured();
                setTimeout(redraw, 10);
            }
        }, channels.map(v => h('option', {
            key: v[1], value: v[1]
        }, v[0])))
    ]));
}
function renderGameRunningActions(ctrl) {
    return h('div.gameControls', {
        key: 'gameRunningActions'
    }, ctrl.data.player.spectator ? [
        gameButton.shareLink(ctrl),
    ] : [
        gameButton.toggleZen(ctrl),
        gameButton.analysisBoard(ctrl),
        gameButton.notes(ctrl),
        gameButton.moretime(ctrl),
        gameButton.standard(ctrl, abortable, 'L', 'abortGame', 'abort'),
    ].concat(forceResignable(ctrl.data) ? [gameButton.forceResign(ctrl)] : [
        gameButton.standard(ctrl, takebackable, 'i', 'proposeATakeback', 'takeback-yes'),
        gameButton.cancelTakebackProposition(ctrl),
        gameButton.offerDraw(ctrl),
        gameButton.drawConfirmation(ctrl),
        gameButton.cancelDrawOffer(ctrl),
        gameButton.threefoldClaimDraw(ctrl),
        gameButton.resign(ctrl),
        gameButton.resignConfirmation(ctrl),
        gameButton.goBerserk(ctrl),
        gameButton.answerOpponentDrawOffer(ctrl),
        gameButton.answerOpponentTakebackProposition(ctrl),
    ]));
}
function renderGameEndedActions(ctrl) {
    let buttons;
    const tournamentId = ctrl.data.game.tournamentId;
    const shareActions = h('button', {
        oncreate: ontap(ctrl.showShareActions),
    }, [h('span.fa.fa-share'), i18n('shareAndExport')]);
    if (ctrl.vm.showingShareActions) {
        buttons = [
            gameButton.shareLink(ctrl),
            gameButton.sharePGN(ctrl),
        ];
    }
    else if (tournamentId) {
        if (ctrl.data.player.spectator) {
            buttons = [
                shareActions,
                gameButton.analysisBoard(ctrl),
                gameButton.returnToTournament(ctrl),
            ];
        }
        else {
            buttons = [
                shareActions,
                gameButton.analysisBoard(ctrl),
                gameButton.withdrawFromTournament(ctrl, tournamentId),
                gameButton.returnToTournament(ctrl),
            ];
        }
    }
    else {
        if (ctrl.data.player.spectator) {
            buttons = [
                shareActions,
                gameButton.analysisBoard(ctrl)
            ];
        }
        else {
            buttons = [
                shareActions,
                gameButton.analysisBoard(ctrl),
                gameButton.notes(ctrl),
                gameButton.newOpponent(ctrl),
                gameButton.rematch(ctrl),
            ];
        }
    }
    return h('div.game_controls', { key: 'gameEndedActions' }, h.fragment({
        key: ctrl.vm.showingShareActions ? 'shareMenu' : 'menu'
    }, buttons));
}
function renderStatus(ctrl) {
    const result$1 = result(ctrl.data);
    const winner = getPlayer(ctrl.data, ctrl.data.game.winner);
    const status = gameStatus.toLabel(ctrl.data.game.status.name, ctrl.data.game.turns, ctrl.data.game.winner, ctrl.data.game.variant.key) +
        (winner ? '. ' + i18n(winner.color === 'white' ? 'whiteIsVictorious' : 'blackIsVictorious') + '.' : '');
    return (gameStatus.aborted(ctrl.data) ? [] : [
        h('strong', result$1), h('br')
    ]).concat([h('em.resultStatus', status)]);
}
function renderGamePopup(ctrl) {
    const header = !playable(ctrl.data) ?
        () => renderStatus(ctrl) : undefined;
    return popup('player_controls', ctrl.vm.showingShareActions ? undefined : header, () => playable(ctrl.data) ?
        renderGameRunningActions(ctrl) :
        renderGameEndedActions(ctrl), ctrl.vm.showingActions, ctrl.hideActions);
}
function renderGameActionsBar(ctrl) {
    const answerRequired = ((ctrl.data.opponent.proposingTakeback ||
        ctrl.data.opponent.offeringDraw) && !gameStatus.finished(ctrl.data)) ||
        forceResignable(ctrl.data) ||
        ctrl.data.opponent.offeringRematch;
    const gmClass = (ctrl.data.opponent.proposingTakeback ? [
        'fa',
        'fa-mail-reply'
    ] : ctrl.data.opponent.offeringDraw ? [] : [
        'fa',
        'fa-list'
    ]).concat([
        'action_bar_button',
        answerRequired ? 'glow' : ''
    ]).join(' ');
    return (h("section", { className: "actions_bar" },
        h("button", { className: gmClass, oncreate: ontap(ctrl.showActions) }, ctrl.data.opponent.offeringDraw ? '½' : ''),
        ctrl.chat && !ctrl.isZen() ?
            h("button", { className: "action_bar_button fa fa-comments withChip", oncreate: ontap(ctrl.chat.open) }, ctrl.chat.nbUnread > 0 ?
                h("span", { className: "chip" }, ctrl.chat.nbUnread <= 99 ? ctrl.chat.nbUnread : 99) : null) : null,
        forecastable(ctrl.data) ? renderAnalysisIcon(ctrl) : null,
        gameButton.flipBoard(ctrl),
        playable(ctrl.data) ? null : gameButton.analysisBoardIconOnly(ctrl),
        gameButton.backward(ctrl),
        gameButton.forward(ctrl)));
}
function renderAnalysisIcon(ctrl) {
    return h('button.action_bar_button[data-icon=A].withChip', {
        oncreate: ontap(ctrl.goToAnalysis)
    }, (ctrl.data.forecastCount || 0) > 0
        ? h('span.chip', ctrl.data.forecastCount)
        : null);
}

function capture(chessgroundCtrl, key) {
    const exploding = [];
    const diff = new Map();
    const orig = key2pos(key);
    for (let x = -1; x < 2; x++) {
        for (let y = -1; y < 2; y++) {
            const k = pos2key([orig[0] + x, orig[1] + y]);
            if (k) {
                exploding.push(k);
                const p = chessgroundCtrl.state.pieces.get(k);
                const explodes = p && (k === key || p.role !== 'pawn');
                if (explodes)
                    diff.set(k, null);
            }
        }
    }
    chessgroundCtrl.setPieces(diff);
    chessgroundCtrl.explode(exploding);
}
// needs to explicitly destroy the capturing pawn
function enpassant(chessgroundCtrl, key, color) {
    const pos = key2pos(key);
    const pawnPos = [pos[0], pos[1] + (color === 'white' ? -1 : 1)];
    capture(chessgroundCtrl, pos2key(pawnPos));
}
var atomic = {
    capture,
    enpassant
};

var crazyValid = {
    drop(data, role, key, possibleDrops) {
        if (!data.game.offline && !isPlayerTurn(data))
            return false;
        if (role === 'pawn' && (key[1] === '1' || key[1] === '8'))
            return false;
        if (possibleDrops === undefined || possibleDrops === null)
            return true;
        const drops = Array.isArray(possibleDrops) ?
            possibleDrops : possibleDrops.match(/.{2}/g) || [];
        return drops.indexOf(key) !== -1;
    }
};

export { LoadingBoard as L, atomic as a, autoScroll as b, crazyValid as c, autoScrollInline as d, view as e, formatClockTime$1 as f, getMoveEl as g, formatClockTime as h, onReplayTap as o, promotion as p, renderMaterial as r, viewOnlyBoardContent as v };
//# sourceMappingURL=crazyValid-BQyVE87l.js.map
