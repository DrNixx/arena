import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, k as hasNetwork, b as session, O as formWidgets, g as settings } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { render, prefsCtrl } from './clock-BGAarcjz.js';
import './prefs-CFmBYsqy.js';

var clock = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('clock')));
        return layout.free(header, h('ul.native_scroller.page.settings_list.multiChoices', renderAppPrefs().concat(hasNetwork() && session.isConnected() ?
            render(prefsCtrl) : [])));
    }
};
function renderAppPrefs() {
    return [
        h('li.list_item', formWidgets.renderMultipleChoiceButton(i18n('settingsClockPosition'), [
            { label: i18n('positionLeft'), value: 'left' },
            { label: i18n('positionRight'), value: 'right' },
        ], settings.game.clockPosition)),
    ];
}

export { clock as default };
//# sourceMappingURL=clock-B3cpym32.js.map
