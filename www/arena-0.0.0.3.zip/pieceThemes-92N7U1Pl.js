import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, g as settings, m as h, p as ontapY, E as getLI } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

var pieceThemes = {
    oncreate: viewSlideIn,
    view() {
        const header = dropShadowHeader(null, backButton(i18n('pieceSet')));
        function onTap(e) {
            const el = getLI(e);
            const key = el && el.dataset.key;
            if (key) {
                settings.general.theme.piece(key);
            }
        }
        function renderBody() {
            const currentTheme = settings.general.theme.piece();
            return [
                h('div.native_scroller.page.settings_list', {
                    oncreate: ontapY(onTap, undefined, getLI)
                }, [
                    h('ul', settings.general.theme.availablePieceThemes.map(t => {
                        const [key, label] = t;
                        const selected = currentTheme === key;
                        return h('li.list_item.piece_theme', {
                            className: key + (selected ? ' selected' : ''),
                            'data-key': key,
                        }, [i18n(label || key), selected ? h('span.fa.fa-check') : null]);
                    }))
                ])
            ];
        }
        return layout.free(header, renderBody());
    }
};

export { pieceThemes as default };
//# sourceMappingURL=pieceThemes-92N7U1Pl.js.map
