import { m as h, p as ontapY, V as ViewOnlyBoard, n as noop, aU as formatTimeInSecs } from './main.js';
import { C as CountdownTimer } from './CountdownTimer-sy6et_C9.js';

const MiniBoard = {
    oninit({ attrs }) {
        this.link = attrs.link || noop;
    },
    onupdate({ attrs }) {
        this.link = attrs.link || noop;
    },
    view({ attrs }) {
        const { gameObj, topText, bottomText } = attrs;
        const isWhite = gameObj?.orientation === 'white';
        return (h("div", { className: "mini_board_container" },
            gameObj ?
                renderPlayer(gameObj, isWhite ? 'black' : 'white') :
                topText ? h('div.mini_board__text', topText) : null,
            h("div", { className: "mini_board", oncreate: ontapY(() => this.link()) },
                h("div", { className: "mini_board_helper" },
                    h("div", { className: "mini_board_wrapper" }, h(ViewOnlyBoard, attrs)))),
            gameObj ?
                renderPlayer(gameObj, isWhite ? 'white' : 'black') :
                bottomText ? h('div.mini_board__text', bottomText) : null));
    }
};
function fenColor(fen) {
    return fen.indexOf(' b') > 0 ? 'black' : 'white';
}
function renderPlayer(gameObj, color) {
    const player = gameObj[color];
    const time = gameObj.c && gameObj.c[color];
    const turn = fenColor(gameObj.fen);
    return h('div.mini_board__player', [
        h('span.mini_board__user', [
            player.rank ? `#${player.rank} ` : '',
            player.title ? h('span.userTitle', player.title + ' ') : null,
            player.name,
            h('span.rating', player.rating),
            player.berserk ? h('span.berserk[data-icon=`]') : null,
        ]),
        gameObj.finished ? renderScore(color, gameObj.winner) :
            time && !isNaN(time) ? renderTime(color, time, turn) : null
    ]);
}
function renderScore(color, winner) {
    return h('span.score', winner ? (color === winner ? '1' : '0') : '½');
}
function renderTime(color, time, turnColor) {
    return turnColor === color ?
        h(CountdownTimer, { seconds: time }) :
        h('span.mini_board__clock', formatTimeInSecs(time));
}

export { MiniBoard as M };
//# sourceMappingURL=miniBoard-_GdiTw1G.js.map
