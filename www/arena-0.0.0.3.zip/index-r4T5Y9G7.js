import { ah as registerPlugin } from './main.js';

const Share = registerPlugin('Share', {
    web: () => import('./web-C88UkRZs.js').then(m => new m.ShareWeb()),
});

export { Share as S };
//# sourceMappingURL=index-r4T5Y9G7.js.map
