(function () {
    'use strict';

    class StrongSocket {
        constructor(ctx, clientId, baseUrl, path, version, settings) {
            this.ctx = ctx;
            this.baseUrl = baseUrl;
            this.path = path;
            this.ackable = new Ackable((t, d, o) => this.send(t, d, o));
            this.lastPingTime = performance.now();
            this.pongCount = 0;
            this.averageLag = 0;
            this.autoReconnect = true;
            this.connect = () => {
                this.disconnect();
                this.autoReconnect = true;
                const fullUrl = makeUrl(this.baseUrl + this.path, {
                    ...this.settings.params,
                    v: this.version
                });
                this.debug('connection attempt to ' + fullUrl);
                try {
                    const ws = this.ws = new WebSocket(fullUrl);
                    ws.onerror = e => this.onError(e);
                    ws.onclose = () => {
                        this.debug('connection closed');
                        this.ctx.postMessage({ topic: 'disconnected' });
                        if (this.autoReconnect) {
                            this.debug('Will autoreconnect in ' + this.options.autoReconnectDelay);
                            this.scheduleConnect(this.options.autoReconnectDelay);
                        }
                    };
                    ws.onopen = () => {
                        this.debug('connected to ' + fullUrl);
                        this.ctx.postMessage({ topic: 'onOpen' });
                        if (this.options.sendOnOpen) {
                            this.options.sendOnOpen.forEach(x => { this.send(x.t, x.d); });
                        }
                        this.onSuccess();
                        this.pingNow();
                        this.ackable.resend();
                    };
                    ws.onmessage = e => {
                        if (e.data === '0')
                            return this.pong();
                        const m = JSON.parse(e.data);
                        if (m.t === 'n')
                            this.pong();
                        this.handle(m);
                    };
                }
                catch (e) {
                    this.onError(e);
                }
                this.scheduleConnect(this.options.pingMaxLag);
            };
            this.schedulePing = (delay) => {
                clearTimeout(this.pingSchedule);
                this.pingSchedule = setTimeout(this.pingNow, delay);
            };
            this.pingNow = () => {
                clearTimeout(this.pingSchedule);
                clearTimeout(this.connectSchedule);
                const pingData = (this.options.isAuth && this.pongCount % 8 === 2) ? JSON.stringify({
                    t: 'p',
                    l: Math.round(0.1 * this.averageLag)
                }) : 'null';
                try {
                    this.ws.send(pingData);
                    this.lastPingTime = performance.now();
                }
                catch (e) {
                    this.debug(e, true);
                }
                this.scheduleConnect(this.options.pingMaxLag);
            };
            this.computePingDelay = () => this.options.pingDelay + (this.options.idle ? 1000 : 0);
            this.pong = () => {
                clearTimeout(this.connectSchedule);
                this.schedulePing(this.computePingDelay());
                const currentLag = Math.min(performance.now() - this.lastPingTime, 10000);
                this.pongCount++;
                // Average first 4 pings, then switch to decaying average.
                const mix = this.pongCount > 4 ? 0.1 : 1 / this.pongCount;
                this.averageLag += mix * (currentLag - this.averageLag);
                this.ctx.postMessage({ topic: 'pingInterval', payload: this.pingInterval() });
            };
            this.disconnect = (onDisconnected) => {
                clearTimeout(this.pingSchedule);
                clearTimeout(this.connectSchedule);
                const ws = this.ws;
                if (ws) {
                    this.debug('Disconnect', true);
                    this.autoReconnect = false;
                    ws.onerror = ws.onclose = ws.onopen = ws.onmessage = () => { };
                    ws.close();
                    if (onDisconnected)
                        setTimeout(onDisconnected, 0);
                }
            };
            this.onError = (e) => {
                this.ctx.postMessage({ topic: 'onError' });
                this.ctx.postMessage({ topic: 'disconnected' });
                this.options.debug = true;
                this.debug('error: ' + JSON.stringify(e));
                clearTimeout(this.pingSchedule);
            };
            this.onSuccess = () => {
                this.ctx.postMessage({ topic: 'connected' });
            };
            this.version = version;
            this.settings = {
                receive: settings.receive,
                events: settings.events || {},
                params: {
                    ...settings.params || {},
                    mobile: 1,
                    sri: clientId,
                }
            };
            this.options = {
                ...StrongSocket.defaultOptions,
                ...settings.options || {}
            };
            this.debug('Debug is enabled');
            this.connect();
        }
        send(t, d, o = {}, noRetry = false) {
            const msg = { t };
            if (d !== undefined) {
                if (o.withLag)
                    d.l = Math.round(this.averageLag);
                if (o.millis >= 0)
                    d.s = Math.round(o.millis * 0.1).toString(36);
                if (o.blur)
                    d.b = 1;
                msg.d = d;
            }
            if (o.ackable) {
                msg.d = msg.d || {}; // can't ack message without data
                this.ackable.register(t, msg.d); // adds d.a, the ack ID we expect to get back
            }
            const message = JSON.stringify(msg);
            this.debug('send ' + message);
            try {
                this.ws.send(message);
            }
            catch (e) {
                // maybe sent before socket opens,
                // try again a second later.
                if (!noRetry)
                    setTimeout(() => this.send(t, msg.d, o, true), 1000);
            }
        }
        scheduleConnect(delay) {
            // self.debug('schedule connect ' + delay)
            clearTimeout(this.pingSchedule);
            clearTimeout(this.connectSchedule);
            this.connectSchedule = setTimeout(() => {
                this.ctx.postMessage({ topic: 'disconnected' });
                this.connect();
            }, delay);
        }
        handle(m) {
            if (m.v && this.version !== undefined) {
                if (m.v <= this.version) {
                    this.debug('already has event ' + m.v);
                    return;
                }
                if (m.v > this.version + 1) {
                    this.debug('event gap detected from ' + this.version + ' to ' + m.v);
                    this.ctx.postMessage({ topic: 'resync' });
                }
                this.version = m.v;
            }
            switch (m.t || false) {
                case false:
                    break;
                case 'ack':
                    this.ackable.onServerAck(m.d);
                    break;
                default:
                    if (this.options.registeredEvents.indexOf(m.t) !== -1) {
                        this.ctx.postMessage({ topic: 'handle', payload: m });
                    }
            }
        }
        setVersion(version) {
            this.version = version;
            this.connect();
        }
        debug(msg, always = false) {
            if ((always || this.options.debug)) {
                console.debug('[' + this.options.name + ' ' + this.settings.params.sri + '] ' + msg);
            }
        }
        delayedDisconnect(delay) {
            this.debug(`Will disconnect in ${delay}...`);
            this.delayedDisconnectTimeoutId = setTimeout(() => {
                this.disconnect();
            }, delay);
        }
        cancelDelayedDisconnect() {
            clearTimeout(this.delayedDisconnectTimeoutId);
            this.delayedDisconnectTimeoutId = undefined;
        }
        /**
         * When the server restarts, we don't want to overload it
         * with thousands of clients trying to reconnect as soon as possible.
         * Instead, we wait between 10 to 20 seconds before reconnecting.
         * The added random allows sampling reconnections nicely.
         */
        deploy() {
            this.disconnect();
            // we don't want to possibly reconnect in background, so make sure there
            // is no disconnect scheduled
            if (this.delayedDisconnectTimeoutId === null) {
                this.scheduleConnect(10 * 1000 + Math.random() * 10 * 1000);
            }
        }
        pingInterval() {
            return this.options.pingDelay + this.averageLag;
        }
    }
    StrongSocket.defaultOptions = {
        name: 'unnamed',
        idle: false,
        pingMaxLag: 9000, // time to wait for pong before reseting the connection
        pingDelay: 2500, // time between pong and ping
        autoReconnectDelay: 3500,
        sendOnOpen: undefined, // message to send on socket open
        registeredEvents: [],
        isAuth: false,
    };
    class Ackable {
        constructor(send) {
            this.send = send;
            this.currentId = 1; // increment with each ackable message sent
            this.messages = [];
            this.sign = (s) => this._sign = s;
            this.resend = () => {
                const resendCutoff = performance.now() - 2500;
                this.messages.forEach(m => {
                    if (m.at < resendCutoff)
                        this.send(m.t, m.d, { sign: this._sign });
                });
            };
            this.register = (t, d) => {
                d.a = this.currentId++;
                this.messages.push({
                    t: t,
                    d: d,
                    at: performance.now()
                });
            };
            this.onServerAck = (id) => {
                this.messages = this.messages.filter(m => m.d.a !== id);
            };
            setInterval(this.resend, 1200);
        }
    }
    function makeUrl(path, params) {
        const searchParams = new URLSearchParams();
        for (const k of Object.keys(params)) {
            if (params[k] !== undefined)
                searchParams.append(k, params[k]);
        }
        const query = searchParams.toString();
        return query ? `${path}?${query}` : path;
    }

    let current;
    const ctx = self;
    ctx.onmessage = (msg) => {
        switch (msg.data.topic) {
            case 'create':
                create(msg.data.payload);
                break;
            case 'send':
                doSend(msg.data.payload);
                break;
            case 'ask': {
                const event = msg.data.payload.listenTo;
                if (current &&
                    current.options.registeredEvents.indexOf(event) === -1) {
                    current.options.registeredEvents.push(event);
                }
                doSend(msg.data.payload.msg);
                break;
            }
            case 'connect':
                if (current)
                    current.connect();
                break;
            case 'disconnect':
                if (current)
                    current.disconnect();
                break;
            case 'delayedDisconnect':
                if (current)
                    current.delayedDisconnect(msg.data.payload);
                break;
            case 'cancelDelayedDisconnect':
                if (current)
                    current.cancelDelayedDisconnect();
                break;
            case 'destroy':
                if (current) {
                    current.disconnect();
                    current = undefined;
                }
                break;
            case 'setVersion':
                if (current) {
                    current.setVersion(msg.data.payload);
                }
                break;
            case 'averageLag':
                if (current) {
                    ctx.postMessage({ topic: 'averageLag', payload: Math.round(current.averageLag) });
                }
                else
                    ctx.postMessage({ topic: 'averageLag', payload: null });
                break;
            case 'getVersion':
                if (current)
                    ctx.postMessage({ topic: 'getVersion', payload: current.version });
                else
                    ctx.postMessage({ topic: 'getVersion', payload: null });
                break;
            case 'deploy':
                if (current)
                    current.deploy();
                break;
            default:
                throw new Error('socker worker message not supported: ' + msg.data.topic);
        }
    };
    function create(payload) {
        // don't always recreate default socket on page change
        // we don't want to do it for other sockets bc/ we want to register other
        // handlers on create
        if (current && payload.opts.options.name === 'default' &&
            current.options.name === 'default') {
            return;
        }
        if (current) {
            current.disconnect(() => {
                current = new StrongSocket(ctx, payload.clientId, payload.socketEndPoint, payload.url, payload.version, payload.opts);
            });
        }
        else {
            current = new StrongSocket(ctx, payload.clientId, payload.socketEndPoint, payload.url, payload.version, payload.opts);
        }
    }
    function doSend(socketMsg) {
        const [url, t, d, o] = socketMsg;
        if (current && current.ws) {
            if (current.path === url || url === 'noCheck') {
                current.send(t, d, o);
            }
            else {
                // trying to send to the wrong URL? log it
                const wrong = {
                    t: t,
                    d: d,
                    url: url
                };
                current.send('wrongHole', wrong);
                console.warn('[socket] wrongHole', wrong);
            }
        }
    }

})();
