import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, m as h, b as session, K as handleXhrError, r as redraw } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

let formError = null;
var kid = {
    oncreate: viewSlideIn,
    oninit() {
        this.submitting = false;
    },
    view() {
        const header = dropShadowHeader(null, backButton(i18n('kidMode')));
        return layout.free(header, renderBody(this));
    }
};
function renderBody(ctrl) {
    return [
        h('div.native_scroller.page.settings_list', [
            h('p.explanation', i18n('kidModeExplanation')),
            h('p.list_item', h.trust(i18n('inKidModeTheLichessLogoGetsIconX', '<span class="kiddo">😊</span>'))),
            h('p.list_item', [
                h('form.defaultForm.kid_form', {
                    onsubmit: (e) => {
                        e.preventDefault();
                        if (ctrl.submitting)
                            return;
                        const form = e.target;
                        const passwd = form['password'].value;
                        if (!passwd)
                            return;
                        ctrl.submitting = true;
                        session.setKidMode(!session.isKidMode(), { passwd })
                            .then(() => {
                            ctrl.submitting = false;
                        })
                            .catch((err) => {
                            ctrl.submitting = false;
                            if (err.status !== 400 && err.status !== 401)
                                handleXhrError(err);
                            // TODO update when server side handle content negotiation
                            else if (err.status === 400) {
                                formError = i18n('incorrectPassword');
                                redraw();
                            }
                        });
                    }
                }, [
                    h('div.field', [
                        h('input#password', {
                            type: 'password',
                            className: formError ? 'form-error' : '',
                            placeholder: i18n('password'),
                            required: true
                        }),
                        formError ? h('div.form-error', formError) : null,
                    ]),
                    h('div.submit', [
                        !session.isKidMode() ?
                            h('button.defaultButton', i18n('enableKidMode')) :
                            h('button.defaultButton.cancel', i18n('disableKidMode'))
                    ])
                ])
            ])
        ])
    ];
}

export { kid as default };
//# sourceMappingURL=kid-CyimFk10.js.map
