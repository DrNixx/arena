import { ah as registerPlugin, g as settings } from './main.js';

var ImpactStyle;
(function (ImpactStyle) {
    /**
     * A collision between large, heavy user interface elements
     *
     * @since 1.0.0
     */
    ImpactStyle["Heavy"] = "HEAVY";
    /**
     * A collision between moderately sized user interface elements
     *
     * @since 1.0.0
     */
    ImpactStyle["Medium"] = "MEDIUM";
    /**
     * A collision between small, light user interface elements
     *
     * @since 1.0.0
     */
    ImpactStyle["Light"] = "LIGHT";
})(ImpactStyle || (ImpactStyle = {}));
var NotificationType;
(function (NotificationType) {
    /**
     * A notification feedback type indicating that a task has completed successfully
     *
     * @since 1.0.0
     */
    NotificationType["Success"] = "SUCCESS";
    /**
     * A notification feedback type indicating that a task has produced a warning
     *
     * @since 1.0.0
     */
    NotificationType["Warning"] = "WARNING";
    /**
     * A notification feedback type indicating that a task has failed
     *
     * @since 1.0.0
     */
    NotificationType["Error"] = "ERROR";
})(NotificationType || (NotificationType = {}));

const Haptics = registerPlugin('Haptics', {
    web: () => import('./web-AVbd_-NE.js').then(m => new m.HapticsWeb()),
});

let shouldVibrate = settings.general.vibrateOnGameEvents();
var vibrate = {
    quick() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(150);
            }
            else {
                void Haptics.vibrate({ duration: 150 });
            }
        }
    },
    tap() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
            else {
                void Haptics.impact({ style: ImpactStyle.Medium });
            }
        }
    },
    heavy() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(100);
            }
            else {
                void Haptics.impact({ style: ImpactStyle.Heavy });
            }
        }
    },
    doubleTap() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
            else {
                void Haptics.impact({ style: ImpactStyle.Medium }).then(() => {
                    void new Promise(r => setTimeout(r, 150)).then(() => {
                        void Haptics.impact({ style: ImpactStyle.Medium });
                    });
                });
            }
        }
    },
    warn() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
            else {
                void Haptics.notification({ type: NotificationType.Warning });
            }
        }
    },
    bad() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
            else {
                void Haptics.notification({ type: NotificationType.Error });
            }
        }
    },
    good() {
        if (shouldVibrate) {
            if (window.navigator.vibrate) {
                window.navigator.vibrate(50);
            }
            else {
                void Haptics.notification({ type: NotificationType.Success });
            }
        }
    },
    onSettingChange(v) {
        shouldVibrate = v;
    }
};

export { ImpactStyle as I, NotificationType as N, vibrate as v };
//# sourceMappingURL=vibrate-CyNrNHlt.js.map
