import { aA as viewSlideIn, G as dropShadowHeader, I as backButton, o as i18n, s as socket, m as h, p as ontapY, q as router } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';

function renderBody() {
    return [
        h('ul.native_scroller.page.settings_list.game', [
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/account/preferences/game-display'))
            }, i18n('gameDisplay')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/account/preferences/clock'))
            }, i18n('clock')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/account/preferences/game-behavior'))
            }, i18n('gameBehavior')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/account/preferences/privacy'))
            }, i18n('privacy')),
            h('li.list_item.nav', {
                oncreate: ontapY(() => router.set('/account/preferences/kidMode'))
            }, i18n('kidMode'))
        ])
    ];
}
const PreferencesScreen = {
    oncreate: viewSlideIn,
    oninit() {
        socket.createDefault();
    },
    view: function () {
        const header = dropShadowHeader(null, backButton(i18n('preferences')));
        return layout.free(header, renderBody());
    }
};

export { PreferencesScreen as default };
//# sourceMappingURL=preferences-BVng74qS.js.map
