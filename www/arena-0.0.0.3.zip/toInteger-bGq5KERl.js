import { f as fetchJSON, bT as fetchText, aw as serializeQueryParameters, $ as Toast, o as i18n, bU as SESSION_ID_KEY, d as debounce, r as redraw, q as router, bO as slidesOutDown, bP as Keyboard, m as h, bR as slidesInUp, x as ontap, bC as closeIcon, w as spinner, g as settings, aW as move, aX as end, bV as toNumber } from './main.js';

function reload(ctrl) {
    return fetchJSON(ctrl.data.url.round);
}
function getPGN(gameId, raw = false) {
    const params = raw ? '?evals=0&clocks=0' : '?literate=1';
    return fetchText(`/game/export/${gameId}${params}`, {
        headers: {
            'Accept': 'application/x-chess-pgn, text/*',
            'X-Requested-With': '__delete',
            [SESSION_ID_KEY]: '__delete',
        },
        credentials: 'omit',
    }, true);
}
function readNote(gameId) {
    return fetchText(`/${gameId}/note`);
}
function syncNote(gameId, notes) {
    return fetchText(`/${gameId}/note`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/*'
        },
        body: serializeQueryParameters({ text: notes })
    }, false)
        .catch(err => {
        Toast.show({ text: i18n('notesSynchronizationHasFailed'), duration: 'short' });
        throw err;
    });
}
function getCrosstable(uid1, uid2) {
    return fetchJSON('/api/crosstable/' + uid1 + '/' + uid2, { cache: 'reload' });
}

class NotesCtrl {
    constructor(data) {
        this.syncNotes = debounce((e) => {
            const text = e.target.value;
            if (this.data.note !== text) {
                syncNote(this.data.game.id, text)
                    .then(() => {
                    this.data.note = text;
                    redraw();
                });
            }
        }, 1000);
        this.open = () => {
            router.backbutton.stack.push(slidesOutDown(this.close, 'notes'));
            this.showing = true;
        };
        this.close = (fromBB) => {
            Keyboard.hide();
            if (fromBB !== 'backbutton' && this.showing) {
                router.backbutton.stack.pop();
            }
            this.showing = false;
        };
        this.syncing = true;
        this.data = data;
        this.showing = false;
        this.inputValue = '';
        readNote(data.game.id)
            .then(note => {
            this.data.note = note;
            this.syncing = false;
            redraw();
        })
            .catch(() => {
            this.syncing = false;
            redraw();
            Toast.show({ text: 'Could not read notes from server.', position: 'bottom', duration: 'short' });
        });
    }
}
function notesView(ctrl) {
    if (!ctrl.showing)
        return null;
    return h('div#notes.modal', { oncreate: slidesInUp }, [
        h('header', [
            h('button.modal_close', {
                oncreate: ontap(slidesOutDown(ctrl.close, 'notes'))
            }, closeIcon),
            h('h2', i18n('notes'))
        ]),
        h('div.modal_content', [
            ctrl.syncing ?
                h('div.notesTextarea.loading', spinner.getVdom()) :
                h('textarea#notesTextarea.native_scroller', {
                    placeholder: i18n('typePrivateNotesHere'),
                    oninput: ctrl.syncNotes,
                    value: ctrl.data.note,
                })
        ])
    ]);
}

function isDraggable(data, color) {
    return data.movable.color === color && (data.turnColor === color || data.predroppable.enabled);
}
function crazyDrag (ctrl, e) {
    if (e.touches && e.touches.length > 1)
        return;
    if (!ctrl.canDrop())
        return;
    const role = e.target.getAttribute('data-role'), color = e.target.getAttribute('data-color'), nb = e.target.getAttribute('data-nb');
    if (!role || !color || nb === '0')
        return;
    if (!isDraggable(ctrl.chessground.state, color))
        return;
    e.stopPropagation();
    e.preventDefault();
    const piece = {
        role,
        color
    };
    ctrl.chessground.dragNewPiece(e, piece);
}

const pieceRoles = ['pawn', 'knight', 'bishop', 'rook', 'queen'];
const CrazyPocket = {
    oninit(vnode) {
        const { ctrl } = vnode.attrs;
        const onstart = (e) => crazyDrag(ctrl, e);
        const onmove = (e) => move(ctrl.chessground, e);
        const onend = (e) => end(ctrl.chessground, e);
        this.pocketOnCreate = function (vnode) {
            const dom = vnode.dom;
            dom.addEventListener('touchstart', onstart);
            dom.addEventListener('touchmove', onmove);
            dom.addEventListener('touchend', onend);
        };
        this.pocketOnRemove = function (vnode) {
            const dom = vnode.dom;
            dom.removeEventListener('touchstart', onstart);
            dom.removeEventListener('touchmove', onmove);
            dom.removeEventListener('touchend', onend);
        };
    },
    view(vnode) {
        const { crazyData, position, color, customPieceTheme } = vnode.attrs;
        const pocket = crazyData.pockets[color === 'white' ? 0 : 1];
        const className = [
            customPieceTheme || settings.general.theme.piece(),
            'pocket',
            position || ''
        ].join(' ');
        return (h("div", { className: className, oncreate: this.pocketOnCreate, onremove: this.pocketOnRemove }, pieceRoles.map(role => h("piece", { "data-role": role, "data-color": color, "data-nb": pocket[role] || 0, className: role + ' ' + color }))));
    }
};

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0,
    MAX_INTEGER = 1.7976931348623157e+308;

/**
 * Converts `value` to a finite number.
 *
 * @static
 * @memberOf _
 * @since 4.12.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {number} Returns the converted number.
 * @example
 *
 * _.toFinite(3.2);
 * // => 3.2
 *
 * _.toFinite(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toFinite(Infinity);
 * // => 1.7976931348623157e+308
 *
 * _.toFinite('3.2');
 * // => 3.2
 */
function toFinite(value) {
  if (!value) {
    return value === 0 ? value : 0;
  }
  value = toNumber(value);
  if (value === INFINITY || value === -Infinity) {
    var sign = (value < 0 ? -1 : 1);
    return sign * MAX_INTEGER;
  }
  return value === value ? value : 0;
}

/**
 * Converts `value` to an integer.
 *
 * **Note:** This method is loosely based on
 * [`ToInteger`](http://www.ecma-international.org/ecma-262/7.0/#sec-tointeger).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {number} Returns the converted integer.
 * @example
 *
 * _.toInteger(3.2);
 * // => 3
 *
 * _.toInteger(Number.MIN_VALUE);
 * // => 0
 *
 * _.toInteger(Infinity);
 * // => 1.7976931348623157e+308
 *
 * _.toInteger('3.2');
 * // => 3
 */
function toInteger(value) {
  var result = toFinite(value),
      remainder = result % 1;

  return result === result ? (remainder ? result - remainder : result) : 0;
}

export { CrazyPocket as C, NotesCtrl as N, getPGN as a, getCrosstable as g, notesView as n, reload as r, toInteger as t };
//# sourceMappingURL=toInteger-bGq5KERl.js.map
