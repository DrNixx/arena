import { as as getLichessVariant, at as getInitialFen, g as settings, S as oppositeColor, X as isPortrait, I as backButton, m as h, o as i18n, au as bookmarkButton, a0 as header, s as socket, am as pageSlideIn, an as elFadeIn, H as safeStringToNum, r as redraw, K as handleXhrError, q as router, P as specialFenVariants } from './main.js';
import { g as getCurrentOTBGame, c as getAnalyseData, b as getCurrentAIGame } from './offlineGames-CDpjbNo0.js';
import { G as GameTitle } from './GameTitle-CU8rmgNb.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { p as playerFromFen, a as plyFromFen } from './fen-97CPMMDI.js';
import { r as renderVariantSelector, a as renderContent, o as overlay, l as loadingScreen, g as gameAnalysis, A as AnalyseCtrl } from './AnalyseCtrl-_vlqF8MU.js';
import './game-CgD9Ef6g.js';
import './perfs-BLfNpglP.js';
import './CountdownTimer-sy6et_C9.js';
import './variant-Cl-7Z946.js';
import './promotion-yOaF5Jgj.js';
import './toInteger-bGq5KERl.js';
import './TabView-CG79fzxt.js';
import './chat-Dbn1ft42.js';
import './html-EBv26hf5.js';
import './tree-ByUN6R2a.js';
import './axis-iOnHMIBv.js';
import './Board-UV3Z06Mn.js';
import './chess-B1K_bSdL.js';
import './vibrate-CyNrNHlt.js';
import './index-CkC0Yhqy.js';
import './index-r4T5Y9G7.js';
import './studyXhr-CPiJUv6u.js';

const emptyPocket = {
    queen: 0,
    rook: 0,
    knight: 0,
    bishop: 0,
    pawn: 0
};
function makeDefaultData(variantKey, fen) {
    const player = playerFromFen(fen);
    const ply = plyFromFen(fen);
    const variant = getLichessVariant(variantKey);
    const initialFen = fen || getInitialFen(variantKey);
    return {
        game: {
            fen: initialFen,
            id: 'synthetic',
            initialFen: initialFen,
            player,
            source: 'offline',
            status: {
                id: 10,
                name: 'created'
            },
            turns: 0,
            startedAtTurn: 0,
            variant
        },
        takebackable: false,
        orientation: 'white',
        opponent: {
            color: oppositeColor(player)
        },
        player: {
            color: player
        },
        pref: {
            destination: settings.game.pieceDestinations(),
            highlight: settings.game.highlights(),
        },
        treeParts: [
            {
                fen: initialFen,
                ply,
                crazyhouse: variant.key === 'crazyhouse' ? {
                    pockets: [emptyPocket, emptyPocket]
                } : undefined,
                pgnMoves: []
            }
        ],
        userAnalysis: true
    };
}

var analyse = {
    oninit(vnode) {
        const source = vnode.attrs.source || 'offline';
        const gameId = vnode.attrs.id;
        const orientation = vnode.attrs.color || 'white';
        const fenArg = vnode.attrs.fen;
        const variant = vnode.attrs.variant;
        const ply = safeStringToNum(vnode.attrs.ply);
        const tabId = vnode.attrs.tabId;
        const shouldGoBack = gameId !== undefined || fenArg !== undefined || vnode.attrs.goBack === '1';
        if (source === 'online' && gameId) {
            const now = performance.now();
            gameAnalysis(gameId, orientation)
                .then(cfg => {
                const elapsed = performance.now() - now;
                setTimeout(() => {
                    this.ctrl = new AnalyseCtrl(cfg, undefined, source, orientation, shouldGoBack, ply, tabId);
                    redraw();
                }, Math.max(400 - elapsed, 0));
            })
                .catch(err => {
                handleXhrError(err);
                if (vnode.attrs.fallback && vnode.attrs.curFen && vnode.attrs.color) {
                    router.set(`/analyse/variant/standard/fen/${encodeURIComponent(vnode.attrs.curFen)}?color=${vnode.attrs.color}&goBack=1`);
                }
                else {
                    router.set('/analyse', true);
                }
                redraw();
            });
        }
        else if (source === 'offline' && gameId === 'otb') {
            getCurrentOTBGame()
                .then(savedOtbGame => {
                setTimeout(() => {
                    const otbData = savedOtbGame && getAnalyseData(savedOtbGame, orientation);
                    if (!otbData) {
                        router.set('/analyse', true);
                    }
                    else {
                        otbData.player.spectator = true;
                        this.ctrl = new AnalyseCtrl(otbData, undefined, source, orientation, shouldGoBack, ply, tabId);
                        redraw();
                    }
                }, 400);
            });
        }
        else if (source === 'offline' && gameId === 'ai') {
            getCurrentAIGame()
                .then(savedAiGame => {
                setTimeout(() => {
                    const aiData = savedAiGame && getAnalyseData(savedAiGame, orientation);
                    if (!aiData) {
                        router.set('/analyse', true);
                    }
                    else {
                        aiData.player.spectator = true;
                        this.ctrl = new AnalyseCtrl(aiData, undefined, source, orientation, shouldGoBack, ply, tabId);
                        redraw();
                    }
                }, 400);
            });
        }
        else {
            if (variant === undefined) {
                let settingsVariant = settings.analyse.syntheticVariant();
                // don't allow special variants fen since they are not supported
                if (fenArg) {
                    settingsVariant = specialFenVariants.has(settingsVariant) ?
                        'standard' : settingsVariant;
                }
                let url = `/analyse/variant/${settingsVariant}`;
                if (fenArg)
                    url += `/fen/${encodeURIComponent(fenArg)}`;
                router.set(url, true);
                redraw();
            }
            else {
                this.ctrl = new AnalyseCtrl(makeDefaultData(variant, fenArg), undefined, source, orientation, shouldGoBack, ply, tabId);
                redraw();
            }
        }
    },
    oncreate(vnode) {
        if (vnode.attrs.slide === '1') {
            pageSlideIn(vnode.dom);
        }
        else {
            elFadeIn(vnode.dom);
        }
    },
    onremove() {
        socket.destroy();
        if (this.ctrl) {
            this.ctrl.unload();
            this.ctrl = undefined;
        }
    },
    view(vnode) {
        const isPortrait$1 = isPortrait();
        if (this.ctrl) {
            let backButton$1 = null;
            if (this.ctrl.shouldGoBack) {
                if (this.ctrl.data.game.id === 'synthetic') {
                    backButton$1 = backButton(h('div.main_header_title', i18n('analysis')));
                }
                else {
                    backButton$1 = backButton([
                        h(GameTitle, { data: this.ctrl.data, subTitle: 'date' }),
                        bookmarkButton(this.ctrl.toggleBookmark, this.ctrl.data.bookmarked),
                    ]);
                }
            }
            const title = this.ctrl.shouldGoBack ? null : h('div.main_header_title.withSub', [
                h('div', i18n('analysis')),
                renderVariantSelector(this.ctrl)
            ]);
            return layout.board(header(title, backButton$1), renderContent(this.ctrl, isPortrait$1), undefined, overlay(this.ctrl));
        }
        else {
            return loadingScreen(isPortrait$1, vnode.attrs.color, vnode.attrs.curFen);
        }
    }
};

export { analyse as default };
//# sourceMappingURL=analyse-BqsjjBlx.js.map
