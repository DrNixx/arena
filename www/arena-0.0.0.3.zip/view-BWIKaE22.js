import { a6 as Chessground, g as settings, a7 as animationDuration, T as uciToMoveOrDrop, a8 as boardOrientation, b as session, o as i18n, S as oppositeColor, a9 as standardFen, $ as Toast, m as h, p as ontapY, aa as ontapX, x as ontap, ab as fixCrazySan, U as classSet } from './main.js';
import { i as isPlayerPlaying, g as gameStatus, r as result, p as playable } from './game-CgD9Ef6g.js';
import { m as move, d as drop, t as threefoldTest, p as pgnDump } from './chess-B1K_bSdL.js';
import { b as autoScroll, d as autoScrollInline, r as renderMaterial, g as getMoveEl, o as onReplayTap } from './crazyValid-BQyVE87l.js';
import { C as CrazyPocket } from './toInteger-bGq5KERl.js';

function makeConfig(data, sit) {
    const lastUci = sit.uciMoves.length ? sit.uciMoves[sit.uciMoves.length - 1] : null;
    const pieceMoveConf = settings.game.pieceMove();
    return {
        fen: sit.fen,
        orientation: boardOrientation(data),
        turnColor: sit.player,
        lastMove: lastUci ? uciToMoveOrDrop(lastUci) : null,
        check: sit.check,
        otb: data.game.id === 'offline_otb',
        coordinates: settings.game.coords(),
        otbMode: settings.otb.flipPieces() ? 'flip' : 'facing',
        symmetricCoordinates: data.game.id === 'offline_otb',
        autoCastle: true,
        highlight: {
            lastMove: settings.game.highlights(),
            check: settings.game.highlights()
        },
        movable: {
            free: false,
            color: isPlayerPlaying(data) ? sit.player : null,
            showDests: settings.game.pieceDestinations(),
            dests: sit.dests,
            rookCastle: settings.game.rookCastle() === 1,
        },
        animation: {
            enabled: !!settings.game.animations(),
            duration: animationDuration(settings.game.animations()),
        },
        premovable: {
            enabled: false
        },
        draggable: {
            enabled: pieceMoveConf === 'drag' || pieceMoveConf === 'both',
            centerPiece: data.pref.centerPiece,
            distance: 3,
            magnified: settings.game.magnified()
        },
        selectable: {
            enabled: pieceMoveConf === 'tap' || pieceMoveConf === 'both'
        },
    };
}
function make(data, sit, userMove, userNewPiece, onMove, onNewPiece) {
    const config = makeConfig(data, sit);
    config.movable.events = {
        after: userMove,
        afterNewPiece: userNewPiece
    };
    config.events = {
        move: onMove,
        dropNewPiece: onNewPiece
    };
    return new Chessground(config);
}
function reload(ground, data, sit) {
    ground.reconfigure(makeConfig(data, sit));
}
function changeOTBMode(ground, flip) {
    ground.setOtbMode(flip ? 'flip' : 'facing');
}
function end(ground) {
    ground.stop();
}
var ground = {
    make,
    reload,
    end,
    changeOTBMode
};

const standardVariant = {
    key: 'standard',
    name: 'Standard',
    short: 'STD',
    title: 'Standard rules of chess (FIDE)'
};
function data(cfg) {
    const confColor = cfg.color || 'white';
    const player = {
        color: confColor,
        username: cfg.id === 'offline_ai' ? session.appUser(i18n(confColor)) : i18n(confColor),
        spectator: false
    };
    return {
        game: {
            id: cfg.id,
            offline: true,
            variant: cfg.variant || standardVariant,
            initialFen: cfg.initialFen || standardFen,
            source: 'offline',
            fen: cfg.fen || standardFen,
            player: cfg.player || 'white',
            turns: 0,
            startedAtTurn: 0,
            status: {
                id: 20,
                name: 'created'
            },
            speed: 'unlimited',
            createdAt: Date.now()
        },
        player,
        opponent: {
            color: oppositeColor(confColor),
            username: i18n(oppositeColor(confColor))
        },
        pref: {
            animationDuration: animationDuration(settings.game.animations()),
            centerPiece: cfg.pref && cfg.pref.centerPiece || false
        },
        steps: [],
        offlineClock: cfg.clock
    };
}

function setResult(ctrl, status, winner) {
    const sit = ctrl.replay?.situation();
    if (status) {
        ctrl.data.game.status = status;
    }
    else {
        ctrl.data.game.status = { id: 20, name: 'started' };
    }
    ctrl.data.game.winner = winner || sit?.winner;
}

class Replay {
    constructor(variant, initialFen, initSituations, initPly, onReplayAdded, onThreefoldRepetition) {
        this.situation = () => {
            return this.situations[this.ply];
        };
        this.addMove = (orig, dest, promotion) => {
            const sit = this.situation();
            move({
                variant: this.variant,
                fen: sit.fen,
                pgnMoves: sit.pgnMoves,
                uciMoves: sit.uciMoves,
                promotion,
                orig,
                dest
            })
                .then(this.addMoveOrDrop)
                .catch(console.error.bind(console));
        };
        this.addDrop = (role, key) => {
            const sit = this.situation();
            drop({
                variant: this.variant,
                fen: sit.fen,
                pgnMoves: sit.pgnMoves,
                uciMoves: sit.uciMoves,
                role,
                pos: key
            })
                .then(this.addMoveOrDrop)
                .catch(console.error.bind(console));
        };
        this.claimDraw = () => {
            const sit = this.situation();
            threefoldTest({
                variant: this.variant,
                initialFen: this.initialFen,
                pgnMoves: sit.pgnMoves
            })
                .then(resp => {
                if (resp.threefoldRepetition) {
                    this.onThreefoldRepetition(resp.status);
                }
                else {
                    Toast.show({ text: i18n('incorrectThreefoldClaim'), position: 'center', duration: 'short' });
                }
            })
                .catch(console.error.bind(console));
        };
        this.pgn = (white, black) => {
            const sit = this.situation();
            return pgnDump({
                variant: this.variant,
                initialFen: this.initialFen,
                pgnMoves: sit.pgnMoves,
                white,
                black
            });
        };
        this.addMoveOrDrop = (moveOrDrop) => {
            this.ply++;
            if (this.ply < this.situations.length) {
                this.situations = this.situations.slice(0, this.ply);
            }
            this.situations.push(moveOrDrop.situation);
            this.onReplayAdded(this.situation());
        };
        this.init(variant, initialFen, initSituations, initPly);
        this.onReplayAdded = onReplayAdded;
        this.onThreefoldRepetition = onThreefoldRepetition;
    }
    init(variant, initialFen, situations, ply) {
        this.variant = variant;
        this.initialFen = initialFen;
        this.situations = situations;
        this.ply = ply || 0;
    }
}

function getChecksCount(ctrl, color) {
    const sit = ctrl.replay?.situation();
    if (sit?.checkCount)
        return oppositeColor(color) === 'white' ?
            sit.checkCount.white : sit.checkCount.black;
    else
        return 0;
}
function renderAntagonist(ctrl, content, material, position, otbFlip, customPieceTheme, clock) {
    const sit = ctrl.replay?.situation();
    const isCrazy = !!sit?.crazyhouse;
    const antagonist = position === 'player' ? ctrl.data.player : ctrl.data.opponent;
    const antagonistColor = antagonist.color;
    const className = [
        'playTable',
        'offline',
        position,
        isCrazy ? 'crazy' : '',
        otbFlip !== undefined ? otbFlip ? 'mode_flip' : 'mode_facing' : '',
        ctrl.chessground.state.turnColor === ctrl.data.player.color ? 'player_turn' : 'opponent_turn',
    ].join(' ');
    return (h("section", { id: position + '_info', className: className },
        h("div", { className: 'antagonistInfos offline' + (isCrazy ? ' crazy' : '') },
            h("div", { className: "antagonistUser" },
                content,
                isCrazy && clock ? renderClock(clock, antagonistColor) : ''),
            !isCrazy ? h("div", { className: "ratingAndMaterial" },
                ctrl.data.game.variant.key === 'horde' ? null : renderMaterial(material),
                ctrl.data.game.variant.key === 'threeCheck' ?
                    h("div", { className: "checkCount" },
                        "\u00A0+",
                        getChecksCount(ctrl, antagonistColor)) : null) : null),
        sit?.crazyhouse ?
            h(CrazyPocket, {
                ctrl,
                crazyData: sit.crazyhouse,
                color: antagonistColor,
                position,
                customPieceTheme
            })
            :
                clock ? renderClock(clock, antagonistColor) : null));
}
function renderGameActionsBar(ctrl) {
    return (h("section", { className: "actions_bar" },
        h("button", { className: "action_bar_button fa fa-list", oncreate: ontap(ctrl.actions.open) }),
        h("button", { className: "action_bar_button fa fa-plus-circle", oncreate: ontap(ctrl.newGameMenu.open, () => Toast.show({ text: i18n('createAGame'), duration: 'short', position: 'bottom' })) }),
        h("button", { className: "fa fa-share-alt action_bar_button", oncreate: ontap(ctrl.sharePGN, () => Toast.show({ text: i18n('sharePgn'), duration: 'short', position: 'bottom' })) }),
        h("button", { className: "action_bar_button", "data-icon": "A", oncreate: ontap(ctrl.goToAnalysis) }),
        renderBackwardButton(ctrl),
        renderForwardButton(ctrl)));
}
function renderEndedGameStatus(ctrl) {
    if (!ctrl.replay)
        return null;
    const sit = ctrl.replay.situation();
    if (gameStatus.finished(ctrl.data)) {
        const result$1 = result(ctrl.data);
        const winner = sit.winner;
        const status = gameStatus.toLabel(ctrl.data.game.status.name, ctrl.data.game.turns, ctrl.data.game.winner, ctrl.data.game.variant.key) +
            (winner ? '. ' + i18n(winner === 'white' ? 'whiteIsVictorious' : 'blackIsVictorious') + '.' : '');
        return (h("div", { className: "result" },
            result$1,
            h("br", null),
            h("em", { className: "resultStatus" }, status)));
    }
    return null;
}
function renderClaimDrawButton(ctrl) {
    return playable(ctrl.data) ? h('button.draw-yes', {
        oncreate: ontap(() => ctrl.replay?.claimDraw())
    }, h('span', '½'), i18n('threefoldRepetition')) : null;
}
function renderReplay(ctrl) {
    const pieceNotation = settings.game.pieceNotation();
    return ctrl.replay ? h('div.replay.box', {
        className: pieceNotation ? ' displayPieces' : '',
        oncreate: (vnode) => {
            setTimeout(() => autoScroll(vnode.dom), 100);
            ontapY((e) => onReplayTap(ctrl, e), undefined, getMoveEl)(vnode);
        },
        onupdate: (vnode) => autoScroll(vnode.dom),
    }, renderMoves(ctrl.replay)) : null;
}
function renderInlineReplay(ctrl) {
    const pieceNotation = settings.game.pieceNotation();
    if (!ctrl.replay || !ctrl.moveList) {
        return null;
    }
    return h('div.replay_inline', {
        className: pieceNotation ? ' displayPieces' : '',
        oncreate: (vnode) => {
            setTimeout(() => autoScrollInline(vnode.dom), 100);
            ontapX((e) => onReplayTap(ctrl, e), undefined, getMoveEl)(vnode);
        },
        onupdate: (vnode) => autoScrollInline(vnode.dom),
    }, renderMoves(ctrl.replay));
}
function renderBackwardButton(ctrl) {
    return ctrl.replay ? h('button.action_bar_button.fa.fa-chevron-left', {
        oncreate: ontap(ctrl.jumpPrev, ctrl.jumpFirst),
        className: classSet({
            disabled: !(ctrl.replay.ply > ctrl.firstPly())
        })
    }) : null;
}
function renderForwardButton(ctrl) {
    return ctrl.replay ? h('button.action_bar_button.fa.fa-chevron-right', {
        oncreate: ontap(ctrl.jumpNext, ctrl.jumpLast),
        className: classSet({
            disabled: !(ctrl.replay.ply < ctrl.lastPly())
        })
    }) : null;
}
function renderMoves(replay) {
    return replay.situations.filter(s => s.san !== undefined).map(s => h('move.replayMove', {
        className: s.ply === replay.ply ? 'current' : '',
        'data-ply': s.ply,
    }, [
        s.ply & 1 ? h('index', renderIndex(s.ply)) : null,
        fixCrazySan(s.san)
    ]));
}
function renderIndexText(ply, withDots) {
    return plyToTurn(ply) + ((ply % 2 === 1 ? '.' : '...') );
}
function renderIndex(ply, withDots) {
    return h('index', renderIndexText(ply));
}
function plyToTurn(ply) {
    return Math.floor((ply - 1) / 2) + 1;
}
function pad2(num) {
    return (num < 10 ? '0' : '') + num;
}
const sepHigh = ':';
const sepLow = ' ';
function formatClockTime(time, isRunning = false) {
    const date = new Date(time);
    const millis = date.getUTCMilliseconds();
    const minutes = pad2(date.getUTCMinutes());
    const seconds = pad2(date.getUTCSeconds());
    if (time >= 3600000) {
        const hours = pad2(date.getUTCHours());
        const pulse = (isRunning && millis < 500) ? sepLow : sepHigh;
        return hours + pulse + minutes;
    }
    if (time < 10000) {
        const tenthsStr = Math.floor(millis / 100).toString();
        return [minutes + sepHigh + seconds, h('tenths', '.' + tenthsStr)];
    }
    return minutes + sepHigh + seconds;
}
function renderClock(clock, color) {
    const runningColor = clock.activeSide();
    const time = clock.getTime(color);
    const isRunning = runningColor === color;
    const moves = clock.clockType === 'stage' ? clock.getMoves(color) : null;
    return h('div', {
        className: classSet({
            clock: true,
            outoftime: !time,
            running: isRunning,
            offlineClock: true,
            stageClock: !!moves,
        })
    }, [
        formatClockTime(time, isRunning),
        moves ? h('div.clockMoves', 'Moves: ' + moves) : null
    ]);
}

export { Replay as R, renderClaimDrawButton as a, renderReplay as b, renderInlineReplay as c, data as d, renderAntagonist as e, renderBackwardButton as f, ground as g, renderForwardButton as h, renderGameActionsBar as i, renderEndedGameStatus as r, setResult as s };
//# sourceMappingURL=view-BWIKaE22.js.map
