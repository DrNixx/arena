import { q as router, ay as batchRequestAnimationFrame, r as redraw, d as debounce, K as handleXhrError, c as fromNow, m as h, bh as autofocus, x as ontap, bC as closeIcon, o as i18n, p as ontapY, h as throttle, w as spinner, bk as lightPlayerName, bi as closestHandler, be as closest, F as viewFadeIn, a0 as header, s as socket } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { b as search, l as list } from './studyXhr-CPiJUv6u.js';

class StudyIndexCtrl {
    constructor(cat = 'all', order = 'hot', q) {
        this.cat = cat;
        this.order = order;
        this.q = q;
        // used to restore scroll position only once from cached state
        this.initialized = false;
        this.toggleSearch = () => {
            this.state.showSearch = !this.state.showSearch;
        };
        this.canCancelSearch = (enabled) => {
            this.state.canCancelSearch = enabled;
        };
        this.cancelSearch = () => {
            if (this.q) {
                router.setQueryParams({ cat: this.cat, order: this.order }, true);
            }
            else {
                this.state.showSearch = false;
            }
        };
        this.onSearch = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const q = e.target[0].value.trim();
            router.setQueryParams({ q }, true);
        };
        this.onCatChange = (e) => {
            const cat = e.target.value;
            router.setQueryParams({ cat }, true);
        };
        this.onOrderChange = (e) => {
            const order = e.target.value;
            router.setQueryParams({ order }, true);
        };
        this.onScroll = (e) => {
            const target = e.target;
            const content = target.firstChild;
            const paginator = this.state.paginator;
            const nextPage = paginator && paginator.nextPage;
            if ((target.scrollTop + target.offsetHeight + 50) > content.offsetHeight) {
                // lichess doesn't allow for more than 39 pages
                if (!this.state.isLoading && nextPage && nextPage < 40) {
                    this.loadNextPage(nextPage);
                }
            }
            this.state.scrollPos = target.scrollTop;
            this.saveState();
        };
        this.afterLoad = ({ dom }) => {
            if (this.cacheAvailable && !this.initialized) {
                batchRequestAnimationFrame(() => {
                    if (cachedState) {
                        dom.parentNode.scrollTop = cachedState.scrollPos;
                    }
                    this.initialized = true;
                });
            }
        };
        this.loadNextPage = (page) => {
            this.state.isLoading = true;
            const req = this.q ? search(this.q, page) : list(this.cat, this.order, page);
            req.then(data => {
                this.state.paginator = data.paginator;
                this.state.isLoading = false;
                this.state.studies = this.state.studies.concat(data.paginator.currentPageResults.map(addDate));
                this.saveState();
                redraw();
            });
            redraw();
        };
        this.saveState = debounce(() => {
            cachedState = this.state;
        }, 200);
        this.state = {
            studies: [],
            paginator: undefined,
            scrollPos: 0,
            showSearch: !!this.q,
            canCancelSearch: !!this.q,
            isLoading: false,
            // a search query has precedence over cat and order
            stateId: this.q || this.cat + this.order,
        };
        this.cacheAvailable = cachedState ?
            this.state.stateId === cachedState.stateId : false;
        // load either from cache (restore previous search) or from server
        if (this.cacheAvailable) {
            setTimeout(() => {
                Object.assign(this.state, cachedState);
                redraw();
            }, 300);
        }
        else {
            const req = this.q ? search(this.q) : list(this.cat, this.order);
            req.then(data => {
                this.state.studies = data.paginator.currentPageResults.map(addDate);
                this.state.paginator = data.paginator;
                redraw();
            })
                .catch(handleXhrError);
        }
    }
    goToStudy(id) {
        router.set(`/study/${id}`);
    }
}
let cachedState;
function addDate(s) {
    return {
        ...s,
        date: fromNow(new Date(s.updatedAt))
    };
}

function studyIndexView(ctrl) {
    return h('div.study-pagerWrapper', [
        h('div.study-pagerSubHeader.subHeader', [
            ctrl.state.showSearch ?
                h('form.study-pagerSearchWrapper', {
                    onsubmit: ctrl.onSearch
                }, [
                    h('div.inputWrapper', [
                        h('input#studySearch[type=search]', {
                            placeholder: 'Search studies',
                            autocapitalize: 'off',
                            autocomplete: 'off',
                            oncreate: autofocus,
                            value: ctrl.q,
                            oninput: debounce((e) => {
                                const val = e.target.value.trim();
                                ctrl.canCancelSearch(val.length > 0);
                                redraw();
                            }, 200, { leading: true, trailing: true })
                        }),
                        ctrl.state.canCancelSearch ? h('div.cancel', {
                            oncreate: ontap(ctrl.cancelSearch)
                        }, closeIcon) : null,
                    ]),
                    h('button', i18n('search')),
                ]) :
                h('div.study-pagerSelectWrapper', [
                    h('div.categories', h('select.study-pagerSelect', {
                        value: ctrl.cat,
                        onchange: ctrl.onCatChange,
                    }, categories.map(c => h('option', {
                        key: c[0],
                        value: c[0],
                    }, c[1])))),
                    h('div.orders', h('select.study-pagerSelect', {
                        value: ctrl.order,
                        onchange: ctrl.onOrderChange,
                    }, orders.map(o => h('option', {
                        key: o[0],
                        value: o[0],
                    }, o[1])))),
                ]),
            h('div.study-pagerToggleSearch.fa.fa-search', {
                oncreate: ontap(ctrl.toggleSearch)
            }),
        ]),
        studyList(ctrl)
    ]);
}
const categories = [
    ['all', i18n('allStudies')],
    ['mine', i18n('myStudies')],
    ['member', i18n('studiesIContributeTo')],
    ['public', i18n('myPublicStudies')],
    ['private', i18n('myPrivateStudies')],
    ['likes', i18n('myFavoriteStudies')],
];
const orders = [
    ['hot', i18n('hot')],
    ['newest', i18n('dateAddedNewest')],
    ['updated', i18n('recentlyUpdated')],
    ['popular', i18n('mostPopular')],
];
function studyList(ctrl) {
    const studies = ctrl.state ? ctrl.state.studies : [];
    return h('div#scroller-wrapper.native_scroller.study-pagerScroller.box', {
        onscroll: throttle(ctrl.onScroll, 30),
        oncreate: ontapY(e => onTap(ctrl, e), undefined, closestHandler('.study-pagerItem'))
    }, ctrl.state.paginator ?
        studies.length ?
            h('ul', {
                oncreate: ctrl.afterLoad,
            }, [...studies.map((study, index) => h(Item, { study, index })), ctrl.state.isLoading ? h('li.list_item.study-pagerItem', 'loading...') : []]) :
            h('div.study-pagerEmpty', 'None yet') :
        h('div.study-pagerLoader', spinner.getVdom('monochrome')));
}
function onTap(ctrl, e) {
    const el = closest(e, '.study-pagerItem');
    const id = el?.dataset.id;
    if (id) {
        ctrl.goToStudy(id);
    }
}
const Item = {
    onbeforeupdate({ attrs }, { attrs: oldattrs }) {
        return attrs.study !== oldattrs.study;
    },
    view({ attrs }) {
        const { study, index } = attrs;
        const ownerName = study.owner ? lightPlayerName(study.owner) : '?';
        return h('li.list_item.study-pagerItem', {
            className: index % 2 === 0 ? 'even' : 'odd',
            'data-id': study.id
        }, [
            h('div.study-pagerItemTitle', [
                h('i[data-icon=4]'),
                h('div', [
                    h('h2', study.name),
                    h('h3', [
                        h('i.fa', {
                            className: study.liked ? 'fa-heart' : 'fa-heart-o'
                        }),
                        h('span', ` ${study.likes} • ${ownerName} • ${study.date}`)
                    ])
                ])
            ]),
            h('div.study-pagerItemBody', [
                h('ul.chapters', study.chapters.map(c => h('li', [h('span.fa.fa-circle-o'), c]))),
                h('ul.members', study.members.filter(m => m.user !== null).map(m => h('li.withIcon', {
                    'data-icon': m.role === 'w' ? '' : 'v'
                }, lightPlayerName(m.user)))),
            ])
        ]);
    }
};

var studyIndex = {
    oncreate: viewFadeIn,
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = new StudyIndexCtrl(attrs.cat, attrs.order, attrs.q);
    },
    view() {
        const ctrl = this.ctrl;
        return layout.free(header(i18n('studyMenu')), studyIndexView(ctrl));
    }
};

export { studyIndex as default };
//# sourceMappingURL=studyIndex-BkX6Lvid.js.map
