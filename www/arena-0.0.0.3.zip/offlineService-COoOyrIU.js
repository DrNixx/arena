import { av as asyncStorage, f as fetchJSON, $ as Toast, q as router, g as settings } from './main.js';

const db = {
    fetch,
    save,
    clean,
};
const dbName = 'offlinePuzzlesV2';
function fetch(userId) {
    return asyncStorage.get(`${dbName}.${userId}`);
}
function save(userId, userData) {
    return asyncStorage.set(`${dbName}.${userId}`, userData);
}
function clean(userId) {
    return asyncStorage.remove(`${dbName}.${userId}`);
}

function round(outcome) {
    return fetchJSON(`/training/${outcome.id}/round2`, {
        method: 'POST',
        body: JSON.stringify({
            win: outcome.win
        })
    });
}
function vote(id, v) {
    return fetchJSON(`/training/${id}/vote`, {
        method: 'POST',
        body: JSON.stringify({
            vote: v ? 1 : 0
        })
    });
}
function loadPuzzle(id) {
    return fetchJSON(`/training/${id}/load`, { cache: 'reload' });
}
function newPuzzle() {
    return fetchJSON('/training/new');
}
function newPuzzlesBatch(num, after) {
    return fetchJSON('/training/batch', {
        method: 'GET',
        query: { nb: num, after },
        cache: 'reload',
    });
}
function solvePuzzlesBatch(outcomes) {
    return fetchJSON('/training/batch', {
        method: 'POST',
        body: JSON.stringify({
            solutions: outcomes
        })
    });
}

/*
 * Synchronize puzzles with server and load a new puzzle from offline database.
 */
function syncAndLoadNewPuzzle(database, user) {
    // try loading first from DB to avoid any unnecessary loading time (spotty
    // connection)
    // if no puzzles available, sync and load
    return loadNewPuzzle(database, user)
        .catch(() => doLoadPuzzle(() => syncPuzzles(database, user)));
}
/*
 * Load a new puzzle from offline database.
 */
function loadNewPuzzle(database, user) {
    return doLoadPuzzle(() => database.fetch(user.id));
}
/*
 * Get remaining puzzles in unsolved queue
 */
function getUnsolved(database, user) {
    return database.fetch(user.id)
        .then(data => data && data.unsolved || []);
}
/*
 * Get the number of remaining puzzles in unsolved queue
 */
function nbRemainingPuzzles(database, user) {
    return database.fetch(user.id)
        .then(data => data && data.unsolved.length || 0);
}
/*
 * Save puzzle result in database and synchronize with server.
 */
function syncPuzzleResult(database, user, outcome) {
    return database.fetch(user.id)
        .then(data => {
        // if we reach here there must be data
        if (data) {
            return database.save(user.id, {
                ...data,
                solved: data.solved.concat([{
                        id: outcome.id,
                        win: outcome.win
                    }]),
                unsolved: data.unsolved.filter(p => p.puzzle.id !== outcome.id)
            })
                .then(() => {
                return syncPuzzles(database, user);
            });
        }
        return null;
    });
}
/*
 * Sync current data then clear puzzle cache to force get new puzzles
 */
function syncAndClearCache(database, user) {
    return syncPuzzles(database, user)
        .then(() => database.clean(user.id).then(() => syncAndLoadNewPuzzle(database, user)));
}
function puzzleLoadFailure(reason) {
    if (typeof reason === 'string') {
        Toast.show({ text: reason, position: 'center', duration: 'long' });
    }
    else {
        Toast.show({ text: 'Could not load puzzle', position: 'center', duration: 'short' });
    }
    router.set('/');
}
/*
 * Synchronize puzzles with server.
 * The goal is to keep a queue of 50 (see settings) puzzles in the offline database,
 * so that they can be played offline at any time.
 *
 * Each time a puzzle is solved or a new puzzle is requested, this function is called.
 * It keeps track of solved puzzles and unsolved ones. Solved ones are synchronized
 * so that rating is up to date server side, and unsolved ones are downloaded
 * when needed, ie. when the queue length is less than 50.
 *
 * Returns a Promise with synchronized data or null if no data was already here
 * and synchronization could not be performed (when offline for instance).
 */
function syncPuzzles(database, user) {
    return database.fetch(user.id)
        .then(stored => {
        const unsolved = stored ? stored.unsolved : [];
        const solved = stored ? stored.solved : [];
        const puzzleDeficit = Math.max(settings.training.puzzleBufferLen - unsolved.length, 0);
        const solvePromise = solved.length > 0 ? solvePuzzlesBatch(solved) : Promise.resolve();
        const allIds = unsolved.map(p => p.puzzle.id);
        const lastId = allIds.length > 0 ? Math.max(...allIds) : undefined;
        return solvePromise
            .then(() => !stored || puzzleDeficit > 0 ?
            newPuzzlesBatch(puzzleDeficit, lastId) : Promise.resolve({
            puzzles: [],
            user: stored.user,
        }))
            .then(newData => {
            return database.save(user.id, {
                user: newData.user,
                unsolved: unsolved.concat(newData.puzzles),
                solved: []
            });
        })
            // when offline, sync cannot be done so we return same stored data
            .catch(() => stored);
    });
}
function doLoadPuzzle(fetchFn) {
    return new Promise((resolve, reject) => {
        fetchFn()
            .then(data => {
            if (data && data.unsolved.length > 0) {
                resolve(data.unsolved[0]);
            }
            else {
                reject(`No additional offline puzzle available. Go online to get another ${settings.training.puzzleBufferLen}`);
            }
        })
            .catch(reject);
    });
}

export { syncAndLoadNewPuzzle as a, syncPuzzleResult as b, nbRemainingPuzzles as c, db as d, loadPuzzle as e, getUnsolved as g, loadNewPuzzle as l, newPuzzle as n, puzzleLoadFailure as p, round as r, syncAndClearCache as s, vote as v };
//# sourceMappingURL=offlineService-COoOyrIU.js.map
