import { n as noop, r as redraw, m as h, x as ontap, g as settings, Y as viewportDim } from './main.js';

function start(ctrl, orig, dest, callback) {
    const piece = ctrl.chessground.state.pieces.get(dest);
    if (piece && piece.role === 'pawn' && ((dest[1] === '1' && ctrl.chessground.state.turnColor === 'white') ||
        (dest[1] === '8' && ctrl.chessground.state.turnColor === 'black'))) {
        ctrl.promoting = {
            orig: orig,
            dest: dest,
            callback: callback
        };
        redraw();
        return true;
    }
    return false;
}
function finish(ctrl, role) {
    const promoting = ctrl.promoting;
    if (promoting) {
        ctrl.chessground.promote(promoting.dest, role);
        promoting.callback(promoting.orig, promoting.dest, role);
    }
    ctrl.promoting = null;
}
function cancel(ctrl, cgConfig) {
    if (ctrl.promoting) {
        ctrl.promoting = null;
        if (cgConfig)
            ctrl.chessground.set(cgConfig);
        redraw();
    }
}
function otbPromoPieceTransform(ctrl) {
    if (ctrl.data.game.id === 'offline_otb') {
        const state = ctrl.chessground.state;
        if ((state.orientation === 'white' && ctrl.player() === 'black') ||
            (state.orientation === 'black' && ctrl.player() === 'white')) {
            return 'rotate(180deg)';
        }
    }
    return '';
}
function view(ctrl, cancelCallback = noop) {
    if (!ctrl.promoting)
        return null;
    const pieces = ['queen', 'knight', 'rook', 'bishop'];
    if (ctrl.data.game.variant.key === 'antichess') {
        pieces.push('king');
    }
    return h('div.overlay.open', {
        oncreate: ontap(() => cancelCallback(ctrl))
    }, [h('div#promotion_choice', {
            className: settings.general.theme.piece(),
            style: { top: `${(viewportDim().vh - 100) / 2}px` }
        }, pieces.map((role) => {
            return h('piece.' + role + '.' + ctrl.player(), {
                style: { transform: otbPromoPieceTransform(ctrl) },
                oncreate: ontap(() => finish(ctrl, role))
            });
        }))]);
}
var promotion = {
    start,
    cancel,
    view
};

export { promotion as p, view as v };
//# sourceMappingURL=promotion-yOaF5Jgj.js.map
