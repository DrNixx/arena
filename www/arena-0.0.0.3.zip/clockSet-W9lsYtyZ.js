import { aU as formatTimeInSecs, m as h, g as settings, O as formWidgets, aV as tupleOf, x as ontap, r as redraw, R as sound } from './main.js';

const MILLIS = 1000;
const MINUTE_MILLIS = 60 * 1000;
const CLOCK_TICK_STEP = 100;
function formatTime(clockType, time) {
    if (clockType === 'hourglass') {
        return formatTimeInSecs(Math.round(time));
    }
    else {
        return formatTimeInSecs(Math.floor(time));
    }
}
function isStageClock(c) {
    return c.whiteMoves !== undefined;
}
function addStage(stagesSetting) {
    const stages = stagesSetting();
    stages[stages.length - 1].moves = stages[stages.length - 2].moves;
    stages.push({ time: stages[stages.length - 1].time, moves: null });
    stagesSetting(stages);
    redraw();
}
function removeStage(stagesSetting) {
    const stages = stagesSetting();
    if (stages.length <= 2)
        return;
    stages.pop();
    stagesSetting(stages);
    redraw();
}
function clockSettingsView(clockType, onChange) {
    const clockTypes = {
        none() {
            return ('');
        },
        simple() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "select_input" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, settings.clock.simple.time, false, onChange))));
        },
        increment() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "select_input" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, settings.clock.increment.time, false, onChange)),
                h("div", { className: "select_input" }, formWidgets.renderSelect('Increment', 'increment', settings.clock.availableIncrements.map(tupleOf), settings.clock.increment.increment, false, onChange))));
        },
        handicapInc() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "handicapRow" },
                    h("div", { className: "handicapRowTitle" }, "Top"),
                    h("div", { className: "select_input inline handicapRowMember" }, formWidgets.renderSelect('Time', 'topTime', settings.clock.availableTimes, settings.clock.handicapInc.topTime, false, onChange)),
                    h("div", { className: "select_input inline handicapRowMember" }, formWidgets.renderSelect('Increment', 'topIncrement', settings.clock.availableIncrements.map(tupleOf), settings.clock.handicapInc.topIncrement, false, onChange))),
                h("div", { className: "handicapRow" },
                    h("div", { className: "handicapRowTitle" }, "Bottom"),
                    h("div", { className: "select_input inline handicapRowMember" }, formWidgets.renderSelect('Time', 'bottomTime', settings.clock.availableTimes, settings.clock.handicapInc.bottomTime, false, onChange)),
                    h("div", { className: "select_input inline handicapRowMember" }, formWidgets.renderSelect('Increment', 'bottomIncrement', settings.clock.availableIncrements.map(tupleOf), settings.clock.handicapInc.bottomIncrement, false, onChange)))));
        },
        delay() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "select_input" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, settings.clock.delay.time, false, onChange)),
                h("div", { className: "select_input" }, formWidgets.renderSelect('Increment', 'increment', settings.clock.availableIncrements.map(tupleOf), settings.clock.delay.increment, false, onChange))));
        },
        bronstein() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "select_input" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, settings.clock.bronstein.time, false, onChange)),
                h("div", { className: "select_input" }, formWidgets.renderSelect('Increment', 'increment', settings.clock.availableIncrements.map(tupleOf), settings.clock.bronstein.increment, false, onChange))));
        },
        hourglass() {
            return (h("div", { className: "clockSettingParameters" },
                h("div", { className: "select_input" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, settings.clock.hourglass.time, false, onChange))));
        },
        stage() {
            return (h("div", { className: "clockSettingParameters" },
                settings.clock.stage.stages().map((_, index) => renderStage(onChange, index)),
                h("div", { className: "select_input" }, formWidgets.renderSelect('Increment', 'increment', settings.clock.availableIncrements.map(tupleOf), settings.clock.stage.increment, false, onChange))));
        }
    };
    return clockTypes[clockType]();
}
function renderStage(onChange, index) {
    const timeProp = updateTime.bind(undefined, index);
    const moves = updateMoves.bind(undefined, index);
    const hidePlus = settings.clock.stage.stages().length >= 5;
    const hideMinus = settings.clock.stage.stages().length <= 2;
    return (h("div", { className: "stageRow" },
        h("div", { className: "stageRowTitle" }, index + 1),
        h("div", { className: "select_input inline stage stageRowMember" }, formWidgets.renderSelect('Time', 'time', settings.clock.availableTimes, timeProp, false, onChange)),
        h("div", { className: 'select_input inline stage stageRowMember' + ((index === settings.clock.stage.stages().length - 1) ? ' lastStage' : '') }, formWidgets.renderSelect('Moves', 'moves', settings.clock.availableMoves.map(tupleOf), moves, false, onChange)),
        h("div", { className: 'stageRowMember addSubtractStage' + ((index === settings.clock.stage.stages().length - 1) ? ' lastStage' : '') },
            h("span", { className: 'fa fa-plus-square-o' + (hidePlus ? ' hiddenButton' : ''), oncreate: ontap(() => addStage(settings.clock.stage.stages)) }),
            " ",
            h("span", { className: 'fa fa-minus-square-o' + (hideMinus ? ' hiddenButton' : ''), oncreate: ontap(() => removeStage(settings.clock.stage.stages)) }))));
}
function updateTime(index, time) {
    const stages = settings.clock.stage.stages();
    if (time) {
        stages[index].time = time;
        settings.clock.stage.stages(stages);
    }
    return stages[index].time;
}
function updateMoves(index, moves) {
    const stages = settings.clock.stage.stages();
    if (moves) {
        stages[index].moves = moves;
        settings.clock.stage.stages(stages);
    }
    return stages[index].moves;
}

function HandicapIncClock(whiteTimeParam, whiteIncrement, blackTimeParam, blackIncrement, onFlag, soundOn) {
    let state = {
        clockType: 'handicapInc',
        whiteTime: (whiteTimeParam !== 0) ? whiteTimeParam : whiteIncrement,
        blackTime: (blackTimeParam !== 0) ? blackTimeParam : blackIncrement,
        whiteIncrement: whiteIncrement,
        blackIncrement: blackIncrement,
        activeSide: undefined,
        flagged: undefined,
        isRunning: false
    };
    let clockInterval;
    let whiteTimestamp;
    let blackTimestamp;
    function tick() {
        const now = performance.now();
        if (activeSide() === 'white') {
            const elapsed = now - whiteTimestamp;
            whiteTimestamp = now;
            state.whiteTime = Math.max(state.whiteTime - elapsed, 0);
            if (whiteTime() <= 0) {
                state.flagged = 'white';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        else if (activeSide() === 'black') {
            const elapsed = now - blackTimestamp;
            blackTimestamp = now;
            state.blackTime = Math.max(state.blackTime - elapsed, 0);
            if (blackTime() <= 0) {
                state.flagged = 'black';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        redraw();
    }
    function clockHit(side) {
        if (flagged()) {
            return;
        }
        sound.clock();
        if (side === 'white') {
            if (activeSide() === 'white') {
                state.whiteTime = state.whiteTime + state.whiteIncrement;
            }
            blackTimestamp = performance.now();
            state.activeSide = 'black';
        }
        else if (side === 'black') {
            if (activeSide() === 'black') {
                state.blackTime = state.blackTime + state.blackIncrement;
            }
            whiteTimestamp = performance.now();
            state.activeSide = 'white';
        }
        clearInterval(clockInterval);
        clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        state.isRunning = true;
        redraw();
    }
    function startStop() {
        if (isRunning()) {
            clearInterval(clockInterval);
            state.isRunning = false;
        }
        else {
            state.isRunning = true;
            if (activeSide() === 'white') {
                whiteTimestamp = performance.now();
            }
            else {
                blackTimestamp = performance.now();
            }
            clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        }
    }
    function activeSide() {
        return state.activeSide;
    }
    function flagged() {
        return state.flagged;
    }
    function isRunning() {
        return state.isRunning;
    }
    function getState() {
        return state;
    }
    function setState(newState) {
        state = newState;
    }
    function whiteTime() {
        return state.whiteTime;
    }
    function blackTime() {
        return state.blackTime;
    }
    function getTime(color) {
        return color === 'white' ? whiteTime() : blackTime();
    }
    function toggleActiveSide() {
        if (state.activeSide)
            if (state.activeSide === 'white') {
                blackTimestamp = performance.now();
                state.activeSide = 'black';
            }
            else {
                whiteTimestamp = performance.now();
                state.activeSide = 'white';
            }
    }
    const clockType = 'handicapInc';
    return {
        clockType,
        getState,
        setState,
        activeSide,
        flagged,
        isRunning,
        clockHit,
        startStop,
        whiteTime,
        blackTime,
        getTime,
        toggleActiveSide,
        clear() {
            clearInterval(clockInterval);
        }
    };
}

function DelayClock(time, increment, onFlag, soundOn) {
    let state = {
        clockType: 'delay',
        whiteTime: (time !== 0) ? time : increment,
        blackTime: (time !== 0) ? time : increment,
        whiteDelay: increment,
        blackDelay: increment,
        increment: increment,
        activeSide: undefined,
        flagged: undefined,
        isRunning: false
    };
    let clockInterval;
    let whiteTimestamp;
    let blackTimestamp;
    function tick() {
        const now = performance.now();
        if (activeSide() === 'white') {
            const elapsed = now - whiteTimestamp;
            whiteTimestamp = now;
            if (Math.floor(state.whiteDelay) > 0) {
                state.whiteDelay = state.whiteDelay - elapsed;
            }
            else {
                state.whiteTime = Math.max(state.whiteTime - elapsed, 0);
                if (state.whiteTime <= 0) {
                    state.flagged = 'white';
                    onFlag(state.flagged);
                    sound.dong();
                    clearInterval(clockInterval);
                }
            }
        }
        else if (activeSide() === 'black') {
            const elapsed = now - blackTimestamp;
            blackTimestamp = now;
            if (state.blackDelay > 0) {
                state.blackDelay = state.blackDelay - elapsed;
            }
            else {
                state.blackTime = Math.max(state.blackTime - elapsed, 0);
                if (blackTime() <= 0) {
                    state.flagged = 'black';
                    onFlag(state.flagged);
                    sound.dong();
                    clearInterval(clockInterval);
                }
            }
        }
        redraw();
    }
    function clockHit(side) {
        if (flagged()) {
            return;
        }
        sound.clock();
        if (side === 'white') {
            if (state.activeSide === 'white') {
                state.blackDelay = state.increment;
            }
            blackTimestamp = performance.now();
            state.activeSide = 'black';
        }
        else if (side === 'black') {
            if (state.activeSide === 'black') {
                state.whiteDelay = state.increment;
            }
            whiteTimestamp = performance.now();
            state.activeSide = 'white';
        }
        clearInterval(clockInterval);
        clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        state.isRunning = true;
        redraw();
    }
    function startStop() {
        if (state.isRunning) {
            state.isRunning = false;
            clearInterval(clockInterval);
        }
        else {
            state.isRunning = true;
            clockInterval = setInterval(tick, CLOCK_TICK_STEP);
            if (activeSide() === 'white') {
                whiteTimestamp = performance.now();
            }
            else {
                blackTimestamp = performance.now();
            }
        }
    }
    function activeSide() {
        return state.activeSide;
    }
    function flagged() {
        return state.flagged;
    }
    function isRunning() {
        return state.isRunning;
    }
    function getState() {
        return state;
    }
    function setState(newState) {
        state = newState;
    }
    function whiteTime() {
        return state.whiteTime;
    }
    function blackTime() {
        return state.blackTime;
    }
    function getTime(color) {
        return color === 'white' ? whiteTime() : blackTime();
    }
    function toggleActiveSide() {
        if (state.activeSide)
            if (state.activeSide === 'white') {
                blackTimestamp = performance.now();
                state.activeSide = 'black';
            }
            else {
                whiteTimestamp = performance.now();
                state.activeSide = 'white';
            }
    }
    const clockType = 'delay';
    return {
        clockType,
        getState,
        setState,
        activeSide,
        flagged,
        isRunning,
        clockHit,
        startStop,
        whiteTime,
        blackTime,
        getTime,
        toggleActiveSide,
        clear() {
            clearInterval(clockInterval);
        }
    };
}

function BronsteinClock(time, increment, onFlag, soundOn) {
    let state = {
        clockType: 'bronstein',
        whiteTime: (time !== 0) ? time : increment,
        blackTime: (time !== 0) ? time : increment,
        whiteDelay: increment,
        blackDelay: increment,
        increment: increment,
        activeSide: undefined,
        flagged: undefined,
        isRunning: false
    };
    let clockInterval;
    let whiteTimestamp;
    let blackTimestamp;
    function tick() {
        const now = performance.now();
        if (state.activeSide === 'white') {
            const elapsed = now - whiteTimestamp;
            whiteTimestamp = now;
            state.whiteTime = Math.max(state.whiteTime - elapsed, 0);
            state.whiteDelay = Math.max(state.whiteDelay - elapsed, 0);
            if (state.whiteTime <= 0) {
                state.flagged = 'white';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        else if (activeSide() === 'black') {
            const elapsed = now - blackTimestamp;
            blackTimestamp = now;
            state.blackTime = Math.max(state.blackTime - elapsed, 0);
            state.blackDelay = Math.max(state.blackDelay - elapsed, 0);
            if (state.blackTime <= 0) {
                state.flagged = 'black';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        redraw();
    }
    function clockHit(side) {
        if (state.flagged) {
            return;
        }
        sound.clock();
        if (side === 'white') {
            if (state.activeSide === 'white') {
                state.whiteTime = state.whiteTime + (state.increment - state.whiteDelay);
                state.blackDelay = state.increment;
            }
            blackTimestamp = performance.now();
            state.activeSide = 'black';
        }
        else {
            if (state.activeSide === 'black') {
                state.blackTime = state.blackTime + (state.increment - state.blackDelay);
                state.whiteDelay = state.increment;
            }
            whiteTimestamp = performance.now();
            state.activeSide = 'white';
        }
        if (clockInterval) {
            clearInterval(clockInterval);
        }
        clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        state.isRunning = true;
        redraw();
    }
    function startStop() {
        if (state.isRunning) {
            state.isRunning = false;
            clearInterval(clockInterval);
        }
        else {
            state.isRunning = true;
            clockInterval = setInterval(tick, CLOCK_TICK_STEP);
            if (state.activeSide === 'white') {
                whiteTimestamp = performance.now();
            }
            else {
                blackTimestamp = performance.now();
            }
        }
    }
    function activeSide() {
        return state.activeSide;
    }
    function flagged() {
        return state.flagged;
    }
    function isRunning() {
        return state.isRunning;
    }
    function getState() {
        return state;
    }
    function setState(newState) {
        state = newState;
    }
    function whiteTime() {
        return state.whiteTime;
    }
    function blackTime() {
        return state.blackTime;
    }
    function getTime(color) {
        return color === 'white' ? whiteTime() : blackTime();
    }
    function toggleActiveSide() {
        if (state.activeSide)
            if (state.activeSide === 'white') {
                blackTimestamp = performance.now();
                state.activeSide = 'black';
            }
            else {
                whiteTimestamp = performance.now();
                state.activeSide = 'white';
            }
    }
    const clockType = 'bronstein';
    return {
        clockType,
        getState,
        setState,
        activeSide,
        flagged,
        isRunning,
        clockHit,
        startStop,
        whiteTime,
        blackTime,
        getTime,
        toggleActiveSide,
        clear() {
            clearInterval(clockInterval);
        }
    };
}

function HourglassClock(time, onFlag, soundOn) {
    let state = {
        clockType: 'hourglass',
        whiteTime: time / 2,
        blackTime: time / 2,
        activeSide: undefined,
        flagged: undefined,
        isRunning: false
    };
    let clockInterval;
    let whiteTimestamp;
    let blackTimestamp;
    function tick() {
        const now = performance.now();
        if (activeSide() === 'white') {
            const elapsed = now - whiteTimestamp;
            whiteTimestamp = now;
            state.whiteTime = Math.max(state.whiteTime - elapsed, 0);
            state.blackTime = time - state.whiteTime;
            if (whiteTime() <= 0) {
                state.flagged = 'white';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        else if (activeSide() === 'black') {
            const elapsed = now - blackTimestamp;
            blackTimestamp = now;
            state.blackTime = Math.max(state.blackTime - elapsed, 0);
            state.whiteTime = time - state.blackTime;
            if (blackTime() <= 0) {
                state.flagged = 'black';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        redraw();
    }
    function clockHit(side) {
        if (flagged()) {
            return;
        }
        sound.clock();
        if (side === 'white') {
            blackTimestamp = performance.now();
            state.activeSide = 'black';
        }
        else {
            whiteTimestamp = performance.now();
            state.activeSide = 'white';
        }
        if (clockInterval) {
            clearInterval(clockInterval);
        }
        clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        state.isRunning = true;
        redraw();
    }
    function startStop() {
        if (isRunning()) {
            state.isRunning = false;
            clearInterval(clockInterval);
        }
        else {
            state.isRunning = true;
            clockInterval = setInterval(tick, CLOCK_TICK_STEP);
            if (activeSide() === 'white') {
                whiteTimestamp = performance.now();
            }
            else {
                blackTimestamp = performance.now();
            }
        }
    }
    function activeSide() {
        return state.activeSide;
    }
    function flagged() {
        return state.flagged;
    }
    function isRunning() {
        return state.isRunning;
    }
    function getState() {
        return state;
    }
    function setState(newState) {
        state = newState;
    }
    function whiteTime() {
        return state.whiteTime;
    }
    function blackTime() {
        return state.blackTime;
    }
    function getTime(color) {
        return color === 'white' ? whiteTime() : blackTime();
    }
    function toggleActiveSide() {
        if (state.activeSide)
            if (state.activeSide === 'white') {
                blackTimestamp = performance.now();
                state.activeSide = 'black';
            }
            else {
                whiteTimestamp = performance.now();
                state.activeSide = 'white';
            }
    }
    const clockType = 'hourglass';
    return {
        clockType,
        getState,
        setState,
        activeSide,
        flagged,
        isRunning,
        clockHit,
        startStop,
        whiteTime,
        blackTime,
        getTime,
        toggleActiveSide,
        clear() {
            clearInterval(clockInterval);
        }
    };
}

function StageClock(stages, increment, onFlag, soundOn) {
    let state = {
        clockType: 'stage',
        whiteTime: Number(stages[0].time) * MINUTE_MILLIS,
        blackTime: Number(stages[0].time) * MINUTE_MILLIS,
        whiteMoves: Number(stages[0].moves),
        blackMoves: Number(stages[0].moves),
        whiteStage: 0,
        blackStage: 0,
        stages: stages,
        increment: increment,
        activeSide: undefined,
        flagged: undefined,
        isRunning: false
    };
    let clockInterval;
    let whiteTimestamp;
    let blackTimestamp;
    function tick() {
        const now = performance.now();
        if (state.activeSide === 'white') {
            const elapsed = now - whiteTimestamp;
            whiteTimestamp = now;
            state.whiteTime = Math.max(state.whiteTime - elapsed, 0);
            if (state.whiteTime <= 0) {
                state.flagged = 'white';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        else if (state.activeSide === 'black') {
            const elapsed = now - blackTimestamp;
            blackTimestamp = now;
            state.blackTime = Math.max(state.blackTime - elapsed, 0);
            if (state.blackTime <= 0) {
                state.flagged = 'black';
                onFlag(state.flagged);
                sound.dong();
                clearInterval(clockInterval);
            }
        }
        redraw();
    }
    function clockHit(side) {
        if (flagged()) {
            return;
        }
        sound.clock();
        const tm = state.whiteMoves;
        const bm = state.blackMoves;
        if (side === 'white') {
            if (tm !== null)
                state.whiteMoves = tm - 1;
            state.whiteTime = state.whiteTime + state.increment;
            if (state.whiteMoves === 0) {
                state.whiteStage = state.whiteStage + 1;
                state.whiteTime = state.whiteTime + Number(state.stages[state.whiteStage].time) * MINUTE_MILLIS;
                if (state.whiteStage === (state.stages.length - 1))
                    state.whiteMoves = null;
                else
                    state.whiteMoves = state.stages[state.whiteStage].moves;
            }
            blackTimestamp = performance.now();
            state.activeSide = 'black';
        }
        else {
            if (bm !== null)
                state.blackMoves = bm - 1;
            state.blackTime = state.blackTime + state.increment;
            if (state.blackMoves === 0) {
                state.blackStage = state.blackStage + 1;
                state.blackTime = state.blackTime + Number(state.stages[state.blackStage].time) * MINUTE_MILLIS;
                if (state.blackStage === (state.stages.length - 1))
                    state.blackMoves = null;
                else
                    state.blackMoves = state.stages[state.blackStage].moves;
            }
            whiteTimestamp = performance.now();
            state.activeSide = 'white';
        }
        if (clockInterval) {
            clearInterval(clockInterval);
        }
        clockInterval = setInterval(tick, CLOCK_TICK_STEP);
        state.isRunning = true;
        redraw();
    }
    function startStop() {
        if (state.isRunning) {
            state.isRunning = false;
            clearInterval(clockInterval);
        }
        else {
            state.isRunning = true;
            clockInterval = setInterval(tick, CLOCK_TICK_STEP);
            if (state.activeSide === 'white') {
                whiteTimestamp = performance.now();
            }
            else {
                blackTimestamp = performance.now();
            }
        }
    }
    function activeSide() {
        return state.activeSide;
    }
    function flagged() {
        return state.flagged;
    }
    function isRunning() {
        return state.isRunning;
    }
    function getState() {
        return state;
    }
    function setState(newState) {
        state = newState;
    }
    function whiteMoves() {
        return state.whiteMoves;
    }
    function blackMoves() {
        return state.blackMoves;
    }
    function whiteTime() {
        return state.whiteTime;
    }
    function blackTime() {
        return state.blackTime;
    }
    function getTime(color) {
        return color === 'white' ? whiteTime() : blackTime();
    }
    function getMoves(color) {
        return color === 'white' ? whiteMoves() : blackMoves();
    }
    function toggleActiveSide() {
        if (state.activeSide)
            if (state.activeSide === 'white') {
                blackTimestamp = performance.now();
                state.activeSide = 'black';
            }
            else {
                whiteTimestamp = performance.now();
                state.activeSide = 'white';
            }
    }
    const clockType = 'stage';
    return {
        clockType,
        getState,
        setState,
        activeSide,
        flagged,
        isRunning,
        clockHit,
        startStop,
        whiteTime,
        blackTime,
        whiteMoves,
        blackMoves,
        getTime,
        getMoves,
        toggleActiveSide,
        clear() {
            clearInterval(clockInterval);
        }
    };
}

function SimpleClock(time, onFlag) {
    return IncrementClock(time, 0, onFlag);
}
function IncrementClock(time, increment, onFlag) {
    return HandicapIncClock(time, increment, time, increment, onFlag);
}
var clockSet = {
    simple: (onFlag) => SimpleClock(Number(settings.clock.simple.time()) * MINUTE_MILLIS, onFlag),
    increment: (onFlag) => IncrementClock(Number(settings.clock.increment.time()) * MINUTE_MILLIS, Number(settings.clock.increment.increment()) * MILLIS, onFlag),
    handicapInc: (onFlag) => HandicapIncClock(Number(settings.clock.handicapInc.topTime()) * MINUTE_MILLIS, Number(settings.clock.handicapInc.topIncrement()) * MILLIS, Number(settings.clock.handicapInc.bottomTime()) * MINUTE_MILLIS, Number(settings.clock.handicapInc.bottomIncrement()) * MILLIS, onFlag),
    delay: (onFlag) => DelayClock(Number(settings.clock.delay.time()) * MINUTE_MILLIS, Number(settings.clock.delay.increment()) * MILLIS, onFlag),
    bronstein: (onFlag) => BronsteinClock(Number(settings.clock.bronstein.time()) * MINUTE_MILLIS, Number(settings.clock.bronstein.increment()) * MILLIS, onFlag),
    hourglass: (onFlag) => HourglassClock(Number(settings.clock.hourglass.time()) * MINUTE_MILLIS, onFlag),
    stage: (onFlag) => StageClock(settings.clock.stage.stages().map(s => {
        return {
            time: Number(s.time),
            moves: s.moves !== null ? Number(s.moves) : null
        };
    }), Number(settings.clock.stage.increment()) * MILLIS, onFlag)
};

export { clockSet as a, clockSettingsView as c, formatTime as f, isStageClock as i };
//# sourceMappingURL=clockSet-W9lsYtyZ.js.map
