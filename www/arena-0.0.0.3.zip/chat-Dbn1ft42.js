import { q as router, bO as slidesOutDown, bP as Keyboard, r as redraw, bQ as requestIdleCallback, m as h, bR as slidesInUp, x as ontap, bC as closeIcon, o as i18n, av as asyncStorage, U as classSet, bS as LRUMap } from './main.js';

class Chat {
    constructor(socket, id, lines, player, writeable, isShadowban, storeKey) {
        this.socket = socket;
        this.id = id;
        this.player = player;
        this.writeable = writeable;
        this.isShadowban = isShadowban;
        this.storeKey = storeKey;
        this.open = () => {
            router.backbutton.stack.push(slidesOutDown(this.close, 'chat'));
            this.showing = true;
            this.nbUnread = 0;
        };
        this.close = (fromBB) => {
            Keyboard.hide();
            if (fromBB !== 'backbutton' && this.showing)
                router.backbutton.stack.pop();
            this.showing = false;
            this.nbUnread = 0;
            this.storeNbLinesRead();
        };
        this.onReload = (lines) => {
            if (lines !== undefined) {
                this.lines = lines;
                this.checkUnreadFromStorage();
            }
        };
        this.append = (msg) => {
            this.lines.push(msg);
            if (msg.u !== 'lichess') {
                this.nbUnread++;
            }
            redraw();
        };
        // --
        this.isLegitMsg = (msg) => {
            return !msg.d && (!msg.r || msg.u === this.player?.user?.username) && !isSpam(msg.t);
        };
        this.showing = false;
        this.lines = lines;
        this.inputValue = '';
        this.nbUnread = 0;
        this.checkUnreadFromStorage();
    }
    selectLines() {
        let prev;
        const ls = [];
        this.lines.forEach((line) => {
            if (this.isLegitMsg(line) &&
                (!prev || !compactableDeletedLines(prev, line))) {
                ls.push(line);
            }
            prev = line;
        });
        return ls;
    }
    nbLines() {
        return this.lines.filter(this.isLegitMsg).length;
    }
    checkUnreadFromStorage() {
        getReadCount(this.storeKey, this.id).then(nb => {
            const storedNb = nb || 0;
            const actualNb = this.nbLines();
            if (this.lines !== undefined && storedNb < actualNb) {
                this.nbUnread = this.nbUnread + (actualNb - storedNb);
                redraw();
            }
        });
    }
    storeNbLinesRead() {
        const linesRead = this.nbLines();
        if (linesRead > 0) {
            requestIdleCallback(() => {
                setReadCount(this.storeKey, this.id, linesRead);
            });
        }
    }
}
function chatView(ctrl, header) {
    if (!ctrl.showing)
        return null;
    return h('div#chat.modal', { oncreate: slidesInUp }, [
        h('header', [
            h('button.modal_close', {
                oncreate: ontap(slidesOutDown(ctrl.close, 'chat'))
            }, closeIcon),
            h('h2', header || i18n('chatRoom'))
        ]),
        h('div#chat_content.modal_content.chat_content', [
            h('ul.chat_scroller.native_scroller', {
                oncreate: ({ dom }) => scrollCallback(ctrl, dom),
                onupdate: ({ dom }) => scrollCallback(ctrl, dom)
            }, ctrl.selectLines().map((msg, i, all) => {
                if (ctrl.player !== undefined)
                    return renderPlayerMsg(ctrl.player, msg, i, all);
                else
                    return renderSpectatorMsg(msg);
            })),
            h('form.chat_form', {
                onsubmit(e) {
                    e.preventDefault();
                    const target = e.target;
                    const ta = target[0];
                    ta.focus();
                    const msg = ta.value.trim();
                    if (!validateMsg(msg))
                        return;
                    ctrl.inputValue = '';
                    ta.setAttribute('rows', '1');
                    ta.style.paddingTop = '8px';
                    ctrl.socket.send('talk', msg);
                    const sendButton = document.getElementById('chat_send');
                    if (sendButton) {
                        sendButton.classList.add('disabled');
                    }
                    return false;
                }
            }, [
                h('textarea#chat_input.chat_input', {
                    placeholder: ctrl.writeable ? i18n('talkInChat') : 'Chat is disabled.',
                    disabled: !ctrl.writeable,
                    rows: 1,
                    maxlength: 140,
                    value: ctrl.inputValue,
                    style: { lineHeight: '18px', margin: '8px 0 8px 10px', paddingTop: '8px' },
                    oninput(e) {
                        const ta = e.target;
                        if (ta.value.length > 140)
                            ta.value = ta.value.substr(0, 140);
                        ctrl.inputValue = ta.value;
                        const style = window.getComputedStyle(ta);
                        const taLineHeight = parseInt(style.lineHeight || '18', 10);
                        const taHeight = calculateContentHeight(ta, taLineHeight);
                        const computedNbLines = Math.ceil(taHeight / taLineHeight);
                        const nbLines = computedNbLines <= 1 ? 1 :
                            computedNbLines > 5 ? 5 : computedNbLines - 1;
                        ta.setAttribute('rows', String(nbLines));
                        if (nbLines === 1)
                            ta.style.paddingTop = '8px';
                        else
                            ta.style.paddingTop = '0';
                        const sendButton = document.getElementById('chat_send');
                        if (sendButton) {
                            if (validateMsg(ctrl.inputValue))
                                sendButton.classList.remove('disabled');
                            else
                                sendButton.classList.add('disabled');
                        }
                    }
                }),
                h('button#chat_send.chat_send.fa.fa-telegram.disabled')
            ])
        ])
    ]);
}
function renderPlayerMsg(player, msg, i, all) {
    const lichessTalking = msg.u === 'lichess';
    const playerTalking = msg.c ? msg.c === player.color :
        player.user && msg.u === player.user.username;
    let closeBalloon = true;
    const next = all[i + 1];
    let nextTalking;
    if (next) {
        nextTalking = next.c ? next.c === player.color :
            player.user && next.u === player.user.username;
    }
    if (nextTalking !== undefined)
        closeBalloon = nextTalking !== playerTalking;
    return h('li.chat_msg.allow_select', {
        className: classSet({
            system: lichessTalking,
            player: !!playerTalking,
            opponent: !lichessTalking && !playerTalking,
            'close_balloon': closeBalloon
        })
    }, msg.t);
}
function renderSpectatorMsg(msg) {
    const lichessTalking = msg.u === 'lichess';
    return h('li.spectator_chat_msg.allow_select', {
        className: classSet({
            system: lichessTalking,
        })
    }, lichessTalking ? msg.t : [
        h('strong', msg.u),
        h.trust('&nbsp;'), h.trust('&nbsp;'),
        h('span', msg.t)
    ]);
}
function scrollCallback(ctrl, el) {
    if (ctrl.lines.length > 5) {
        const autoScroll = (el.scrollTop === 0 || (el.scrollTop > (el.scrollHeight - el.clientHeight - 100)));
        if (autoScroll) {
            el.scrollTop = 999999;
            setTimeout(() => el.scrollTop = 999999, 300);
        }
    }
}
function calculateContentHeight(ta, scanAmount) {
    const origHeight = ta.style.height, scrollHeight = ta.scrollHeight, overflow = ta.style.overflow;
    let height = ta.offsetHeight;
    /// only bother if the ta is bigger than content
    if (height >= scrollHeight) {
        /// check that our browser supports changing dimension
        /// calculations mid-way through a function call...
        ta.style.height = (height + scanAmount) + 'px';
        /// because the scrollbar can cause calculation problems
        ta.style.overflow = 'hidden';
        /// by checking that scrollHeight has updated
        if (scrollHeight < ta.scrollHeight) {
            /// now try and scan the ta's height downwards
            /// until scrollHeight becomes larger than height
            while (ta.offsetHeight >= ta.scrollHeight) {
                ta.style.height = (height -= scanAmount) + 'px';
            }
            /// be more specific to get the exact height
            while (ta.offsetHeight < ta.scrollHeight) {
                ta.style.height = (height++) + 'px';
            }
            /// reset the ta back to it's original height
            ta.style.height = origHeight;
            /// put the overflow back
            ta.style.overflow = overflow;
            return height;
        }
    }
    return scrollHeight;
}
function isSpam(txt) {
    return /chess-bot/.test(txt);
}
function compactableDeletedLines(l1, l2) {
    return l1.d && l2.d && l1.u === l2.u;
}
function validateMsg(msg) {
    if (!msg)
        return false;
    return msg.trim().length <= 140;
}
const storage = {
    Corres: {
        key: 'corresChat',
    },
    Game: {
        key: 'gameChat',
    },
    Study: {
        key: 'studyChat',
    },
    Tournament: {
        key: 'tourChat',
    },
};
function initStorage(storeKey) {
    const store = storage[storeKey];
    if (store.readCounts)
        return Promise.resolve();
    else {
        return asyncStorage.get(store.key)
            .then(data => {
            if (data)
                store.readCounts = new LRUMap(100, data);
            else
                store.readCounts = new LRUMap(100);
        });
    }
}
async function getReadCount(storeKey, id) {
    await initStorage(storeKey);
    return storage[storeKey].readCounts?.get(id);
}
async function setReadCount(storeKey, id, nb) {
    await initStorage(storeKey);
    const store = storage[storeKey];
    if (store.readCounts) {
        store.readCounts.set(id, nb);
        asyncStorage.set(store.key, store.readCounts.toJSON());
    }
}

export { Chat as C, chatView as c };
//# sourceMappingURL=chat-Dbn1ft42.js.map
