import { M as popup, m as h, x as ontap, o as i18n, q as router, g as settings, O as formWidgets, P as specialFenVariants, Q as getVariant, V as ViewOnlyBoard, J as prop, X as isPortrait, Y as viewportDim, _ as hasSpaceForInlineReplay, a1 as uciToProm, r as redraw, a2 as uciToDropPos, a3 as uciToDropRole, a4 as aiName, R as sound, S as oppositeColor, T as uciToMoveOrDrop, a5 as getRandomArbitrary, F as viewFadeIn, a0 as header, s as socket } from './main.js';
import { a as setCurrentAIGame, b as getCurrentAIGame } from './offlineGames-CDpjbNo0.js';
import { p as playerFromFen, e as emptyFen } from './fen-97CPMMDI.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { a as atomic, c as crazyValid, v as viewOnlyBoardContent } from './crazyValid-BQyVE87l.js';
import { G as GameTitle } from './GameTitle-CU8rmgNb.js';
import { B as Board } from './Board-UV3Z06Mn.js';
import { r as renderEndedGameStatus, a as renderClaimDrawButton, c as renderInlineReplay, e as renderAntagonist, i as renderGameActionsBar, b as renderReplay, s as setResult, R as Replay, g as ground, d as data } from './view-BWIKaE22.js';
import { v as view, p as promotion } from './promotion-yOaF5Jgj.js';
import { p as playable, g as gameStatus } from './game-CgD9Ef6g.js';
import { S as Share } from './index-r4T5Y9G7.js';
import { i as init } from './chess-B1K_bSdL.js';
import { v as vibrate } from './vibrate-CyNrNHlt.js';
import { S as StockfishPlugin, g as getNbCores } from './index-CkC0Yhqy.js';
import './perfs-BLfNpglP.js';
import './countries-D-Tn65Re.js';
import './CountdownTimer-sy6et_C9.js';
import './tournamentXhr-kOGDWEN6.js';
import './toInteger-bGq5KERl.js';
import './chat-Dbn1ft42.js';

function opponentSelector() {
    const opts = settings.ai.availableOpponents.map(o => ['aiNameLevelAiLevel', o[1], o[0], o[1]]);
    return h('div.select_input', formWidgets.renderSelect('opponent', 'opponent', opts, settings.ai.opponent));
}
function renderAlways(ctrl) {
    return [
        h('button[data-icon=A]', {
            oncreate: ontap(ctrl.goToAnalysis)
        }, i18n('analysis')),
        h('div.action.opponentSelector', [
            opponentSelector()
        ])
    ];
}
function resignButton(ctrl) {
    return playable(ctrl.data) ? h('button[data-icon=b]', {
        oncreate: ontap(() => {
            ctrl.actions.close();
            ctrl.resign();
        })
    }, i18n('resign')) : null;
}
var actions = {
    controller: function (root) {
        let isOpen = false;
        function open() {
            router.backbutton.stack.push(close);
            isOpen = true;
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen)
                router.backbutton.stack.pop();
            isOpen = false;
        }
        return {
            open: open,
            close: close,
            isOpen() {
                return isOpen;
            },
            root: root
        };
    },
    view(ctrl) {
        return popup('offline_actions', undefined, () => {
            return [
                renderEndedGameStatus(ctrl.root)
            ].concat(renderClaimDrawButton(ctrl.root), resignButton(ctrl.root), renderAlways(ctrl.root));
        }, ctrl.isOpen(), ctrl.close);
    }
};

const colors = [
    ['white', 'white'],
    ['black', 'black'],
    ['randomColor', 'random']
];
var newGameMenu = {
    controller(root) {
        const isOpen = prop(false);
        function open() {
            router.backbutton.stack.push(close);
            isOpen(true);
        }
        function close(fromBB) {
            if (fromBB !== 'backbutton' && isOpen() === true)
                router.backbutton.stack.pop();
            isOpen(false);
        }
        return {
            open,
            close,
            isOpen,
            root
        };
    },
    view(ctrl) {
        if (ctrl.isOpen()) {
            return popup('new_offline_game', undefined, function () {
                const availVariants = settings.ai.availableVariants;
                const variants = ctrl.root.vm.setupFen ?
                    availVariants.filter(i => !specialFenVariants.has(i[1])) :
                    availVariants;
                const setupVariant = settings.ai.variant();
                const hasSpecialSetup = ctrl.root.vm.setupFen && specialFenVariants.has(setupVariant);
                const settingsColor = settings.ai.color();
                const setupColor = settingsColor !== 'random' ? settingsColor : 'white';
                return (h("div", null,
                    h("div", { className: "action" },
                        opponentSelector(),
                        sideSelector(),
                        hasSpecialSetup ?
                            h("div", { className: "select_input disabled" },
                                h("label", { for: "variant" }, i18n('variant')),
                                h("select", { disabled: true, id: "variant" },
                                    h("option", { value: setupVariant, selected: true }, getVariant(setupVariant).name))) :
                            h("div", { className: "select_input" }, formWidgets.renderSelect('variant', 'variant', variants, settings.ai.variant)),
                        ctrl.root.vm.setupFen ?
                            h("div", { className: "from_position_wrapper" },
                                h("p", null, i18n('fromPosition')),
                                h("div", { className: "from_position" },
                                    h("div", { style: {
                                            width: '130px',
                                            height: '130px'
                                        }, oncreate: ontap(() => {
                                            if (ctrl.root.vm.setupFen)
                                                router.set(`/editor/${encodeURIComponent(ctrl.root.vm.setupFen)}`);
                                        }) }, h(ViewOnlyBoard, {
                                        fen: ctrl.root.vm.setupFen,
                                        orientation: setupColor,
                                    })))) : null),
                    h("div", { className: "popupActionWrapper" },
                        h("button", { className: "defaultButton", oncreate: ontap(() => {
                                ctrl.root.startNewGame(settings.ai.variant(), ctrl.root.vm.setupFen);
                            }) }, i18n('play')))));
            }, ctrl.isOpen(), () => {
                if (ctrl.root.vm.setupFen) {
                    router.set('/ai');
                }
                ctrl.close();
            });
        }
        return null;
    }
};
function sideSelector() {
    return (h("div", { className: "select_input" }, formWidgets.renderSelect('side', 'color', colors, settings.ai.color)));
}

function renderContent(ctrl) {
    const material = ctrl.chessground.getMaterialDiff();
    const isPortrait$1 = isPortrait();
    const vd = viewportDim();
    const aiName = (h("h2", null,
        ctrl.getOpponent().name,
        ctrl.vm.engineSearching ?
            h("span", { className: "engineSpinner fa fa-hourglass-half" }) :
            null));
    const board = h(Board, {
        variant: ctrl.data.game.variant.key,
        chessground: ctrl.chessground,
    });
    if (isPortrait$1) {
        return [
            hasSpaceForInlineReplay(vd, isPortrait$1) ? renderInlineReplay(ctrl) : null,
            renderAntagonist(ctrl, aiName, material[ctrl.data.opponent.color], 'opponent'),
            board,
            renderAntagonist(ctrl, ctrl.playerName(), material[ctrl.data.player.color], 'player'),
            renderGameActionsBar(ctrl)
        ];
    }
    else {
        return [
            board,
            h("section", { className: "table offline" },
                renderAntagonist(ctrl, aiName, material[ctrl.data.opponent.color], 'opponent'),
                renderReplay(ctrl),
                renderGameActionsBar(ctrl),
                renderAntagonist(ctrl, ctrl.playerName(), material[ctrl.data.player.color], 'player'))
        ];
    }
}
function overlay(ctrl) {
    return [
        actions.view(ctrl.actions),
        newGameMenu.view(ctrl.newGameMenu),
        view(ctrl)
    ];
}

class Engine {
    constructor(ctrl, variant) {
        this.ctrl = ctrl;
        this.variant = variant;
        this.level = 1;
        this.isInit = false;
        this.listener = (e) => {
            const line = e.output;
            console.debug('[stockfish >>] ' + line);
            const bmMatch = line.match(/^bestmove (\w{4,5})|^bestmove ([PNBRQ]@\w{2})/);
            if (bmMatch) {
                if (bmMatch[1])
                    this.ctrl.onEngineMove(bmMatch[1]);
                else if (bmMatch[2])
                    this.ctrl.onEngineDrop(bmMatch[2]);
            }
        };
        this.stockfish = new StockfishPlugin(variant);
    }
    async init() {
        try {
            if (!this.isInit) {
                await this.stockfish.start();
                this.isInit = true;
                window.addEventListener('stockfish', this.listener, { passive: true });
                await this.stockfish.setVariant();
                await this.stockfish.setOption('Threads', getNbCores());
                await this.newGame();
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    async newGame() {
        // from UCI protocol spec, the client should always send isready after
        // ucinewgame
        await this.stockfish.send('ucinewgame');
        await this.stockfish.isReady();
        await this.stockfish.setOption('UCI_AnalyseMode', false);
        await this.stockfish.setOption('UCI_LimitStrength', true);
    }
    async search(initialFen, moves) {
        // console.info('engine search pos: ', `position fen ${initialFen} moves ${moves}`)
        await this.stockfish.send(`position fen ${initialFen} moves ${moves}`);
        await this.stockfish.send(`go movetime ${moveTime(this.level)} depth ${depth(this.level)}`);
    }
    setLevel(l) {
        this.level = l;
    }
    async exit() {
        window.removeEventListener('stockfish', this.listener, false);
        return this.stockfish.exit();
    }
}
const maxMoveTime = 5000;
const levelToDepth = {
    1: 5,
    2: 5,
    3: 5,
    4: 5,
    5: 5,
    6: 8,
    7: 13,
    8: 22
};
function moveTime(level) {
    return level * maxMoveTime / 8;
}
function depth(level) {
    return levelToDepth[level];
}

class AiRound {
    constructor(saved, setupFen, setupVariant, setupColor) {
        this.promoting = null;
        this.goToAnalysis = () => {
            if (this.replay) {
                router.set(`/analyse/offline/ai/${this.data.player.color}?ply=${this.replay.ply}&curFen=${this.replay.situation().fen}`);
            }
        };
        this.sharePGN = () => {
            this.replay?.pgn(this.white(), this.black())
                .then((data) => Share.share({ text: data.pgn }));
        };
        this.playerName = () => {
            return this.data.player.username;
        };
        this.onEngineMove = (bestmove) => {
            const from = bestmove.slice(0, 2);
            const to = bestmove.slice(2, 4);
            const role = uciToProm(bestmove);
            this.vm.engineSearching = false;
            this.chessground.apiMove(from, to);
            this.replay?.addMove(from, to, role);
            redraw();
        };
        this.onEngineDrop = (bestdrop) => {
            const pos = uciToDropPos(bestdrop);
            const role = uciToDropRole(bestdrop);
            const piece = { role, color: this.data.opponent.color };
            this.vm.engineSearching = false;
            this.chessground.apiNewPiece(piece, pos);
            this.replay?.addDrop(role, pos);
            redraw();
        };
        this.engineMove = () => {
            this.vm.engineSearching = true;
            const sit = this.replay.situation();
            setTimeout(() => {
                const l = this.getOpponent().level;
                this.data.opponent.name = aiName({
                    ai: l
                });
                this.engine.init()
                    .then(() => {
                    this.engine.setLevel(l);
                    return this.engine.search(this.data.game.initialFen, sit.uciMoves.join(' '));
                });
            }, 500);
        };
        this.isEngineToMove = () => {
            const sit = this.replay.situation();
            return !sit.end && sit.player !== this.data.player.color;
        };
        this.onPromotion = (orig, dest, role) => {
            this.replay?.addMove(orig, dest, role);
        };
        this.userMove = (orig, dest) => {
            if (!promotion.start(this, orig, dest, this.onPromotion)) {
                this.replay?.addMove(orig, dest);
            }
        };
        this.onMove = (_, dest, capturedPiece) => {
            if (capturedPiece) {
                if (this.data.game.variant.key === 'atomic') {
                    atomic.capture(this.chessground, dest);
                    sound.explosion();
                }
                else
                    sound.capture();
            }
            else {
                sound.move();
            }
            vibrate.tap();
        };
        this.onUserNewPiece = (role, key) => {
            const sit = this.replay.situation();
            if (crazyValid.drop(this.data, role, key, sit.drops)) {
                this.replay?.addDrop(role, key);
            }
            else {
                this.apply(this.replay.situation());
            }
        };
        this.onNewPiece = () => {
            sound.move();
        };
        this.onReplayAdded = (sit) => {
            this.data.game.fen = sit.fen;
            this.apply(sit);
            setResult(this, sit.status);
            if (gameStatus.finished(this.data)) {
                this.onGameEnd();
            }
            else if (this.isEngineToMove()) {
                this.engineMove();
            }
            this.save();
            redraw();
        };
        this.onThreefoldRepetition = (newStatus) => {
            setResult(this, newStatus);
            this.save();
            this.onGameEnd();
        };
        this.onGameEnd = () => {
            this.chessground.cancelMove();
            this.chessground.stop();
            setTimeout(() => {
                this.actions.open();
                redraw();
            }, 500);
        };
        this.resign = () => {
            setResult(this, { id: 31, name: 'resign' }, oppositeColor(this.data.player.color));
            this.save();
            this.onGameEnd();
        };
        this.firstPly = () => {
            return this.data.player.color === oppositeColor(this.firstPlayerColor()) ? 1 : 0;
        };
        this.lastPly = () => {
            return this.replay.situations.length - 1;
        };
        this.jump = (ply) => {
            this.chessground.cancelMove();
            if (this.replay.ply === ply || ply < 0 || ply >= this.replay.situations.length)
                return false;
            this.replay.ply = ply;
            this.apply(this.replay.situation());
            return false;
        };
        this.jumpFirst = () => this.jump(this.firstPly());
        this.jumpPrev = () => {
            const ply = this.replay.ply;
            if (this.data.player.color === oppositeColor(this.firstPlayerColor())) {
                const offset = ply % 2 === 0 ? 1 : 2;
                return this.jump(ply - offset);
            }
            else {
                const offset = ply % 2 === 0 ? 2 : 1;
                return this.jump(ply - offset);
            }
        };
        this.jumpNext = () => {
            const ply = this.replay.ply;
            return this.jump(ply + (ply + 2 >= this.replay.situations.length ? 1 : 2));
        };
        this.jumpLast = () => this.jump(this.lastPly());
        this.canDrop = () => true;
        this.actions = actions.controller(this);
        this.newGameMenu = newGameMenu.controller(this);
        this.moveList = !!settings.game.moveList();
        this.vm = {
            engineSearching: false,
            setupFen,
            savedFen: saved ? saved.data.game.fen : undefined
        };
        if (setupFen) {
            this.newGameMenu.isOpen(true);
            if (setupColor) {
                settings.ai.color(setupColor);
            }
            if (setupVariant) {
                settings.ai.variant(setupVariant);
            }
            redraw();
        }
        else {
            const currentVariant = settings.ai.variant();
            if (saved) {
                try {
                    this.init(saved.data, saved.situations, saved.ply);
                }
                catch (e) {
                    console.log(e, 'Fail to load saved game');
                    this.startNewGame(currentVariant);
                }
            }
            else {
                this.startNewGame(currentVariant);
            }
        }
    }
    init(data, situations, ply) {
        this.newGameMenu.close();
        this.actions.close();
        this.data = data;
        const variant = this.data.game.variant.key;
        const initialFen = this.data.game.initialFen;
        if (!this.replay) {
            this.replay = new Replay(variant, initialFen, situations, ply, this.onReplayAdded, this.onThreefoldRepetition);
        }
        else {
            this.replay.init(variant, initialFen, situations, ply);
        }
        if (!this.chessground) {
            this.chessground = ground.make(this.data, this.replay.situation(), this.userMove, this.onUserNewPiece, this.onMove, this.onNewPiece);
        }
        else {
            ground.reload(this.chessground, this.data, this.replay.situation());
        }
        if (this.engine && this.engine.variant === variant) {
            this.engine.newGame()
                .then(() => {
                if (this.isEngineToMove()) {
                    this.engineMove();
                }
            });
        }
        else {
            if (this.engine) {
                this.engine.exit();
                this.engine = undefined;
            }
            this.engine = new Engine(this, variant);
            this.engine.init()
                .then(() => {
                if (this.isEngineToMove()) {
                    this.engineMove();
                }
            });
        }
        this.save();
        redraw();
    }
    // clockType preceded by underscore until we implement AI timed games
    startNewGame(variant, setupFen, _clockType, setupColor) {
        const payload = {
            variant
        };
        if (setupFen) {
            payload.fen = setupFen;
        }
        init(payload)
            .then((data$1) => {
            this.init(data({
                id: 'offline_ai',
                variant: data$1.variant,
                initialFen: data$1.setup.fen,
                fen: data$1.setup.fen,
                color: setupColor || getColorFromSettings(),
                player: data$1.setup.player
            }), [data$1.setup], 0);
        })
            .then(() => {
            if (setupFen) {
                this.vm.setupFen = undefined;
                router.History.replaceState(undefined, '/ai');
            }
        });
    }
    save() {
        if (this.replay) {
            setCurrentAIGame({
                data: this.data,
                situations: this.replay.situations,
                ply: this.replay.ply
            });
        }
    }
    white() {
        if (this.data.player.color === 'white')
            // set in offlineround data
            return this.data.player.username;
        else
            return this.getOpponent().name;
    }
    black() {
        if (this.data.player.color === 'black')
            // set in offlineround data
            return this.data.player.username;
        else
            return this.getOpponent().name;
    }
    getOpponent() {
        const level = settings.ai.opponent();
        const opp = settings.ai.availableOpponents.find(e => e[1] === level);
        const name = opp && opp.length && opp[0] || 'Stockfish';
        return {
            name: i18n('aiNameLevelAiLevel', name, level),
            level: parseInt(level) || 1
        };
    }
    player() {
        return this.data.player.color;
    }
    apply(sit) {
        if (sit) {
            const lastUci = sit.uciMoves.length ? sit.uciMoves[sit.uciMoves.length - 1] : null;
            this.chessground.set({
                fen: sit.fen,
                turnColor: sit.player,
                lastMove: lastUci ? uciToMoveOrDrop(lastUci) : null,
                dests: sit.dests,
                movableColor: sit.player === this.data.player.color ? sit.player : null,
                check: sit.check
            });
        }
    }
    firstPlayerColor() {
        return playerFromFen(this.data.game.initialFen);
    }
}
function getColorFromSettings() {
    let color = settings.ai.color();
    if (color === 'random') {
        if (getRandomArbitrary(0, 2) > 1)
            color = 'white';
        else
            color = 'black';
    }
    return color;
}

var ai = {
    oninit({ attrs }) {
        socket.createDefault();
        getCurrentAIGame()
            .then(saved => {
            const setupFen = attrs.fen;
            const setupVariant = attrs.variant;
            const setupColor = attrs.color;
            this.round = new AiRound(saved, setupFen, setupVariant, setupColor);
        });
    },
    oncreate: viewFadeIn,
    onremove() {
        if (this.round)
            this.round.engine?.exit();
    },
    view({ attrs }) {
        let content, header$1;
        if (this.round && this.round.data && this.round.chessground && this.round.engine) {
            header$1 = header(h(GameTitle, { data: this.round.data }));
            content = renderContent(this.round);
        }
        else {
            const fen = attrs.fen || emptyFen;
            const color = playerFromFen(fen);
            header$1 = header(i18n('computer'));
            content = viewOnlyBoardContent(fen, color, undefined);
        }
        return layout.board(header$1, content, undefined, this.round && overlay(this.round));
    }
};

export { ai as default };
//# sourceMappingURL=ai-np9G6JEV.js.map
