import { r as redraw, K as handleXhrError, D as challengeForm, s as socket, m as h, w as spinner, p as ontapY, z as gameIcon, o as i18n, q as router, F as viewFadeIn, G as dropShadowHeader, I as backButton, H as safeStringToNum } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { u as unfollow, f as follow, a as following } from './userXhr-i6lHGN-w.js';

class RelatedCtrl {
    constructor(userId, defaultTab) {
        this.userId = userId;
        this.defaultTab = defaultTab;
        this.isLoadingNextPage = false;
        this.loadNextPage = (page) => {
            this.isLoadingNextPage = true;
            this.getData(this.userId, page)
                .then(() => {
                this.isLoadingNextPage = false;
                redraw();
            })
                .catch(handleXhrError);
            redraw();
        };
        this.toggleFollowing = (obj) => {
            if (obj.relation)
                unfollow(obj.user).then(d => this.setNewUserState(obj, d));
            else
                follow(obj.user).then(d => this.setNewUserState(obj, d));
        };
        this.challenge = (id) => {
            challengeForm.open(id);
        };
        socket.createDefault();
        this.getData(this.userId, 1)
            .then(redraw)
            .catch(handleXhrError);
    }
    getData(userId, page) {
        return following(userId, page)
            .then(d => {
            this.following = (this.following || []).concat(d.paginator.currentPageResults);
            this.followingPaginator = d.paginator;
        });
    }
    setNewUserState(obj, newData) {
        obj.relation = newData.following;
        redraw();
    }
}

function renderBody(ctrl) {
    return renderContent(ctrl, ctrl.following, ctrl.followingPaginator);
}
function renderContent(ctrl, content, paginator) {
    if (!content) {
        return (h("div", { className: "followingListEmpty" }, spinner.getVdom('monochrome')));
    }
    else if (content.length) {
        const nextPage = paginator && paginator.nextPage;
        return (h("ul", { className: "native_scroller page" },
            content.map((p, i) => renderPlayer(ctrl, p, i)),
            nextPage ?
                h("li", { className: "list_item followingList moreFollow", oncreate: ontapY(() => ctrl.loadNextPage(nextPage)) }, ctrl.isLoadingNextPage ? spinner.getVdom('monochrome') : '...') : null));
    }
    else {
        return (h("div", { className: "followingListEmpty" }, "Oops! Nothing here."));
    }
}
function renderPlayer(ctrl, obj, i) {
    const status = obj.online ? 'online' : 'offline';
    const perfKey = obj.perfs && Object.keys(obj.perfs)[0];
    const perf = obj.perfs && obj.perfs[perfKey];
    const userLink = ontapY(() => router.set(`/@/${obj.user}`));
    const evenOrOdd = i % 2 === 0 ? 'even' : 'odd';
    return (h("li", { className: `list_item followingList ${evenOrOdd}` },
        h("div", { className: "followingPlayerTitle", oncreate: userLink },
            h("div", { className: "user" },
                obj.patron ?
                    h("span", { className: 'patron userStatus ' + status, "data-icon": "\uE019" }) :
                    h("span", { className: 'fa fa-circle userStatus ' + status }),
                obj.title ? h("span", { className: "userTitle" },
                    obj.title,
                    "\u00A0") : null,
                obj.user),
            perfKey ?
                h("span", { className: "rating", "data-icon": gameIcon(perfKey) }, perf.rating) : null),
        obj.followable ?
            h("div", { className: "followingPlayerItem" },
                h("div", { className: "check_container" },
                    h("label", null, i18n('follow')),
                    h("input", { type: "checkbox", checked: obj.relation, onchange: () => ctrl.toggleFollowing(obj) }))) : null));
}

var related = {
    oncreate: viewFadeIn,
    oninit(vnode) {
        this.ctrl = new RelatedCtrl(vnode.attrs.id, safeStringToNum(vnode.attrs.tab));
    },
    view() {
        const name = h('div.title', [
            h('span', i18n('friends'))
        ]);
        return layout.free(dropShadowHeader(null, backButton(name)), renderBody(this.ctrl));
    }
};

export { related as default };
//# sourceMappingURL=related-BwAzJbjx.js.map
