import { bl as getMenuWidth, Y as viewportDim, bm as translateMenu, bn as backdropOpacity, bo as BACKDROP_OPACITY, bp as OPEN_AFTER_SLIDE_RATIO, b as session, m as h, bq as mainMenuCtrl, br as profileMenuOpen, bg as ontapXY, bs as toggleHeader, k as hasNetwork, ai as loginModal, o as i18n, E as getLI, aw as serializeQueryParameters, bt as inboxUnreadCount, y as plural, bu as friendsApi, bv as ping, bw as mlat, s as socket, bx as route, by as action, bz as friendsPopup, C as newGameForm, ar as gamesMenu, r as redraw, $ as Toast, M as popup, g as settings, q as router, O as formWidgets, a$ as parseFen, b2 as makeFen, x as ontap, V as ViewOnlyBoard, aV as tupleOf, bA as newAiGame, K as handleXhrError, bB as EDGE_SLIDE_THRESHOLD, J as prop, u as distanceToNowStrict, bC as closeIcon, bD as announce, U as classSet, bE as backdropCloseHandler, bF as signupModal, D as challengeForm, aK as lobby, bG as getSystemTheme } from './main.js';

/**
 * Adapted from https://github.com/sciactive/tinygesture
 */
class Gesture {
    constructor(element, vd, options) {
        this.element = element;
        this.vd = vd;
        this.options = options;
        this.handlers = {
            panstart: [],
            panmove: [],
            panend: [],
            swipeleft: [],
            swiperight: [],
            swipeup: [],
            swipedown: [],
        };
        this.swipingDirection = null;
        this.startInputTimestamp = 0;
        this.onTouchStart = (event) => {
            if (event.changedTouches.length > 1)
                return;
            this.touchStartX = event.changedTouches[0].pageX;
            this.touchStartY = event.changedTouches[0].pageY;
            this.velocityX = 0;
            this.velocityY = 0;
            this.touchMoveX = 0;
            this.touchMoveY = 0;
            this.touchEndX = null;
            this.touchEndY = null;
            this.startInputTimestamp = performance.now();
            this.fire('panstart', event);
        };
        this.onTouchMove = (event) => {
            if (event.changedTouches.length > 1)
                return;
            this.touchMoveX = event.changedTouches[0].pageX - this.touchStartX;
            const deltaTime = performance.now() - this.startInputTimestamp;
            this.velocityX = this.touchMoveX / deltaTime;
            this.touchMoveY = event.changedTouches[0].pageY - this.touchStartY;
            this.velocityY = this.touchMoveY / deltaTime;
            const absTouchMoveX = Math.abs(this.touchMoveX);
            const absTouchMoveY = Math.abs(this.touchMoveY);
            const swipingHorizontal = absTouchMoveX > this.swipeThresholdX;
            const swipingVertical = absTouchMoveY > this.swipeThresholdY;
            this.swipingDirection = absTouchMoveX > absTouchMoveY
                ? (swipingHorizontal ? 'horizontal' : 'pre-horizontal')
                : (swipingVertical ? 'vertical' : 'pre-vertical');
            this.fire('panmove', event);
        };
        this.onTouchEnd = (event) => {
            if (event.changedTouches.length > 1)
                return;
            this.touchEndX = event.changedTouches[0].pageX;
            this.touchEndY = event.changedTouches[0].pageY;
            this.fire('panend', event);
            const x = this.touchEndX - this.touchStartX;
            const absX = Math.abs(x);
            const y = this.touchEndY - this.touchStartY;
            const absY = Math.abs(y);
            if (absX > this.swipeThresholdX || absY > this.swipeThresholdY) {
                const swipedHorizontal = absX >= absY && absX > this.swipeThresholdX;
                const swipedVertical = absY > absX && absY > this.swipeThresholdY;
                if (swipedHorizontal) {
                    if (x < 0) {
                        if (this.velocityX < -this.opts.swipeVelocityThreshold) {
                            this.fire('swipeleft', event);
                        }
                    }
                    else {
                        if (this.velocityX > this.opts.swipeVelocityThreshold) {
                            this.fire('swiperight', event);
                        }
                    }
                }
                if (swipedVertical) {
                    if (y < 0) {
                        if (this.velocityY < -this.opts.swipeVelocityThreshold) {
                            this.fire('swipeup', event);
                        }
                    }
                    else {
                        if (this.velocityY > this.opts.swipeVelocityThreshold) {
                            this.fire('swipedown', event);
                        }
                    }
                }
            }
        };
        this.swipeThresholdX = threshold('x', vd);
        this.swipeThresholdY = threshold('y', vd);
        this.element = element;
        this.opts = Object.assign({}, defaults, options);
        this.touchStartX = null;
        this.touchStartY = null;
        this.touchEndX = null;
        this.touchEndY = null;
        this.velocityX = 0;
        this.velocityY = 0;
        this.touchMoveX = 0;
        this.touchMoveY = 0;
        this.element.addEventListener('touchstart', this.onTouchStart, passive);
        this.element.addEventListener('touchmove', this.onTouchMove, this.opts.passiveMove ? passive : false);
        this.element.addEventListener('touchend', this.onTouchEnd, passive);
    }
    destroy() {
        this.element.removeEventListener('touchstart', this.onTouchStart);
        this.element.removeEventListener('touchmove', this.onTouchMove);
        this.element.removeEventListener('touchend', this.onTouchEnd);
    }
    on(type, fn) {
        if (this.handlers[type]) {
            this.handlers[type].push(fn);
            return {
                type,
                fn,
                cancel: () => this.off(type, fn)
            };
        }
    }
    off(type, fn) {
        if (this.handlers[type]) {
            const idx = this.handlers[type].indexOf(fn);
            if (idx !== -1) {
                this.handlers[type].splice(idx, 1);
            }
        }
    }
    fire(type, event) {
        for (let i = 0; i < this.handlers[type].length; i++) {
            this.handlers[type][i](event);
        }
    }
}
function threshold(t, vd) {
    return Math.max(25, Math.floor(0.15 * (t === 'x' ? vd.vw : vd.vh)));
}
const defaults = {
    swipeVelocityThreshold: 0.4,
    passiveMove: true,
};
const passive = { passive: true };

function CloseSlideHandler(el, ctrl) {
    const side = ctrl.side;
    const menuWidth = getMenuWidth();
    const state = {
        backDropElement: null,
        isScrolling: false,
        isClosing: false,
    };
    const gesture = new Gesture(el, viewportDim(), {
        passiveMove: false
    });
    gesture.on('panstart', () => {
        state.backDropElement = ctrl.getBackdropEl();
        state.isScrolling = false;
        state.isClosing = false;
    });
    gesture.on('panmove', (e) => {
        if (state.isScrolling)
            return;
        if (state.isClosing) {
            e.preventDefault();
        }
        else {
            if ((side === 'left' && gesture.touchMoveX < -5) ||
                (side === 'right' && gesture.touchMoveX > 5)) {
                e.preventDefault();
                state.isClosing = true;
            }
            else {
                state.isScrolling = Math.abs(gesture.touchMoveY) > 5;
                if (state.isScrolling)
                    return;
            }
        }
        if (side === 'left') {
            if (gesture.touchMoveX < 0 && gesture.touchMoveX >= -menuWidth) {
                translateMenu(el, gesture.touchMoveX);
                backdropOpacity(state.backDropElement, ((menuWidth + gesture.touchMoveX) / menuWidth * 100) / 100 * BACKDROP_OPACITY);
            }
        }
        else {
            if (gesture.touchMoveX > 0 && gesture.touchMoveX <= menuWidth) {
                translateMenu(el, gesture.touchMoveX);
                backdropOpacity(state.backDropElement, ((menuWidth - gesture.touchMoveX) / menuWidth * 100) / 100 * BACKDROP_OPACITY);
            }
        }
    });
    gesture.on('panend', () => {
        if (state.isScrolling)
            return;
        state.isScrolling = false;
        state.isClosing = false;
        // we don't want to close menu accidentaly when scrolling thus it is important
        // to check X velocity only
        const velocity = gesture.velocityX;
        if (velocity !== 0) {
            if (side === 'left') {
                if (velocity < 0 &&
                    (gesture.touchMoveX < -(menuWidth - menuWidth * OPEN_AFTER_SLIDE_RATIO) || velocity < -0.4)) {
                    ctrl.close();
                }
                else {
                    ctrl.open();
                }
            }
            else {
                if (velocity > 0 &&
                    (gesture.touchMoveX > (menuWidth - menuWidth * OPEN_AFTER_SLIDE_RATIO) || velocity > 0.4)) {
                    ctrl.close();
                }
                else {
                    ctrl.open();
                }
            }
        }
    });
}

var MenuView = {
    onbeforeupdate() {
        return mainMenuCtrl.isOpen;
    },
    view() {
        const user = session.get();
        return (h("aside", { id: "side_menu", oncreate: ({ dom }) => {
                CloseSlideHandler(dom, mainMenuCtrl);
            } },
            renderHeader(user),
            h("div", { className: "native_scroller side_menu_scroller" }, user && profileMenuOpen() ? renderProfileActions(user) : renderLinks(user))));
    }
};
function renderHeader(user) {
    const caretClass = profileMenuOpen() ? 'up' : 'down';
    return (h("header", { className: "side_menu_header", oncreate: ontapXY(toggleHeader) },
        session.isKidMode() ? h("div", { className: "kiddo" }, "\uD83D\uDE0A") : null,
        networkStatus(user),
        hasNetwork() && !user ?
            h("button", { className: "signInButton", oncreate: ontapXY(loginModal.open) }, i18n('signIn')) : null,
        user ?
            h("h2", { className: "username" },
                user.username,
                h("i", { className: 'fa fa-caret-' + caretClass })) : null));
}
function renderProfileActions(user) {
    const gamesRouteParams = {
        username: user.username,
    };
    if (user.title)
        gamesRouteParams.title = user.title;
    if (user.patron)
        gamesRouteParams.patron = '1';
    return (h("ul", { className: "side_links profileActions", oncreate: ontapXY(onLinkTap, undefined, getLI) },
        h("li", { className: "side_link", "data-route": `/@/${user.id}` },
            user.patron ?
                h("span", { className: "patron", "data-icon": "\uE019" }) :
                h("span", { className: "fa fa-circle userStatus online" }),
            i18n('profile')),
        h("li", { className: "side_link", "data-route": `/@/${user.id}/games?${serializeQueryParameters(gamesRouteParams)}` },
            h("span", { className: "menu_icon_game" }),
            i18n('games')),
        h("li", { className: "side_link", "data-route": "/inbox" },
            h("span", { className: "fa fa-envelope" }),
            i18n('inbox') + ((inboxUnreadCount() !== null && inboxUnreadCount() > 0) ? (' (' + inboxUnreadCount() + ')') : '')),
        h("li", { className: "side_link", "data-route": "/account/preferences" },
            h("span", { "data-icon": "%" }),
            i18n('preferences')),
        h("li", { className: "side_link", "data-action": "friends" },
            h("span", { "data-icon": "f" }),
            plural('nbFriendsOnline', friendsApi.count())),
        h("li", { className: "side_link", "data-nocloseaction": "logout" },
            h("span", { "data-icon": "w" }),
            i18n('logOut'))));
}
const actionMap = {
    gamesMenu: () => gamesMenu.open(),
    createGame: () => newGameForm.openRealTime(),
    friends: () => friendsPopup.open(),
    logout: () => {
        session.logout();
        profileMenuOpen(false);
    },
};
function onLinkTap(e) {
    e.stopPropagation();
    const el = getLI(e);
    if (el) {
        const ds = el.dataset;
        if (ds.route) {
            route(ds.route)();
        }
        else if (el && ds.action) {
            action(actionMap[ds.action])();
        }
        else if (el && ds.nocloseaction) {
            actionMap[ds.nocloseaction]();
            redraw();
        }
    }
}
function renderLinks(user) {
    const online = hasNetwork();
    return (h("ul", { className: "side_links", oncreate: ontapXY(onLinkTap, undefined, getLI) },
        h("li", { className: "side_link", "data-route": "/" },
            h("span", { className: "fa fa-home" }),
            i18n('home')),
        online ?
            h("li", { className: "sep_link" }, i18n('playOnline')) : null,
        online && !session.hasCurrentBan() ?
            h("li", { className: "side_link", "data-action": "createGame" },
                h("span", { className: "fa fa-plus-circle" }),
                i18n('createAGame')) : null,
        online ?
            h("li", { className: "side_link", "data-route": "/tournament" },
                h("span", { className: "fa fa-trophy" }),
                i18n('tournaments')) : null,
        h("li", { className: "sep_link" }, i18n('learnMenu')),
        online ?
            h("li", { className: "side_link", "data-route": "/training" },
                h("span", { "data-icon": "-" }),
                i18n('puzzles')) : null,
        !online && user ?
            h("li", { className: "side_link", "data-route": "/training" },
                h("span", { "data-icon": "-" }),
                i18n('puzzles')) : null,
        online ?
            h("li", { className: "side_link", "data-route": "/study" },
                h("span", { "data-icon": "4" }),
                i18n('studyMenu')) : null,
        h("li", { className: "side_link", "data-route": "/coord" },
            h("span", { className: "fa fa-thumb-tack" }),
            i18n('coordinates')),
        online ?
            h("li", { className: "sep_link" }, i18n('watch')) : null,
        online ?
            h("li", { className: "side_link", "data-route": "/tv" },
                h("span", { "data-icon": "1" }),
                i18n('watchGames')) : null,
        online ?
            h("li", { className: "sep_link" }, i18n('community')) : null,
        online ?
            h("li", { className: "side_link", "data-route": "/players" },
                h("span", { className: "fa fa-at" }),
                i18n('players')) : null,
        h("li", { className: "sep_link" }, i18n('tools')),
        h("li", { className: "side_link", "data-route": "/analyse" },
            h("span", { "data-icon": "A" }),
            i18n('analysis')),
        h("li", { className: "side_link", "data-route": "/editor" },
            h("span", { className: "fa fa-pencil" }),
            i18n('boardEditor')),
        h("li", { className: "side_link", "data-route": "/clock" },
            h("span", { className: "fa fa-clock-o" }),
            i18n('clock')),
        online ?
            h("li", { className: "side_link", "data-route": "/importer" },
                h("span", { className: "fa fa-cloud-upload" }),
                i18n('importGame')) : null,
        h("li", { className: "sep_link" }, i18n('playOffline')),
        h("li", { className: "side_link", "data-route": "/ai" },
            h("span", { className: "fa fa-cogs" }),
            i18n('computer')),
        h("li", { className: "side_link", "data-route": "/otb" },
            h("span", { className: "fa fa-beer" }),
            i18n('overTheBoard')),
        h("li", { className: "hr" }),
        h("li", { className: "side_link", "data-route": "/settings" },
            h("span", { className: "fa fa-cog" }),
            i18n('settings'))));
}
function networkStatus(user) {
    const ping$1 = ping();
    const server = mlat();
    const pingHelp = `PING: ${i18n('networkLagBetweenYouAndLichess')}; SERVER: ${i18n('timeToProcessAMoveOnLichessServer')}`;
    const showToast = (e) => {
        e.stopPropagation();
        Toast.show({ text: pingHelp, duration: 'long', position: 'top' });
    };
    return (h("div", { className: "pingServer" },
        signalBars(hasNetwork() ? ping$1 : undefined),
        hasNetwork() ? (h("div", null,
            h("div", null,
                h("span", { className: "pingKey" }, "Ping\u00A0\u00A0\u00A0"),
                h("strong", { className: "pingValue" }, socket.isConnected() && ping$1 ? ping$1 : '?'),
                " ms"),
            user ?
                h("div", null,
                    h("span", { className: "pingKey" }, "Server\u00A0"),
                    h("strong", { className: "pingValue" }, socket.isConnected() && server ? server : '?'),
                    " ms") : null)) : (h("div", null, "Offline")),
        hasNetwork() ?
            h("i", { className: "fa fa-question-circle-o", oncreate: ontapXY(showToast) }) : null));
}
function signalBars(ping) {
    const lagRating = ping === undefined ? 0 :
        (ping < 150) ? 4 :
            (ping < 300) ? 3 :
                (ping < 500) ? 2 : 1;
    const bars = [];
    for (let i = 1; i <= 4; i++)
        bars.push(h(i <= lagRating ? 'i' : 'i.off'));
    return h('signal.q' + lagRating, bars);
}

let isOpen = false;
let setupFen;
var playMachineForm = {
    open,
    close,
    openAIFromPosition(fen) {
        settings.gameSetup.ai.variant('3');
        open();
        setupFen = fen;
    },
    view() {
        function form() {
            return renderForm('ai', settings.gameSetup.ai, settings.gameSetup.ai.availableVariants, settings.gameSetup.ai.availableTimeModes);
        }
        return popup('game_form_popup', undefined, form, isOpen, close);
    }
};
function open() {
    router.backbutton.stack.push(close);
    setupFen = undefined;
    isOpen = true;
}
function close(fromBB) {
    if (fromBB !== 'backbutton' && isOpen)
        router.backbutton.stack.pop();
    isOpen = false;
}
function startAIGame() {
    return newAiGame(setupFen)
        .then((data) => {
        router.set('/game' + data.url.round);
    })
        .catch(handleXhrError);
}
const colors = [
    ['randomColor', 'random'],
    ['white', 'white'],
    ['black', 'black']
];
function renderForm(formName, settingsObj, variants, timeModes) {
    const timeMode = settingsObj.timeMode();
    const hasClock = timeMode === '1';
    const generalFieldset = [
        h('div.select_input', [
            formWidgets.renderSelect('side', formName + 'color', colors, settingsObj.color)
        ]),
        h('div.select_input', [
            formWidgets.renderSelect('variant', formName + 'variant', variants, settingsObj.variant)
        ]),
        settingsObj.variant() === '3' ?
            h('div.setupPosition', [
                h('div.setupPositionInput', [
                    h('input[type=text][name=fen]', {
                        placeholder: i18n('pasteTheFenStringHere'),
                        oninput: (e) => {
                            const rawfen = e.target.value;
                            if (rawfen === '') {
                                setupFen = undefined;
                            }
                            else {
                                setupFen = parseFen(rawfen).unwrap(s => makeFen(s), () => false);
                            }
                            redraw();
                        }
                    }),
                    h('button.withIcon', {
                        oncreate: ontap(() => {
                            close();
                            router.set('/editor');
                        })
                    }, h('span.fa.fa-pencil')),
                ]),
                setupFen === false ?
                    h('div.setupFenError', 'Invalid FEN') : null,
                setupFen !== undefined && setupFen !== false ? [
                    h('div', {
                        style: {
                            width: '100px',
                            height: '100px'
                        },
                        oncreate: ontap(() => {
                            close();
                            if (setupFen)
                                router.set(`/editor/${encodeURIComponent(setupFen)}`);
                        })
                    }, [
                        h(ViewOnlyBoard, { fen: setupFen, orientation: 'white' })
                    ])
                ] : null
            ]) : null,
        h('div.select_input', [
            formWidgets.renderSelect('level', 'ailevel', [
                '1', '2', '3', '4', '5', '6', '7', '8'
            ].map(tupleOf), settingsObj.level)
        ])
    ];
    const timeFieldset = [
        h('div.select_input', [
            formWidgets.renderSelect('clock', formName + 'timeMode', timeModes, settingsObj.timeMode)
        ])
    ];
    if (hasClock) {
        timeFieldset.push(h('div.select_input.inline', [
            formWidgets.renderSelect('time', formName + 'time', settings.gameSetup.availableTimes, settingsObj.time, false)
        ]), h('div.select_input.inline', [
            formWidgets.renderSelect('increment', formName + 'increment', settings.gameSetup.availableIncrements.map(tupleOf), settingsObj.increment, false)
        ]));
    }
    return h('form.game_form', {
        onsubmit: function (e) {
            e.preventDefault();
            if (!settings.gameSetup.isTimeValid(settingsObj))
                return;
            close();
            startAIGame();
        }
    }, [
        h('fieldset', generalFieldset),
        h('fieldset', timeFieldset),
        h('div.popupActionWrapper', [
            h('button.defaultButton[type=submit]', i18n('playWithTheMachine'))
        ])
    ]);
}

function EdgeOpenHandler(ctrl) {
    const side = ctrl.side;
    const menuWidth = getMenuWidth();
    const state = {
        menuElement: null,
        backDropElement: null,
        canSlide: false
    };
    return {
        panstart: (gesture) => (e) => {
            const target = e.target;
            if (target.nodeName === 'PIECE' ||
                target.nodeName === 'SQUARE' ||
                // svg element className is not a string
                (target.className.startsWith && target.className.startsWith('cg-board manipulable')) ||
                !inEdgeArea(gesture.touchStartX, side, viewportDim().vw)) {
                state.canSlide = false;
            }
            else {
                state.menuElement = ctrl.getMenuEl();
                state.backDropElement = ctrl.getBackdropEl();
                if (state.menuElement && state.backDropElement) {
                    state.menuElement.style.visibility = 'visible';
                    state.backDropElement.style.visibility = 'visible';
                    state.canSlide = true;
                    redraw();
                }
            }
        },
        panmove: (gesture) => () => {
            if (state.canSlide) {
                const delta = gesture.touchMoveX;
                if (side === 'left') {
                    if (delta <= menuWidth) {
                        translateMenu(state.menuElement, -menuWidth + delta);
                        backdropOpacity(state.backDropElement, (delta / menuWidth * 100) / 100 * BACKDROP_OPACITY);
                    }
                }
                else {
                    if (delta >= -menuWidth) {
                        translateMenu(state.menuElement, menuWidth + delta);
                        backdropOpacity(state.backDropElement, (-delta / menuWidth * 100) / 100 * BACKDROP_OPACITY);
                    }
                }
            }
        },
        panend: (gesture) => () => {
            const velocity = gesture.velocityX;
            if (state.canSlide && velocity !== 0) {
                state.canSlide = false;
                const delta = gesture.touchMoveX;
                if (side === 'left') {
                    if (velocity > 0 &&
                        (delta >= menuWidth * OPEN_AFTER_SLIDE_RATIO || velocity > 0.2)) {
                        ctrl.open();
                    }
                    else {
                        ctrl.close();
                    }
                }
                else {
                    if (velocity < 0 &&
                        (delta <= -(menuWidth * OPEN_AFTER_SLIDE_RATIO) || velocity < -0.2)) {
                        ctrl.open();
                    }
                    else {
                        ctrl.close();
                    }
                }
            }
        }
    };
}
function inEdgeArea(inputPos, side, vw) {
    return side === 'left' ?
        inputPos < EDGE_SLIDE_THRESHOLD :
        inputPos > vw - EDGE_SLIDE_THRESHOLD;
}

const expanded = prop(false);
function renderAnnouncement(announcement) {
    if (!announcement) {
        return null;
    }
    return h('div.announce', {
        className: expanded() ? 'expanded' : '',
    }, [
        h('span.text', {
            oncreate: ontap(() => {
                expanded(!expanded());
                redraw();
            })
        }, announcement.msg),
        h('small', distanceToNowStrict(new Date(announcement.date), true)),
        h('button.dismiss', {
            oncreate: ontap(announce.dismiss)
        }, closeIcon)
    ]);
}

var MainBoard = {
    oninit() {
        this.boundHandlers = false;
    },
    oncreate({ dom }) {
        this.gesture = new Gesture(dom, viewportDim());
        const defaultHandlers = EdgeOpenHandler(mainMenuCtrl);
        for (const eventName in defaultHandlers) {
            this.gesture.on(eventName, defaultHandlers[eventName](this.gesture));
        }
    },
    onupdate({ attrs }) {
        if (!this.boundHandlers && attrs.handlers) {
            this.boundHandlers = true;
            for (const eventName in attrs.handlers) {
                this.gesture.on(eventName, attrs.handlers[eventName](this.gesture));
            }
        }
    },
    view({ attrs, children }) {
        const { header, color } = attrs;
        const classes = {
            righty: settings.game.landscapeBoardSide() === 'right'
        };
        if (attrs.klass) {
            classes[attrs.klass] = true;
        }
        return h('main#page', {
            className: color,
        }, [
            h('header.main_header.board', header),
            renderAnnouncement(announce.get()),
            h('div.content_round', {
                className: classSet(classes),
            }, children),
            h('div#menu-close-overlay.menu-backdrop', { oncreate: backdropCloseHandler })
        ]);
    }
};

var layout = {
    board(header, content, key, overlay, handlers, color, klass) {
        const background = settings.general.theme.background();
        const opts = key ? {
            key,
            ...containerOpts(background)
        } : containerOpts(background);
        return h('div.view-container', opts, [
            h(MainBoard, { header, color, handlers, klass }, content),
            h(MenuView),
            gamesMenu.view(),
            loginModal.view(),
            signupModal.view(),
            newGameForm.view(),
            playMachineForm.view(),
            challengeForm.view(),
            friendsPopup.view(),
            lobby.view(),
            overlay
        ]);
    },
    free(header, content, footer, overlay, scrollListener) {
        const background = settings.general.theme.background();
        return h('div.view-container', containerOpts(background), [
            h('main#page', { oncreate: handleMenuOpen }, [
                h('header.main_header', header),
                renderAnnouncement(announce.get()),
                h('div#free_content.content.native_scroller', {
                    className: footer ? 'withFooter' : '',
                    oncreate: ({ dom }) => {
                        if (scrollListener) {
                            dom.addEventListener('scroll', scrollListener);
                        }
                    }
                }, content),
                footer ? h('footer.main_footer', footer) : null,
                h('div#menu-close-overlay.menu-backdrop', { oncreate: backdropCloseHandler })
            ]),
            h(MenuView),
            gamesMenu.view(),
            loginModal.view(),
            signupModal.view(),
            newGameForm.view(),
            playMachineForm.view(),
            challengeForm.view(),
            friendsPopup.view(),
            lobby.view(),
            overlay
        ]);
    },
    clock(content, overlay) {
        const background = settings.general.theme.background();
        return h('div.view-container', containerOpts(background), [
            h('main#page', [
                h('div.content.fullScreen', content())
            ]),
            overlay ? overlay() : null
        ]);
    }
};
function handleMenuOpen({ dom }) {
    const mainEl = dom;
    const gesture = new Gesture(mainEl, viewportDim(), {
        passiveMove: true
    });
    const defaultHandlers = EdgeOpenHandler(mainMenuCtrl);
    for (const eventName in defaultHandlers) {
        gesture.on(eventName, defaultHandlers[eventName](gesture));
    }
}
function bgClass(key) {
    return key === 'dark' || key === 'light' ? key :
        key === 'system' ? getSystemTheme() :
            'transp ' + key;
}
function containerOpts(bgTheme) {
    return {
        className: bgClass(bgTheme)
    };
}

export { CloseSlideHandler as C, EdgeOpenHandler as E, Gesture as G, layout as l, playMachineForm as p };
//# sourceMappingURL=layout-DoxuEk9x.js.map
