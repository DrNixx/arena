import { r as redraw, K as handleXhrError, a_ as loadLocalJsonFile, g as settings, F as viewFadeIn, b as session, a0 as header, o as i18n, s as socket, H as safeStringToNum } from './main.js';
import { l as layout } from './layout-DoxuEk9x.js';
import { a as renderTournamentsList, b as renderFooter, n as newTournamentForm } from './tournamentsListView-Csa0M4-v.js';
import { a as currentTournaments } from './tournamentXhr-kOGDWEN6.js';
import './TabView-CG79fzxt.js';

class TournamentsListCtrl {
    constructor(defaultTab) {
        this.onTabChange = (tabIndex) => {
            const loc = window.location.search.replace(/\?tab=\w+$/, '');
            try {
                window.history.replaceState(window.history.state, '', loc + '?tab=' + tabIndex);
            }
            catch (e) {
                console.error(e);
            }
            this.currentTab = tabIndex;
            redraw();
        };
        this.currentTab = defaultTab || 0;
        currentTournaments()
            .then(data => {
            data.started = data.started.filter(supported);
            data.created = data.created.filter(supported);
            data.finished = data.finished.filter(supported);
            data.started.sort(sortByLichessAndDate);
            data.finished.sort(sortByEndDate);
            this.tournaments = data;
            redraw();
        })
            .catch(handleXhrError);
        loadLocalJsonFile('data/positions.json')
            .then(data => {
            this.startPositions = data;
            redraw();
        });
    }
}
function supported(t) {
    return settings.game.supportedVariants.indexOf(t.variant.key) !== -1;
}
function sortByLichessAndDate(a, b) {
    if (a.createdBy === 'lichess' && b.createdBy === 'lichess') {
        return a.startsAt - b.startsAt;
    }
    else if (a.createdBy === 'lichess') {
        return -1;
    }
    else {
        return 1;
    }
}
function sortByEndDate(a, b) {
    return b.finishesAt - a.finishesAt;
}

var tournamentList = {
    oncreate: viewFadeIn,
    oninit({ attrs }) {
        socket.createDefault();
        this.ctrl = new TournamentsListCtrl(safeStringToNum(attrs.tab));
    },
    view() {
        const ctrl = this.ctrl;
        const body = renderTournamentsList(ctrl);
        const footer = session.isConnected() ? renderFooter() : undefined;
        const overlay = newTournamentForm.view(ctrl);
        return layout.free(header(i18n('tournaments')), body, footer, overlay);
    }
};

export { tournamentList as default };
//# sourceMappingURL=tournamentList-BnDIVu8z.js.map
