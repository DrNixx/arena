const AutoQueen = {
    NEVER: 1,
    PREMOVE: 2,
    ALWAYS: 3
};
const AutoQueenChoices = [
    makeOption(AutoQueen.NEVER, 'never'),
    makeOption(AutoQueen.ALWAYS, 'always'),
    makeOption(AutoQueen.PREMOVE, 'whenPremoving')
];
const SubmitMove = {
    NEVER: 0,
    CORRESPONDENCE_ONLY: 4,
    CORRESPONDENCE_UNLIMITED: 1,
    ALWAYS: 2
};
const SubmitMoveChoices = [
    makeOption(SubmitMove.NEVER, 'never'),
    makeOption(SubmitMove.CORRESPONDENCE_ONLY, 'inCorrespondenceGames'),
    makeOption(SubmitMove.CORRESPONDENCE_UNLIMITED, 'correspondenceAndUnlimited'),
    makeOption(SubmitMove.ALWAYS, 'always')
];
const AutoThreefold = {
    NEVER: 1,
    TIME: 2,
    ALWAYS: 3
};
const AutoThreefoldChoices = [
    makeOption(AutoThreefold.NEVER, 'never'),
    makeOption(AutoThreefold.ALWAYS, 'always'),
    makeOption(AutoThreefold.TIME, 'whenTimeRemainingLessThanThirtySeconds')
];
const Takeback = {
    NEVER: 1,
    CASUAL: 2,
    ALWAYS: 3
};
const TakebackChoices = [
    makeOption(Takeback.NEVER, 'never'),
    makeOption(Takeback.ALWAYS, 'always'),
    makeOption(Takeback.CASUAL, 'inCasualGamesOnly')
];
const Animation = {
    NONE: 0,
    FAST: 1,
    NORMAL: 2,
    SLOW: 3
};
const AnimationChoices = [
    makeOption(Animation.NONE, 'none'),
    makeOption(Animation.FAST, 'fast'),
    makeOption(Animation.NORMAL, 'normal'),
    makeOption(Animation.SLOW, 'slow')
];
const ClockTenths = {
    NEVER: 0,
    LOWTIME: 1,
    ALWAYS: 2
};
const ClockTenthsChoices = [
    makeOption(ClockTenths.NEVER, 'never'),
    makeOption(ClockTenths.LOWTIME, 'whenTimeRemainingLessThanTenSeconds'),
    makeOption(ClockTenths.ALWAYS, 'always')
];
const MoreTime = {
    NEVER: 1,
    CASUAL: 2,
    ALWAYS: 3,
};
const MoreTimeChoices = [
    makeOption(MoreTime.NEVER, 'never'),
    makeOption(MoreTime.ALWAYS, 'always'),
    makeOption(MoreTime.CASUAL, 'inCasualGamesOnly'),
];
const Challenge = {
    NEVER: 1,
    RATING: 2,
    FRIEND: 3,
    ALWAYS: 4
};
const ChallengeChoices = [
    makeOption(Challenge.NEVER, 'never'),
    makeOption(Challenge.RATING, 'ifRatingIsPlusMinusX', '500'),
    makeOption(Challenge.FRIEND, 'onlyFriends'),
    makeOption(Challenge.ALWAYS, 'always')
];
function makeOption(value, label, labelArg) {
    return {
        value,
        label,
        labelArg,
    };
}

export { AnimationChoices as A, Challenge as C, MoreTime as M, SubmitMove as S, Takeback as T, Animation as a, ChallengeChoices as b, ClockTenths as c, ClockTenthsChoices as d, MoreTimeChoices as e, AutoThreefold as f, AutoQueen as g, TakebackChoices as h, AutoQueenChoices as i, AutoThreefoldChoices as j, SubmitMoveChoices as k };
//# sourceMappingURL=prefs-CFmBYsqy.js.map
